#include "FileMGCMD.h"


void InitFileMngPanel(HWND hDlg)
{
	LVCOLUMN lv;
	char *szText[]={"�ļ���", "��С", "����", "�޸�����"};

	lv.mask = LVCF_TEXT|LVCF_WIDTH;
	lv.fmt = LVCFMT_RIGHT;
	lv.cx = 170;
	lv.pszText = szText[0];
	SendDlgItemMessage(hDlg,IDC_FILELIST,LVM_INSERTCOLUMN,(WPARAM)0,(LPARAM)&lv);
	lv.cx = 80;
	lv.pszText = szText[1];
	SendDlgItemMessage(hDlg,IDC_FILELIST,LVM_INSERTCOLUMN,(WPARAM)1,(LPARAM)&lv);
	lv.cx = 80;
	lv.pszText = szText[2];
	SendDlgItemMessage(hDlg,IDC_FILELIST,LVM_INSERTCOLUMN,(WPARAM)2,(LPARAM)&lv);
	lv.cx = 110;
	lv.pszText = szText[3];
	SendDlgItemMessage(hDlg,IDC_FILELIST,LVM_INSERTCOLUMN,(WPARAM)3,(LPARAM)&lv);

	SendDlgItemMessage(hDlg,IDC_FILELIST, LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT | LVS_EX_HEADERDRAGDROP);

}

int IsFileInList(HWND hCtrl, char *lpFileName)
{
	LVFINDINFO lvfi;
	lvfi.flags = LVFI_STRING;
	lvfi.psz = lpFileName;

	return SendMessage(hCtrl, LVM_FINDITEM , 0,  (LPARAM)&lvfi);
}

void AddFileToList(HWND hCtrl, LP_MG_FILE_INFO pFI)
{
	int ret;
	char szBuf[MAX_PATH];
	SYSTEMTIME stUTC, stLocal;
	SHFILEINFO FileInfo;
	UINT uFlags;
	uFlags = SHGFI_TYPENAME|SHGFI_USEFILEATTRIBUTES|SHGFI_SYSICONINDEX|SHGFI_SMALLICON;

	char *PostFix = strrchr(pFI->szFileName, '.');
	SHGetFileInfo(PostFix?PostFix:"", pFI->dwFileAttributes, &FileInfo, sizeof(SHFILEINFO), uFlags);
	LVITEM	Lv = {0};

	//�ļ���
	Lv.mask			= LVIF_TEXT|LVIF_IMAGE;
	Lv.iItem		= 0;
	Lv.iSubItem		= 0;
	Lv.pszText		= pFI->szFileName;

	Lv.iImage       = FileInfo.iIcon;
	ret = SendMessage(hCtrl, LVM_INSERTITEM , 0,  (LPARAM)&Lv);

	//��С
	Lv.iItem		= ret;
	Lv.mask			= LVIF_TEXT;
	Lv.iSubItem		= 1;

	if (pFI->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
		Lv.pszText		= "";
	else
		Lv.pszText		= FormatSize(pFI->nFileSize, szBuf);
	ret = SendMessage(hCtrl, LVM_SETITEM , 0,  (LPARAM)&Lv);

	//����
	Lv.mask			= LVIF_TEXT;
	Lv.iSubItem		= 2;
	Lv.pszText		= FileInfo.szTypeName;
	ret = SendMessage(hCtrl, LVM_SETITEM , 0, (LPARAM)&Lv);

	//����
	FileTimeToSystemTime(&pFI->ftLastWriteTime, &stUTC);
	SystemTimeToTzSpecificLocalTime(NULL, &stUTC, &stLocal);
	ret = sprintf(szBuf, "%02u-%02u-%02u %02u:%02u", 
		stLocal.wYear, stLocal.wMonth, stLocal.wDay, stLocal.wHour, stLocal.wMinute);

	Lv.mask			= LVIF_TEXT;
	Lv.iSubItem		= 3;
	Lv.pszText		= szBuf;
	ret = SendMessage(hCtrl, LVM_SETITEM , 0, (LPARAM)&Lv);

	DestroyIcon(FileInfo.hIcon);
}

BOOL GetSelectedFiles(HWND hDlg, char *lpFileName, int &nextFileIdx)
{
	int idx;
	char pszText[MAX_PATH] = {0};
	char DirPath[MAX_PATH] = {0};
	LVITEM lv;

	HWND hFileList = GetDlgItem(hDlg, IDC_FILELIST);

	idx = SendMessage(hFileList, LVM_GETNEXTITEM, nextFileIdx, LVNI_SELECTED);
	if(idx == -1)
		return FALSE;
	nextFileIdx = idx;
	memset(&lv, 0, sizeof(LVITEM));
	memset(pszText, 0, sizeof(pszText));
	lv.iSubItem		= 0;
	lv.cchTextMax	= MAX_PATH;
	lv.pszText		= pszText;

	if(SendMessage(hFileList, LVM_GETITEMTEXT, idx, LPARAM(&lv)) <= 0)
		return FALSE;

	if(!GetDlgItemText(hDlg, IDC_DIRPATH, DirPath, MAX_PATH))
		return FALSE;

	sprintf(TempBuf, "%s\\%s", DirPath, pszText);
	FormatPathString(TempBuf, lpFileName, MAX_PATH, true);
	return idx+1;
}

BOOL GetFileNameByIdx(HWND hDlg, int idx, char *lpFileName)
{
	char pszText[MAX_PATH];
	LVITEM lv;

	HWND hFileList = GetDlgItem(hDlg, IDC_FILELIST);

	memset(&lv, 0, sizeof(LVITEM));
	memset(pszText, 0, sizeof(pszText));
	lv.iSubItem		= 0;
	lv.cchTextMax	= MAX_PATH;
	lv.pszText		= pszText;

	if(SendMessage(hFileList, LVM_GETITEMTEXT, idx, LPARAM(&lv)) <= 0)
		return FALSE;

	FormatPathString(pszText, lpFileName, MAX_PATH, true);
	
	return TRUE;
}

int GetAllDrivers(HWND hCtrl, CFileManager *pFileMng)
{
	std::vector<MG_FILE_INFO> Files;
	MSG msg;
	msg.hwnd = GetDlgItem(GetParent(hCtrl), IDC_ERRMSG);
	pFileMng->SetOutPutFunc(&msg, GetProgress);
	int nCount = pFileMng->__GetRemoteFileList("", Files);

	for(int i=0; i<nCount; i++)
	{
		SendMessage(hCtrl, CB_INSERTSTRING, -1, LPARAM(Files[i].szFileName));
	}
	if(nCount)
		GetProgress(msg.hwnd, WM_FILELIST, (WPARAM)"ö��Զ�̼���������б��ɹ�. ��������Զ��·���������˵���.", 0);
	else
		GetProgress(msg.hwnd, WM_FILELIST, (WPARAM)"ö��Զ�̼���������б�ʧ��. ", 0);
	return nCount;
}

int GetFileList(HWND hDlg, CFileManager *pFileMng)
{
	CZXCount zc(pFileMng->cl);

	std::vector<MG_FILE_INFO> Files;
	char DirPath[MAX_PATH];

	if(!GetDlgItemText(hDlg, IDC_DIRPATH, DirPath, MAX_PATH))
		return -1;

	sndPlaySound(lpMemSound_OPENFILE, SND_MEMORY|SND_ASYNC);

	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), FALSE);
	EnableWindow(GetDlgItem(hDlg, IDC_DIRPATH), FALSE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), FALSE);

	MSG msg;
	msg.hwnd = GetDlgItem(hDlg, IDC_ERRMSG);
	pFileMng->SetOutPutFunc(&msg, GetProgress);
	GetProgress(GetDlgItem(hDlg, IDC_ERRMSG), WM_FILELIST, (WPARAM)"��ȡ�ļ���Ϣ...", (LPARAM)pFileMng);

	int nCount = pFileMng->__GetRemoteFileList(DirPath, Files);

	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), TRUE);
	EnableWindow(GetDlgItem(hDlg, IDC_DIRPATH), TRUE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), TRUE);

	if(nCount == -1)
		return -1;

	sprintf(TempBuf, "%s\\", DirPath);
	FormatPathString(TempBuf, DirPath, MAX_PATH, true);
	pFileMng->SetRemotePath(DirPath);

	SendMessage(GetDlgItem(hDlg, IDC_FILELIST), LVM_DELETEALLITEMS, 0, 0);
	
	int nCount_Folder = 0, nCount_File = 0;
	nCount = Files.size();
	
	for(int i=0; i<nCount; i++)
	{
		AddFileToList(GetDlgItem(hDlg, IDC_FILELIST), &Files[i]);
		if(Files[i].dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			nCount_Folder++;
		else
			nCount_File++;
	}

	sprintf(TempBuf, "%d���ļ���%d���ļ���", nCount_File, nCount_Folder);
	SetDlgItemText(hDlg, IDC_ERRMSG, TempBuf);
	return nCount;
}

int DeletePath(HWND hDlg, CFileManager *pFileMng)
{
	int ret;
	char szFileName[MAX_PATH];

	if(!(ret = SendMessage(GetDlgItem(hDlg, IDC_FILELIST), LVM_GETSELECTEDCOUNT , 0, 0)))
	{
		err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, ERROR_PROC_NOT_FOUND);
		return 0;
	}
	if(MessageBox(hDlg, MB_YESNO, "��������", "ȷ��Ҫɾ��ѡ���� %d ���ļ�?", ret) != IDYES)
		return 0;
	MSG msg;
	msg.hwnd = GetDlgItem(hDlg, IDC_ERRMSG);
	pFileMng->SetOutPutFunc(&msg, GetProgress);
	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), FALSE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), FALSE);

	int nextFileIdx = -1;
	while(GetSelectedFiles(hDlg, szFileName, nextFileIdx))
	{
		pFileMng->__DeleteFile(szFileName);
		if(pFileMng->GetError() == 0)
		{
			SendMessage(GetDlgItem(hDlg, IDC_FILELIST), LVM_DELETEITEM, nextFileIdx, 0);
			nextFileIdx--;
		}
		err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, pFileMng->GetError());
	}
	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), TRUE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), TRUE);

	return pFileMng->GetError() == 0;
}

int MoveFile(HWND hDlg, CFileManager *pFileMng)
{
	char szFileName[MAX_PATH];
	char sznewFileName[MAX_PATH];
	int ret;
	if(SendMessage(GetDlgItem(hDlg, IDC_FILELIST), LVM_GETSELECTEDCOUNT, 0, 0) == 0)
	{
		err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, ERROR_PROC_NOT_FOUND);
		return 0;
	}
	sprintf(sznewFileName, "�����µ�·��");
	ret = DialogBoxParam(Main.hInst, (LPCTSTR)IDD_GETSTRING, hDlg, (DLGPROC)GetStringProc, (LPARAM)sznewFileName);
	if(!ret || !sznewFileName[0])
	{
		err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, ERROR_CANCELLED);
		return 0;
	}
	FormatPathString(sznewFileName, sznewFileName, MAX_PATH, false);
	MSG msg;
	msg.hwnd = GetDlgItem(hDlg, IDC_ERRMSG);
	pFileMng->SetOutPutFunc(&msg, GetProgress);
	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), FALSE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), FALSE);

	int nextFileIdx = -1;
	while(GetSelectedFiles(hDlg, szFileName, nextFileIdx))
	{
		pFileMng->__MoveFile(szFileName, sznewFileName);
		if(pFileMng->GetError() == 0)
		{
			SendMessage(GetDlgItem(hDlg, IDC_FILELIST), LVM_DELETEITEM, nextFileIdx, 0);
			nextFileIdx--;
		}
		err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, pFileMng->GetError());
	}
	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), TRUE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), TRUE);
	return 1;
}

int ExecuteFile(HWND hDlg, CFileManager *pFileMng)
{
	char szFileName[MAX_PATH];
	char szParam[MAX_PATH];
	int ret;
	if(SendMessage(GetDlgItem(hDlg, IDC_FILELIST), LVM_GETSELECTEDCOUNT , 0, 0) == 0)
	{
		err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, ERROR_PROC_NOT_FOUND);
		return 0;
	}
	sprintf(szParam, "�������в�����������Ҫ�����ղ�ȷ��");
	ret = DialogBoxParam(Main.hInst, (LPCTSTR)IDD_GETSTRING, hDlg, (DLGPROC)GetStringProc, (LPARAM)szParam);
	if(!ret)
	{
		err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, ERROR_CANCELLED);
		return 0;
	}
	MSG msg;
	msg.hwnd = GetDlgItem(hDlg, IDC_ERRMSG);
	pFileMng->SetOutPutFunc(&msg, GetProgress);
	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), FALSE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), FALSE);

	int nextFileIdx = -1;
	while(GetSelectedFiles(hDlg, szFileName, nextFileIdx))
	{
		sprintf(szFileName, "%s %s", szFileName, szParam);

		pFileMng->__ExecuteFile(szFileName);
		err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, pFileMng->GetError());
	}
	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), TRUE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), TRUE);
	return 1;
}

int SetPlugPath_VNC(HWND hDlg, CFileManager *pFileMng)
{
	char szFileName[MAX_PATH] = {0};
	char szBuf[MAX_PATH] = {0};

	if(SendMessage(GetDlgItem(hDlg, IDC_FILELIST), LVM_GETSELECTEDCOUNT , 0, 0) == 0)
	{
		err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, ERROR_PROC_NOT_FOUND);
		return 0;
	}
	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), FALSE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), FALSE);

	int nextFileIdx = -1;
	while(GetSelectedFiles(hDlg, szFileName, nextFileIdx))
	{
		if(pFileMng->__SetPlugPath_VNC(szFileName, szBuf) == -1)
			err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, pFileMng->GetError());
		else
		{
			sprintf(szBuf, "�ѽ� %s ����ΪVNC�Ĳ��·��.", szFileName);
			SetDlgItemText(hDlg, IDC_ERRMSG, szBuf);
		}
	}
	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), TRUE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), TRUE);

	return 1;
}

int GetMd5string(HWND hDlg, CFileManager *pFileMng)
{
	char szFileName[MAX_PATH] = {0};
	char szBuf[MAX_PATH] = {0};

	if(SendMessage(GetDlgItem(hDlg, IDC_FILELIST), LVM_GETSELECTEDCOUNT , 0, 0) == 0)
	{
		err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, ERROR_PROC_NOT_FOUND);
		return 0;
	}

	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), FALSE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), FALSE);
	EnableWindow(GetDlgItem(hDlg, IDC_ABORT), TRUE);
	ShowWindow(GetDlgItem(hDlg, IDC_ABORT), SW_SHOW);

	int nextFileIdx = -1;
	while(GetSelectedFiles(hDlg, szFileName, nextFileIdx))
	{
		if(pFileMng->__Md5File(szFileName, szBuf) == -1)
			err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, pFileMng->GetError());
		else
		{
			PathStripPath(szFileName);
			sprintf(szFileName, "%s: %s", szFileName, szBuf);
			SetDlgItemText(hDlg, IDC_ERRMSG, szFileName);
		}
	}
	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), TRUE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), TRUE);
	ShowWindow(GetDlgItem(hDlg, IDC_ABORT), SW_HIDE);

	return 1;
}

int RenameFile(HWND hDlg, CFileManager *pFileMng)
{
	char szFileName[MAX_PATH];
	char sznewFileName[MAX_PATH], szCurrPath[MAX_PATH], szFullPath[MAX_PATH];
	int ret;
	ret = SendMessage(GetDlgItem(hDlg, IDC_FILELIST), LVM_GETSELECTEDCOUNT , 0, 0);
	if(ret != 1)
	{
		err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, ERROR_NOT_SUPPORTED);
		return 0;
	}
	HWND hEdit = ListView_GetEditControl(GetDlgItem(hDlg, IDC_FILELIST));
	ret = GetWindowText(hEdit, sznewFileName, sizeof(sznewFileName));

//	sprintf(sznewFileName, "�����µ��ļ���");
//	ret = DialogBoxParam(Main.hInst, (LPCTSTR)IDD_GETSTRING, hDlg, (DLGPROC)GetStringProc, (LPARAM)sznewFileName);
	if(!ret || !sznewFileName[0])
	{
		err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, ERROR_CANCELLED);
		return 0;
	}

	MSG msg;
	msg.hwnd = GetDlgItem(hDlg, IDC_ERRMSG);
	pFileMng->SetOutPutFunc(&msg, GetProgress);
	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), FALSE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), FALSE);

	int nextFileIdx = -1;
	if(GetSelectedFiles(hDlg, szFileName, nextFileIdx))
	{

		if(GetDlgItemText(hDlg, IDC_DIRPATH, szCurrPath, MAX_PATH))
			sprintf(TempBuf, "%s\\%s", szCurrPath, sznewFileName);
		else
			goto exit;
		FormatPathString(TempBuf, szFullPath, MAX_PATH, true);

		if(!stricmp(szFileName, szFullPath))
		{
			goto exit;
		}

		pFileMng->__RenameFile(szFileName, szFullPath);
		if(pFileMng->GetError() == 0)
		{
			LVITEM	Lv = {0};
			Lv.mask			= LVIF_TEXT;
			Lv.iItem		= nextFileIdx;
			Lv.iSubItem		= 0;
			Lv.pszText		= sznewFileName;
			SendMessage(GetDlgItem(hDlg, IDC_FILELIST), LVM_SETITEM , 0, (LPARAM)&Lv);
			err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, 0);
		}else
			err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, pFileMng->GetError());
			//SetWindowText(GetDlgItem(hDlg, IDC_ERRMSG), "����ʧ��.");

	}

exit:
	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), TRUE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), TRUE);

	return 1;
}

int NewFolder(HWND hDlg, CFileManager *pFileMng)
{
	int ret;
	char sznewFileName[MAX_PATH];
	MG_FILE_INFO FI;
	if(!GetDlgItemText(hDlg, IDC_DIRPATH, sznewFileName, MAX_PATH))
	{
		err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, ERROR_PROC_NOT_FOUND);
		return 0;
	}
	sprintf(sznewFileName, "����Ŀ¼��");
	ret = DialogBoxParam(Main.hInst, (LPCTSTR)IDD_GETSTRING, hDlg, (DLGPROC)GetStringProc, (LPARAM)sznewFileName);
	if(!ret || !sznewFileName[0])
	{
		err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, ERROR_CANCELLED);
		return 0;
	}
	MSG msg;
	msg.hwnd = GetDlgItem(hDlg, IDC_ERRMSG);
	pFileMng->SetOutPutFunc(&msg, GetProgress);
	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), FALSE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), FALSE);

	pFileMng->__NewFolder(sznewFileName);
	if(pFileMng->GetError() == 0)
	{
		memset(&FI, 0, sizeof(FI));
		FI.dwFileAttributes |= FILE_ATTRIBUTE_DIRECTORY;
		sprintf(FI.szFileName, "%s", sznewFileName);
		AddFileToList(GetDlgItem(hDlg, IDC_FILELIST), &FI);
	}
	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), TRUE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), TRUE);

	err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, pFileMng->GetError());
	return 1;
}

int RemoteSearchFile(HWND hDlg, CFileManager *pFileMng)
{
	int ret;
	char szFileName[MAX_PATH];
	MG_FILE_INFO FI;
	if(!GetDlgItemText(hDlg, IDC_DIRPATH, szFileName, MAX_PATH))
	{
		err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, ERROR_PROC_NOT_FOUND);
		return 0;
	}
	sprintf(szFileName, "����Ҫ�������ļ���(֧��ͨ���,��: *.jpg;*;gif)");
	ret = DialogBoxParam(Main.hInst, (LPCTSTR)IDD_GETSTRING, hDlg, (DLGPROC)GetStringProc, (LPARAM)szFileName);
	if(!ret || !szFileName[0])
	{
		err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, ERROR_CANCELLED);
		return 0;
	}
	MSG msg;
	msg.hwnd = GetDlgItem(hDlg, IDC_ERRMSG);
	pFileMng->SetOutPutFunc(&msg, GetProgress);
	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), FALSE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), FALSE);
	EnableWindow(GetDlgItem(hDlg, IDC_ABORT), TRUE);
	ShowWindow(GetDlgItem(hDlg, IDC_ABORT), SW_SHOW);

	std::vector<MG_FILE_INFO> Files;

	int nCount = pFileMng->__SearchFile(szFileName, Files);

	SendMessage(GetDlgItem(hDlg, IDC_FILELIST), LVM_DELETEALLITEMS, 0, 0);

	int nCount_Folder = 0, nCount_File = 0;
	nCount = Files.size();

	for(int i=0; i<nCount; i++)
	{
		AddFileToList(GetDlgItem(hDlg, IDC_FILELIST), &Files[i]);
		if(Files[i].dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			nCount_Folder++;
		else
			nCount_File++;
	}
	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), TRUE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), TRUE);
	ShowWindow(GetDlgItem(hDlg, IDC_ABORT), SW_HIDE);

	sprintf(TempBuf, "����������%d���ļ���%d���ļ���", nCount_File, nCount_Folder);
	SetDlgItemText(hDlg, IDC_ERRMSG, TempBuf);
	return 1;
}



DWORD CALLBACK GetProgress(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	char szBuf[MAX_PATH];
	LP_MG_PROGRESS pmg_prg;
	switch(uMsg)
	{

	case WM_TRANSFER:
		pmg_prg = (LP_MG_PROGRESS)lParam;
		pmg_prg->used_time = GetTickCount() - pmg_prg->start_time + 1;
		sprintf(TempBuf, "%d/%d���ļ�,%d/%d���ļ���,�ܹ�%s (%.2d%%), %d kb/s, ��ʱ%d��",
			pmg_prg->done_Files, pmg_prg->total_Files, 
			pmg_prg->done_Folders, pmg_prg->total_Folders, 
			FormatSize(pmg_prg->total_FileSize, szBuf), 
			pmg_prg->total_FileSize ? DWORD(pmg_prg->done_FileSize*100/pmg_prg->total_FileSize) : 100,
			DWORD( (pmg_prg->done_FileSize-pmg_prg->exist_FileSize) * 1000 / pmg_prg->used_time/ 1024),
			DWORD(pmg_prg->used_time/1000)
			);
		SetWindowText(hDlg, TempBuf);
		break;
	case WM_FILELIST:
		SetWindowText(hDlg, (char*)wParam);
		break;
	case WM_FILEOPERATE:
		SetWindowText(hDlg, (char*)wParam);
		break;
	}
	//TranMsg();
	return true;
}

int DownLoadFile(HWND hDlg, CFileManager *pFileMng)
{
	int nCount, ret;
	MG_FILE_INFO FI;
	std::vector<MG_FILE_INFO> Files;
	char szFileName[MAX_PATH], szName[MAX_PATH], szItemText[MAX_PATH];

	if(!GetDlgItemText(hDlg, IDC_DIRPATH, szFileName, MAX_PATH))
		return -1;

	if(!GetDirPath(hDlg, 0, szFileName))
	{
		err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, ERROR_CANCELLED);
		return -1;
	}

	pFileMng->SetLocalPath(szFileName);//���ر���·��

	Files.clear();//����vector

	MSG msg;
	msg.hwnd = GetDlgItem(hDlg, IDC_ERRMSG);
	pFileMng->SetOutPutFunc(&msg, GetProgress);

	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), FALSE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), FALSE);

	nCount = 0;
	int nextFileIdx = -1;
	while(GetSelectedFiles(hDlg, szFileName, nextFileIdx))
	{
		sprintf(szName, "%s", szFileName);
		PathStripPath(szName);
		sprintf(TempBuf, "%s\\%s", pFileMng->GetLocalPath(), szName);
		if(FindFile(TempBuf, &FI))
		{
			if(FI.nFileSize > 0)
			{
				ret = MessageBox(hDlg, MB_YESNOCANCEL, "��ʾ", 
					"�����ļ� %s �Ѿ�����,\r\n"
					"�ϵ㴫���� [��]\r\n"
					"ɾ���ļ��������ذ� [��]\r\n"
					"ȡ�����ظ��ļ��� [ȡ��]",
					szName);
				if(ret == IDNO)
				{
					if(DeleteExistFile(TempBuf) != 0)
					{
						MessageBox(hDlg, "����ɾ��ʧ�ܣ����ļ���������", "����", MB_ICONERROR);
						continue;
					}
				}else if(ret == IDCANCEL)
				{
					continue;
				}
			}
		}

		//�Ȼ��Ҫ���ص��ļ��б�
		ret = pFileMng->__GetFileVector(szFileName, Files);
		if(ret == -1)
			continue;//�����������selected���ļ�

		ZeroMemory(szItemText, sizeof(szItemText));
		GetFileNameByIdx(hDlg, nextFileIdx, szItemText);
		for(int i=0; i<ret; i++)
		{
			//�������������
			if(szItemText[0] == '\\')
			{
				char *lastSlash = strrchr(szItemText, '\\');
				if(lastSlash > szItemText)
				{
					//�ļ�������Ŀ¼
					strncpy(szName, szItemText, lastSlash-szItemText+1);
					szName[lastSlash-szItemText+1] = '\0';
					
					strcat(szName, Files[nCount+i].szFileName);
					strcpy(Files[nCount+i].szFileName, szName);
				}

			}
		}

		nCount += ret;
		err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, pFileMng->GetError());
		if(pFileMng->GetError() != 0)
			break;
	}
	//
	//EnableMenuItem(::GetSystemMenu(hDlg, FALSE), SC_CLOSE,MF_BYCOMMAND|MF_GRAYED);//���ιرհ�ť,�ϴ��ļ��в��ܷ���quit����
	//ShowWindow(GetDlgItem(hDlg, IDC_ABORT), SW_SHOW);
	//���б��ϵ��ļ���Ϣ�����ļ�
	pFileMng->__RecvFileVector(&msg, GetProgress, Files);
	//EnableMenuItem(::GetSystemMenu(hDlg, FALSE), SC_CLOSE,MF_BYCOMMAND|MF_ENABLED);
	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), TRUE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), TRUE);
	//ShowWindow(GetDlgItem(hDlg, IDC_ABORT), SW_HIDE);

	return 1;
}

int UpLoadFile(HWND hDlg, char *LocalFile, CFileManager *pFileMng)
{
	int nCount, ret;
	std::vector<MG_FILE_INFO> Files;
	char   szFileName[MAX_PATH];
	char   drive[_MAX_DRIVE];   
	char   dir[_MAX_DIR];   
	char   fname[_MAX_FNAME];   
	char   ext[_MAX_EXT];   

	if(!GetDlgItemText(hDlg, IDC_DIRPATH, szFileName, MAX_PATH))
		return -1;

	Files.clear();
	nCount = 0;

	_splitpath(LocalFile, drive, dir, fname, ext);   

	sprintf(szFileName, "%s%s", drive, dir);
	pFileMng->SetCurrDir(szFileName);//�����ļ���Ŀ¼
	sprintf(szFileName, "%s%s", fname, ext);

	ret = IsFileInList(GetDlgItem(hDlg, IDC_FILELIST), szFileName);
	if(ret >= 0)
	{
		ret = MessageBox(hDlg, MB_YESNOCANCEL, "��ʾ", 
			"Զ���ļ� %s �Ѿ�����,\r\n"
			"�ϵ㴫���� [��]\r\n"
			"ɾ��Զ���ļ������ϴ��� [��]\r\n"
			"ȡ�����ظ��ļ��� [ȡ��]",
			szFileName);
		if(ret == IDNO)
		{
			sprintf(TempBuf, "%s\\%s", pFileMng->GetRemotePath(), szFileName);
			if(pFileMng->__DeleteFile(TempBuf) != 0)
			{
				MessageBox(hDlg, "����ɾ��ʧ�ܣ����ļ���������", "����", MB_ICONERROR);
				return -1;
			}
		}else if(ret == IDCANCEL)
		{
			return -1;
		}
	}
	DWORD err=0;
	MSG msg;
	msg.hwnd = GetDlgItem(hDlg, IDC_ERRMSG);
	pFileMng->SetOutPutFunc(&msg, GetProgress);

	pFileMng->__GetLocalFileList(szFileName, false, Files);//������е��ļ���Ϣ��vector

	//EnableMenuItem(::GetSystemMenu(hDlg, FALSE), SC_CLOSE,MF_BYCOMMAND|MF_GRAYED);//���ιرհ�ť,�ϴ��ļ��в��ܷ���quit����
	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), FALSE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), FALSE);
	//ShowWindow(GetDlgItem(hDlg, IDC_ABORT), SW_SHOW);
	ret = pFileMng->__SendFileVector(&msg, GetProgress, Files);//��vector�е��ļ����ͳ�ȥ
	//EnableMenuItem(::GetSystemMenu(hDlg, FALSE), SC_CLOSE,MF_BYCOMMAND|MF_ENABLED);
	EnableWindow(GetDlgItem(hDlg, IDC_FILELIST), TRUE);
	EnableWindow(GetDlgItem(hDlg, IDC_FILEMG_GO), TRUE);
	//ShowWindow(GetDlgItem(hDlg, IDC_ABORT), SW_HIDE);
	GetWindowText(GetDlgItem(hDlg, IDC_ERRMSG), szFileName, MAX_PATH);//����upload�Ľ��
	if(!ret)
	{
		err = pFileMng->GetError();//�������ŵ�err
		sprintf(szFileName, "%s %s", szFileName, "δ���: ");
	}
	GetFileList(hDlg, pFileMng);//ˢ��Ŀ¼
	if(!ret)//����ŷ�0��ʾ�д�����ʾ������Ϣ
	{
		err_display(GetDlgItem(hDlg, IDC_ERRMSG), szFileName, err);//������ʾupload�Ľ��
		sndPlaySound(lpMemSound_Error, SND_MEMORY|SND_ASYNC);
	}
	return 1;
}

//IDD_GETSTRING���ڴ�������
int CALLBACK GetStringProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	char *pStringBuf = (char*)GetWindowLong(hDlg, GWL_USERDATA);

	switch(uMsg)
	{
	case WM_INITDIALOG:
		SetWindowLong(hDlg, GWL_USERDATA, (long)lParam);
		SetWindowText(hDlg, (char*)lParam);
		SetActiveWindow(GetDlgItem(hDlg, IDC_STRING));

		return true;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDOK:
			memset(pStringBuf, 0, MAX_PATH);
			GetDlgItemText(hDlg, IDC_STRING, pStringBuf, MAX_PATH);
			EndDialog(hDlg, true);
			return true;
		case IDCANCEL:
			EndDialog(hDlg, 0);
			return false;
		}
		break;
	}
	return false;
}