#include "bmp2file.h"


bool GetSavePath(HWND hWnd, char *szFilter, char *szTitle, char *buf)
{
	OPENFILENAME  Ofn;

	memset(&Ofn, 0, sizeof(OPENFILENAME)); 

	Ofn.lStructSize = sizeof(OPENFILENAME); 
	Ofn.hwndOwner = hWnd; 
	Ofn.lpstrFilter = szFilter; 
	Ofn.lpstrFile= buf; 
	Ofn.nMaxFile = MAX_PATH-1; 
	Ofn.Flags = OFN_EXPLORER | OFN_HIDEREADONLY|OFN_PATHMUSTEXIST|OFN_OVERWRITEPROMPT; 
	Ofn.lpstrTitle = szTitle; 
 
	return GetSaveFileName(&Ofn);
}

// created for debug purposes
bool	SaveBitmapToBMPFile(
			HANDLE hFile,
			void *lpDIB,
			BITMAPINFO *pbmi)
{

	bool bReverse;
	BYTE BIBUF[0x440];
	BITMAPINFO *pBI = (BITMAPINFO *)BIBUF;

	BITMAPFILEHEADER bfh = {0};
	bfh.bfType			= 0x4d42;	// 0x42 = "B" 0x4d = "M" 


	//BMP->DIB��Ϣͷ����
	DWORD bmiLenToWrite = pbmi->bmiHeader.biSize;

	if(pbmi->bmiHeader.biBitCount == 4)
	{
		//���ϵ�ɫ�����ݳ���
		bmiLenToWrite += 16*4;
	}else if(pbmi->bmiHeader.biBitCount == 8)
	{
		//���ϵ�ɫ�����ݳ���
		bmiLenToWrite += 256*4;
	}else if (pbmi->bmiHeader.biCompression == BI_BITFIELDS)
	{
		//����BITFIELDS����
		bmiLenToWrite += 3*sizeof(DWORD);
	}

	if(bmiLenToWrite > 0x440)
		return false;

	memcpy(pBI, pbmi, 0x440);
	if(pBI->bmiHeader.biHeight < 0)
	{
		bReverse = true;
		pBI->bmiHeader.biHeight = -pBI->bmiHeader.biHeight;
	}else
	{
		bReverse = false;
	}

	//BMP�ļ�ͷ->DIB����ƫ��
	bfh.bfOffBits = sizeof(BITMAPFILEHEADER) + bmiLenToWrite;

	//BMP�ļ�ͷ->�ļ���С
	bfh.bfSize = bfh.bfOffBits + pbmi->bmiHeader.biSizeImage; 

	ULONG ulnWr = 0;

	//дBMP�ļ�ͷ
	if (!WriteFile(hFile, &bfh, sizeof(bfh), &ulnWr, NULL) || ulnWr!=sizeof(bfh))
		return false;

	//дDIB��Ϣͷ
	if (!WriteFile(hFile, pBI, bmiLenToWrite, &ulnWr, NULL) || ulnWr!=bmiLenToWrite)
		return false;

	//дDIB����

	if(bReverse)
	{
		unsigned lineSize = pbmi->bmiHeader.biWidth*pbmi->bmiHeader.biBitCount/8;
		for (int i = pBI->bmiHeader.biHeight-1; i>=0; i--)
		{
			int offset = i*(pBI->bmiHeader.biWidth)*pBI->bmiHeader.biBitCount/8;	
			if (!WriteFile(hFile, (BYTE*)lpDIB+offset, lineSize, &ulnWr, NULL) || ulnWr!=lineSize)
				return false;
		}
	}else
	{
		if(!WriteFile(hFile, lpDIB, pBI->bmiHeader.biSizeImage, &ulnWr, NULL) || ulnWr!=pBI->bmiHeader.biSizeImage)
			return false;
	}

	SetEndOfFile(hFile);

	return true;
}

// created for debug purposes
bool	bDbgBmDump(
			char *filename,
			void *lpDIB,
			BITMAPINFO *pbmi)
{

	HANDLE hFile = CreateFile(
		filename,
		FILE_WRITE_DATA,
		0,
		NULL,
		CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		NULL);
	if (hFile==INVALID_HANDLE_VALUE)
	{
		return false;
	}

	bool b= SaveBitmapToBMPFile(
		hFile,
		lpDIB,
		pbmi);

	CloseHandle(hFile);
	return b;
}
