#if !defined _BMP2FILE

#define _BMP2FILE

#include <windows.h>

bool	SaveBitmapToBMPFile(
			HANDLE hFile,
			void *lpDIB,
			BITMAPINFO *pbmi);

bool	bDbgBmDump(
			char *filename,
			void *lpDIB,
			BITMAPINFO *pbmi);

bool GetSavePath(HWND hWnd, char *szFilter, char *szTitle, char *buf);


#endif