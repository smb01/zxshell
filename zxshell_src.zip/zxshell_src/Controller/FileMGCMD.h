#if !defined _FILEMGCMD
#define _FILEMGCMD

#include "main.h"
#include "FileManager.h"


void InitFileMngPanel(HWND hDlg);
int IsFileInList(HWND hCtrl, char *lpFileName);
void AddFileToList(HWND hCtrl, LP_MG_FILE_INFO pFI);
BOOL GetSelectedFiles(HWND hDlg, char *lpFileName, int &nextFileIdx);
int GetAllDrivers(HWND hCtrl, CFileManager *pFileMng);
int GetFileList(HWND hDlg, CFileManager *pFileMng);
int DeletePath(HWND hDlg, CFileManager *pFileMng);
int MoveFile(HWND hDlg, CFileManager *pFileMng);
int ExecuteFile(HWND hDlg, CFileManager *pFileMng);
int SetPlugPath_VNC(HWND hDlg, CFileManager *pFileMng);
int GetMd5string(HWND hDlg, CFileManager *pFileMng);
int RenameFile(HWND hDlg, CFileManager *pFileMng);
int NewFolder(HWND hDlg, CFileManager *pFileMng);
DWORD CALLBACK GetProgress(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
int DownLoadFile(HWND hDlg, CFileManager *pFileMng);
int UpLoadFile(HWND hDlg, char *LocalFile, CFileManager *pFileMng);
int CALLBACK GetStringProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
int RemoteSearchFile(HWND hDlg, CFileManager *pFileMng);


#endif