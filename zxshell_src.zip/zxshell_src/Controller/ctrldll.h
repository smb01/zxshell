#if !defined _CTRLDLL

#define _CTRLDLL

#define _WIN32_WINNT 0x0500

#include <windows.h>

#define ZX_KEYEVENT WM_USER+520

extern HINSTANCE g_hHookIns;


extern HHOOK hLLKeyboardHook;						// Handle to LowLevel kbd hook
extern HWND g_hWnd;


LRESULT CALLBACK LowLevelKeyboardFilterProc(int nCode, WPARAM wParam, LPARAM lParam);

HHOOK WINAPI SetKeybdHook(HWND hwnd);
BOOL WINAPI UnSetKeybdHook();

typedef HHOOK WINAPI SETKEYBDHOOK(HWND hwnd);
typedef BOOL WINAPI UNSETKEYBDHOOK();

#endif