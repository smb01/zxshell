#include "ShellList.h"
#include "..\zxsCommon\link.h"

_tagConnInfo::_tagConnInfo()
{
	memset(this, 0, sizeof(_tagConnInfo));
}


int C_CMDCONNLIST::AddSocket(_tagConnInfo ci)
{
	EnterCriticalSection(&cs);
	int ret = Add(ci);
	LeaveCriticalSection(&cs);
	return ret;
}

int C_CMDCONNLIST::DelSocket(SOCKET s)
{
	int ret = 0;
	EnterCriticalSection(&cs);
	_Node<_tagConnInfo> *curr = Head;
	for(int n=0; n<Count; n++)
	{
		if(curr->data.Socket == s)
		{
			Delp(curr);
			ret = 1;
			break;
		}
		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);
	return ret;
}

_tagConnInfo *C_CMDCONNLIST::IsSocketInList(SOCKET s)
{
	_tagConnInfo *ret = NULL;
	EnterCriticalSection(&cs);
	_Node<_tagConnInfo> *curr = Head;
	for(int n=0; n<Count; n++)
	{
		if(curr->data.Socket == s)
		{
			ret = &curr->data;
			break;
		}
		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);
	return ret;
}


int C_CMDCONNLIST::CloseAllSocket()
{
	int ret = 0;
	EnterCriticalSection(&cs);
	_Node<_tagConnInfo> *curr = Head;

	for(int n=0; n<Count; n++)
	{
		shutdown(curr->data.Socket, SD_BOTH);//~~~~~~~~~~~~
		curr = curr->Next;
		ret++;
	}
	LeaveCriticalSection(&cs);

	return ret;
}


///////////////////////////////

_CZXServer::_CZXServer()
{
	memset(this, 0, sizeof(_CZXServer));
}

int _CZXServer::Send(char *buff, int len)
{
	if(bytesleft > 0)
		return 0;
	memcpy(sendbuff, buff, len);
	bytesleft = len;
	bytessent = 0;

	return 1;
}

int _CZXServer::Send()
{
	int retval;
	if(bytesleft > 0)
	{
		retval = send(Socket, sendbuff+bytessent, bytesleft, 0);
		if(retval == SOCKET_ERROR)
		{
			if (WSAGetLastError() == WSAEWOULDBLOCK)
				return 1;
			else
				return 0;
		}else
		{
			bytessent += retval;
			bytesleft -= retval;
		}
	}
	return 1;
}

/////////////////////////////////////////////////////////////

int C_SHELLLIST::AddSocket(_CZXServer s)
{
	EnterCriticalSection(&cs);
	int ret = Add(s);
	LeaveCriticalSection(&cs);
	return ret;
}

int C_SHELLLIST::DelSocket(SOCKET s)
{
	int ret = 0;
	EnterCriticalSection(&cs);
	_Node<_CZXServer> *curr = Head;
	for(int n=0; n<Count; n++)
	{
		if(curr->data.Socket == s)
		{
			Delp(curr);
			ret = 1;
			break;
		}
		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);
	return ret;
}

_CZXServer *C_SHELLLIST::IsSocketInList(SOCKET s)
{
	_CZXServer *ret = NULL;
	EnterCriticalSection(&cs);
	_Node<_CZXServer> *curr = Head;
	for(int n=0; n<Count; n++)
	{
		if(curr->data.Socket == s)
		{
			ret = &curr->data;
			break;
		}
		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);
	return ret;
}

float C_SHELLLIST::GetShellVersion(SOCKET s)
{
	float ver = 0;
	EnterCriticalSection(&cs);
	_Node<_CZXServer> *curr = Head;
	for(int n=0; n<Count; n++)
	{
		if(curr->data.Socket == s)
		{
			ver = curr->data.ver;
			break;
		}
		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);
	return ver;
}

int C_SHELLLIST::CloseAllSocket()
{
	int ret = 0;
	EnterCriticalSection(&cs);
	_Node<_CZXServer> *curr = Head;

	for(int n=0; n<Count; n++)
	{
		shutdown(curr->data.Socket, SD_BOTH);//~~~~~~~~~~~~
		curr = curr->Next;
		ret++;
	}
	LeaveCriticalSection(&cs);

	return ret;
}