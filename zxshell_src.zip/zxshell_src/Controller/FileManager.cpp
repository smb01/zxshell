// FileManager.cpp: implementation of the CFileManager class.
//
//////////////////////////////////////////////////////////////////////

#include "FileManager.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

VOID CreateDirByPath(char *lpFilePath)
{
	char szPath[MAX_PATH] = "\0";

	int i = 0;
	char ch = *(lpFilePath+i);

	while(ch && i<MAX_PATH)
	{
		if(ch == '\\' || ch == '/')
		{
			CreateDirectory(szPath, NULL);
		}
		szPath[i] = ch;
		szPath[i+1] = '\0';

		i++;
		ch = *(lpFilePath+i);
	}

}

bool FindFile(char *lpFileName, LP_MG_FILE_INFO pFI)
{
	WIN32_FIND_DATA  FileData;
	HANDLE hSearch = FindFirstFile(lpFileName, &FileData);
	if(hSearch == INVALID_HANDLE_VALUE)
		return false;
	FindClose(hSearch);
	pFI->dwFileAttributes = FileData.dwFileAttributes;
	pFI->ftCreationTime   = FileData.ftCreationTime;
	pFI->ftLastAccessTime = FileData.ftLastAccessTime;
	pFI->ftLastWriteTime  = FileData.ftLastWriteTime;
	pFI->nFileSize        = (FileData.nFileSizeHigh * ((__int64)MAXDWORD+1)) + FileData.nFileSizeLow;
	strcpy(pFI->szFileName, FileData.cFileName);
	return true;
}

int DeleteExistFile(char *lpFileName)
{
	SHFILEOPSTRUCT FileOp;
	ZeroMemory(&FileOp,sizeof(FileOp));
	FileOp.fFlags = FOF_NOCONFIRMATION|FOF_SILENT;
	FileOp.hNameMappings = NULL;
	FileOp.hwnd = NULL;
	FileOp.lpszProgressTitle = NULL;
	FileOp.pFrom = lpFileName;
	FileOp.pTo = NULL;
	FileOp.wFunc = FO_DELETE;

	return SHFileOperation(&FileOp);
}

bool ChangeFileAttributes(char *lpFileName, LP_MG_FILE_INFO pFI)
{
	bool result;
	HANDLE hFile = CreateFile(lpFileName,
		GENERIC_READ | GENERIC_WRITE,
		FILE_SHARE_READ|FILE_SHARE_DELETE,
		NULL,
		OPEN_EXISTING,
		(pFI->dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)? FILE_FLAG_BACKUP_SEMANTICS : FILE_ATTRIBUTE_NORMAL,
		NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		return false;
	}
	result = SetFileTime(hFile,
		&pFI->ftCreationTime,
		&pFI->ftLastAccessTime,
		&pFI->ftLastWriteTime);
	if(!result)
		goto exit;
	result = SetFileAttributes(lpFileName, pFI->dwFileAttributes);
	if(!result)
		goto exit;

exit:
	CloseHandle(hFile);
	return result;
}
char * FormatSize(__int64 nSize, char *szSize)
{
	double fSize = nSize;
	char Demarkation[40];
	
	if (fSize >= (1024 * 1024 * 1024))
	{
		sprintf(Demarkation, " GB");
		fSize /= (1024 * 1024 * 1024);
	}
	else if (fSize >= (1024 * 1024))
	{
		sprintf(Demarkation, " MB");
		fSize /= (1024 * 1024);
	}
	else if (fSize >= 1024)
	{
		sprintf(Demarkation, " KB");
		fSize /= 1024;
	}
	else
		sprintf(Demarkation, " bytes");

	if (nSize >= 1024)
		sprintf(szSize, "%.1I64f", fSize);
	else
		sprintf(szSize, "%.0I64f", fSize);

	strcat(szSize, Demarkation);

	return szSize;
}

//����win2000Դ����
int FormatPathString(char *Source, char *Dest, int buflen, bool flag)
{
#define IS_PATH_SEPARATOR(ch) ((ch == '\\') || (ch == '/'))
#define IS_DOT(s) ( s[0] == '.' && ( IS_PATH_SEPARATOR(s[1]) || s[1] == '\0') )
#define IS_DOT_DOT(s) ( s[0] == '.' && s[1] == '.' && ( IS_PATH_SEPARATOR(s[2]) || s[2] == '\0') )

	char ch = flag ? '\\' : '/';
	char *lpRetBuf = Dest;
	char *lproot = Dest;
	bool IsGetlpRoot = false;
	while ( *Source ) {
		switch ( *Source ) {

		case '\\' :
		case '/' :
			if  ( *(Dest-1) != ch ) {
				if(!IsGetlpRoot)
				{
					lproot = Dest;
					IsGetlpRoot = true;
				}
				*Dest++ = ch;

				if(Dest - lpRetBuf >= buflen -1)
					goto exit;
			}
			Source++;
			break;
            case '.' :
                //
                // Ignore dot in a leading //./
                // Eat single dots as in /./
                // Double dots back up one level as in /../
                // Any other . is just a filename character
                //

                if ( IS_DOT(Source) ) {
                    Source++;
                    if (IS_PATH_SEPARATOR(*Source)) {
                        Source++;
                        }
                    break;
                    }
                else if ( IS_DOT_DOT(Source) ) {

                    //
                    // backup destination string looking for
                    // a \
                    //

                    while (*Dest != ch && Dest > lpRetBuf)
						Dest--;

                    //
                    // backup to previous component..
                    // \a\b\c\.. to \a\b
                    //

                    do {

                        //
                        // If we bump into root prefix, then
                        // stay at root
                        //

                        if (Dest == lproot) {
                            break;
                            }

                        Dest--;

                        } while (*Dest != ch);
                    if ( Dest ==  lproot && *Dest == ch) {
                        Dest++;
                        }

                    //
                    // Advance source past ..
                    //

                    Source += 2;

                    break;
                    }

                //
                // FALLTHRU
                //
		default:
			while ( *Source && !IS_PATH_SEPARATOR(*Source)) {
				*Dest++ = *Source++;

				if(Dest - lpRetBuf >= buflen -1)
					goto exit;
			}
		}
	}
exit:
	*Dest = '\0';
	return Dest - lpRetBuf;
}


CFileManager::CFileManager()
{
	memset(this, 0, sizeof(CFileManager));

	cl.Init();

}

CFileManager::~CFileManager()
{

}

void CFileManager::Init(SOCKET s)
{
	Socket = s;
}

char *CFileManager::GetPeerIP()
{
	struct sockaddr_in client;
	int structsize=sizeof(struct sockaddr);

	if(getpeername(Socket, (struct sockaddr *)&client, &structsize)<0)
		return "Unknown";
	else
		return inet_ntoa(client.sin_addr);
}

BOOL CFileManager::RecvErr()//����һ��DWORD����Զ�̷��ص�һ��״̬��־
{
	CZXCount zc(cl);

	LastErr = 0xFFFFFFFF;
	if(! RecvMessage(Socket, (char*)&LastErr, sizeof(DWORD), 24))
	{
		LastErr = 13805;
	}
	return LastErr;
}

void CFileManager::Abort()
{
	CZXCount zc(cl);

	if(SendMessage(Socket, "ABOR\r\n") <= 0)
	{
		LastErr = WSAGetLastError();
		return;
	}
}

bool CFileManager::Quit()
{
	if(Socket != 0)
	{
		closesocket(Socket);
		Socket = 0;
	}

	HANDLE hEvent = cl.GetHandle();

	if(WaitForSingleObject(hEvent, 1) == WAIT_TIMEOUT)
		return false;
	else
		return true;

}

void CFileManager::SetOutPutFunc(PMSG pmsg, LPTRANSFERPROGESS pFun)
{
	pMsg = pmsg;
	pProgress = pFun;
}

int CFileManager::__GetRemoteFileList(char *RemotePath, std::vector<MG_FILE_INFO> &Files)
{
	CZXCount zc(cl);

	Files.clear();
	if(SendMessage(Socket, "LIST %s\r\n", RemotePath) <= 0)
	{
		LastErr = WSAGetLastError();
		return -1;
	}
	if(RecvErr())
		return -1;
	return __RecvFileInfo(Files);
}

int CFileManager::__DeleteFile(char *RemotePath)
{
	CZXCount zc(cl);

	if(SendMessage(Socket, "DELE %s\r\n", RemotePath) <= 0)
	{
		LastErr = WSAGetLastError();
		return -1;
	}
	if(RecvErr())
		return -1;
	return 0;
}

int CFileManager::__MoveFile(char *OriginPath, char *newPath)
{
	CZXCount zc(cl);

	if(SendMessage(Socket, "MOVE \"%s\" \"%s\"\r\n", OriginPath, newPath) <= 0)
	{
		LastErr = WSAGetLastError();
		return -1;
	}
	if(RecvErr())
		return -1;
	return 0;
}

int CFileManager::__RenameFile(char *OriginPath, char *newPath)
{
	CZXCount zc(cl);

	if(SendMessage(Socket, "RNTO \"%s\" \"%s\"\r\n", OriginPath, newPath) <= 0)
	{
		LastErr = WSAGetLastError();
		return -1;
	}
	if(RecvErr())
		return -1;
	return 0;
}

int CFileManager::__NewFolder(char *RemotePath)
{
	CZXCount zc(cl);

	if(SendMessage(Socket, "XMKD %s\r\n", RemotePath) <= 0)
	{
		LastErr = WSAGetLastError();
		return -1;
	}
	if(RecvErr())
		return -1;
	return 0;
}

int CFileManager::__ExecuteFile(char *RemotePath)
{
	CZXCount zc(cl);

	if(SendMessage(Socket, "EXEC %s\r\n", RemotePath) <= 0)
	{
		LastErr = WSAGetLastError();
		return -1;
	}
	if(RecvErr())
		return -1;
	return 0;
}

int CFileManager::__SetRestart(__int64 StartPos)
{
	CZXCount zc(cl);

	if(SendMessage(Socket, "REST %I64d\r\n", StartPos) <= 0)
	{
		LastErr = WSAGetLastError();
		return -1;
	}
	if(RecvErr())
		return -1;
	return 0;
}

DWORD CALLBACK CFileManager::ProgressProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CZXCount zc(cl);

	if(pProgress)
		return pProgress(hDlg, uMsg, wParam, lParam);
	else
		return 0;
}

int CFileManager::__GetFileVector(char *RemotePath, std::vector<MG_FILE_INFO> &Files)
{
	CZXCount zc(cl);

	if(SendMessage(Socket, "FILE %s\r\n", RemotePath) <= 0)
	{
		LastErr = WSAGetLastError();
		return -1;
	}
	if(RecvErr())
		return -1;
	return __RecvFileInfo(Files);
}

int CFileManager::__DownloadFile(char *RemotePath)
{
	CZXCount zc(cl);

	if(SendMessage(Socket, "RETR %s\r\n", RemotePath) <= 0)
	{
		LastErr = WSAGetLastError();
		return -1;
	}
	if(RecvErr())
		return -1;
	return 0;
}

int CFileManager::__UploadFile(char *RemotePath)
{
	CZXCount zc(cl);

	if(SendMessage(Socket, "STOR %s\r\n", RemotePath) <= 0)
	{
		LastErr = WSAGetLastError();
		return -1;
	}
	if(RecvErr())
		return -1;
	return 0;
}

int CFileManager::__Md5File(char *RemotePath, char *szBuf)
{
	CZXCount zc(cl);

	if(SendMessage(Socket, "XMD5 %s\r\n", RemotePath) <= 0)
	{
		LastErr = WSAGetLastError();
		return -1;
	}
	if(RecvErr())
		return -1;
	if(__Recv(Socket, szBuf, 32+1, -1) <= 0)
		return -1;
	else
		return 0;
}

int CFileManager::__SetPlugPath_VNC(char *RemotePath, char *szBuf)
{
	CZXCount zc(cl);

	if(SendMessage(Socket, "PLUG_vnc %s\r\n", RemotePath) <= 0)
	{
		LastErr = WSAGetLastError();
		return -1;
	}
	if(RecvErr())
		return -1;

	return 0;
}

int CFileManager::__SearchFile(char *RemotePath, std::vector<MG_FILE_INFO> &Files)
{
	CZXCount zc(cl);
	
	Files.clear();
	if(SendMessage(Socket, "SEARCH %s\r\n", RemotePath) <= 0)
	{
		LastErr = WSAGetLastError();
		return -1;
	}

	return __RecvFileInfo(Files);
}

//����ָ�����ļ�����Ϣ��Ŀ¼�Ļ������������Ŀ¼���ļ�,�����ӵ�vector
int CFileManager::__RecvFileInfo(std::vector<MG_FILE_INFO> &Files)
{
	CZXCount zc(cl);

	MG_FILE_INFO *pFI, FI;
	bool bError = false;
	int nRetVal, nRecvBytes = 0;
	int bufsize = MAXBUFSIZE*10;
	char *tmp, *RecvBuf;
	const int EndFlagSize = sizeof(MG_FILE_INFO)-MAX_PATH;//len_head_FileInfo
	char EndFlag[EndFlagSize];

	int nFileCount = 0;

	RecvBuf = new char [bufsize];
	if(RecvBuf == NULL)
		return 0;
	memset(EndFlag, 0, sizeof(EndFlag));

	ProgressProc(pMsg->hwnd, WM_FILELIST, (WPARAM)"��ȡ�ļ���Ϣ...", 0);
	
	while(1)
	{
		if(bufsize - nRecvBytes < MAXBUFSIZE)
		{
			bufsize *= 2;
			tmp = new char [bufsize];
			if(tmp == NULL)
			{
				bError = true;
				break;
			}
			memcpy(tmp, RecvBuf, nRecvBytes);
			delete [] RecvBuf;
			RecvBuf = tmp;
		}
		nRetVal = __Recv(Socket, RecvBuf+nRecvBytes, bufsize - nRecvBytes, -1);
		if(nRetVal <= 0)
		{
			bError = true;
			break;
		}
		nRecvBytes += nRetVal;

		sprintf(TempBuf, "��������... %dkb", nRecvBytes/1024);
		ProgressProc(pMsg->hwnd, WM_FILELIST, (WPARAM)TempBuf, 0);

		if(nRecvBytes >= EndFlagSize)
		{
			tmp = &RecvBuf[nRecvBytes - EndFlagSize];
			if(memcmp(tmp, EndFlag, EndFlagSize) == 0)//������յ��������len_head_FileInfo���ֽ���ȫ'\0'�Ļ�����Ϊ�ǽ������
				break;
		}
	}
	if(!bError)
	{
		tmp = RecvBuf;
		pFI = (LP_MG_FILE_INFO)tmp;
		while(memcmp(pFI, EndFlag, EndFlagSize) != 0 && (tmp - RecvBuf < nRecvBytes))//�ֽ���յ������ݣ������ֽ�������ļ�һ�������ӵ�vector
		{
			FI.dwFileAttributes = pFI->dwFileAttributes;
			FI.ftCreationTime   = pFI->ftCreationTime;
			FI.ftLastAccessTime = pFI->ftLastAccessTime;
			FI.ftLastWriteTime  = pFI->ftLastWriteTime;
			FI.nFileSize        = pFI->nFileSize;
			nRetVal = _snprintf(FI.szFileName, MAX_PATH, "%s", pFI->szFileName);
			if(nRetVal == 0)
				break;
			Files.push_back(FI);
			nFileCount++;
			tmp += EndFlagSize + nRetVal + 1;
			pFI = (LP_MG_FILE_INFO)tmp;
		}

	}
	delete [] RecvBuf;

	return nFileCount;
}

//��vector���е��ļ�ȫ����������
int CFileManager::__RecvFileVector(PMSG pmsg, LPTRANSFERPROGESS pFun, std::vector<MG_FILE_INFO> &Files)
{
	CZXCount zc(cl);

	char FileName[MAX_PATH];
	int nCount = Files.size();
	pMsg = pmsg;
	pProgress = pFun;
	memset(&mg_prg, 0, sizeof(mg_prg));

	//��ѭ��ͳ��vector���������ļ�����Ϣ����Ŀ¼��Ԥ�ȱ��ش����ļ���
	int i=0;
	for(i=0; i<nCount; i++)
	{
		_snprintf(FileName, MAX_PATH, "%s\\%s", LocalPath, Files[i].szFileName);
		CreateDirByPath(FileName);

		if(Files[i].dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
		{
			if(CreateDirectory(FileName, NULL))
			{
				mg_prg.done_Folders++;
			}else
			{
				if(GetLastError() == ERROR_ALREADY_EXISTS)
					mg_prg.done_Folders++;
			}
			mg_prg.total_Folders++;
		}else
			mg_prg.total_Files++;
		mg_prg.total_FileSize += Files[i].nFileSize;
	}

	mg_prg.start_time = GetTickCount();

	ProgressProc(pMsg->hwnd, WM_TRANSFER, 0, (LPARAM)&mg_prg);

	//��ѭ����vector�������з��ļ������Ե��ļ�һ������������
	for(i=0; i<nCount; i++)
	{
		if(!(Files[i].dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
		{
			if(__RecvFileData(&Files[i]))//�����ļ�
			{
				_snprintf(FileName, MAX_PATH, "%s\\%s", LocalPath, Files[i].szFileName);
				ChangeFileAttributes(FileName, &Files[i]);
			}
		}
	}
	//�޸��ļ���������Ϣ
	for(i=0; i<nCount; i++)
	{
		if(Files[i].dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
		{
			_snprintf(FileName, MAX_PATH, "%s\\%s", LocalPath, Files[i].szFileName);
			ChangeFileAttributes(FileName, &Files[i]);
		}
	}
	return 1;
}

//����һ���ļ�
int CFileManager::__RecvFileData(LP_MG_FILE_INFO pFI)
{
	CZXCount zc(cl);

	int nRetVal, nBytes, fSuccess = TRUE;
	char LocalFile[MAX_PATH];
	char RecvBuf[MAXBUFSIZE];
	__int64 TotalBytesRecv = 0;
	__int64 FileSize = pFI->nFileSize;
	LARGE_INTEGER LI;
	BOOL bError;
	DWORD ts,te=0;

	_snprintf(LocalFile, MAX_PATH, "%s\\%s", LocalPath, pFI->szFileName);

	SetFileAttributes(LocalFile, FILE_ATTRIBUTE_NORMAL);

	HANDLE hFile = CreateFile(LocalFile, 
        GENERIC_READ|GENERIC_WRITE, 
        FILE_SHARE_READ|FILE_SHARE_WRITE, 
        NULL, 
        OPEN_ALWAYS, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		return FALSE;
	}
	if(!GetFileSizeEx(hFile, &LI)){
		fSuccess = FALSE;
		goto exit;
	}
	if(!SetFilePointerEx(hFile, LI, NULL, FILE_BEGIN)){
		fSuccess = FALSE;
		goto exit;
	}

	if(__SetRestart(LI.QuadPart) != 0){
		fSuccess = FALSE;
		goto exit;
	}

	mg_prg.exist_FileSize += LI.QuadPart;//����ɵı����� ���������صĲ���
	mg_prg.done_FileSize += LI.QuadPart;
	FileSize -= LI.QuadPart;//�����صı����� ��ȥ�����صĲ���

	if(__DownloadFile(pFI->szFileName) != 0){
		fSuccess = FALSE;
		goto exit;
	}
	ts = GetTickCount();
	while(TotalBytesRecv < FileSize)
	{
		if(FileSize - TotalBytesRecv < (__int64)MAXBUFSIZE)
			nBytes = FileSize - TotalBytesRecv;
		else
			nBytes = MAXBUFSIZE;

		nRetVal = __Recv(Socket, RecvBuf, nBytes, -1);
		if(nRetVal <= 0)
		{
			fSuccess = FALSE;
			break;
		}
		else
		{
			if(!__WriteToFile(hFile, RecvBuf, nRetVal))
			{
				fSuccess = FALSE;
				break;
			}
			TotalBytesRecv += nRetVal;
		}
		mg_prg.done_FileSize += nRetVal;
		te = GetTickCount();
		if(te - ts >= 500)
		{
			ts = te;
			ProgressProc(pMsg->hwnd, WM_TRANSFER, 0, (LPARAM)&mg_prg);
		}

	}

	SetEndOfFile(hFile);
	if(RecvErr()){
		fSuccess = FALSE;
		goto exit;
	}
	mg_prg.done_Files++;
	ProgressProc(pMsg->hwnd, WM_TRANSFER, 0, (LPARAM)&mg_prg);
exit:

    CloseHandle(hFile);
	return fSuccess;
}

//���������е�ָ�����ֽ���д���ļ���
int CFileManager::__WriteToFile(HANDLE hFile, char *Buff, int Datalen)
{
	CZXCount zc(cl);

	DWORD nBytesLeft = Datalen;
	DWORD dwNumOfBytesWritten = 0;
	char *pBuf = Buff;
	while(nBytesLeft > 0) {
		if(!WriteFile(hFile, pBuf, nBytesLeft, &dwNumOfBytesWritten, NULL)) {
			return FALSE;
		}
		pBuf += dwNumOfBytesWritten;
		nBytesLeft -= dwNumOfBytesWritten;
	}
	return TRUE;
}

//���õ�ǰĿ¼
void CFileManager::SetCurrDir(char *path)
{
	int len = FormatPathString(path, CurrPath, MAX_PATH, true);
	if(CurrPath[len-1] == '\\')
		CurrPath[len-1] = '\0';
}

//���ָ��Ҫ�ϴ����ļ�����Ϣ��Ŀ¼������������ļ��У�����ȫ���ļ���Ϣ���ӵ�vector��
int CFileManager::__GetLocalFileList(char *FileName, bool bRecursion, std::vector<MG_FILE_INFO> &Files)
{
	CZXCount zc(cl);

	MG_FILE_INFO FI;
	int FileNameLen;

	int idx = 0,nFiles=0, len=0, ret = 0;
	char lpFileName[MAX_PATH];
	WIN32_FIND_DATA wfd;
	int nCount_Dir, i;

	if(bRecursion)
		_snprintf(TempBuf, MAX_PATH, "%s\\%s\\*.*", CurrPath, FileName);
	else
		_snprintf(TempBuf, MAX_PATH, "%s\\%s", CurrPath, FileName);

	FormatPathString(TempBuf, lpFileName, MAX_PATH, true);

	HANDLE hFile = FindFirstFile(lpFileName, &wfd);
	if (hFile == INVALID_HANDLE_VALUE)
		return 0;

	do{

		if(!stricmp(wfd.cFileName, ".") || !stricmp(wfd.cFileName, ".."))
			continue;
		FI.dwFileAttributes = wfd.dwFileAttributes;
		FI.ftCreationTime   = wfd.ftCreationTime;
		FI.ftLastAccessTime = wfd.ftLastAccessTime;
		FI.ftLastWriteTime  = wfd.ftLastWriteTime;
		FI.nFileSize = (wfd.nFileSizeHigh * ((__int64)MAXDWORD+1)) + wfd.nFileSizeLow;

		if(bRecursion)
			FileNameLen = _snprintf(FI.szFileName, MAX_PATH, "%s\\%s", FileName, wfd.cFileName);
		else
			FileNameLen = _snprintf(FI.szFileName, MAX_PATH, "%s", FileName);

		Files.push_back(FI);
		nFiles++;
		if(FI.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
		{
			if(bRecursion)
				_snprintf(lpFileName, MAX_PATH, "%s\\%s", FileName, wfd.cFileName);
			else
				_snprintf(lpFileName, MAX_PATH, "%s", FileName);
			nFiles += __GetLocalFileList(lpFileName, true, Files);
		}
		ProgressProc(pMsg->hwnd, WM_FILELIST, (WPARAM)"��ȡ�ļ���Ϣ...", 0);
	}while(FindNextFile(hFile, &wfd));

	FindClose(hFile);
	return nFiles;
}

//��vector�е��ļ�ȫ�����͵�Զ�̼����
int CFileManager::__SendFileVector(PMSG pmsg, LPTRANSFERPROGESS pFun, std::vector<MG_FILE_INFO> &Files)
{
	CZXCount zc(cl);

	char FileName[MAX_PATH];
	int nCount = Files.size();
	pMsg = pmsg;
	pProgress = pFun;
	memset(&mg_prg, 0, sizeof(mg_prg));
	int i=0;
	for(i=0; i<nCount; i++)
	{
		if(Files[i].dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			mg_prg.total_Folders++;
		else
			mg_prg.total_Files++;
		mg_prg.total_FileSize += Files[i].nFileSize;
		ProgressProc(pMsg->hwnd, WM_INITDIALOG, 0, (LPARAM)&mg_prg);
	}

	mg_prg.start_time = GetTickCount();
	ProgressProc(pMsg->hwnd, WM_TRANSFER, 0, (LPARAM)&mg_prg);

	for(i=0; i<nCount; i++)
	{
		_snprintf(FileName, MAX_PATH, "%s\\%s", CurrPath, Files[i].szFileName);
		if(Files[i].dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)//Ŀ¼�����½��ļ�������
		{
			if(__NewFolder(Files[i].szFileName) == 0)
			{
				mg_prg.done_Folders++;
			}else
			{
				if(GetError() == ERROR_ALREADY_EXISTS)
					mg_prg.done_Folders++;
				else
					break;
			}
		}else
		{
			if(__SendFileData(&Files[i]) != -1)//�����ļ�
			{
				mg_prg.done_Files++;
			}else
				continue;
		}
		ProgressProc(pMsg->hwnd, WM_TRANSFER, 0, (LPARAM)&mg_prg);
	}
	return (mg_prg.done_Files == mg_prg.total_Files) && (mg_prg.done_Folders == mg_prg.total_Folders);
}

__int64 CFileManager::GetRemoteFileSize(char *RemotePath)
{
	CZXCount zc(cl);

	if(SendMessage(Socket, "SIZE %s\r\n", RemotePath) <= 0)
	{
		LastErr = WSAGetLastError();
		return -1;
	}
	__int64 FileSize = 0;
	if(!RecvMessage(Socket, (char*)&FileSize, sizeof(__int64), -1))
	{
		LastErr = WSAGetLastError();
		return -1;
	}
	return FileSize;
}

//����һ���ļ�
int CFileManager::__SendFileData(LP_MG_FILE_INFO pFI)
{
	CZXCount zc(cl);

	__int64 ret = -1;
	char LocalFile[MAX_PATH];
	LARGE_INTEGER Len;

	_snprintf(LocalFile, MAX_PATH, "%s\\%s", CurrPath, pFI->szFileName);

	HANDLE hFile = CreateFile(LocalFile, 
        GENERIC_READ, 
        FILE_SHARE_READ, 
        NULL, 
        OPEN_EXISTING, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		return -1;
	}

	__int64 StartPos = GetRemoteFileSize(pFI->szFileName);//�Ȼ��Զ���ļ���С�����Զϵ㴫��
	if(StartPos == -1)
		goto error;

	if(__UploadFile(pFI->szFileName) != 0)
		goto error;

	Len.QuadPart = StartPos;//�ƶ��ļ�ָ�룬�ϵ㴫��
	if(!SetFilePointerEx(hFile, Len, NULL, FILE_BEGIN))
		goto error;

	pFI->nFileSize -= StartPos;//�޸���Ҫ�ϴ��Ĵ�С
	mg_prg.done_FileSize += StartPos;
	mg_prg.exist_FileSize += StartPos;

	if(! __Send(Socket, (char*)pFI, len_head_FileInfo, 20))//�����ļ���Ϣ
		goto error;

	ret = Transmitfile(Socket, hFile, pFI->nFileSize);
	if(ret != pFI->nFileSize)
	{
		ret = -1;
		goto error;
	}
error:
	LastErr = WSAGetLastError();
	CloseHandle(hFile);
	return ret;
}

int CFileManager::DataSend(SOCKET s, char *DataBuf, int DataLen)//��DataBuf�е�DataLen���ֽڷ���sȥ
{
	CZXCount zc(cl);

	int nBytesLeft = DataLen;
	int nBytesSent = 0;
	int ret;
	//set socket to blocking mode
	int iMode = 0;
	ioctlsocket(s, FIONBIO, (u_long FAR*) &iMode);
	while(nBytesLeft > 0)
	{
		ret = send(s, DataBuf + nBytesSent, nBytesLeft, 0);
		if(ret <= 0)
			break;
		nBytesSent += ret;
		nBytesLeft -= ret;
	}
	return nBytesSent;
}

__int64 CFileManager::Transmitfile(SOCKET sd, HANDLE hFile, __int64 size)
{
	CZXCount zc(cl);

    DWORD len, nBytes, ret = 0;
    __int64 tatolsize = size, len_sent = 0;
	char buf[MAXBUFSIZE];

	DWORD ts = GetTickCount();
	DWORD te = 0;
    while(len_sent < size)
    {
		if(tatolsize < (__int64)MAXBUFSIZE)
			nBytes = tatolsize;
		else
			nBytes = MAXBUFSIZE;
		if(!ReadFile(hFile, buf, nBytes, &len, NULL))
			return len_sent;
		if(len == 0)
			break;
		//ret = DataSend(sd, buf, len);
		ret = __Send(sd, buf, len, -1);
		//TranMsg();
		//ret = len;
        if(ret != len || ret == 0)
        {
            return 0;
        }
        len_sent += len;
		tatolsize -= len;
		////////////
		mg_prg.done_FileSize += len;

		te = GetTickCount();
		if(te - ts >= 500)
		{
			ts = te;
			ProgressProc(pMsg->hwnd, WM_TRANSFER, 0, (LPARAM)&mg_prg);
		}
    }

	return len_sent;
}
