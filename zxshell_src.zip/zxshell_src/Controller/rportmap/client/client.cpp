#include <Winsock2.h>
#include <MSTcpIP.h>
#include "connMapList.h"
#include "client.h"
#include "..\..\..\zxsCommon\link.h"
#include ".\..\..\main.h"

void TranMsg();

CCREALPORTMAP::CCREALPORTMAP(SOCKET s)
{
	bindSocket = 0;
	ErrorCode = 0;
	connIndex = 0;
	m_socket = s;
	mapPort = 5200;
	hMainThread = NULL;
	memset(ErrorString, 0, 50);
	InitializeCriticalSection(&cs);
}

CCREALPORTMAP::~CCREALPORTMAP()
{
	DeleteCriticalSection(&cs);
}

void CCREALPORTMAP::SetProVersion(int ver)
{
	ProVer = ver;
}

void CCREALPORTMAP::XORData(char *p, int n)
{
	if(ProVer < 5)
		return;
	while(n--)
		*(p++) ^= 0x1985;
}

DWORD WINAPI CCREALPORTMAP::_udpconnThread(LPVOID lParam)
{
	CONNMAP *lpconnmap = (CONNMAP*)lParam;
	SOCKET s = lpconnmap->GetUDPSocket();
	CCREALPORTMAP *client = lpconnmap->client;

	int nRetVal;
	char RecvBuf[2048];
	PROHEADER *pPH;
	pPH = (PROHEADER *)RecvBuf;
	pPH->connID = lpconnmap->GetID();
	pPH->flag = 0x8B;

	struct	sockaddr_in SenderAddr;
	int		SenderAddrSize=sizeof(SenderAddr);


	while(lpconnmap->GetconnError() == 0)
	{
		if(SetTimeOut(s, -1) <= 0)
			break;

		nRetVal = recvfrom(s, RecvBuf+5, sizeof(RecvBuf)-5, 0, (struct sockaddr FAR *)&SenderAddr, &SenderAddrSize);
		if(nRetVal <= 0)
		{
			break;
		}
#if defined _TEST
		printf("recvfrom -> %s:%d len: %d\r\n", inet_ntoa(SenderAddr.sin_addr), ntohs(SenderAddr.sin_port), nRetVal);
#endif
		lpconnmap->SetUDPMode();
		lpconnmap->SetUDPAddress(SenderAddr.sin_addr.S_un.S_addr, ntohs(SenderAddr.sin_port));

		//////////////////////

		//������xor�򵥼���
		pPH->dataLength = nRetVal;
		if(! lpconnmap->client->Send(RecvBuf, nRetVal+5))
		{
			break;
		}
	}
#if defined _TEST
	printf("�ر�udp socket\r\n");
#endif

	//closesocket(s);
	return 0;
}

DWORD WINAPI CCREALPORTMAP::_connThread(LPVOID lParam)
{
	CONNMAP *lpconnmap = (CONNMAP*)lParam;
	SOCKET s = lpconnmap->GetSocket();
	CCREALPORTMAP *client = lpconnmap->client;

	int nRetVal;
	char RecvBuf[1460];
	PROHEADER *pPH;
	pPH = (PROHEADER *)RecvBuf;
	pPH->connID = lpconnmap->GetID();
	pPH->flag = 0x8B;

	if(!lpconnmap->SendCreateConn())
	{
		lpconnmap->SetconnError(1);
		closesocket(s);
		delete lpconnmap;
		return 1;
	}

	while(lpconnmap->GetconnError() == 0)
	{
		if(SetTimeOut(s, -1) <= 0)
			break;

		nRetVal = recv(s, RecvBuf+5, sizeof(RecvBuf)-5, 0);
		if(nRetVal <= 0)
		{
			break;
		}
		//�������ӵ���socks5������udpģʽ
		if(lpconnmap->MapSocksUDP(RecvBuf+5, nRetVal) == -1)
			break;

		//////////////////////

		//������xor�򵥼���
		pPH->dataLength = nRetVal;
		if(! lpconnmap->client->Send(RecvBuf, nRetVal+5))
		{
			break;
		}
	}

	closesocket(s);
	//if udp mode is setted, close the udp socket
	lpconnmap->shutUDPsocket();
	lpconnmap->SendError();
	client->DelConn(pPH->connID);

	delete lpconnmap;

	return 0;
}

BOOL CCREALPORTMAP::udpconnThread(CONNMAP *lpconnmap)
{
	DWORD dwThread;
	HANDLE hThread;
	hThread = CreateThread(NULL, 0, _udpconnThread, (LPVOID)lpconnmap, 0, &dwThread);
	if(hThread)
	{
		lpconnmap->SetThreadHandle(hThread);//����Ժ�����
		//CloseHandle(hThread);
		return TRUE;
	}else
	{
		return FALSE;
	}
}

BOOL CCREALPORTMAP::connThread(CONNMAP *lpconnmap)
{
	DWORD dwThread;
	HANDLE hThread;
	hThread = CreateThread(NULL, 0, _connThread, (LPVOID)lpconnmap, 0, &dwThread);
	if(hThread)
	{
		//lpconnmap->SetThreadHandle(hThread);
		CloseHandle(hThread);//���û����
		return TRUE;
	}else
	{
		return FALSE;
	}
}

char *CCREALPORTMAP::GetPeerIP()
{
	struct sockaddr_in client;
	int structsize=sizeof(struct sockaddr);

	if(getpeername(m_socket, (struct sockaddr *)&client, &structsize)<0)
		return "Unknown";
	else
		return inet_ntoa(client.sin_addr);
}

void CCREALPORTMAP::DelConn(WORD Id)
{
	m_connmaplist.DelConnById(Id);
}

BOOL CCREALPORTMAP::Send(char *buf, int len)
{
	EnterCriticalSection(&cs);

	BOOL ret = (DataSend(m_socket, buf, len) == len);

	LeaveCriticalSection(&cs);

	return ret;
}

DWORD WINAPI CCREALPORTMAP::_listenThread(LPVOID lParam)
{
	CCREALPORTMAP *_this = (CCREALPORTMAP*)lParam;

	while(1)
	{
		SOCKET s = DoAccept(_this->bindSocket, -1);
		if(s == INVALID_SOCKET)
			break;

		CONNMAP *lpconnmap = new CONNMAP(_this, _this->IncIndex(), s);
		if(lpconnmap == NULL)
		{
			closesocket(s);
			continue;
		}
		if(!_this->connThread(lpconnmap))
		{
			closesocket(s);//�������߳�ʧ�ܣ�ֱ�ӹرո���������
			delete lpconnmap;
		}else
		{
			//���뵽����
			_this->m_connmaplist.AddConn(lpconnmap);
		}

	}
	return 0;
}

BOOL CCREALPORTMAP::listenThread(CCREALPORTMAP *_this)
{
	DWORD dwThread;
	HANDLE hThread;

	bindSocket = CreateSocket(0, mapPort);

	if(!bindSocket)
	{
		_this->SetErrorCode(6);
		_this->SetErrorString("�򿪱��ض˿�ʧ��.\r\n");
		return FALSE;
	}

	hThread = CreateThread(NULL, 0, _listenThread, (LPVOID)_this, 0, &dwThread);
	if(hThread)
	{
		CloseHandle(hThread);
		return TRUE;
	}else
	{
		_this->SetErrorCode(7);
		_this->SetErrorString("�����߳�ʧ��.\r\n");
		return FALSE;
	}
}


BOOL CCREALPORTMAP::mainThread()
{
	DWORD dwThread;
	HANDLE hThread;
	hThread = CreateThread(NULL, 0, _mainThread, (LPVOID)this, 0, &dwThread);
	if(hThread)
	{
		SetThreadHandle(hThread);
		return TRUE;
	}else
	{
		SetErrorCode(7);
		SetErrorString("�����߳�ʧ��.\r\n");
		return FALSE;
	}
}

DWORD WINAPI CCREALPORTMAP::_mainThread(LPVOID lParam)
{
	CCREALPORTMAP * _this = (CCREALPORTMAP *)lParam;
	SOCKET m_socket = _this->GetSocket();

	PROHEADER PH;
	char RecvBuf[64*1024];
#if !defined _TEST
	DWORD ret;
	ret = TurnOnKeepAlive(m_socket, 80*1000, 5000);
#endif
	while(1)
	{
		if(! RecvMessage(m_socket, (char*)&PH, 5, -1))
		{
			//error
			//printf("�������ӳ���\r\n");
			_this->SetErrorCode(1);
			_this->SetErrorString("�������ӳ���\r\n");
			break;
		}
		if(PH.flag != PRO_FLAG)
		{
			//Э���
			_this->SetErrorCode(2);
			_this->SetErrorString("Э���\r\n");
			break;
		}
		if(PH.dataLength != 0 && PH.dataLength != 0xFFFF)
		{
			if(! RecvMessage(m_socket, RecvBuf, PH.dataLength, -1))
			{
				_this->SetErrorCode(1);
				_this->SetErrorString("�������ӳ���\r\n");
				break;
			}
			//xor��ԭ����
		}
		CONNMAP *lpconnmap = _this->m_connmaplist.GetConnMapFromList(PH.connID);

		if(lpconnmap == NULL)//��Ч���ݣ�����
			continue;

		//����λ��Ч�������յ��ر�������Ϣ
		if(PH.dataLength == 0xFFFF || PH.dataLength == 0)
		{
			lpconnmap->SetconnError(4);//��ʾ����֪ͨ��һ��
			lpconnmap->Close();
		}else
		{
			if(lpconnmap->GetconnError() == 0)
			{
				if(!lpconnmap->RecvData(RecvBuf, PH.dataLength))
				{
					//ת��ʧ�ܣ��ر�����
					lpconnmap->Close();
					
				}
			}
		}

	}
	return 0;
}

BOOL CCREALPORTMAP::SendConfigInfo(char *szIP, WORD wPort)
{
	_TARGET addr;
	strcpy(addr.szIP, szIP);
	addr.wPort = wPort;
	BOOL ret = Send((char*)&addr, sizeof(addr));
	if(!ret)
	{
		SetErrorCode(1);
		SetErrorString("�������ӳ���, �޷�����ӳ������\r\n");
		return FALSE;
	}
	return TRUE;
}

void CCREALPORTMAP::wait()
{
	WaitForSingleObject(hMainThread, -1);
	CloseHandle(hMainThread);
}

int CCREALPORTMAP::stop()
{
	int ret = 1;
	m_connmaplist.CloseAllSocket();
	//�ȴ��������Ӷ������ٲ��ܰ�ȫ�˳�
	DWORD timeout = GetTickCount();
	while(m_connmaplist.GetCount() > 0)
	{
		Sleep(2);
#if !defined _TEST
		TranMsg();
#endif
		if(GetTickCount() - timeout > 15*1000){
			ret = 0;
			break;
		}
	}
	closesocket(bindSocket);
	closesocket(m_socket);

	return ret;
}

int CCREALPORTMAP::start()
{
	SetErrorCode(0);


	return mainThread();
}