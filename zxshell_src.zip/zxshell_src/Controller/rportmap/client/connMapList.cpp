#include <Winsock2.h>
#include "client.h"
#include "connMapList.h"
#include "common.h"
#include "connmap.h"
#include "..\..\..\zxsCommon\link.h"

CONNMAP::CONNMAP(CCREALPORTMAP *clt, WORD id, SOCKET s)
{
	socks5udp = 0;
	sock_req = 0;
	connID = id;
	m_socket = s;
	udp_sock = 0;
	connState = 0;
	client = clt;
	handleThread = NULL;
}

WORD CONNMAP::GetID()
{
	return connID;
}

SOCKET CONNMAP::GetSocket()
{
	return m_socket;
}

SOCKET CONNMAP::GetUDPSocket()
{
	return udp_sock;
}

int CONNMAP::GetconnError()
{
	return connState;
}

void CONNMAP::SetconnError(int code)
{
	connState = code;
}

void CONNMAP::SetThreadHandle(HANDLE hThread)
{
	handleThread = hThread;
}

BOOL CONNMAP::SendCreateConn()
{
	PROHEADER PH;
	PH.flag = 0x8B;//��־��
	PH.connID = connID;//�����Ӵ���
	PH.dataLength = 0;//�½�������
	return client->Send((char*)&PH, 5);
}

void CONNMAP::SendError()
{
	if(GetconnError() == 4)
		return;
	PROHEADER PH;
	PH.flag = 0x8B;
	PH.connID = connID;
	PH.dataLength = 0xFFFF;//bye
	client->Send((char*)&PH, 5);
}

int CONNMAP::MapSocksUDP(char *DataBuf, int DataLen)
{
	if(socks5udp == 1)
		return -1;
	if(sock_req < 0xB0)
	{
		if(sock_req == 0)
		{
			if(DataBuf[0] == 0x05 && DataLen==(DataBuf[1]+2))
			{
				sock_req++;
			}
			else
				sock_req = 0xff;
		}
		else if(sock_req == 1)
		{
			if(DataBuf[0] == 0x01)
			{
				sock_req++;
			}
			else if(DataBuf[0] == 0x05 && DataBuf[1] == 0x03 && DataBuf[2] == 0x00)
			{
				if((DataBuf[3] == 1 && DataLen==10)
					||
					(DataBuf[3] == 3 && DataLen==(7+DataBuf[4]))
					)
				{
					sock_req = 0xc1;//��־��
				}else
				{
					sock_req = 0xff;
				}

			}
			else
				sock_req = 0xff;
		}
		else if(sock_req == 2)
		{
			if(DataBuf[0] == 0x05 && DataBuf[1] == 0x03 && DataBuf[2] == 0x00)
			{
				if((DataBuf[3] == 1 && DataLen==10)
					||
					(DataBuf[3] == 3 && DataLen==(7+DataBuf[4])))
				{
					sock_req = 0xc1;
					udp_dwip = *(DWORD*)(&DataBuf[4]);
					udp_port = ntohs(*(WORD*)(&DataBuf[8]));
				}else
				{
					sock_req = 0xff;
				}

			}
			else
				sock_req = 0xff;
		}


	}
	return 0;
}

BOOL CONNMAP::RecvData(char *DataBuf, int DataLen)
{
	if(sock_req == 0xc1)//socks5������UDP IP�˿ڻ�Ӧ��
	{
		if(DataBuf[0]==0x05 && DataBuf[1]==0x00 && DataBuf[2]==0x00)
		{
			if((DataBuf[3] == 1 && DataLen==10)
				||
				(DataBuf[3] == 3 && DataLen==(7+DataBuf[4]))
				)
			{
				//�����޸İ�
				DataBuf[3] = 1;//dwip
				DataLen = 10;
				udp_sock = CreateUDPSocket((DWORD*)&DataBuf[4], (WORD*)&DataBuf[8]);
				if(!udp_sock)
					return FALSE;
				if(!client->udpconnThread(this))
					return FALSE;
			}
		}
		sock_req = 0xff;
	}
	//udp
	if(socks5udp == 1)
	{
		return UDPSend(udp_sock, DataBuf, DataLen, udp_dwip, udp_port) == DataLen;
	}else
	{
		//tcp
		return DataSend(m_socket, DataBuf, DataLen) == DataLen;
	}
}

int CONNMAP::shutUDPsocket()
{
	if(udp_sock != 0)
	{
		closesocket(udp_sock);
		WaitForSingleObject(handleThread, -1);//�ȴ�udpת���߳��˳�
		CloseHandle(handleThread);
		return 1;
	}
	return 0;
}
	
void CONNMAP::SetUDPMode()
{
	if(socks5udp == 0)
		socks5udp = 1;
}

void CONNMAP::SetUDPAddress(DWORD dwIP, WORD wPort)
{
	udp_dwip = dwIP;
	udp_port = wPort;
}

void CONNMAP::Close()
{
	SetconnError(1);
	shutdown(m_socket, SD_BOTH);
	//SendError();
	//WaitForSingleObject(handleThread, -1);
	//CloseHandle(handleThread);
}
/////////////////////////////////////////////////


C_CONNMAPLIST::C_CONNMAPLIST()
{
	InitializeCriticalSection(&cs);
}

C_CONNMAPLIST::~C_CONNMAPLIST()
{
	DeleteCriticalSection(&cs);
}

int C_CONNMAPLIST::AddConn(CONNMAP *pcm)
{
	EnterCriticalSection(&cs);
	int ret = Add(pcm);
	LeaveCriticalSection(&cs);
	return ret;
}

int C_CONNMAPLIST::DelConnById(WORD Id)
{
	int ret = 0;
	EnterCriticalSection(&cs);
	_Node<CONNMAP*> *curr = Head;
	for(int n=0; n<Count; n++)
	{
		if(curr->data->GetID() == Id)
		{
			//delete curr->data;//��ÿ���߳̽�����ʱ��ɾ����
			Delp(curr);
			ret = 1;
			break;
		}
		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);
	return ret;
}

CONNMAP *C_CONNMAPLIST::GetConnMapFromList(WORD Id)
{
	CONNMAP *ponnmap = NULL;
	EnterCriticalSection(&cs);
	_Node<CONNMAP*> *curr = Head;
	for(int n=0; n<Count; n++)
	{
		if(curr->data->GetID() == Id)
		{
			ponnmap = curr->data;
			break;
		}
		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);
	return ponnmap;
}

void C_CONNMAPLIST::CloseAllSocket()
{
	EnterCriticalSection(&cs);
	_Node<CONNMAP*> *curr = Head;
	for(int n=0; n<Count; n++)
	{
		curr->data->SetconnError(4);
		shutdown(curr->data->GetSocket(), SD_BOTH);
		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);
}