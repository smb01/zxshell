#include <winsock2.h>
#include "client.h"
#include <windows.h>
#include <stdio.h>
#include <MSTcpIP.h>

#pragma comment(lib, "ws2_32.lib")


BOOL TurnOnKeepAlive(SOCKET s, int time, int interval)
{
	//KeepAliveʵ��
	tcp_keepalive inKeepAlive = {0}; //�������
	unsigned long ulInLen = sizeof(tcp_keepalive); 
	
	tcp_keepalive outKeepAlive = {0}; //�������
	unsigned long ulOutLen = sizeof(tcp_keepalive); 
	
	unsigned long ulBytesReturn = 0; 
	
	//����socket��keep aliveΪ5�룬���ҷ��ʹ���Ϊ3��
	inKeepAlive.onoff = 1; 
	inKeepAlive.keepaliveinterval = interval; //����KeepAlive̽����ʱ����
	inKeepAlive.keepalivetime = time; //��ʼ�״�KeepAlive̽��ǰ��TCP�ձ�ʱ��
	
	if (WSAIoctl((unsigned int)s, SIO_KEEPALIVE_VALS,
		(LPVOID)&inKeepAlive, ulInLen,
		(LPVOID)&outKeepAlive, ulOutLen,
		&ulBytesReturn, NULL, NULL) == SOCKET_ERROR) 
	{ 
		return FALSE;
	}
	
	return TRUE;
}

char *GetInetIP(char *OutIP)
{
	// Get host adresses
	char addr[16];
	struct hostent * pHost; 
	pHost = gethostbyname(""); 
	for( int i = 0; pHost!= NULL && pHost->h_addr_list[i]!= NULL; i++ ) 
	{
		OutIP[0]=0;
		for( int j = 0; j < pHost->h_length; j++ ) 
		{
			if( j > 0 ) strcat(OutIP,".");
			sprintf(addr,"%u", (unsigned int)((unsigned char*)pHost->h_addr_list[i])[j]);
			strcat(OutIP,addr);
		}
	}
	return OutIP;
}

SOCKET CreateUDPSocket(DWORD *LPIP, WORD *LPPort)
{
	char szIP[32];
	struct sockaddr_in 	UDPServer;
	struct sockaddr_in  in;
	memset(&in,0,sizeof(sockaddr_in));
	int structsize=sizeof(sockaddr_in);
	UDPServer.sin_family=AF_INET;
	UDPServer.sin_addr.s_addr= inet_addr(GetInetIP(szIP));
	UDPServer.sin_port=INADDR_ANY;
	SOCKET Locals = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if(Locals == SOCKET_ERROR)
	{
		//printf("UDP socket create failed.\n");
		return 0;
	}
	if(bind(Locals,(SOCKADDR*)&UDPServer, sizeof(UDPServer)) == SOCKET_ERROR)
	{
		//printf("UDP socket bind failed.\n");
		return 0;
	}
	getsockname(Locals,(struct sockaddr *)&in,&structsize);

	if(LPIP)
		*LPIP = in.sin_addr.s_addr;
	if(LPPort)
		*LPPort = in.sin_port;

#if defined _TEST
	printf("UDP Bound to %s:%d\r\n", szIP, ntohs(in.sin_port));
#endif
	return Locals;
}

int UDPSend(SOCKET s, char *buff, int nBufSize, DWORD dwIP, WORD wPort)
{
	int nBytesLeft = nBufSize;
	int idx = 0, nBytes = 0;
	int iMode = 0;
	ioctlsocket(s, FIONBIO, (u_long FAR*) &iMode);

	struct sockaddr_in 	addrin;
	memset(&addrin,0,sizeof(sockaddr_in));

	addrin.sin_family = AF_INET;
	addrin.sin_addr.s_addr = dwIP;
	addrin.sin_port = htons(wPort);

#if defined _TEST
	printf("UDPSend -> %s:%d\r\n", inet_ntoa(addrin.sin_addr), wPort);
#endif

	while(nBytesLeft > 0)
	{
		nBytes = sendto(s, &buff[idx], nBytesLeft, 0, (SOCKADDR *)&addrin, sizeof(addrin));
		if(nBytes == SOCKET_ERROR) 
		{
			//printf("Failed to send buffer to socket %d.\r\n", WSAGetLastError());
			return SOCKET_ERROR;
		}
		nBytesLeft -= nBytes;
		idx += nBytes;
	}
	return idx;
}

int SetTimeOut(SOCKET Socket,int nTimeOut)
{   
	fd_set FdRead;
	struct timeval TimeOut;
	FD_ZERO(&FdRead);
	FD_SET(Socket,&FdRead);
	TimeOut.tv_sec  = nTimeOut;
	TimeOut.tv_usec = 0;
	return select(Socket+1,&FdRead,NULL,NULL,(nTimeOut == -1)?NULL:&TimeOut);
}

int RecvMessage(SOCKET Socket, char *RecvBuf, int DataLen, int TimeOut_sec)
{
	int nRetVal, TotalBytesRecv = 0;
	while(TotalBytesRecv < DataLen)
	{
		if(SetTimeOut(Socket, TimeOut_sec) <= 0)
			return 0;
		nRetVal = recv(Socket, RecvBuf+TotalBytesRecv, DataLen-TotalBytesRecv, 0);
		if(nRetVal <= 0)
			return 0;
		else
			TotalBytesRecv += nRetVal;
	}
	return DataLen == TotalBytesRecv;
}


int DataSend(SOCKET s, char *DataBuf, int DataLen)//��DataBuf�е�DataLen���ֽڷ���sȥ
{
	int nBytesLeft = DataLen;
	int nBytesSent = 0;
	int ret;
	//set socket to blocking mode
	int iMode = 0;
	ioctlsocket(s, FIONBIO, (u_long FAR*) &iMode);
	while(nBytesLeft > 0)
	{
		ret = send(s, DataBuf + nBytesSent, nBytesLeft, 0);
		if(ret <= 0)
			break;
		nBytesSent += ret;
		nBytesLeft -= ret;
	}
	return nBytesSent;
}


SOCKET ConnectHost(DWORD dwIP, WORD wPort)//����ָ��IP�Ͷ˿�
{
	SOCKET sockid;

	if ((sockid = socket(PF_INET, SOCK_STREAM,IPPROTO_TCP)) == INVALID_SOCKET)
		return 0;
	struct sockaddr_in srv_addr;
	srv_addr.sin_family = AF_INET;
	srv_addr.sin_addr.S_un.S_addr = dwIP;
	srv_addr.sin_port = htons(wPort);
	if (connect(sockid,(struct sockaddr*)&srv_addr,sizeof(struct sockaddr_in)) == SOCKET_ERROR)
		goto error;
	return sockid;
error:
	closesocket(sockid);
	return 0;
}

char *DNS(char *HostName)
{
	HOSTENT *hostent = NULL;
	IN_ADDR iaddr;
	hostent = gethostbyname(HostName);
	if (hostent == NULL)
	{
		return NULL;
	}
	iaddr = *((LPIN_ADDR)*hostent->h_addr_list);
	return inet_ntoa(iaddr);
}

SOCKET ConnectHost(char *szIP, WORD wPort)
{
	if (inet_addr(szIP) != INADDR_NONE)
		return ConnectHost(inet_addr(szIP), wPort);
	else
	{
		if (DNS(szIP) != NULL)
			return ConnectHost(inet_addr(DNS(szIP)), wPort);
		else
			return 0;
	}
}

SOCKET CreateSocket(DWORD dwIP, WORD wPort)//��dwIP�ϰ�wPort�˿�
{
	SOCKET sockid;

	if ((sockid = socket(PF_INET, SOCK_STREAM,IPPROTO_TCP)) == INVALID_SOCKET)
		return 0;
	struct sockaddr_in srv_addr = {0};
	srv_addr.sin_family = AF_INET;
	srv_addr.sin_addr.S_un.S_addr = dwIP;
	srv_addr.sin_port = htons(wPort);
	if (bind(sockid,(struct sockaddr*)&srv_addr,sizeof(struct sockaddr_in)) == SOCKET_ERROR)
		goto error;
	if (listen(sockid,3) == SOCKET_ERROR)
		goto error;
	return sockid;
error:
	closesocket(sockid);
	return 0;
}

SOCKET CreateTmpSocket(WORD *wPort)//����һ����ʱ���׽���,ָ��wPort��ô�������ʱ�˿�
{
	struct sockaddr_in srv_addr = {0};
	int addrlen = sizeof(struct sockaddr_in);

	SOCKET s = CreateSocket(INADDR_ANY, 0);
	if(s <= 0)
		goto error;

	if(getsockname(s, (struct sockaddr*)&srv_addr, &addrlen) == SOCKET_ERROR)
		goto error;
	*wPort = ntohs(srv_addr.sin_port);
	return s;
error:
	closesocket(s);
	return 0;
}

BOOL InitSock()
{
	WSADATA wsadata;
	return WSAStartup(MAKEWORD(2,2),&wsadata) == 0;
}

SOCKET DoAccept(SOCKET s, int nTimeOut)
{
	int iMode = 1;//nonzero
	ioctlsocket(s, FIONBIO, (u_long FAR*) &iMode);//Enabled Nonblocking Mode

	struct timeval TimeOut;
	fd_set FdRead;
	FD_ZERO(&FdRead);
	FD_SET(s,&FdRead);
	TimeOut.tv_sec  = nTimeOut;//12 sec
	TimeOut.tv_usec = 0;
	if(select(s+1, &FdRead, NULL, NULL, nTimeOut==-1 ? NULL : &TimeOut) <= 0)//����accept��ʱ
		return 0;
	return accept(s, NULL, NULL);
}


int main(int argc, char **argv)
{
	if(argc < 3)
	{
		printf("%s dataport listenport\r\n", argv[0]);
		return 1;
	}

	InitSock();
	
	WORD mapPort = atoi(argv[2]);

	printf("listening......");

	SOCKET ls = CreateSocket(0, atoi(argv[1]));
	SOCKET s = DoAccept(ls, -1);

	if(s != INVALID_SOCKET)
		printf("ok\r\n");
	else
		printf("error\r\n");

	CCREALPORTMAP crmp(s);

	crmp.SetMapPort(mapPort);

	if(!crmp.listenThread(&crmp))
	{
		return 0;
	}

	crmp.start();

	crmp.wait();

	if(crmp.GetErrorCode())
		printf(crmp.GetErrorString());

	return 0;
}