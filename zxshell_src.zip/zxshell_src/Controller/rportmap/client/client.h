#ifndef C_MAPCLIENT_H
#define C_MAPCLIENT_H

#include "connMapList.h"
#include "common.h"

class CCREALPORTMAP
{
private:
	SOCKET m_socket;
	WORD mapPort;
	WORD connIndex;
	HANDLE hMainThread;
	char ErrorString[50];
	DWORD ErrorCode;
	int ProVer;
public:
	//REALPORTMAP();
	CCREALPORTMAP(SOCKET s);
	~CCREALPORTMAP();
	CRITICAL_SECTION cs;
	C_CONNMAPLIST m_connmaplist;
	SOCKET bindSocket;

public:
	void SetProVersion(int ver);
	void XORData(char *p, int n);

	DWORD GetConnCount(){ return m_connmaplist.GetCount();}
	DWORD GetErrorCode(){ return ErrorCode;}
	void SetErrorCode(DWORD code){ ErrorCode = code;}
	char *GetErrorString(){ return ErrorString;}
	void SetErrorString(char *str){ strcpy(ErrorString, str);}

	void SetThreadHandle(HANDLE hThread){hMainThread = hThread;}

	BOOL mainThread();
	static DWORD WINAPI _mainThread(LPVOID lParam);

	WORD GetMapPort(){ return mapPort;}
	WORD SetMapPort(WORD wPort){ mapPort = wPort; return mapPort;}
	SOCKET GetSocket(){ return m_socket;}
	WORD IncIndex(){ return connIndex++;}
	char *GetPeerIP();
	BOOL SendConfigInfo(char *szIP, WORD wPort);

	BOOL udpconnThread(CONNMAP *lpconnmap);
	BOOL connThread(CONNMAP *lpconnmap);
	static DWORD WINAPI _udpconnThread(LPVOID lParam);
	static DWORD WINAPI _connThread(LPVOID lParam);
	static DWORD WINAPI _listenThread(LPVOID lParam);
	BOOL listenThread(CCREALPORTMAP *_this);
	BOOL Send(char *buf, int len);
	void DelConn(WORD Id);
	int start();
	int stop();
	void wait();
};

#endif