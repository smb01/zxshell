#ifndef C_CONNMAPLIST_H
#define C_CONNMAPLIST_H

#include <windows.h>
#include "..\..\..\zxsCommon\link.h"
#include "connmap.h"


class C_CONNMAPLIST:public LINKTABLE<CONNMAP*>
{
protected:
	CRITICAL_SECTION cs;
public:
	C_CONNMAPLIST();
	~C_CONNMAPLIST();

	int AddConn(CONNMAP *pcm);
	int DelConnById(WORD Id);
	CONNMAP *GetConnMapFromList(WORD Id);
	void CloseAllSocket();

};

#endif