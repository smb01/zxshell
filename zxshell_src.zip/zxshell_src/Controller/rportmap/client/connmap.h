#ifndef C_CONNMAP_H
#define C_CONNMAP_H


#include <windows.h>

class CCREALPORTMAP;

class CONNMAP
{
public:
	CCREALPORTMAP *client;

public:
	CONNMAP(CCREALPORTMAP *clt, WORD id, SOCKET s);

	int MapSocksUDP(char *DataBuf, int DataLen);
	WORD GetID();
	SOCKET GetSocket();
	SOCKET GetUDPSocket();
	int GetconnError();
	void SetconnError(int code);
	BOOL RecvData(char *DataBuf, int DataLen);
	void SendError();
	BOOL SendCreateConn();
	void Close();
	void SetThreadHandle(HANDLE hThread);
	int shutUDPsocket();
	void SetUDPMode();
	void SetUDPAddress(DWORD dwIP, WORD wPort);


public:
	BYTE sock_req;
	BYTE socks5udp;

private:
	HANDLE handleThread;
	int connState;
	WORD connID;
	SOCKET m_socket;

	DWORD udp_dwip;
	WORD udp_port;
	SOCKET udp_sock;
};

#endif