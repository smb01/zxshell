extern int SendMessage(SOCKET Socket, const char *fmt, ...);
extern MAIN Main;

int SetTimeOut(SOCKET Socket,int nTimeOut)
{   
	fd_set FdRead;
	struct timeval TimeOut;
	FD_ZERO(&FdRead);
	FD_SET(Socket,&FdRead);
	TimeOut.tv_sec  = nTimeOut;
	TimeOut.tv_usec = 0;
	return select(Socket+1,&FdRead,NULL,NULL,(nTimeOut == -1)?NULL:&TimeOut);
}


int DataSend(SOCKET s, char *DataBuf, int DataLen)//��DataBuf�е�DataLen���ֽڷ���sȥ
{
	int nBytesLeft = DataLen;
	int nBytesSent = 0;
	int ret;
	//set socket to blocking mode
	int iMode = 0;
	ioctlsocket(s, FIONBIO, (u_long FAR*) &iMode);
	while(nBytesLeft > 0)
	{
		ret = send(s, DataBuf + nBytesSent, nBytesLeft, 0);
		if(ret <= 0)
			break;
		nBytesSent += ret;
		nBytesLeft -= ret;
	}
	return nBytesSent;
}

BOOL WriteToFile(HANDLE hFile, char *Buff, int Datalen)
{
	DWORD nBytesLeft = Datalen;
	DWORD dwNumOfBytesWritten = 0;
	char *pBuf = Buff;
	while(nBytesLeft > 0) {
		if(!WriteFile(hFile, pBuf, nBytesLeft, &dwNumOfBytesWritten, NULL)) {
			return FALSE;
		}
		pBuf += dwNumOfBytesWritten;
		nBytesLeft -= dwNumOfBytesWritten;
	}
	return TRUE;
}


__int64 Transmitfile(SOCKET sd, HANDLE hFile, __int64 size)
{
    DWORD len, nBytes, ret = 0;
    __int64 tatolsize = size, len_sent = 0;
	char buf[MAXBUFSIZE];

    while(len_sent < size)
    {
		if(tatolsize < (__int64)MAXBUFSIZE)
			nBytes = tatolsize;
		else
			nBytes = MAXBUFSIZE;
		if(!ReadFile(hFile, buf, nBytes, &len, NULL))
			return len_sent;
		if(len == 0)
			break;
		ret = DataSend(sd, buf, len);
        if(ret != len || ret == 0)
        {
            return 0;
        }
        len_sent += len;
		tatolsize -= len;
		sprintf(buf, "    %.2d%%", len_sent*100/size);
		SetDlgItemText(Main.hWnd, IDC_TRANFILEPERCENT, buf);

    }

	return len_sent;
}


int SendFileData(SOCKET Socket, char *LocalFile)
{
	__int64 ret = -1;
	LARGE_INTEGER LI;

	HANDLE hFile = CreateFile(LocalFile, 
        GENERIC_READ, 
        FILE_SHARE_READ, 
        NULL, 
        OPEN_EXISTING, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		return ret;
	}

	if(!GetFileSizeEx(hFile, &LI))
		goto error;

	if((ret = Transmitfile(Socket, hFile, LI.QuadPart)) != LI.QuadPart)
		ret = -1;

error:
	CloseHandle(hFile);
	return ret;
}


BOOL IsReadability(char *LocalFile, __int64 *lpFileSize)
{
	BOOL fSuccess = FALSE;
	LARGE_INTEGER LI;
	HANDLE hFile = CreateFile(LocalFile, 
        GENERIC_READ, 
        FILE_SHARE_READ, 
        NULL, 
        OPEN_EXISTING, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		return FALSE;
	}
	if(GetFileSizeEx(hFile, &LI))
	{
		*lpFileSize = LI.QuadPart;
		fSuccess = TRUE;
	}

	CloseHandle(hFile);
	return fSuccess;
}

int UploadFile(SOCKET Socket, char *LocalFile, char *RemoteFile)
{
	__int64 ret = -1;
	LARGE_INTEGER LI;

	HANDLE hFile = CreateFile(LocalFile, 
        GENERIC_READ, 
        FILE_SHARE_READ, 
        NULL, 
        OPEN_EXISTING, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		return ret;
	}

	if(!GetFileSizeEx(hFile, &LI))
		goto error;

	SendMessage(Socket, "Upload %s %I64d\r\n", RemoteFile, LI.QuadPart);

error:
	CloseHandle(hFile);
	return ret;
}

BOOL IsWritable(char *LocalFile)
{
	HANDLE hFile = CreateFile(LocalFile, 
        GENERIC_WRITE, 
        FILE_SHARE_WRITE, 
        NULL, 
        CREATE_ALWAYS, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		return FALSE;
	}

	CloseHandle(hFile);
	return TRUE;
}

BOOL RecvFileData(SOCKET Socket, char *LocalFile, __int64 FileSize)
{
	int nRetVal, nBytes, fSuccess = TRUE;
	char RecvBuf[MAXBUFSIZE];
	__int64 TotalBytesRecv = 0;
	BOOL bError;

	HANDLE hFile = CreateFile(LocalFile, 
        GENERIC_WRITE, 
        FILE_SHARE_WRITE, 
        NULL, 
        CREATE_ALWAYS, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		return FALSE;
	}

	while(TotalBytesRecv < FileSize)
	{
		if(FileSize - TotalBytesRecv < (__int64)MAXBUFSIZE)
			nBytes = FileSize - TotalBytesRecv;
		else
			nBytes = MAXBUFSIZE;

		SetTimeOut(Socket, -1);
		nRetVal = recv(Socket, RecvBuf, nBytes, 0);
		if(nRetVal <= 0)
		{
			fSuccess = FALSE;
			break;
		}
		else
		{
			if(!WriteToFile(hFile, RecvBuf, nRetVal))
			{
				fSuccess = FALSE;
				break;
			}
			TotalBytesRecv += nRetVal;
		}
		sprintf(RecvBuf, "    %.2d%%", TotalBytesRecv*100/FileSize);
		SetDlgItemText(Main.hWnd, IDC_TRANFILEPERCENT, RecvBuf);
	}

exit:

    CloseHandle(hFile);
	return fSuccess;
}