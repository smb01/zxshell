#include "capViewerDlg.h"
#include "capViewer.h"



//�������ڴ�Сʱ�Կؼ�λ�õĵ���
BOOL CALLBACK capPositionChildProc(HWND hwndChild, LPARAM lParam) 
{ 
    RECT rcParent; 
	POINT ptMe;
	POINT ptMap;
	RECT rcMe;
	RECT rcMap, rcup,rcdown;
    int i, idChild;
	HWND hDlg = (HWND)lParam;

	int top_h, down_h;

	if(GetParent(hwndChild) != hDlg)
		return TRUE;
 
    // Retrieve the child-window identifier. Use it to set the 
    // position of the child window. 

	GetClientRect(hDlg, &rcParent);

	GetClientRect(GetDlgItem(hDlg, IDC_CAPDEVLIST), &rcdown);
	down_h = rcdown.bottom-rcdown.top;
	GetClientRect(GetDlgItem(hDlg, IDC_CAPERROR), &rcdown);
	down_h += rcdown.bottom-rcdown.top+15;

    idChild = GetWindowLong(hwndChild, GWL_ID); 
 
    if (idChild == IDC_CAPVIDEO) 
    {
  		GetWindowRect(hwndChild, &rcMap);
		ptMap.x = 0;
		ptMap.y = rcMap.top;
		ScreenToClient(hDlg, &ptMap);

		MoveWindow(hwndChild, 
				   1, 
				   1, 
				   rcParent.right-2, 
				   rcParent.bottom-rcParent.top-down_h,
				   TRUE); 

	}
    else if (idChild == IDC_LINE) 
    {
		GetWindowRect(hwndChild, &rcMe);
  		GetWindowRect(GetDlgItem(hDlg,IDC_CAPVIDEO), &rcMap);
		ptMe.x = rcMap.left;
		ptMe.y = rcMap.bottom;
		ScreenToClient(hDlg, &ptMe);

		MoveWindow(hwndChild, 
				   ptMe.x, 
				   ptMe.y+2,
				   rcMap.right-rcMap.left, 
				   2,
				   TRUE); 

	}  
	else if (idChild == IDC_CAPSTOP) 
    {
		GetWindowRect(hwndChild, &rcMe);
   		GetWindowRect(GetDlgItem(hDlg,IDC_LINE), &rcMap);
		ptMap.x = rcMap.right;
		ptMap.y = rcMap.bottom;

		ScreenToClient(hDlg, &ptMap);

		MoveWindow(hwndChild, 
				   ptMap.x-(rcMe.right-rcMe.left), 
				   ptMap.y+2, 
				   rcMe.right-rcMe.left, 
				   rcMe.bottom-rcMe.top, 
				   TRUE); 
  
	}
	else if (idChild == IDC_CAPSTART) 
    {
		GetWindowRect(hwndChild, &rcMe);
   		GetWindowRect(GetDlgItem(hDlg,IDC_CAPSTOP), &rcMap);
		ptMap.x = rcMap.left;
		ptMap.y = rcMap.top;

		ScreenToClient(hDlg, &ptMap);

		MoveWindow(hwndChild, 
				   ptMap.x-(rcMe.right-rcMe.left)-2, 
				   ptMap.y, 
				   rcMe.right-rcMe.left, 
				   rcMe.bottom-rcMe.top, 
				   TRUE); 
  
	}
    else if (idChild == IDC_CAPSSAVE)
    {   
  		GetWindowRect(hwndChild, &rcMe);
  		GetWindowRect(GetDlgItem(hDlg, IDC_CAPSTART), &rcMap);
		ptMap.x = rcMap.left;
		ptMap.y = rcMap.top;

		ScreenToClient(hDlg, &ptMap);

		MoveWindow(hwndChild, 
				   ptMap.x-(rcMe.right-rcMe.left)-2, 
				   ptMap.y, 
				   rcMe.right-rcMe.left, 
				   rcMe.bottom-rcMe.top, 
				   TRUE); 
	}
	else if (idChild == IDC_CAPDEVLIST) 
    {
		GetWindowRect(hwndChild, &rcMe);
   		GetWindowRect(GetDlgItem(hDlg,IDC_CAPSSAVE), &rcMap);
		ptMap.x = rcMap.left;
		ptMap.y = rcMap.top;

		ScreenToClient(hDlg, &ptMap);

		MoveWindow(hwndChild, 
				   1, 
				   ptMap.y, 
				   ptMap.x-5, 
				   rcMe.bottom-rcMe.top, 
				   TRUE); 
  
	}
	else if (idChild == IDC_CAPERROR)
    {
  		GetWindowRect(hwndChild, &rcMe);
  		GetWindowRect(GetDlgItem(hDlg,IDC_CMD), &rcMap);
		ptMe.x = rcMap.right;
		ptMe.y = rcMap.top;
		ScreenToClient(Main.hWnd, &ptMe);

		MoveWindow(hwndChild, 
				   1, 
				   rcParent.bottom-(rcMe.bottom-rcMe.top)-1, 
				   rcParent.right-rcParent.left-2, 
				   rcMe.bottom-rcMe.top, 
				   TRUE); 
	}

 	ShowWindow(hwndChild, SW_SHOW);

    return TRUE;
}

int capErrorSetText(HWND hDlg, char *Text)
{
	return SetWindowText(GetDlgItem(hDlg, IDC_CAPERROR), Text);
}

int capDoBlt(HWND hDlg, BYTE *lpDIB, BITMAPINFO *lpbi)
{

	RECT rect;
	HWND hCtrl = GetDlgItem(hDlg, IDC_CAPVIDEO);
	GetWindowRect(hCtrl, &rect);
	HDC hDC = GetWindowDC(hCtrl);

	if(rect.right-rect.left-4 == lpbi->bmiHeader.biWidth
		&& rect.bottom-rect.top-4 == lpbi->bmiHeader.biHeight
		)
	{
		SetStretchBltMode(hDC, COLORONCOLOR);
	}else
	{
		SetStretchBltMode(hDC, HALFTONE);
	}

	StretchDIBits(hDC, 2, 2, rect.right-rect.left-5, rect.bottom-rect.top-5,
		0, 0, lpbi->bmiHeader.biWidth, lpbi->bmiHeader.biHeight,
		lpDIB, lpbi, DIB_RGB_COLORS, SRCCOPY);

	ReleaseDC(hCtrl, hDC);
	return 1;
}

//����Ƶ���ӡ����ڴ�������
int CALLBACK RemoteCapDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	int ret=0;
	char szBuf[100];

	CcapViewer *pCapViewer = (CcapViewer*)GetWindowLong(hDlg, GWL_USERDATA);

	switch(uMsg)
	{
	case WM_INITDIALOG:
		{
		//�׽��ֲ��� lParam
		pCapViewer = new CcapViewer(lParam, hDlg);
		SetWindowLong(hDlg, GWL_USERDATA, (long)0);
		SetWindowLong(hDlg, GWL_USERDATA, (long)pCapViewer);//save a object

		HMENU hSysMenu = GetSystemMenu(hDlg, FALSE);
		AppendMenu(hSysMenu, MF_SEPARATOR, 0, 0);
		AppendMenu(hSysMenu, MF_STRING|MF_ENABLED, IDC_CONNINFO, "������Ϣ");

		sprintf(szBuf, "��Ƶ���� \\\\%s", GetPeerIPStr(lParam));
		SetWindowText(hDlg, szBuf);

		HICON hCapIcon;
		
		hCapIcon = LoadIcon(Main.hInst, MAKEINTRESOURCE(IDI_CAPICON));
		SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hCapIcon);
		SendMessage(hDlg, WM_SETICON, ICON_BIG, (LPARAM)hCapIcon);

		EnableWindow(GetDlgItem(hDlg, IDC_CAPSTART), FALSE);
		EnableWindow(GetDlgItem(hDlg, IDC_CAPSTOP), FALSE);

		if(pCapViewer->start())
		{
			capErrorSetText(hDlg, "���ڶ�ȡԶ����Ƶ�豸...");
		}else
		{
			capErrorSetText(hDlg, "��Ƶ���� ����ʧ��.");
		}

		PostMessage(hDlg, WM_SIZE, 0, 0);
		SetForegroundWindow(hDlg);

		}
		return TRUE;

	case WM_SIZE:
	case WM_SIZING:
	{
		EnumChildWindows(hDlg, capPositionChildProc, (LPARAM) hDlg); 
		break;
	}

	case CAP_READY:
		{
			//add video devices into comboxlist

			CAPDRV *pcd = NULL;
			char drvinfo[256]="\0";
			
			while(pcd = pCapViewer->capDrivers.GetNextDriver())
			{
				sprintf(drvinfo, "%d. %s (%s)",
					pCapViewer->capDrivers.GetIndex(),
					pcd->szDeviceName,
					pcd->szDeviceVersion);

				SendMessage(GetDlgItem(hDlg, IDC_CAPDEVLIST), CB_INSERTSTRING, 0, LPARAM(drvinfo));
			}
			//
			EnableWindow(GetDlgItem(hDlg, IDC_CAPSTART), TRUE);
			capErrorSetText(hDlg, "��ѡ���б��е��豸��[��ʼ].");

			SetFocus(GetDlgItem(hDlg, IDC_CAPDEVLIST));
		}
		break;
	case CAP_NOCAPDEV:
		{
			capErrorSetText(hDlg, "Զ�̼����û����Ƶ�豸.");
		}
		break;

	case WM_PAINT:
	//case CAP_DOBLT:
		{
			if(!pCapViewer->GetDibBuf() || !pCapViewer->GetBmpInfo())
				return 0;

			RECT rect;
			PAINTSTRUCT paint;

			if( GetUpdateRect(hDlg, &rect, FALSE) == FALSE)
				return 0;

			BeginPaint(hDlg, &paint);

			capDoBlt(hDlg, 
				pCapViewer->GetDibBuf(),
				pCapViewer->GetBmpInfo()
				);

			EndPaint(hDlg, &paint);
		}
		return DefWindowProc(hDlg, uMsg, wParam, lParam);

	case CAP_STOPPED:
		{
			EnableWindow(GetDlgItem(hDlg, IDC_CAPSTOP), FALSE);
			EnableWindow(GetDlgItem(hDlg, IDC_CAPSTART), TRUE);
			capErrorSetText(hDlg, "��Ƶ���ӳɹ�ֹͣ.");
		}
		break;
	case CAP_ERROR:
		{
			capErrorSetText(hDlg, "Զ����Ƶ�豸����.");
		}
	case CAP_QUIT:
		{
			capErrorSetText(hDlg, "�����Զ���豸����, ���˳�");
		}
		break;

	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDC_CAPSSAVE:
			{
				if(!pCapViewer->GetDibBuf() || !pCapViewer->GetBmpInfo())
					return 0;
				SYSTEMTIME stm;
				GetLocalTime(&stm);
				TCHAR szFileName[MAX_PATH];
				sprintf(
					szFileName,
					"%04u.%02u.%02u-%02u-%02u-%02u.bmp",
					stm.wYear, stm.wMonth, stm.wDay,
					stm.wHour, stm.wMinute, stm.wSecond
					);

				if(GetSavePath(hDlg, "BMP Files (*.BMP)\0*.BMP\0\0", "��Ƶ���ӡ�ͼ�񱣴�Ϊ...", szFileName))
				{
					char *pext = strstr(szFileName, ".bmp");
					if(!pext || pext[4])
						strcat(szFileName, ".bmp");
					bDbgBmDump(szFileName, 
						pCapViewer->GetDibBuf(),
						pCapViewer->GetBmpInfo());
				}
			}
			break;
		case IDC_CAPSTART:
			{
				//get idx from combox list
				char drvinfo[256]="\0";
				int capIdx=0;

				int idx = SendDlgItemMessage(hDlg, IDC_CAPDEVLIST, CB_GETCURSEL, 0, 0);
				if(idx== CB_ERR)
				{
					capErrorSetText(hDlg, "��ѡ���б��е��豸��[��ʼ].");
					return 0;
				}
				SendDlgItemMessage(hDlg, IDC_CAPDEVLIST, CB_GETLBTEXT, idx, (LPARAM)drvinfo);

				capIdx = atoi(drvinfo);

				if(pCapViewer->SetCapDevice(capIdx) && !pCapViewer->bRoutineExited())
				{
					EnableWindow(GetDlgItem(hDlg, IDC_CAPSTART), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_CAPSTOP), TRUE);

					capErrorSetText(hDlg, "��ʼ��������...");
				}else
				{
					capErrorSetText(hDlg, "ʧ��.");
				}
			}
			return TRUE;

		case IDC_CAPSTOP:
			if(pCapViewer->CaptureStop() && !pCapViewer->bRoutineExited())
			{
				capErrorSetText(hDlg, "������ָͣ��...");
			}else
			{
				capErrorSetText(hDlg, "������ָͣ��ʧ��.");
			}

			return TRUE;

		}
		break;

	case WM_SYSCOMMAND:
		switch(wParam)
		{
		case IDC_CONNINFO:
			{
				DialogBoxParam(Main.hInst, (LPCTSTR)IDD_CONNINFO, hDlg, (DLGPROC)ConnInfoDlgProc, pCapViewer->GetSocket());
			}
			break;

		case SC_MAXIMIZE:
			{
				//����󻯰�ťʱ�����ڴ�С����Ϊͼ��ԭʼ��С��ֵ
				BITMAPINFO *lpbi = pCapViewer->GetBmpInfo();

				if(lpbi == NULL)
					return 0;
				if(!pCapViewer->GetDibBuf())
					return 0;

				RECT windowrt, rect;
				int width,height;

				HWND hCtrl = GetDlgItem(hDlg, IDC_CAPVIDEO);
				GetWindowRect(hCtrl, &rect);

				GetWindowRect(hDlg, &windowrt);

				width = (windowrt.right-windowrt.left)+(lpbi->bmiHeader.biWidth-(rect.right-rect.left-4));
				height = (windowrt.bottom-windowrt.top)+(lpbi->bmiHeader.biHeight-(rect.bottom-rect.top-4));

				SetWindowPos(hDlg, HWND_TOP, windowrt.left, windowrt.top,
								width,
								height, SWP_SHOWWINDOW);

				return TRUE;
			}
			break;
			
		case SC_CLOSE:
			{
				capErrorSetText(hDlg, "�����˳���......");
				if(pCapViewer->stop())
				{
					delete pCapViewer;
					EndDialog(hDlg, LOWORD(wParam));
				}
				return TRUE;
			}
			break;
		}
	}
	return FALSE;
}