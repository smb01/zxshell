#if !defined _CAPVIEWERDLG
#define _CAPVIEWERDLG


#include "..\main.h"
#include "..\res\resource.h"

#define CAP_MSG WM_USER+1

#define CAP_READY	CAP_MSG+0
#define CAP_NOCAPDEV	CAP_MSG+1
#define CAP_DOBLT	CAP_MSG+2
#define CAP_STOPPED	CAP_MSG+3
#define CAP_ERROR	CAP_MSG+4

#define CAP_QUIT	CAP_MSG+5

int CALLBACK RemoteCapDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);


#endif