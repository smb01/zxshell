#include "capViewer.h"
#include "capViewerDlg.h"
#include "..\..\zxsCommon\debugoutput.h"


capDrvDes::capDrvDes()
{
	idx = 0;
	capIndex = 0;
}

capDrvDes::~capDrvDes()
{

}

CAPDRV * capDrvDes::GetNextDriver()
{
	if(idx > 9)
		idx = 0;

	while(!capDrv[idx].bExisted)
	{
		if(++idx > 9)
		{
			idx = 0;
			return NULL;
		}
	}

	capIndex = idx++;

	return capDrv+capIndex;
}

///////////////////

int XORCHG(void *x, void *y, int bytes)
{
	int ret = 0;
	DWORD *a = (DWORD*)x;
	DWORD *b = (DWORD*)y;

	int mod = bytes%4;
	int dwSize = bytes/4;

	while(dwSize>0)
	{
		if(*a ^= *b)
			ret = 1;
		*b ^= *a;

		a++;
		b++;
		dwSize--;
	}

	BYTE *bx = (BYTE*)a;
	BYTE *by = (BYTE*)b;

	while(mod>0)
	{
		if(*bx ^= *by)
			ret = 1;
		*by ^= *bx;

		bx++;
		by++;
		mod--;
	}

	return ret;
}

///////////////

CcapViewer::CcapViewer(SOCKET s, HWND hwnd)
{
	m_socket = s;
	m_hwnd = hwnd;
	memset(&BI, 0, sizeof(_BMPINFO));
	pbiBitInfo = (BITMAPINFO *)&BI;

	sockdata.init(s);

	hThread = NULL;
	dwThreadId = 0;
	runFlag = 1;
	capDrivers.bUpdated = false;
	stopping = 0;
}

CcapViewer::~CcapViewer()
{

}

BYTE *CcapViewer::GetDibBuf()
{
	return bmpbuf.GetBuffer();
}

BITMAPINFO *CcapViewer::GetBmpInfo()
{
	return pbiBitInfo;
}

DWORD WINAPI CcapViewer::_capRecvMessage(LPVOID lParam)
{
	CcapViewer *_this = (CcapViewer*)lParam;

	return _this->capRecvMessage(NULL);
}

DWORD WINAPI CcapViewer::capRecvMessage(LPVOID lParam)
{

	_tagZLIBINFO zinfo;
	int ret;

	while(runFlag)
	{
		ret = Recv(m_socket, (char*)&rdph, sizeof(rdph));

		if(!ret)
		{
			DWORD err = WSAGetLastError();
			break;
		}


		switch(rdph.action)
		{
			case CAPP_VERSION:
			{
				//CAPPVersion��һ��float
				*(DWORD*)&CAPPVersion = rdph.dataSize;
			}
			break;

			case CAPP_CAPDEVLIST:
			{
				//���������б�����Ϣ
				if(rdph.flag == us_ZLIB)
				{
					ret = Recv(m_socket, (char*)&zinfo, sizeof(zinfo));
					if(!ret)
					{
						runFlag = 0;
						break;
					}
					//
					if(!zbmpbuf.checkBufferSize(rdph.dataSize, false))
					{
						__printf("zbmpbuf checkBufferSize failed.\r\n");
						runFlag = 0;
						break;
					}	
					ret = Recv(m_socket, zbmpbuf, rdph.dataSize);
					if(!ret)
					{
						runFlag = 0;
						break;
					}

					if(zinfo.uncomprLen > sizeof(capDrivers.capDrv))
					{
						__printf("zinfo.uncomprLen overflow.\r\n");
						runFlag = 0;
						break;
					}

					ret = uncompress((BYTE*)capDrivers.capDrv, &zinfo.uncomprLen, (BYTE*)zbmpbuf, rdph.dataSize);
					if(ret != 0)
					{
						__printf("capDrivers.capDrv uncompress failed.\r\n");
						runFlag = 0;
						break;
					}

					capDrivers.bUpdated = true;
					//
				}else
				{
					__printf("CAPP_CAPDEVLIST != us_ZLIB.\r\n");
					break;
				}

			}
			break;
			case CAPP_DEVICESTATUS:
			{
				//error{ 1=no capdevice, 2=cap stopped, 3=cap error}
				switch(rdph.flag)
				{
				case 0:
					//ok
					PostMessage(m_hwnd, CAP_READY, 0, 0);
					break;
				case 1:
					PostMessage(m_hwnd, CAP_NOCAPDEV, 0, 0);
					return 0;
				case 2:
					PostMessage(m_hwnd, CAP_STOPPED, 0, 0);
					break;
				case 3:
					PostMessage(m_hwnd, CAP_ERROR, 0, 0);
					break;
				}
			}
			break;

			case CAPP_BITMAPINFO:
			{
				//���մ���λͼ����Ϣ
				if(rdph.flag == us_ZLIB)
				{
					ret = Recv(m_socket, (char*)&zinfo, sizeof(zinfo));
					if(!ret)
					{
						runFlag = 0;
						break;
					}
					//
					if(!zbmpbuf.checkBufferSize(rdph.dataSize, false))
					{
						__printf("zbmpbuf checkBufferSize failed.\r\n");
						runFlag = 0;
						break;
					}	
					ret = Recv(m_socket, zbmpbuf, rdph.dataSize);
					if(!ret)
					{
						runFlag = 0;
						break;
					}

					if(zinfo.uncomprLen > sizeof(BI))
					{
						__printf("zinfo.uncomprLen overflow.\r\n");
						runFlag = 0;
						break;
					}

					ret = uncompress((BYTE*)&BI, &zinfo.uncomprLen, (BYTE*)zbmpbuf, rdph.dataSize);
					if(ret != 0)
					{
						__printf("BI uncompress failed.\r\n");
						runFlag = 0;
						break;
					}

					//
				}else
				{
					__printf("CAPP_BITMAPINFO != us_ZLIB.\r\n");
					break;
				}

			}
			break;

			//���ո���λͼ
			case CAPP_UPDATEVIDEO:
			{
				DWORD dibLen;

				if(rdph.flag == us_ZLIB)
				{
					ret = Recv(m_socket, (char*)&zinfo, sizeof(zinfo));
					//if(!)
					if(!zbmpbuf.checkBufferSize(rdph.dataSize, false))
					{
						__printf("zbmpbuf checkBufferSize failed.\r\n");
						runFlag = 0;
						break;
					}				
					ret = Recv(m_socket, zbmpbuf, rdph.dataSize);
					if(!ret)
					{
						runFlag = 0;
						break;
					}

					if(!bmpbuf1.checkBufferSize(zinfo.uncomprLen, false)
						|| !bmpbuf.checkBufferSize(zinfo.uncomprLen, true)
						)
					{
						__printf("bmpbuf1 bmpbuf checkBufferSize failed.\r\n");
						runFlag = 0;
						break;
					}
					ret = uncompress((BYTE*)bmpbuf1, &zinfo.uncomprLen, (BYTE*)zbmpbuf, rdph.dataSize);
					if(ret != 0)
					{
						__printf("zbmpbuf uncompress failed.\r\n");
						runFlag = 0;
						break;
					}
					dibLen = zinfo.uncomprLen;
				}else
				{
					if(!bmpbuf1.checkBufferSize(rdph.dataSize, false)
						|| !bmpbuf.checkBufferSize(rdph.dataSize, true)
						)
					{
						__printf("bmpbuf1 bmpbuf checkBufferSize failed.\r\n");
						runFlag = 0;
						break;
					}
					ret = Recv(m_socket, bmpbuf1, rdph.dataSize);
					if(!ret)
					{
						runFlag = 0;
						break;
					}

					dibLen = rdph.dataSize;

				}

				XORCHG((BYTE*)bmpbuf, (BYTE*)bmpbuf1, dibLen);
				//handles drawing
				//PostMessage(m_hwnd, CAP_DOBLT, 0, 0);

				InvalidateRect(m_hwnd, 0, FALSE);
				//UpdateWindow(m_hwnd);

				/*
				SYSTEMTIME stm;
				GetLocalTime(&stm);
				TCHAR szFileName[MAX_PATH];
				sprintf(
					szFileName,
					"%04u.%02u.%02u-%02u-%02u-%02u.bmp",
					stm.wYear, stm.wMonth, stm.wDay,
					stm.wHour, stm.wMinute, stm.wSecond
					);

				bDbgBmDump(szFileName, (BYTE*)bmpbuf, pbiBitInfo);
				*/

			}
			break;
			default:
			{
				__printf("unknown action: %d, %d, %d\r\n", rdph.action, rdph.flag, rdph.dataSize);
				runFlag = 0;
				break;
			}
		}

	}
	PostMessage(m_hwnd, CAP_QUIT, 0, 0);
	runFlag = 0;

	return 1;
}


BOOL CcapViewer::NewWorkThread()
{
	if(hThread)
		return 0;

	hThread = CreateThread(0, 0, _capRecvMessage, (LPVOID)this,
		0, &dwThreadId);
	
	return hThread != NULL;
}

BOOL CcapViewer::CaptureStop()
{
	_tagRDPHEAD r;

	r.action = CAPP_CAPSTOP;
	r.flag = 0;
	r.dataSize = 0;

	return sockdata.SendAction(&r);
}

BOOL CcapViewer::SetCapDevice(int idx)
{
	_tagRDPHEAD r;

	r.action = CAPP_SETCAPTUREDRV;
	r.flag = idx;
	r.dataSize = 0;

	return sockdata.SendAction(&r);
}

BOOL CcapViewer::start()
{
	return NewWorkThread();
}

BOOL CcapViewer::stop()
{
	if(stopping)
		return FALSE;

	stopping = 1;
	runFlag = 0;
	shutdown(m_socket, SD_BOTH);
	closesocket(m_socket);
	WaitForSingleObject(hThread, INFINITE);
	CloseHandle(hThread);

	//closesocket(m_socket);
	return TRUE;
}