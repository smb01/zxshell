// FileManager.h: interface for the CFileManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILEMANAGER_H__6742600F_C93A_4DD1_9CC4_509B5163833A__INCLUDED_)
#define AFX_FILEMANAGER_H__6742600F_C93A_4DD1_9CC4_509B5163833A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "main.h"
#include "res\resource.h"
#include <vector>
#include "..\zxsCommon\evlock.h"

#pragma pack(push, 8)

typedef struct _MG_FILE_INFO{
    DWORD           dwFileAttributes; 
    FILETIME        ftCreationTime; 
    FILETIME        ftLastAccessTime; 
    FILETIME        ftLastWriteTime; 
    __int64         nFileSize;
    TCHAR           szFileName[MAX_PATH];
} MG_FILE_INFO, *LP_MG_FILE_INFO;

typedef struct _MG_PROGRESS{
	int             total_Files;
	int             total_Folders;
	__int64         total_FileSize;
	int             done_Files;
	int             done_Folders;
	__int64         done_FileSize;
	__int64         exist_FileSize;
	DWORD           start_time;
	DWORD           used_time;
    TCHAR           szFileName[MAX_PATH];
} MG_PROGRESS, *LP_MG_PROGRESS;

#pragma pack(pop)

#define len_head_FileInfo sizeof(MG_FILE_INFO)-MAX_PATH

bool FindFile(char *lpFileName, LP_MG_FILE_INFO pFI);
char * FormatSize(__int64 nSize, char *szSize);
int FormatPathString(char *Source, char *Dest, int buflen, bool flag);

typedef DWORD (CALLBACK *LPTRANSFERPROGESS)(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

//Զ���ļ��������ͻ���
class CFileManager  
{
protected:
	char LocalPath[MAX_PATH];
	char RemotePath[MAX_PATH];
	char CurrPath[MAX_PATH];
	char TempBuf[MAX_PATH];
	SOCKET Socket;
	DWORD LastErr;

	MG_PROGRESS mg_prg;
	PMSG pMsg;
	LPTRANSFERPROGESS pProgress;

	float m_srvVer;

public:
	CFileManager();
	~CFileManager();

	CCountLock cl;

	LP_MG_PROGRESS lpGetProgress(){ return &mg_prg; }
	DWORD CALLBACK ProgressProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

	void SetServerVer(float ver)
	{
		m_srvVer = ver;
	};
	float GetServerVer(){ return m_srvVer;};

	void Init(SOCKET s);
	SOCKET GetSocket(){return Socket;}
	char *GetPeerIP();
	void SetCurrDir(char *path);
	char *GetCurrDir(){ return CurrPath; };
	void SetLocalPath(char *lpPath){ strcpy(LocalPath, lpPath); }
	char *GetLocalPath(){ return LocalPath; }
	void SetRemotePath(char *lpPath){ strcpy(RemotePath, lpPath); }
	char *GetRemotePath(){ return RemotePath; }
	void SetOutPutFunc(PMSG pmsg, LPTRANSFERPROGESS pFun);
	BOOL RecvErr();
	bool Quit();
	void Abort();
	DWORD GetError(){ return LastErr;}
	int __GetRemoteFileList(char *RemotePath, std::vector<MG_FILE_INFO> &Files);
	int __GetLocalFileList(char *FileName, bool bRecursion, std::vector<MG_FILE_INFO> &Files);
	int __DeleteFile(char *RemotePath);
	int __MoveFile(char *OriginPath, char *newPath);
	int __RenameFile(char *OriginPath, char *newPath);
	int __NewFolder(char *RemotePath);
	int __ExecuteFile(char *RemotePath);
	int __DownloadFile(char *RemotePath);
	int __UploadFile(char *RemotePath);
	int __Md5File(char *RemotePath, char *szBuf);
	int __SetPlugPath_VNC(char *RemotePath, char *szBuf);
	int __SearchFile(char *RemotePath, std::vector<MG_FILE_INFO> &Files);

	int __SetRestart(__int64 StartPos);
	int __GetFileVector(char *RemotePath, std::vector<MG_FILE_INFO> &Files);

	int __RecvFileVector(PMSG pmsg, LPTRANSFERPROGESS pFun, std::vector<MG_FILE_INFO> &Files);
	int __RecvFileInfo(std::vector<MG_FILE_INFO> &Files);
	int __RecvFileData(LP_MG_FILE_INFO pFI);
	int __WriteToFile(HANDLE hFile, char *Buff, int Datalen);

	int __SendFileVector(PMSG pmsg, LPTRANSFERPROGESS pFun, std::vector<MG_FILE_INFO> &Files);
	int __SendFileData(LP_MG_FILE_INFO pFI);
	__int64 GetRemoteFileSize(char *RemotePath);
	int DataSend(SOCKET s, char *DataBuf, int DataLen);
	__int64 Transmitfile(SOCKET sd, HANDLE hFile, __int64 size);


};

#endif // !defined(AFX_FILEMANAGER_H__6742600F_C93A_4DD1_9CC4_509B5163833A__INCLUDED_)
