#if !defined _RDVIEWER
#define _RDVIEWER
#define _WIN32_WINNT  0x0400
#define WINVER 0x0500
#include "..\..\..\zxsCommon\zlib\zlib.h"
#include <windows.h>
#include "sock.h"
#include "..\..\..\zxsCommon\RDP.h"
#include "..\..\..\zxsCommon\rdpBuffer.h"
#include "..\..\..\zxsCommon\rdpBufferEncodeZlib.h"
#include "..\..\..\zxsCommon\CSocketData.h"
#include "..\..\..\zxsCommon\CSpeedTest.h"
#include "..\..\..\zxsCommon\evlock.h"

#include <stdio.h>
#include <shlwapi.h>
#include <shlobj.h>
#include <shellapi.h>
#include "resource.h"

#include "..\..\ctrldll.h"

#if defined _ZXS_RDVIEWER
#include "../../res\resource.h"
int CALLBACK ConnInfoDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
#pragma comment(lib, "../zxsCommon/zlib/zlib.lib")
#else
#pragma comment(lib, "../../../zxsCommon/zlib/zlib.lib")

#endif

#define RD_SOCKET WM_USER+7


typedef void (__cdecl * cbitXtoY)(void *src, void *dest, void *b434, int offset, int width);

class CMemBMP
{
protected:
	DWORD width;
	DWORD hight;

	HDC m_hDC;

public:
	CMemBMP();
	~CMemBMP();

	HDC m_hMemDC;
	HBITMAP m_hBitmap;

	int init(HDC hDC);

	int SetBmpRect(DWORD w, DWORD h);
	
	BOOL MemPaint(_tagRect *lpRect, CONST VOID *lpBits, CONST BITMAPINFO *lpBitsInfo);


};

class CLOWKEYBDHOOK
{
private:
	HMODULE hDll;
	SETKEYBDHOOK *SetKeybdHook;
	UNSETKEYBDHOOK *UnSetKeybdHook;

	HHOOK hkeybdhook;

	HWND hookmsgHwnd;
	HWND callbackHwnd;

	HANDLE hHookThread;
	DWORD dwThreadId;

public:
	CLOWKEYBDHOOK();
	~CLOWKEYBDHOOK();

	BOOL LoadDll();
	BOOL SetHook(HWND hwnd);
	BOOL UnSetHook();
	//HWND GetHookHwnd(){ return hookmsgHwnd; }

	static DWORD WINAPI KeyboardProcThread(LPVOID lParam);
	DWORD WINAPI _KeyboardProcThread(LPVOID lParam);

	static LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	LRESULT CALLBACK _WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

};

class RDVIEWER
{
protected:

	int runFlag;

	HINSTANCE AppInstance;

	char WinTitle[MAX_PATH];
	HWND m_hwnd , m_hwnd1, m_hwndscroll;
	HCURSOR hDenyCursor, hNormalCursor, hDotCursor;
	RECT rt;

	HDC m_viewerDC;
	HDC m_hMemDC;

	//CMemBMP cMemBmp;

	bool bitmapExisted;

	bool bCaptureBlt;
	//ID_DISPLAY_NORMAL  ID_DISPLAY_STRETCH  ID_DISPLAY_FULLSCR
	int m_DisplayMode;
	//ID_MODE_CTRL ID_MODE_VIEW
	int m_ContorlMode;
	int m_CursorlMode;

	// Window may be scrollable - these control the scroll position
	int m_hScrollPos, m_hScrollMax, m_vScrollPos, m_vScrollMax;

	// The size of the current client area
	int m_cliwidth, m_cliheight;
	// The size of a window needed to hold entire screen without scrollbars
	int m_fullwinwidth, m_fullwinheight;
	int m_winwidth, m_winheight;	
	// The size of the CE CommandBar
	int m_barheight;

	// Next window in clipboard chain
	HWND m_hwndNextViewer; 
	bool m_initialClipboardSeen;		

	bool m_MenuState;

	bool m_bUseJpegEncode;

	//����viewer�˵�ǰ����ʾ λɫ
	WORD m_prevLocalBits;

	//�ͼ����̹���
	CLOWKEYBDHOOK lowKeybdHook;

	//////////////////////////////
	float RDPVersion;

	WORD BitsPerPixel;

	_rdpBuffer bitinfobuf;
	RGBQUAD colorTable[256];
	_BMPINFO *pmybi;
	BITMAPINFO *pbiBitInfo;
	HDC hTestDC;
	HBITMAP hTestBitmap;

	int srvscrX, srvscrY;
	WORD cursorX,cursorY;
	WORD prevcursorX,prevcursorY;
	HCURSOR hRemoteCursor;
	HBRUSH hCursorBrush;

	CMutexLock evLock;

	CSpeedTest speedtest;
	CSocketData sockdata;
	SOCKET m_socket;

	_tagRDPHEAD rdph;

	_rdpBuffer bmpbuf;
	_rdpBuffer bmpbuf1;
	_rdpBuffer zbmpbuf;

public:
	RDVIEWER(SOCKET s);
	~RDVIEWER();
	void UpdateScrollbars() ;
	bool ScrollScreen(int dx, int dy);
	void PositionChildWindow();
	BOOL InFullScreenMode(){ return m_DisplayMode == ID_DISPLAY_FULLSCR;}
	BOOL InControlMode(){ return m_ContorlMode == ID_MODE_CTRL;}
	BOOL EnableControlMode(){
		if(!bitmapExisted)
			return FALSE;
		m_ContorlMode = ID_MODE_CTRL;
		return TRUE;
	}
	BOOL DisableControlMode(){ m_ContorlMode = ID_MODE_VIEW; return TRUE;}
	int SetCursorState(bool b){ return m_CursorlMode = b;}
	int GetCursorState(){ return m_CursorlMode;}
	int SetComprLevel(int level);
	void SetCaptureBlt(bool b){ bCaptureBlt = b;}
	bool bCaptureBltState(){ return bCaptureBlt;}

	void RealiseFullScreenMode(bool suppressPrompt);

	int UpdateLocalClipboard();
	int ProcessLocalClipboardChange();
	int SendMouseEvent(UINT iMsg, WPARAM wParam, LPARAM lParam);
	int SendKeybdEvent(UINT iMsg, WPARAM wParam, LPARAM lParam);

	void SetDisplayWinTitle(char *szTitle);
	int CreateDisplay();
	int RecvMessage();
	int SendAction(BYTE action, BYTE flag);
	int msgloop();

	static LRESULT CALLBACK Proc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam);
	static LRESULT CALLBACK WndProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam);
	static LRESULT CALLBACK WndProc1(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam);
	static LRESULT CALLBACK ScrollProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam);
	LRESULT CALLBACK _ScrollProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam);
	LRESULT CALLBACK _WndProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam);
	LRESULT CALLBACK _WndProc1(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam);


	void SetColorTable();
	cbitXtoY GetFunc(WORD bits);
	bool SetBitInfo();
	int UpdateRect(_tagRect &posrect, BYTE *pDIBData, DWORD dibLen);
	int DoBlt(RECT *lpPaint);
	int DoBlt1(RECT *lpPaint);
	int DrawCursor();

};

#endif