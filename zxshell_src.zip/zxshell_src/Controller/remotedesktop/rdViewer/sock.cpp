#include <winsock2.h>
#include "sock.h"

#pragma comment(lib, "ws2_32")

#if !defined _ZXS_RDVIEWER
void TranMsg()
{
	MSG msg;
	while(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))//ȡ��������Ϣ������,��ֹ�������
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
}


SOCKET ConnectHost(DWORD dwIP, WORD wPort)//����ָ��IP�Ͷ˿�
{
	SOCKET sockid;

	if ((sockid = socket(PF_INET, SOCK_STREAM,IPPROTO_TCP)) == INVALID_SOCKET)
		return 0;
	struct sockaddr_in srv_addr;
	srv_addr.sin_family = AF_INET;
	srv_addr.sin_addr.S_un.S_addr = dwIP;
	srv_addr.sin_port = htons(wPort);
	if (connect(sockid,(struct sockaddr*)&srv_addr,sizeof(struct sockaddr_in)) == SOCKET_ERROR)
		goto error;
	return sockid;
error:

	closesocket(sockid);
	return 0;
}

char *DNS(char *HostName)
{
	HOSTENT *hostent = NULL;
	IN_ADDR iaddr;
	hostent = gethostbyname(HostName);
	if (hostent == NULL)
	{
		return NULL;
	}
	iaddr = *((LPIN_ADDR)*hostent->h_addr_list);
	return inet_ntoa(iaddr);
}

SOCKET ConnectHost(char *szIP, WORD wPort)
{
	if (inet_addr(szIP) != INADDR_NONE)
		return ConnectHost(inet_addr(szIP), wPort);
	else
	{
		if (DNS(szIP) != NULL)
			return ConnectHost(inet_addr(DNS(szIP)), wPort);
		else
			return 0;
	}
}

SOCKET CreateSocket(DWORD dwIP, WORD wPort)//��dwIP�ϰ�wPort�˿�
{
	SOCKET sockid;

	if ((sockid = socket(PF_INET, SOCK_STREAM,IPPROTO_TCP)) == INVALID_SOCKET)
		return 0;
	struct sockaddr_in srv_addr = {0};
	srv_addr.sin_family = AF_INET;
	srv_addr.sin_addr.S_un.S_addr = dwIP;
	srv_addr.sin_port = htons(wPort);
	if (bind(sockid,(struct sockaddr*)&srv_addr,sizeof(struct sockaddr_in)) == SOCKET_ERROR)
		goto error;
	if (listen(sockid,3) == SOCKET_ERROR)
		goto error;
	return sockid;
error:
	closesocket(sockid);
	return 0;
}

BOOL InitSock()
{
	WSADATA wsadata;
	return WSAStartup(MAKEWORD(2,2),&wsadata) == 0;
}
#endif
//for GUI
int SetTimeOut(SOCKET s, bool read, bool write, int timeout_sec)
{   
	int ret;
	DWORD timepassed = 0;
	fd_set FdRead, FdWrite;
	struct timeval TimeOut;


	TimeOut.tv_sec  = 0;
	TimeOut.tv_usec = timeout_sec ? 1 : 0;

	while(1)
	{
		if(read)
		{
			FD_ZERO(&FdRead);
			FD_SET(s,&FdRead);
			TranMsg();
		}
		if(write)
		{
			FD_ZERO(&FdWrite);
			FD_SET(s,&FdWrite);
		}
		ret = select(s+1,
			read?&FdRead:NULL,
			write?&FdWrite:NULL,
			NULL,
			&TimeOut);

		if(ret == 0)
		{
			if(timeout_sec > 0)
			{
				if(timepassed >= timeout_sec*100)
					break;
			}else if(timeout_sec == 0)
			{
				return 1;
			}

			timepassed += 1;
			continue;
		}else
		{
			break;
		}
	}
//	DWORD err = WSAGetLastError();
	return ret;
}


int _SetTimeOut(SOCKET s, bool read, bool write, int timeout_sec)
{   
	int ret;
	DWORD timepassed = 0;
	fd_set FdRead, FdWrite;
	struct timeval TimeOut;


	TimeOut.tv_sec  = timeout_sec;
	TimeOut.tv_usec = 0;


	if(read)
	{
		FD_ZERO(&FdRead);
		FD_SET(s,&FdRead);
	}
	if(write)
	{
		FD_ZERO(&FdWrite);
		FD_SET(s,&FdWrite);
	}
	ret = select(s+1,
		read?&FdRead:NULL,
		write?&FdWrite:NULL,
		NULL,
		timeout_sec==-1?NULL:&TimeOut);


//	DWORD err = WSAGetLastError();
	return ret;
}

int Shutdown(SOCKET s)
{
	return shutdown(s, SD_BOTH);
}

int CloseSocket(SOCKET s)
{
	return CloseSocket(s);
}

SOCKET Accept(SOCKET Socket, int TimeOut_sec)
{
	if(SetTimeOut(Socket, 1, 0, TimeOut_sec) <= 0)
		return -1;

	return accept(Socket, NULL, NULL);
}

SOCKET Accept(SOCKET Socket)
{
	return Accept(Socket, -1);
}

BOOL Recv(SOCKET Socket, char *RecvBuf, int DataLen, int TimeOut_sec)
{
	int nRetVal, TotalBytesRecv = 0;
	int recvlen;
	while(TotalBytesRecv < DataLen)
	{
		if(SetTimeOut(Socket, 1, 0, TimeOut_sec) <= 0)
			return -1;
		if(DataLen - TotalBytesRecv > 2048)
			recvlen = 2048;
		else
			recvlen = DataLen - TotalBytesRecv;
		nRetVal = recv(Socket, RecvBuf+TotalBytesRecv, recvlen, 0);
/*
		nRetVal = recv(Socket, RecvBuf+TotalBytesRecv, DataLen-TotalBytesRecv, 0);
*/
		if(nRetVal <= 0)
			return 0;
		else
			TotalBytesRecv += nRetVal;
	}
	return DataLen == TotalBytesRecv;
}

BOOL Send(SOCKET Socket, char *DataBuf, int DataLen, int TimeOut_sec)
{
	int nBytesLeft = DataLen;
	int nBytesSent = 0;
	int nRetVal;

	while(nBytesLeft > 0)
	{
		if(SetTimeOut(Socket, 0, 1, TimeOut_sec) <= 0)
			return -1;
		nRetVal = send(Socket, DataBuf + nBytesSent, nBytesLeft, 0);
		if(nRetVal <= 0)
			break;
		nBytesSent += nRetVal;
		nBytesLeft -= nRetVal;
	}
	return nBytesSent == DataLen;
}

BOOL Recv(SOCKET Socket, char *RecvBuf, int DataLen)
{
	return Recv(Socket, RecvBuf, DataLen, -1);
}

BOOL Send(SOCKET Socket, char *DataBuf, int DataLen)
{
	return Send(Socket, DataBuf, DataLen, -1);
}
