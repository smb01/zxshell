#include "rdViewer.h"


DWORD WINAPI GetMessageThread(LPVOID lParam)
{
	SOCKET as = (SOCKET)lParam;

	RDVIEWER *rdv = new RDVIEWER(as);

	rdv->CreateDisplay();

	rdv->RecvMessage();

	printf("%d closed\r\n", as);
	closesocket(as);

	delete rdv;

	return 0;
}


void main(int argc, char **argv)
{
	int port = 1234;

	if(argc == 2)
	{
		port = atoi(argv[1]);
	}


	InitSock();

	SOCKET ls = CreateSocket(0, port);

	DWORD t = GetTickCount();

	while(1)
	{

	SOCKET as = Accept(ls);

	if(as == -1)
		break;

		DWORD dwThreadId;
		HANDLE hThread = CreateThread(0, 0, GetMessageThread, (LPVOID)as, 0, &dwThreadId);
		if(hThread == NULL)
			return;
		CloseHandle(hThread);
	}


}