#include <windows.h>

void cbit24to32(void *src, void *dest, void *b434, int height, int width)
{
	width *= height;
	BYTE *b32 = (BYTE*)dest + (width - 1)*4;
	BYTE *b24 = (BYTE*)src + (width - 1)*3;
	
	while(width > 0)
	{
		*(DWORD*)b32 = *(DWORD*)b24 & 0xffffff;

		b24-=3;
		b32-=4;

		width--;
	}

}

void cbit16_565to555(void *src, void *dest, void *b434, int height, int width)
{
	width *= height;
	WORD *b555 = (WORD*)dest;
	WORD *b565 = (WORD*)src;

	while(width > 0)
	{
		//*b555 = u16_565_to_555(*b565);
		*b555 = (((*b565&0xf800) | (*b565&0x7c0)) >> 1) | ((*b565&0x1f));

		b555++;
		b565++;

		width--;
	}

}

void cbit16_555to565(void *src, void *dest, void *b434, int height, int width)
{
	width *= height;
	WORD *b565 = (WORD*)dest;
	WORD *b555 = (WORD*)src;

	while(width > 0)
	{
		//*b565 = u16_555_to_565(*b555);
		*b565 = (((*b555&0x7c00) | (*b555&0x3e0)) << 1) | ((*b555&0x1f));

		b555++;
		b565++;

		width--;
	}

}

void cbit16_555_to_32(void *src, void *dest, void *b434, int height, int width)
{
	width *= height;
	DWORD *b32 = (DWORD*)dest + width - 1;
	WORD *b555 = (WORD*)src + width - 1;

	while(width > 0)
	{
		//*b32 = u32_16_555_to_32(*b555);
		*b32 = (((*b555&0x7c00)<<9) | ((*b555&0x3e0))<<6) | (((*b555&0x1f)<<3));

		b555--;
		b32--;

		width--;
	}

}

void cbit8to16_555(void *src, void *dest, void *b434, int height, int width)
{
	width *= height;
	WORD *b16 = (WORD*)dest + width - 1;
	BYTE *b8 = (BYTE*)src + width - 1;

	LPPALETTEENTRY pColors = (LPPALETTEENTRY)(b434);
	while(width > 0)
	{
		*b16 = (((*(DWORD*)&pColors[*b8])&0x0F8)>>3) 
			| (((*(DWORD*)&pColors[*b8])&0x0F800)>>6) 
			| (((*(DWORD*)&pColors[*b8])&0x0F80000)>>9);
//		*b16 = ( (pColors[*b8].peBlue >>3)
//			| ((pColors[*b8].peGreen >>3)<< 5 )
//			| ((pColors[*b8].peRed<<10) | 0x800 )  );

		b8--;
		b16--;

		width--;
	}

}

void cbit8to16_565(void *src, void *dest, void *b434, int height, int width)
{
	width *= height;
	WORD *b16 = (WORD*)dest + width - 1;
	BYTE *b8 = (BYTE*)src + width - 1;

	LPPALETTEENTRY pColors = (LPPALETTEENTRY)(b434);
	while(width > 0)
	{
//		*b16 = (((*(DWORD*)&pColors[*b8])&0x0F8)>>3) 
//			| (((*(DWORD*)&pColors[*b8])&0x0F800)>>6) 
//			| (((*(DWORD*)&pColors[*b8])&0x0F80000)>>9);
		*b16 = ( (pColors[*b8].peBlue >>3)
			| ((pColors[*b8].peGreen >>2)<< 5 )
			| ((pColors[*b8].peRed>>3) << 11 )  );

		b8--;
		b16--;

		width--;
	}

}

void cbit4to16_565(void *src, void *dest, void *b434, int height, int width)
{
	width *= height;
	WORD *b16 = (WORD*)dest + width - 1;
	BYTE *b4 = (BYTE*)src + width/2 - 1;
	RGBQUAD * bits16ct = (RGBQUAD *)(b434);

	while(width > 0)
	{
		BYTE h,l;

		l = *b4 & 0xf;
		h = *b4 >> 4;

		*b16 = ( (bits16ct[h].rgbBlue >>3)
			| ((bits16ct[h].rgbGreen >>2)<< 5 )
			| ((bits16ct[h].rgbRed>>3) << 11 )  );

		b16--;

		*b16 = ( (bits16ct[l].rgbBlue >>3)
			| ((bits16ct[l].rgbGreen >>2)<< 5 )
			| ((bits16ct[l].rgbRed>>3) << 11 )  );

		b16--;

		b4--;
		width-=2;
	}

}

void cbit4to16_555(void *src, void *dest, void *b434, int height, int width)
{
	width *= height;
	WORD *b16 = (WORD*)dest + width - 1;
	BYTE *b4 = (BYTE*)src + width/2 - 1;
	RGBQUAD * bits16ct = (RGBQUAD *)(b434);

	while(width > 0)
	{
		BYTE h,l;

		l = *b4 & 0xf;
		h = *b4 >> 4;

		*b16 = ( (bits16ct[h].rgbBlue >>3)
			| ((bits16ct[h].rgbGreen >>2)<< 5 )
			| (((bits16ct[h].rgbRed>>3) << 10 )&0x8000)  );

		b16--;

		*b16 = ( (bits16ct[l].rgbBlue >>3)
			| ((bits16ct[l].rgbGreen >>2)<< 5 )
			| (((bits16ct[l].rgbRed>>3) << 10 )&0x8000)  );

		b16--;

		b4--;
		width-=2;
	}

}

void cbit4to32(void *src, void *dest, void *b434, int height, int width)
{
	width *= height;
	DWORD *b32 = (DWORD*)dest + width - 1;
	BYTE *b4 = (BYTE*)src + width/2 - 1;
	RGBQUAD * bits16ct = (RGBQUAD *)(b434);

	while(width > 0)
	{
		BYTE h,l;

		l = *b4 & 0xf;
		h = *b4 >> 4;

		*b32 = ( (bits16ct[h].rgbBlue)
			| (bits16ct[h].rgbGreen <<8 )
			| (bits16ct[h].rgbRed<<16) );

		b32--;

		*b32 = ( (bits16ct[l].rgbBlue)
			| (bits16ct[l].rgbGreen <<8 )
			| (bits16ct[l].rgbRed<<16) );

		b32--;

		b4--;
		width-=2;
	}

}

void cbit8to32(void *src, void *dest, void *b434, int height, int width)
{
	width *= height;
	DWORD *b32 = (DWORD*)dest + width -1;
	BYTE *b8 = (BYTE*)src + width -1;

	LPPALETTEENTRY pColors = (LPPALETTEENTRY)(b434);

	while(width > 0)
	{
		*b32 = ( (pColors[*b8].peBlue )
			| (pColors[*b8].peGreen << 8 )
			| ((pColors[*b8].peRed << 16 )| 0xff000000)  );

		b8--;
		b32--;

		width--;
	}

}


void cbit24to16_555(void *src, void *dest, void *b434, int height, int width)
{
	width *= height;
	BYTE *b24 = (BYTE*)src;
	WORD *b555 = (WORD*)dest;

	while(width > 0)
	{
		*b555 = (*(b24+2)>>3<<10) | (*(b24+1)>>3<<5) | (*(b24)>>3);

		b555++;
		b24+=3;

		width--;
	}

}

void cbit24to16_565(void *src, void *dest, void *b434, int height, int width)
{
	width *= height;
	BYTE *b24 = (BYTE*)src;
	WORD *b555 = (WORD*)dest;

	while(width > 0)
	{
		*b555 = (*(b24+2)>>3<<11) | (*(b24+1)>>2<<5) | (*(b24)>>3);

		b555++;
		b24+=3;

		width--;
	}

}
