#include <windows.h>


void TranMsg();

SOCKET ConnectHost(DWORD dwIP, WORD wPort);

char *DNS(char *HostName);
SOCKET ConnectHost(char *szIP, WORD wPort);

SOCKET CreateSocket(DWORD dwIP, WORD wPort);
BOOL InitSock();
int SetTimeOut(SOCKET s, bool read, bool write, int timeout_sec);
SOCKET Accept(SOCKET Socket, int TimeOut_sec);

SOCKET Accept(SOCKET Socket);

BOOL Recv(SOCKET Socket, char *RecvBuf, int DataLen, int TimeOut_sec);

BOOL Send(SOCKET Socket, char *DataBuf, int DataLen, int TimeOut_sec);

BOOL Recv(SOCKET Socket, char *RecvBuf, int DataLen);

BOOL Send(SOCKET Socket, char *DataBuf, int DataLen);
