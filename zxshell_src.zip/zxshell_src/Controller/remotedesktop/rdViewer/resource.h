//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by rdViewer.rc
//
#define IDR_RD_MENU                     102
#define IDC_POINTER                     103
#define IDC_NODROP                      106
#define IDC_CURSOR1                     107
#define IDI_RDICON                      109
#define IDI_ICON_DISABLE                111
#define ID_KE_CTRLALTDEL                40008
#define ID_CMD_REMOVEWALLPAPER          40009
#define ID_MODE_CTRL                    40010
#define ID_MODE_VIEW                    40011
#define ID_DISPLAY_FULLSCR              40012
#define ID_DISPLAY_NORMAL               40013
#define ID_DISPLAY_STRETCH              40016
#define ID_MENUITEM40017                40017
#define ID_TAKESNAPSHOT                 40017
#define ID_DISPLAY_HALFTONE             40018
#define ID_DISPLAY_DELETESCANS          40019
#define ID_GETCLIPDATA                  40020
#define ID_CURSOR_SHOW                  40021
#define ID_CURSOR_HIDE                  40022
#define ID_COMPRLEVEL_AUTO              40023
#define ID_COMPRLEVEL_0                 40024
#define ID_COMPRLEVEL_1                 40025
#define ID_COMPRLEVEL_2                 40026
#define ID_COMPRLEVEL_3                 40027
#define ID_COMPRLEVEL_4                 40028
#define ID_COMPRLEVEL_5                 40029
#define ID_COMPRLEVEL_6                 40030
#define ID_COMPRLEVEL_7                 40031
#define ID_COMPRLEVEL_8                 40032
#define ID_COMPRLEVEL_9                 40033
#define ID_CAPTUREBLT                   40034
#define ID_LOGONASSYS                   40035
#define ID_40036                        40036
#define ID_JPEGEC                       40037
#define ID_SETPIXEL_BASE                41000
#define ID_SETPIXEL_4                   41004
#define ID_SETPIXEL_8                   41008
#define ID_SETPIXEL_16                  41016
#define ID_SETPIXEL_32                  41032

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40038
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
