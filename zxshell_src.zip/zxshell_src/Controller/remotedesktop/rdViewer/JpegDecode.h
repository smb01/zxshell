#ifndef _JPEGDECODE_H__
#define _JPEGDECODE_H__

#include <Windows.h>



BOOL 
DecodeFromJPEGBuffer(
					 BYTE *	lpJpgBuffer,
					 DWORD 	dwJpgBufferSize,
					 BYTE**	lppRgbBuffer,
					 DWORD*	lpdwWidth,
					 DWORD*	lpdwHeight,
					 DWORD*	lpdwNumberOfChannels
					 );



#endif