#include "JpegDecode.h"

#include <ijl.h>

#pragma comment(lib, "ijl15l.lib")



BOOL
DecodeFromJPEGBuffer(
					 BYTE *	lpJpgBuffer,
					 DWORD 	dwJpgBufferSize,
					 BYTE**	lppRgbBuffer,
					 DWORD*	lpdwWidth,
					 DWORD*	lpdwHeight,
					 DWORD*	lpdwNumberOfChannels
					 )
{

	BOOL 	bres;
	IJLERR 	jerr;
	DWORD 	dwWholeImageSize;
	BYTE* 	lpTemp = NULL;

	// Allocate the IJL JPEG_CORE_PROPERTIES structure.
	JPEG_CORE_PROPERTIES jcprops;

	bres = TRUE;

	__try
	{
		// Initialize the Intel(R) JPEG Library.
		jerr = ijlInit(&jcprops);
		if(IJL_OK != jerr)
		{
			bres = FALSE;
			__leave;
		} 	

		// Get information on the JPEG image
		// (i.e., width, height, and channels).

		jcprops.JPGFile = NULL;
		jcprops.JPGBytes = lpJpgBuffer;
		jcprops.JPGSizeBytes = dwJpgBufferSize;
		jerr = ijlRead(&jcprops, IJL_JBUFF_READPARAMS);
		if(IJL_OK != jerr)
		{
			bres = FALSE;
			__leave;
		}
		// Set the JPG color space ... this will always be
		// somewhat of an educated guess at best because JPEG
		// is "color blind" (i.e., nothing in the bit stream
		// tells you what color space the data was encoded from).
		// However, in this example we assume that we are
		// reading JFIF files which means that 3 channel images
		// are in the YCbCr color space and 1 channel images are
		// in the Y color space.
		switch(jcprops.JPGChannels)
		{
		case 1:
			{
				jcprops.JPGColor = IJL_G;
				jcprops.DIBColor = IJL_BGR;
				jcprops.DIBChannels = 3;
				break;
			}
		case 3:
			{
				jcprops.JPGColor = IJL_YCBCR;
				jcprops.DIBColor = IJL_BGR;
				jcprops.DIBChannels = 3;
				break;
			}
		default:
			{
				// This catches everything else, but no
				// color twist will be performed by the IJL.

				jcprops.JPGColor = IJL_OTHER;
				jcprops.DIBColor = IJL_OTHER;
				jcprops.DIBChannels = jcprops.JPGChannels;
				break;
			}
		}
		// Compute size of desired pixel buffer.
		dwWholeImageSize = jcprops.JPGWidth * jcprops.JPGHeight *
			jcprops.DIBChannels;
		// Allocate memory to hold the decompressed image data.
		lpTemp = new BYTE [dwWholeImageSize];
		if(NULL == lpTemp)
		{
			bres = FALSE;
			__leave;
		}
		// Set up the info on the desired DIB properties.
		jcprops.DIBWidth = jcprops.JPGWidth;
		jcprops.DIBHeight = jcprops.JPGHeight;
		jcprops.DIBPadBytes = 0;
		jcprops.DIBBytes = lpTemp;
		// Now get the actual JPEG image data into the pixel buffer.
		jerr = ijlRead(&jcprops, IJL_JBUFF_READWHOLEIMAGE);
		if(IJL_OK != jerr)
		{
			bres = FALSE;
			__leave;
		}
	} // __try
	__finally
	{
		if(FALSE == bres)
		{
			if(NULL != lpTemp)
			{
				delete [] lpTemp;
				lpTemp = NULL;
			}
		}

		// Clean up the Intel(R) JPEG Library.
		ijlFree(&jcprops);
		*lpdwWidth = jcprops.DIBWidth;
		*lpdwHeight = jcprops.DIBHeight;
		*lpdwNumberOfChannels = jcprops.DIBChannels;
		*lppRgbBuffer = lpTemp;

	} // __finally


	return bres;
} // DecodeFromJPEGBuffer()


