#define WINVER 0x40A


#include "rdViewer.h"
#include "cbitXtoY.h"
#include "..\..\..\zxsCommon\debugoutput.h"

#include "imm.h"
#include "../../bmp2file.h"
#include "JpegDecode.h"

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "shlwapi.lib")
#pragma comment(lib, "imm32.lib")

#define VWR_WND_CLASS_NAME "ZXScreenCtrl"


CMemBMP::CMemBMP()
{
	memset(this, 0, sizeof(CMemBMP));
}

CMemBMP::~CMemBMP()
{
	if(m_hMemDC)
		DeleteDC(m_hMemDC);
	if(m_hBitmap)
		DeleteObject(m_hBitmap);

}

int CMemBMP::init(HDC hDC)
{
	m_hDC = hDC;
	m_hMemDC = CreateCompatibleDC(hDC);

	SetStretchBltMode(m_hMemDC, COLORONCOLOR);

	return (int)m_hMemDC;
}

int CMemBMP::SetBmpRect(DWORD w, DWORD h)
{
	if(w == width && h == hight)
		return 0;

	width = w;
	hight = h;


	if(m_hBitmap == NULL)
	{
		m_hBitmap = CreateCompatibleBitmap(m_hDC, width, hight);

		if(m_hBitmap == NULL)
			return -1;

		SelectObject(m_hMemDC, m_hBitmap);

		return 1;
	}

	if(!SetBitmapDimensionEx(m_hBitmap, width, hight, NULL))
		return -1;


	return 1;
}

BOOL CMemBMP::MemPaint(_tagRect *lpRect, CONST VOID *lpBits, CONST BITMAPINFO *lpBitsInfo)
{

	return SetDIBitsToDevice(m_hMemDC, 
							lpRect->x,
							lpRect->y,
							lpRect->w,
							lpRect->h,
							0,
							0,
							0,
							lpRect->h,
							lpBits,
							lpBitsInfo,
							DIB_RGB_COLORS);
}

//////////////////////////////////////////

CLOWKEYBDHOOK::CLOWKEYBDHOOK()
{
	memset(this, 0, sizeof(CLOWKEYBDHOOK));
}

CLOWKEYBDHOOK::~CLOWKEYBDHOOK()
{
	if(hkeybdhook != NULL)
		UnSetHook();
	if(hHookThread != NULL)
		CloseHandle(hHookThread);
}

BOOL CLOWKEYBDHOOK::LoadDll()
{
	if(hDll && SetKeybdHook && UnSetKeybdHook)
		return TRUE;

	char dllPath[MAX_PATH];

	GetModuleFileName(NULL, dllPath, MAX_PATH);

	if(strrchr(dllPath, '\\'))
		strcpy(strrchr(dllPath, '\\'), "\\ctrldll.dll");
	else
		strcpy(dllPath, "ctrldll.dll");

	hDll = LoadLibrary(dllPath);
	if(hDll == NULL)
		return FALSE;

	SetKeybdHook = (SETKEYBDHOOK*)GetProcAddress(hDll, "SetKeybdHook");
	UnSetKeybdHook = (UNSETKEYBDHOOK*)GetProcAddress(hDll, "UnSetKeybdHook");

	return (SetKeybdHook != NULL) && (UnSetKeybdHook != NULL);
}


LRESULT CALLBACK CLOWKEYBDHOOK::WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CLOWKEYBDHOOK *_this = (CLOWKEYBDHOOK*)GetWindowLong(hWnd, GWL_USERDATA);

	return _this->_WndProc(hWnd, uMsg, wParam, lParam);
}

LRESULT CALLBACK CLOWKEYBDHOOK::_WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
	case ZX_KEYEVENT:
		{
			return SendMessage(callbackHwnd, ZX_KEYEVENT, wParam, lParam);
		}

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;

	}
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

DWORD WINAPI CLOWKEYBDHOOK::KeyboardProcThread(LPVOID lParam)
{
	CLOWKEYBDHOOK *_this = (CLOWKEYBDHOOK*)lParam;

	return _this->_KeyboardProcThread(lParam);
}

DWORD WINAPI CLOWKEYBDHOOK::_KeyboardProcThread(LPVOID lParam)
{
	WNDCLASS wndclass;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.hbrBackground = NULL;
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hInstance = NULL;
	wndclass.lpfnWndProc = CLOWKEYBDHOOK::WndProc;
	wndclass.lpszClassName = "ctrldll_keybdhook";
	wndclass.lpszMenuName = NULL;
	wndclass.style = CS_HREDRAW | CS_VREDRAW;

	RegisterClass(&wndclass);

	hookmsgHwnd = CreateWindow("ctrldll_keybdhook", "ctrldll_keybdhook",
		WS_OVERLAPPEDWINDOW, 0, 0, 32, 32,
		NULL, NULL, NULL, NULL);

	if(hookmsgHwnd == NULL)
		return 1;

	SetWindowLong(hookmsgHwnd, GWL_USERDATA, (LONG)this);

	hkeybdhook = SetKeybdHook(hookmsgHwnd);

	if(hkeybdhook == NULL)
		return 1;

	MSG msg;
	while(GetMessage(&msg, hookmsgHwnd, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return 0;
}

BOOL CLOWKEYBDHOOK::SetHook(HWND hwnd)
{
	if(SetKeybdHook == NULL)
		return FALSE;

	if(hkeybdhook != NULL)
		return TRUE;

	callbackHwnd = hwnd;

	hHookThread = CreateThread(0, 0, KeyboardProcThread, this, 0, &dwThreadId);

	return hHookThread != NULL;
}

BOOL CLOWKEYBDHOOK::UnSetHook()
{
	if(hkeybdhook != NULL && UnSetKeybdHook != NULL && hHookThread != NULL)
		UnSetKeybdHook();
	else
		return FALSE;

	SendMessage(hookmsgHwnd, WM_CLOSE, 0, 0);

	WaitForSingleObject(hHookThread, -1);

	CloseHandle(hHookThread);

	hkeybdhook = NULL;
	hHookThread = NULL;

	return TRUE;
}
//////////////////////////////////////////

RDVIEWER::RDVIEWER(SOCKET s)
{
	m_socket = s;
	runFlag = 1;
	m_CursorlMode = 1;
	bitmapExisted = false;
	bCaptureBlt = false;

	m_MenuState = false;

	WinTitle[0] = '\0';

	RDPVersion = 0;

	m_ContorlMode = ID_MODE_VIEW;

	AppInstance = GetModuleHandle(NULL);

    BOOL              bOsVersionInfoEx;
    OSVERSIONINFOEX   osviex;
    memset(&osviex,0,sizeof(OSVERSIONINFOEX));
    osviex.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
    if( !(bOsVersionInfoEx = GetVersionEx ((OSVERSIONINFO *) &osviex)) )
    {
		osviex.dwOSVersionInfoSize = sizeof (OSVERSIONINFO);
		bOsVersionInfoEx = GetVersionEx ( (OSVERSIONINFO *) &osviex);
    }
	if(bOsVersionInfoEx)
	{
		if(osviex.dwPlatformId == VER_PLATFORM_WIN32_NT)
		{
			if ( osviex.dwMajorVersion == 5 && osviex.dwMinorVersion > 0 )
			{
				hDenyCursor =  (HCURSOR)LoadImage(AppInstance, (LPCTSTR)IDI_ICON_DISABLE, IMAGE_ICON, 
					16, 16, LR_DEFAULTCOLOR);
			}else
			{
				hDenyCursor = LoadCursor(AppInstance, (LPCTSTR)IDC_NODROP);
			}
		}
	}

	hNormalCursor = LoadCursor(NULL, (LPCTSTR)IDC_ARROW);
	//hDenyCursor = LoadCursor(AppInstance, (LPCTSTR)IDC_NODROP);
	////hDenyCursor = LoadCursor(AppInstance, (LPCTSTR)IDI_ICON_DISABLE);
	hDotCursor = LoadCursor(AppInstance, (LPCTSTR)IDC_CURSOR1);

	bitinfobuf.checkBufferSize(0x440, 0);
	pmybi = (_BMPINFO *)(BYTE*)bitinfobuf;
	pbiBitInfo = (BITMAPINFO *)(BYTE*)bitinfobuf;

	m_hMemDC = NULL;

	m_hScrollPos = 0; m_vScrollPos = 0;
	evLock.Init();

	m_bUseJpegEncode = false;

	m_prevLocalBits = 0;
}

RDVIEWER::~RDVIEWER()
{
	evLock.Destroy();
    ReleaseDC(m_hwnd, m_viewerDC);
    DeleteDC(hTestDC);
	DeleteObject(hTestBitmap);

	DestroyWindow(m_hwnd);
	DestroyWindow(m_hwnd1);
	DestroyWindow(m_hwndscroll);

}


cbitXtoY RDVIEWER::GetFunc(WORD bits)
{
//bits 8, 16, 32

	WORD bitcount = pbiBitInfo->bmiHeader.biBitCount;
	DWORD compr = pbiBitInfo->bmiHeader.biCompression;

	if(bits == 4)
	{
		if(bitcount == 16 && compr == 3)
		{
			return cbit4to16_565;
		}else if(bitcount == 16 && compr == 0)
		{
			return cbit4to16_555;
		}else if(bitcount == 32 && compr == 3)
		{
			return cbit4to32;
		}else if(bitcount == 32 && compr == 0)
		{
			return cbit4to32;
		}
	}else if(bits == 8)
	{
		if(bitcount == 16 && compr == 0)
		{
			return cbit8to16_555;
		}else if(bitcount == 16 && compr == 3)
		{
			return cbit8to16_565;
		}else if(bitcount == 32 && compr == 3)
		{
			return cbit8to32;
		}else if(bitcount == 32 && compr == 0)
		{
			return cbit8to32;
		}
	}else if(bits == 16)
	{
		if(bitcount == 16 && compr == 0)
		{
			return NULL;//����Ҫ
		}else if(bitcount == 16 && compr == 3)
		{
			return cbit16_555to565;
		}else if(bitcount == 32 && compr == 3)
		{
			return cbit16_555_to_32;
		}else if(bitcount == 32 && compr == 0)
		{
			return cbit16_555_to_32;
		}
	}else if(bits == 24)
	{
		if(bitcount == 16 && compr == 0)
		{
			return cbit24to16_555;
		}else if(bitcount == 16 && compr == 3)
		{
			return cbit24to16_565;
		}else if(bitcount == 32 && compr == 3)
		{
			return cbit24to32;
		}else if(bitcount == 32 && compr == 0)
		{
			return cbit24to32;
		}
	}

	return NULL;

}

void RDVIEWER::SetColorTable()
{

	if(BitsPerPixel == 8)
	{

		for(int idx=0;idx<256;idx++)
		{
			colorTable[idx].rgbBlue = idx;
			colorTable[idx].rgbRed = idx;
			colorTable[idx].rgbGreen = idx;

			colorTable[idx].rgbReserved = 0;

		}
	}
	if(BitsPerPixel == 4)
	{
		for(int idx=0;idx<16;idx++)
		{
			colorTable[idx].rgbBlue = idx * 16;
			colorTable[idx].rgbGreen = idx * 16;
			colorTable[idx].rgbRed = idx * 16;
			colorTable[idx].rgbReserved = 0;
		}


	}


}

bool RDVIEWER::SetBitInfo()
{
    DWORD ScreenPixel = GetDeviceCaps(m_viewerDC, BITSPIXEL);
	DWORD Rast = GetDeviceCaps(m_viewerDC, RASTERCAPS);

	if((Rast & 0x100) || (ScreenPixel !=16 && ScreenPixel != 24 && ScreenPixel != 32) )
	{
		// s1
		//+43c	= 932030
		//+434	= 0
		//+e	= 10
		//+10	= 0
		//+42c	= 0
		//+2b550	= 1
		//return 1
		pbiBitInfo->bmiHeader.biBitCount = 16;
		pbiBitInfo->bmiHeader.biCompression = 0;

		return 1;
	}
	if(ScreenPixel < 16)
	{
		pbiBitInfo->bmiHeader.biBitCount = ScreenPixel;
		pbiBitInfo->bmiHeader.biCompression = 0;

		return 1;
	}

	if(ScreenPixel == 16)
	{
		DWORD rq[3] = {0, 0, 0};

		HBITMAP hb = CreateBitmap(5,1,1, 16 ,NULL);
		//hb == 0 // s1
		HBITMAP ohb = (HBITMAP)SelectObject(hTestDC, hb);

		SetPixel(hTestDC, 0, 0, 0x0ff);//red
		GetBitmapBits(hb, 2, &rq[0]);

		SetPixel(hTestDC, 0, 0, 0x0ff00);//green
		GetBitmapBits(hb, 2, &rq[1]);

		SetPixel(hTestDC, 0, 0, 0x0ff0000);//blue
		GetBitmapBits(hb, 2, &rq[2]);

		SelectObject(hTestDC, ohb);
		DeleteObject(hb);

		if((rq[0] & 0x0ffff) == 0 || (rq[1] & 0x0ffff) == 0 || (rq[2] & 0x0ffff) == 0)
		{
			//s1
			pbiBitInfo->bmiHeader.biBitCount = 16;
			pbiBitInfo->bmiHeader.biCompression = 0;

			return 1;
		}
		//5-5-5
		if((rq[0] & 0x0ffff) == 0x7c00 && (rq[1] & 0x0ffff) == 0x3e0 && (rq[2] & 0x0ffff) == 0x1f)
		{
			//+43c	= 932030
			//+434	= 0
			//+10	= 0
			//+42c	= 0
			//return 1
			pbiBitInfo->bmiHeader.biBitCount = 16;
			pbiBitInfo->bmiHeader.biCompression = 0;

			return 1;
		}


		WORD pix_red, pix_green, pix_blue;
		pix_red = rq[0] & 0x0ffff;
		pix_green = rq[1] & 0x0ffff;
		pix_blue = rq[2] & 0x0ffff;
/*

		BYTE e34 = 0;
		while(1)
		{
			if((pix_red&0x8000) != 0)
				break;
			e34++;
			pix_red = (pix_red) << 1;
		}

		pix_red = pix_red >> e34;//(SAR)??!!

		BYTE e40 = 0;

		while(1)
		{
			if((pix_green&0x8000) != 0)
				break;
			e40++;
			pix_green = pix_green << 1;
		}
		pix_green = pix_green >> e40;

		BYTE e30 = 0;

		while(1)
		{
			if((pix_blue&0x8000) != 0)
				break;
			e30++;
			pix_blue = pix_blue << 1;
		}
		pix_blue = pix_blue >> e30;
*/

		rq[0] = pix_red;
		rq[1] = pix_green;
		rq[2] = pix_blue;

		memcpy((BYTE*)pbiBitInfo+sizeof(pbiBitInfo->bmiHeader), rq, sizeof(rq));

//		bitinfobuf[0x430] = ScreenPixel;
//		*(DWORD*)&bitinfobuf[0x434] = (DWORD)bmpbuf2;

		pbiBitInfo->bmiHeader.biBitCount = 16;
		pbiBitInfo->bmiHeader.biCompression = 3;

			//+43c	= 931fd0
		//set each bits
			//+10	= 3
			//+42c	= 0
		return 1;

	}

	if(ScreenPixel == 24)
	{
		DWORD rq[3] = {0, 0, 0};

		HBITMAP hb = CreateBitmap(5,1,1, 24 ,NULL);
		HBITMAP ohb = (HBITMAP)SelectObject(hTestDC, hb);

		SetPixel(hTestDC, 0, 0, 0x0ff);//red
		GetBitmapBits(hb, 3, &rq[0]);

		SetPixel(hTestDC, 0, 0, 0x0ff00);//green
		GetBitmapBits(hb, 3, &rq[1]);

		SetPixel(hTestDC, 0, 0, 0x0ff0000);//blue
		GetBitmapBits(hb, 3, &rq[2]);

		SelectObject(hTestDC, ohb);
		DeleteObject(hb);

		if(rq[0] == 0 || rq[1] == 0 || rq[2] == 0)
		{
			//s1
			pbiBitInfo->bmiHeader.biBitCount = 16;
			pbiBitInfo->bmiHeader.biCompression = 0;
			return 1;
		}
		//make sure each pixel to and 0xffffff
		//needless
		if(rq[0] == 0xff0000 && rq[1] == 0xff00 && rq[2] == 0xff)
		{
			//+434 = 0
			//+43c = 932150
			//+10  = 0
			//+42c = 0
			pbiBitInfo->bmiHeader.biBitCount = 16;
			pbiBitInfo->bmiHeader.biCompression = 0;
			return 1;
		}
		if(rq[0] == 0xff && rq[1] == 0xff00 && rq[2] == 0xff0000)
		{
			//+434 = 0
			//+43c = 9320b0
			//+10  = 3
		//set each bits
			//+42c = 0
			memcpy((BYTE*)pbiBitInfo+sizeof(pbiBitInfo->bmiHeader), rq, sizeof(rq));
			pbiBitInfo->bmiHeader.biBitCount = 16;
			pbiBitInfo->bmiHeader.biCompression = 3;
			return 1;
		}else
		{
			//s1
			pbiBitInfo->bmiHeader.biBitCount = 16;
			pbiBitInfo->bmiHeader.biCompression = 0;
			return 1;
		}
	}

	if(ScreenPixel == 32)
	{
		DWORD rq[3] = {0, 0, 0};

		HBITMAP hb = CreateBitmap(5,1,1, 32 ,NULL);
		HBITMAP ohb = (HBITMAP)SelectObject(hTestDC, hb);

		SetPixel(hTestDC, 0, 0, 0x0ff);//red
		GetBitmapBits(hb, 4, &rq[0]);

		SetPixel(hTestDC, 0, 0, 0x0ff00);//green
		GetBitmapBits(hb, 4, &rq[1]);

		SetPixel(hTestDC, 0, 0, 0x0ff0000);//blue
		GetBitmapBits(hb, 4, &rq[2]);

		SelectObject(hTestDC, ohb);
		DeleteObject(hb);

		if(rq[0] == 0 || rq[1] == 0 || rq[2] == 0)
		{
			//s1
			//..
			//+43c = 932030
			pbiBitInfo->bmiHeader.biBitCount = 16;
			pbiBitInfo->bmiHeader.biCompression = 0;
			return 1;
		}
		//radmin save it to pbiBitInfo+0x2b554,0x2b558,0x2b55c
		//...
		//...
		//make sure each pixel to and 0xffffff
		//needless
		if(rq[0] == 0xff && rq[1] == 0xff00 && rq[2] == 0xff0000)
		{
			//+434 = 0
			//+43c = 932060
			//+10 = 0
			//+42c = 0
			pbiBitInfo->bmiHeader.biBitCount = 32;
			pbiBitInfo->bmiHeader.biCompression = 0;
			return 1;
		}
		if(rq[0] == 0xff0000 && rq[1] == 0xff00 && rq[2] == 0xff)
		{
			//+434 = 0
			//+43c = 932100
			//+10 = 3
		//set each bits
			//+42c = 0
			memcpy((BYTE*)pbiBitInfo+sizeof(pbiBitInfo->bmiHeader), rq, sizeof(rq));
			pbiBitInfo->bmiHeader.biBitCount = 32;
			pbiBitInfo->bmiHeader.biCompression = 3;//!!!!!!!!!!
			return 1;
		}else
		{
			//s1
			//+43c = 932030
			pbiBitInfo->bmiHeader.biBitCount = 16;
			pbiBitInfo->bmiHeader.biCompression = 0;
			return 1;
		}
	}

	return true;
}


int RDVIEWER::DrawCursor()
{
	if(srvscrX == 0 || srvscrY == 0 || !GetCursorState())
		return 0;

	if(m_DisplayMode == ID_DISPLAY_NORMAL)
	{
		DrawIcon(m_viewerDC,
			cursorX-m_hScrollPos,
			cursorY-m_vScrollPos,
			hRemoteCursor);
	}else
	{
		GetClientRect(m_hwnd, &rt);

	/*	StretchDIBits(g_myDC, 
			prevcursorX*(rt.right-rt.left)/srvscrX,
			prevcursorY*(rt.bottom-rt.top)/srvscrX,
			10*(rt.right-rt.left)/srvscrX, 
			10*(rt.bottom-rt.top)/srvscrX, 
			prevcursorX,prevcursorY,10, 10, bmpbuf, pbiBitInfo, DIB_RGB_COLORS, SRCCOPY);
	*/
		DrawIcon(m_viewerDC,
			cursorX*(rt.right-rt.left)/srvscrX,
			cursorY*(rt.bottom-rt.top)/srvscrY,
			hRemoteCursor);
	}

	prevcursorX = cursorX;
	prevcursorY = cursorY;

	return 0;
}

int RDVIEWER::DoBlt(RECT *lpPaint)
{
	if(srvscrX == 0 || srvscrY == 0)
		return 0;

	if(!bitmapExisted)
	{
		COLORREF bgcol = RGB(0xcc, 0xcc, 0xcc);
		COLORREF oldbgcol  = SetBkColor(m_viewerDC, bgcol);
		COLORREF oldtxtcol = SetTextColor(m_viewerDC, RGB(0,0,64));

		RECT rect;
		GetClientRect(m_hwnd1, &rect);
		DrawText (m_viewerDC, ("���Ժ� - ���ڳ�ʼ����Ļ"), -1, &rect,
				  DT_SINGLELINE | DT_CENTER | DT_VCENTER);

		SetBkColor(m_viewerDC, oldbgcol);
		SetTextColor(m_viewerDC, oldtxtcol);

	}else
	{
		if(m_DisplayMode == ID_DISPLAY_NORMAL)
		{
			SetStretchBltMode(m_viewerDC, COLORONCOLOR);

			SetDIBitsToDevice(m_viewerDC, 0,0,srvscrX, srvscrY, 
				m_hScrollPos,-m_vScrollPos,0, srvscrY, (BYTE*)bmpbuf, pbiBitInfo, DIB_RGB_COLORS);
			//StretchDIBits(m_viewerDC, 0,0,srvscrX, srvscrY, 
			//	m_hScrollPos,-m_vScrollPos,srvscrX, srvscrY, (BYTE*)bmpbuf, pbiBitInfo, DIB_RGB_COLORS, SRCCOPY);

		}else
		{
			GetClientRect(m_hwnd, &rt);
			int winW,winH;
			
			winW = rt.right-rt.left;
			winH = rt.bottom-rt.top;
			
			if(winW == 0 || winH == 0)
				return 0;

			if(srvscrX<=winW && srvscrY<=winH)
			{
				SetStretchBltMode(m_viewerDC, COLORONCOLOR);
				SetDIBitsToDevice(m_viewerDC, 0,0,srvscrX, srvscrY, 
					m_hScrollPos,-m_vScrollPos,0, srvscrY, (BYTE*)bmpbuf, pbiBitInfo, DIB_RGB_COLORS);
			}else
			{
				StretchDIBits(m_viewerDC, 0,0,winW, winH, 
					0,0,srvscrX, srvscrY, (BYTE*)bmpbuf, pbiBitInfo, DIB_RGB_COLORS, SRCCOPY);
/*
				int bufX,bufY, bufW, bufH;

				bufX = 0;
				bufY = lpPaint->top*(-pbiBitInfo->bmiHeader.biHeight)/winH;
				
				bufW = pbiBitInfo->bmiHeader.biWidth;
				bufH = (lpPaint->bottom-lpPaint->top)*(-pbiBitInfo->bmiHeader.biHeight)/winH;

				StretchDIBits(m_viewerDC, 
					0,lpPaint->top, 
					winW, lpPaint->bottom-lpPaint->top, 
					bufX, bufY, 
					bufW, bufH, 
					(BYTE*)bmpbuf, pbiBitInfo, DIB_RGB_COLORS, SRCCOPY);
*/
			}
		}

		DrawCursor();
	}

/*	DrawIcon(m_viewerDC,
		cursorX*(rt.right-rt.left)/srvscrX,
		cursorY*(rt.bottom-rt.top)/srvscrY,
		hRemoteCursor);
*/
	return 1;
}

/*
int RDVIEWER::DoBlt1(RECT *lpPaint)
{
	if(srvscrX == 0 || srvscrY == 0)
		return 0;

	int ret;

	if(!bitmapExisted)
	{
		COLORREF bgcol = RGB(0xcc, 0xcc, 0xcc);
		COLORREF oldbgcol  = SetBkColor(m_viewerDC, bgcol);
		COLORREF oldtxtcol = SetTextColor(m_viewerDC, RGB(0,0,64));

		RECT rect;
		GetClientRect(m_hwnd1, &rect);
		DrawText (m_viewerDC, ("���Ժ� - ���ڳ�ʼ����Ļ"), -1, &rect,
				  DT_SINGLELINE | DT_CENTER | DT_VCENTER);

		SetBkColor(m_viewerDC, oldbgcol);
		SetTextColor(m_viewerDC, oldtxtcol);

	}else
	{
		if(m_DisplayMode == ID_DISPLAY_NORMAL)
		{
			SetStretchBltMode(m_viewerDC, COLORONCOLOR);
			ret = BitBlt(m_viewerDC, m_hScrollPos, -m_vScrollPos,
				srvscrX, srvscrY, cMemBmp.m_hMemDC, 0,0, SRCCOPY);

		}else
		{
			GetClientRect(m_hwnd, &rt);
			int winW,winH;
			
			winW = rt.right-rt.left;
			winH = rt.bottom-rt.top;
			
			if(winW == 0 || winH == 0)
				return 0;

			if(srvscrX<=winW && srvscrY<=winH)
			{
				SetStretchBltMode(m_viewerDC, COLORONCOLOR);
				SetDIBitsToDevice(m_viewerDC, 0,0,srvscrX, srvscrY, 
					m_hScrollPos,-m_vScrollPos,0, srvscrY, (BYTE*)bmpbuf, pbiBitInfo, DIB_RGB_COLORS);
			}else
			{
				StretchDIBits(m_viewerDC, 0,0,winW, winH, 
					0,0,srvscrX, srvscrY, (BYTE*)bmpbuf, pbiBitInfo, DIB_RGB_COLORS, SRCCOPY);

			}
		}

		DrawCursor();
	}

	return 1;
}
*/
int RDVIEWER::UpdateRect(_tagRect &posrect, BYTE *pDIBData, DWORD dibLen)
{

	int i, ret;

	int len = 0;

	if(posrect.w*posrect.h*BitsPerPixel/8  != dibLen)
	{
		__printf("data len incorroct.\r\n");
		return 0;
	}

	if((posrect.h-1+posrect.y)*(pbiBitInfo->bmiHeader.biWidth)*pbiBitInfo->bmiHeader.biBitCount/8 
		+ posrect.x*pbiBitInfo->bmiHeader.biBitCount/8 > bmpbuf.GetSize())
	{
		__printf("data len overflow.\r\n");
		return 0;
	}

	//SetBitInfo();

	cbitXtoY pFun = GetFunc(BitsPerPixel);
	//
	//if(m_prevLocalBits != pbiBitInfo->bmiHeader.biBitCount)
	//{
	//	//
	//	bitmapExisted = false;

	//	m_prevLocalBits = pbiBitInfo->bmiHeader.biBitCount;
	//}

	len = 0;
	for(i=0; i<posrect.h; i++)
	{
		int offset = (i+posrect.y)*(pbiBitInfo->bmiHeader.biWidth)*pbiBitInfo->bmiHeader.biBitCount/8 + posrect.x*pbiBitInfo->bmiHeader.biBitCount/8;

		if(pFun)
		{
			pFun(pDIBData+len, bmpbuf+offset, colorTable, 1, posrect.w);
		}else
		{
			memcpy(bmpbuf+offset, pDIBData+len, posrect.w*BitsPerPixel/8);
		}

		len += posrect.w*BitsPerPixel/8;
	}
	InvalidateRect(m_hwnd, NULL, FALSE);

/*
	RECT upRect;
	GetClientRect(m_hwnd, &rt);
	int winW,winH;
	
	winW = rt.right-rt.left;
	winH = rt.bottom-rt.top;

	upRect.left = posrect.x*winW/srvscrX;
	upRect.top = posrect.y*winH/srvscrY;
	upRect.right = (posrect.x+posrect.w)*winW/srvscrX;
	upRect.bottom = (posrect.y+posrect.h)*winH/srvscrY;

	InvalidateRect(m_hwnd, &upRect, FALSE);
	//DoBlt(&upRect);
*/
//	if(posrect.h < 11)
//		return;
//__printf("%9d, %4d %4d %4d %4d\r\n", totallen,
//						posrect.x/perpixelsize, posrect.y, posrect.w/perpixelsize, posrect.h);

	return 1;
}

int RDVIEWER::SendAction(BYTE action, BYTE flag)
{
	_tagRDPHEAD rdph;

	rdph.action = action;
	rdph.flag = flag;
	rdph.dataSize = 0;

	return sockdata.SendAction(&rdph);
}

int RDVIEWER::SetComprLevel(int level)
{
	_tagRDPHEAD rdph;

	rdph.action = RDP_SETCOMPRLEVEL;
	rdph.flag = level;
	rdph.dataSize = 0;

	return sockdata.SendAction(&rdph);
}



//ע�����÷������ݵ��ٽ�
int RDVIEWER::RecvMessage()
{
	DWORD t;

	_tagZLIBINFO zinfo;
	int ret;

	t = GetTickCount();
	int frame=0;
	int ctime = 1;
	DWORD currtime=0, totalsize=0, currtotalsize = 0;

	while(runFlag)
//	int forfun = 1;
//	while(forfun)
	{
//		forfun = 0;

		ret = Recv(m_socket, (char*)&rdph, sizeof(rdph));

		if(!ret)
		{
			DWORD err = WSAGetLastError();
			break;
		}


		switch(rdph.action)
		{
			case RDP_VERSION:
			{
				//RDPVersion��һ��float
				*(DWORD*)&RDPVersion = rdph.dataSize;
			}
			break;
			case RDP_CUTTEXT:
			{
				//����Զ�̼���������
				ret = UpdateLocalClipboard();
				if(ret < 0)
				{
					runFlag = 0;
					break;
				}

			}
			break;
			case RDP_CURSORPOS:
			{
				cursorX = rdph.dataSize >> 16;
				cursorY = rdph.dataSize & 0xffff;

				//__printf("Cursor:(%4d, %4d)\r\n", cursorX, cursorY);

			//	GetClientRect(m_hwnd, &rt);
			
			//	DrawCursor();
				InvalidateRect(m_hwnd, NULL, FALSE);

			//	DoBlt(&rt);
				

			}
			break;
			case RDP_BITMAPINFO:
			{
				//���մ���λͼ����Ϣ
				if(rdph.flag == us_ZLIB)
				{
					ret = Recv(m_socket, (char*)&zinfo, sizeof(zinfo));
					if(!ret)
					{
						runFlag = 0;
						break;
					}
					//
					if(!zbmpbuf.checkBufferSize(rdph.dataSize, false))
					{
						__printf("zbmpbuf checkBufferSize failed.\r\n");
						runFlag = 0;
						break;
					}	
					ret = Recv(m_socket, zbmpbuf, rdph.dataSize);
					if(!ret)
					{
						runFlag = 0;
						break;
					}

					//bitinfobuf checkbuffersize
					if(!bitinfobuf.checkBufferSize(zinfo.uncomprLen, 0))
					{
						__printf("bitinfobuf checkBufferSize failed.\r\n");
						runFlag = 0;
						break;
					}

					ret = uncompress((BYTE*)bitinfobuf, &zinfo.uncomprLen, (BYTE*)zbmpbuf, rdph.dataSize);
					if(ret != 0)
					{
						__printf("bitinfobuf uncompress failed.\r\n");
						runFlag = 0;
						break;
					}
					//!!!!����point
					pmybi = (_BMPINFO *)(BYTE*)bitinfobuf;

					srvscrX = pmybi->bmih.biWidth;
					srvscrY = -pmybi->bmih.biHeight;
					BitsPerPixel = pmybi->BitsPerPixel;
/*
					if(cMemBmp.SetBmpRect(srvscrX, srvscrY) < 0)
					{
						__printf("Set memory Bmp Rect failed.\r\n");
						runFlag = 0;
						break;		
					}
*/
					CheckMenuItem(GetMenu(m_hwnd1), ID_SETPIXEL_4, MF_BYCOMMAND|MF_UNCHECKED);
					CheckMenuItem(GetMenu(m_hwnd1), ID_SETPIXEL_8, MF_BYCOMMAND|MF_UNCHECKED);
					CheckMenuItem(GetMenu(m_hwnd1), ID_SETPIXEL_16, MF_BYCOMMAND|MF_UNCHECKED);
					CheckMenuItem(GetMenu(m_hwnd1), ID_SETPIXEL_32, MF_BYCOMMAND|MF_UNCHECKED);

					CheckMenuItem(GetMenu(m_hwnd1), ID_SETPIXEL_BASE+BitsPerPixel, MF_BYCOMMAND|MF_CHECKED);

					//�Ȼ�ñ�������ʾ��Ϣ
					SetBitInfo();

					//����㹻����Ա���ɫλ��Զ�̼�����ֱ��ʵ�bmpͼƬ�ڴ�
					if(!bmpbuf.checkBufferSize(srvscrX*srvscrY*pbiBitInfo->bmiHeader.biBitCount/8 , true))
					{
						__printf("bmpbuf checkBufferSize failed.\r\n");
						return 0;
					}

					SetColorTable();

					pbiBitInfo->bmiHeader.biSizeImage = srvscrX*srvscrY*pbiBitInfo->bmiHeader.biBitCount/8;


					PositionChildWindow();

					bitmapExisted = false;

					RECT rect;
					GetClientRect(m_hwnd1, &rect);
					DoBlt(&rect);
				}else
				{
					__printf("RDP_BITMAPINFO != us_ZLIB.\r\n");
					break;
				}

			}
			break;

			//������Ļ����λͼ
			case RDP_UPDATESCREEN:
			{
				bitmapExisted = true;
				
				DWORD dibLen;
				_tagRect Rect;

				speedtest.Start(0);

				//�����ֱ�������� ZLIB ѹ����ֻ��us_JPEGZLIB��ѹ�����JPEG����
				if(rdph.flag == us_ZLIB || rdph.flag == us_JPEGZLIB)
				{
					ret = Recv(m_socket, (char*)&zinfo, sizeof(zinfo));
					//if(!)
					if(!zbmpbuf.checkBufferSize(rdph.dataSize, false))
					{
						__printf("zbmpbuf checkBufferSize failed.\r\n");
						runFlag = 0;
						break;
					}				
					ret = Recv(m_socket, zbmpbuf, rdph.dataSize);
					if(!ret)
					{
						runFlag = 0;
						break;
					}

					if(!bmpbuf1.checkBufferSize(zinfo.uncomprLen, false))
					{
						__printf("zbmpbuf checkBufferSize failed.\r\n");
						runFlag = 0;
						break;
					}
					ret = uncompress((BYTE*)bmpbuf1, &zinfo.uncomprLen, (BYTE*)zbmpbuf, rdph.dataSize);
					if(ret != 0)
					{
						__printf("zbmpbuf uncompress failed.\r\n");
						runFlag = 0;
						break;
					}
					dibLen = zinfo.uncomprLen - sizeof(Rect);

				}
				else
				{
					if(!bmpbuf1.checkBufferSize(rdph.dataSize, false))
					{
						__printf("bmpbuf1 checkBufferSize failed.\r\n");
						runFlag = 0;
						break;
					}
					ret = Recv(m_socket, bmpbuf1, rdph.dataSize);
					if(!ret)
					{
						runFlag = 0;
						break;
					}

					dibLen = rdph.dataSize - sizeof(Rect);

				}

				//�����JPEG�������ٽ���ΪBMP
				if(rdph.flag == us_JPEGZLIB)
				{
					BYTE *lpRGBBuf = NULL;
					BYTE *lpJPEGBuf = (BYTE*)bmpbuf1+sizeof(Rect);
					DWORD jw,jh, jc;
					WORD currBits;

					memcpy(&Rect, (BYTE*)bmpbuf1, sizeof(Rect));

					if(!DecodeFromJPEGBuffer(lpJPEGBuf, dibLen, &lpRGBBuf, &jw, &jh, &jc))
					{
						__printf("DecodeFromJPEGBuffer failed.\r\n");
						runFlag = 0;
						break;
					}

					//DecodeFromJPEGBuffer == TRUE
					//��ʱ lpRGBBuf �õ�һ������24 bit ��DIB �ڴ� ָ��

					currBits = BitsPerPixel;
					//��ʱ�޸�BitsPerPixelΪ24�� �Ա���UpdateRect�����̴���24 bit ��DIB
					BitsPerPixel = jc*8;

					ret = UpdateRect(Rect, lpRGBBuf, jw*jh*jc);

					//�ָ�ԭ����ֵ
					BitsPerPixel = currBits;

					//�ͷ��ڴ�
					delete [] lpRGBBuf;
					
					if(!ret)
					{
						runFlag = 0;
						break;
					}


				}else
				{
					//bmpbuf1+sizeof(Rect) Ϊ DIB ���ݣ� ֱ�Ӹ��µ�ͼ�񻺳���
					memcpy(&Rect, (BYTE*)bmpbuf1, sizeof(Rect));

					if(!UpdateRect(Rect, (BYTE*)bmpbuf1+sizeof(Rect), dibLen))
					{
						runFlag = 0;
						break;
					}
				}

				__printf("wh: %d*%d, size: %d\r\n", Rect.w, Rect.h, rdph.dataSize);
	
				speedtest.Stop(rdph.dataSize);
		
				currtotalsize += rdph.dataSize;

				frame++;

			}
			break;
			default:
			{
				__printf("unknown action: %d, %d, %d\r\n", rdph.action, rdph.flag, rdph.dataSize);
				runFlag = 0;
				break;
			}
		}


	/*
		packets++;
		__printf("%d\r\n", packets);
	
		currtime = GetTickCount();
		if(currtime - t >= 1000)
		{
			char buf[100];
			totalsize += currtotalsize;

			sprintf(buf, "Frames/sec: %-4d, kb/sec: %-9d | %-9d\r\n", frame, currtotalsize*1000/(currtime - t)/1024, speedtest.GetumSpeed());
			SetConsoleTitle(buf);

			t = currtime;
			frame = 0;
			currtotalsize = 0;
			ctime++;
		}
*/
	}

	return runFlag;

}

int RDVIEWER::msgloop()
{
	MSG msg;
	while(GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return 1;
}

void RDVIEWER::SetDisplayWinTitle(char *szTitle)
{
	strncpy(WinTitle, szTitle, sizeof(WinTitle));
}

int RDVIEWER::CreateDisplay()
{
	WNDCLASS wndclass;

	wndclass.style			= 0;
	wndclass.lpfnWndProc	= Proc;
	wndclass.cbClsExtra		= 0;
	wndclass.cbWndExtra		= 0;
	wndclass.hInstance		= AppInstance;
	wndclass.hIcon			= LoadIcon(AppInstance, (LPCTSTR)IDI_RDICON);
	wndclass.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground	= (HBRUSH) GetStockObject(BLACK_BRUSH);
    wndclass.lpszMenuName	= (LPCTSTR)IDR_RD_MENU;
	wndclass.lpszClassName	= VWR_WND_CLASS_NAME;


	RegisterClass(&wndclass);

	wndclass.style			= 0;
	wndclass.lpfnWndProc	= ScrollProc;
	wndclass.cbClsExtra		= 0;
	wndclass.cbWndExtra		= 0;
	wndclass.hInstance		= AppInstance;
	wndclass.hIcon			= NULL;
	wndclass.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground	= (HBRUSH) GetStockObject(BLACK_BRUSH);
    wndclass.lpszMenuName	= (LPCTSTR)NULL;
	wndclass.lpszClassName	= "ScrollClass";

	RegisterClass(&wndclass);


	wndclass.style			= 0;
	wndclass.lpfnWndProc	= Proc;
	wndclass.cbClsExtra		= 0;
	wndclass.cbWndExtra		= 0;
	wndclass.hInstance		= AppInstance;
	wndclass.hIcon			= NULL;
	wndclass.hbrBackground	= (HBRUSH) GetStockObject(BLACK_BRUSH);
    wndclass.lpszMenuName	= (LPCTSTR)NULL;
	wndclass.lpszClassName	= "ChildClass";

	RegisterClass(&wndclass);
	
	m_hwnd1 = CreateWindow(VWR_WND_CLASS_NAME,
			      "ZXScreenCtrl",
			      WS_BORDER|WS_CAPTION|WS_SYSMENU|WS_SIZEBOX|
				  WS_MINIMIZEBOX|WS_MAXIMIZEBOX|
				  WS_CLIPCHILDREN,
			      CW_USEDEFAULT,
			      CW_USEDEFAULT,
			      500,       // x-size
			      400,       // y-size
			      NULL,                // Parent handle
			      NULL,                // Menu handle
			      AppInstance,
			      NULL);

	SetWindowLong(m_hwnd1, GWL_USERDATA, (LONG) this);
	SetWindowLong(m_hwnd1, GWL_WNDPROC, (LONG)WndProc1);
	ShowWindow(m_hwnd1, SW_SHOW);

#if defined _ZXS_RDVIEWER
	HMENU hSysMenu = GetSystemMenu(m_hwnd1, FALSE);
	AppendMenu(hSysMenu, MF_SEPARATOR, 0, 0);
	AppendMenu(hSysMenu, MF_STRING|MF_ENABLED, IDC_CONNINFO, "������Ϣ");
#endif

	m_hwndscroll = CreateWindow("ScrollClass",
			      NULL,
			      WS_CHILD | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | WS_BORDER,
			      CW_USEDEFAULT,
			      CW_USEDEFAULT,
			      CW_USEDEFAULT,       // x-size
			      CW_USEDEFAULT,       // y-size
			      m_hwnd1,                // Parent handle
			      NULL,                // Menu handle
			      AppInstance,
			      NULL);
	SetWindowLong(m_hwndscroll, GWL_USERDATA, (LONG) this);
	ShowWindow(m_hwndscroll, SW_HIDE);

	m_hwnd = CreateWindow("ChildClass",
			      NULL,
			      WS_CHILD | WS_CLIPSIBLINGS | WS_GROUP,
			      CW_USEDEFAULT,
			      CW_USEDEFAULT,
			      CW_USEDEFAULT,       // x-size
			      CW_USEDEFAULT,	   // y-size
			      m_hwndscroll,             // Parent handle
			      NULL,                // Menu handle
			      AppInstance,
			      NULL);

	m_viewerDC = GetDC(m_hwnd);
	m_DisplayMode = ID_DISPLAY_STRETCH;
	SetStretchBltMode(m_viewerDC, STRETCH_DELETESCANS);

    ShowWindow(m_hwnd, SW_HIDE);
		
	SetWindowLong(m_hwnd, GWL_USERDATA, (LONG) this);
	SetWindowLong(m_hwnd, GWL_WNDPROC, (LONG)WndProc);

	hRemoteCursor = LoadCursor(AppInstance, MAKEINTRESOURCE(IDC_POINTER));

	PositionChildWindow();
	
	CheckMenuRadioItem(GetSubMenu(GetMenu(m_hwnd1), 3), ID_COMPRLEVEL_AUTO, ID_COMPRLEVEL_9, ID_COMPRLEVEL_AUTO, MF_BYCOMMAND);

    hTestDC = CreateCompatibleDC(0);

    hTestBitmap = CreateCompatibleBitmap(m_viewerDC, 5, 1);

	SelectObject(hTestDC, hTestBitmap);

	//cMemBmp.init(m_viewerDC);

	m_hwndNextViewer = SetClipboardViewer(m_hwnd);

	//��ֹ���ش����л����뷨
	ImmDisableIME(GetCurrentThreadId());

	SOCKADDR_IN sa;
	int salen = sizeof(SOCKADDR_IN);
	getpeername(m_socket, (struct sockaddr *)&sa, &salen);
	if(!WinTitle[0])
	{
		sprintf(WinTitle, "\\%s", inet_ntoa(sa.sin_addr ));
	}
	SetWindowText(m_hwnd1, WinTitle);
	
	sockdata.init(m_socket);

//	if(WSAAsyncSelect(m_socket, m_hwnd1, RD_SOCKET, FD_READ|FD_CLOSE) == SOCKET_ERROR) {
//		MessageBox(m_hwnd1, "�����Ѿ�����.", "����", MB_ICONERROR);
//	}

	return 1;
}


LRESULT CALLBACK RDVIEWER::Proc(HWND hwnd, UINT iMsg,
										WPARAM wParam, LPARAM lParam)
{
	return DefWindowProc(hwnd, iMsg, wParam, lParam);
}

LRESULT CALLBACK RDVIEWER::_ScrollProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{

	switch (iMsg) {
	case WM_HSCROLL:
		{				
			int dx = 0;
			int pos = HIWORD(wParam);
			switch (LOWORD(wParam)) {
			case SB_LINEUP:
				dx = - 2; break;
			case SB_LINEDOWN:
				dx = 2; break;
			case SB_PAGEUP:
				dx = m_cliwidth * -1/4; break;
			case SB_PAGEDOWN:
				dx = m_cliwidth * 1/4; break;
			case SB_THUMBPOSITION:
				dx = pos - m_hScrollPos;
			case SB_THUMBTRACK:
				dx = pos - m_hScrollPos;
			}
			//if (!_this->m_opts.m_FitWindow) 
			ScrollScreen(dx,0);
			return 0;
		}
	case WM_VSCROLL:
		{
			int dy = 0;
			int pos = HIWORD(wParam);
			switch (LOWORD(wParam)) {
			case SB_LINEUP:
				dy =  - 2; break;
			case SB_LINEDOWN:
				dy = 2; break;
			case SB_PAGEUP:
				dy =  m_cliheight * -1/4; break;
			case SB_PAGEDOWN:
				dy = m_cliheight * 1/4; break;
			case SB_THUMBPOSITION:
				dy = pos - m_vScrollPos;
			case SB_THUMBTRACK:
				dy = pos - m_vScrollPos;
			}
			//if (!_this->m_opts.m_FitWindow) 
			ScrollScreen(0,dy);
			return 0;
		}
	}
	return DefWindowProc(hwnd, iMsg, wParam, lParam);
}

bool RDVIEWER::ScrollScreen(int dx, int dy) 
{
	dx = max(dx, -m_hScrollPos);
	//dx = min(dx, m_hScrollMax-(m_cliwidth-1)-m_hScrollPos);
	dx = min(dx, m_hScrollMax-(m_cliwidth)-m_hScrollPos);
	dy = max(dy, -m_vScrollPos);
	//dy = min(dy, m_vScrollMax-(m_cliheight-1)-m_vScrollPos);
	dy = min(dy, m_vScrollMax-(m_cliheight)-m_vScrollPos);
	if (dx || dy) {
		m_hScrollPos += dx;
		m_vScrollPos += dy;
		RECT clirect;
		GetClientRect(m_hwnd, &clirect);
		ScrollWindowEx(m_hwnd, -dx, -dy,
				NULL, &clirect, NULL, NULL,  SW_INVALIDATE);
		UpdateScrollbars();
		UpdateWindow(m_hwnd);
		return true;
	}
	return false;
}

void RDVIEWER::UpdateScrollbars() 
{
	// We don't update the actual scrollbar info in full-screen mode
	// because it causes them to flicker.
	bool setInfo = !InFullScreenMode();
	//bool setInfo = 1;

	SCROLLINFO scri;
	scri.cbSize = sizeof(scri);
	scri.fMask = SIF_ALL | SIF_DISABLENOSCROLL;
	scri.nMin = 0;
	scri.nMax = m_hScrollMax; 
	scri.nPage= m_cliwidth;
	scri.nPos = m_hScrollPos; 
	
	if (setInfo) 
		SetScrollInfo(m_hwndscroll, SB_HORZ, &scri, TRUE);
	
	scri.cbSize = sizeof(scri);
	scri.fMask = SIF_ALL | SIF_DISABLENOSCROLL;
	scri.nMin = 0;
	scri.nMax = m_vScrollMax;     
	scri.nPage= m_cliheight;
	scri.nPos = m_vScrollPos; 
	
	if (setInfo) 
		SetScrollInfo(m_hwndscroll, SB_VERT, &scri, TRUE);
}

void RDVIEWER::PositionChildWindow()
{

	RECT rparent;
	GetClientRect(m_hwnd1, &rparent);
	
	int parentwidth = rparent.right - rparent.left;
	int parentheight = rparent.bottom - rparent.top; 

	m_fullwinwidth = srvscrX;
	m_fullwinheight = srvscrY;

	
	SetWindowPos(m_hwndscroll, HWND_TOP, rparent.left - 1, rparent.top - 1,
					parentwidth + 2, parentheight + 2, SWP_SHOWWINDOW);

	if (m_DisplayMode != ID_DISPLAY_NORMAL) {				
		ShowScrollBar(m_hwndscroll, SB_HORZ, FALSE);
		ShowScrollBar(m_hwndscroll, SB_VERT, FALSE);
	} else {
		ShowScrollBar(m_hwndscroll, SB_VERT, parentheight < m_fullwinheight);
		ShowScrollBar(m_hwndscroll, SB_HORZ, parentwidth  < m_fullwinwidth);
		GetClientRect(m_hwndscroll, &rparent);	
		parentwidth = rparent.right - rparent.left;
		parentheight = rparent.bottom - rparent.top;
		ShowScrollBar(m_hwndscroll, SB_VERT, parentheight < m_fullwinheight);
		ShowScrollBar(m_hwndscroll, SB_HORZ, parentwidth  < m_fullwinwidth);
		GetClientRect(m_hwndscroll, &rparent);	
		parentwidth = rparent.right - rparent.left;
		parentheight = rparent.bottom - rparent.top;		
	}


	
	int x, y;
	if (parentwidth  > m_fullwinwidth) {
		x = (parentwidth - m_fullwinwidth) / 2;
	} else {
		x = rparent.left;
	}
	if (parentheight > m_fullwinheight) {
		y = (parentheight - m_fullwinheight) / 2;
	} else {
		y = rparent.top;
	}
	
	SetWindowPos(m_hwnd, HWND_TOP, x, y,
					min(parentwidth, m_fullwinwidth),
					min(parentheight, m_fullwinheight),
					SWP_SHOWWINDOW);

	m_cliwidth = min( (int)parentwidth, (int)m_fullwinwidth);
	m_cliheight = min( (int)parentheight, (int)m_fullwinheight);

	m_hScrollMax = m_fullwinwidth;
	m_vScrollMax = m_fullwinheight;
           
	int newhpos, newvpos;

	newhpos = max(0, min(m_hScrollPos, 
							 m_hScrollMax - max(m_cliwidth, 0)));
	newvpos = max(0, min(m_vScrollPos, 
				             m_vScrollMax - max(m_cliheight, 0)));

	RECT clichild;
	GetClientRect(m_hwnd, &clichild);
	ScrollWindowEx(m_hwnd, m_hScrollPos-newhpos, m_vScrollPos-newvpos,
					NULL, &clichild, NULL, NULL,  SW_INVALIDATE);
								
	m_hScrollPos = newhpos;
	m_vScrollPos = newvpos;

	UpdateScrollbars();
		
	UpdateWindow(m_hwnd);
}

void RDVIEWER::RealiseFullScreenMode(bool suppressPrompt)
{
	LONG style = GetWindowLong(m_hwnd1, GWL_STYLE);
	if (InFullScreenMode()) {

		SetMenu(m_hwnd1, NULL);
		ShowWindow(m_hwnd1, SW_MAXIMIZE);
		style = GetWindowLong(m_hwnd1, GWL_STYLE);
		style &= ~(WS_DLGFRAME | WS_THICKFRAME);
		
		SetWindowLong(m_hwnd1, GWL_STYLE, style);
		int cx = GetSystemMetrics(SM_CXSCREEN);
		int cy = GetSystemMetrics(SM_CYSCREEN);
		SetWindowPos(m_hwnd1, HWND_TOPMOST, -1, -1, cx + 3, cy + 3, SWP_FRAMECHANGED);
		
	} else {

		style |= (WS_DLGFRAME | WS_THICKFRAME);
		
		SetMenu(m_hwnd1, LoadMenu(AppInstance, (LPCTSTR)IDR_RD_MENU));

		SetWindowLong(m_hwnd1, GWL_STYLE, style);
		SetWindowPos(m_hwnd1, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		ShowWindow(m_hwnd1, SW_NORMAL);		

	}

	SetFocus(m_hwnd);

}

LRESULT CALLBACK RDVIEWER::WndProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	RDVIEWER *_this = (RDVIEWER *) GetWindowLong(hwnd, GWL_USERDATA);

	return _this->_WndProc(hwnd, iMsg, wParam, lParam);
}

LRESULT CALLBACK RDVIEWER::WndProc1(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	RDVIEWER *_this = (RDVIEWER *) GetWindowLong(hwnd, GWL_USERDATA);

	return _this->_WndProc1(hwnd, iMsg, wParam, lParam);
}

LRESULT CALLBACK RDVIEWER::ScrollProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	RDVIEWER *_this = (RDVIEWER *) GetWindowLong(hwnd, GWL_USERDATA);

	return _this->_ScrollProc(hwnd, iMsg, wParam, lParam);
}


LRESULT CALLBACK RDVIEWER::_WndProc1(HWND hwnd, UINT iMsg, 
					   WPARAM wParam, LPARAM lParam) 
{
	int ret;
	HMENU hMenu = GetMenu(m_hwnd1);
	
	switch (iMsg) {

		case WM_SIZE:
		case WM_SIZING:
		{
			PositionChildWindow();
			break;
		}

		//����û�����˵������ʱ��������־��
		//������̹��Ӱ�ͨ������ѡ��˵����¼�Ҳ����Զ�̼����
		case WM_INITMENUPOPUP:
			m_MenuState = true;
			return 0;

		case WM_UNINITMENUPOPUP:
			m_MenuState = false;
			return 0;

		case WM_SETFOCUS://�Ӵ����ղ���WM_MOUSEWHEEL����Ϣ
			{
				SetFocus(m_hwnd);	
			}
			break;
/*
		case RD_SOCKET:
			{
				if(WSAGETSELECTERROR(lParam)){
					PostMessage(hwnd, RD_SOCKET, wParam, FD_CLOSE);
					return 0;
				}

				switch(WSAGETSELECTEVENT(lParam)){
				case FD_READ:
					if(RecvMessage() == 0)
						PostMessage(hwnd, RD_SOCKET, wParam, FD_CLOSE);
					return 0;

				case FD_CLOSE:
					PostMessage(hwnd, WM_CLOSE, 0, 0);
					return 0;
				}

			}
			return 0;
*/

	case WM_COMMAND:
	case WM_SYSCOMMAND:

		switch (LOWORD(wParam)) {

#if defined _ZXS_RDVIEWER

		case IDC_CONNINFO:
			{
				HINSTANCE hInst = GetModuleHandle(NULL);
				DialogBoxParam(hInst, (LPCTSTR)IDD_CONNINFO, hwnd, (DLGPROC)ConnInfoDlgProc, m_socket);
			}
			break;	
#endif
			////////
		case ID_COMPRLEVEL_AUTO:
			{
			ret = CheckMenuRadioItem(GetSubMenu(hMenu, 3), ID_COMPRLEVEL_AUTO, ID_COMPRLEVEL_9, LOWORD(wParam), MF_BYCOMMAND);
			SetComprLevel(0xff);
			}
			break;
		case ID_COMPRLEVEL_0:
			ret = CheckMenuRadioItem(GetSubMenu(hMenu, 3), ID_COMPRLEVEL_AUTO, ID_COMPRLEVEL_9, LOWORD(wParam), MF_BYCOMMAND);
			SetComprLevel(0);
			break;
		case ID_COMPRLEVEL_1:
			ret = CheckMenuRadioItem(GetSubMenu(hMenu, 3), ID_COMPRLEVEL_AUTO, ID_COMPRLEVEL_9, LOWORD(wParam), MF_BYCOMMAND);
			SetComprLevel(1);
			break;
		case ID_COMPRLEVEL_2:
			ret = CheckMenuRadioItem(GetSubMenu(hMenu, 3), ID_COMPRLEVEL_AUTO, ID_COMPRLEVEL_9, LOWORD(wParam), MF_BYCOMMAND);
			SetComprLevel(2);
			break;
		case ID_COMPRLEVEL_3:
			CheckMenuRadioItem(GetSubMenu(hMenu, 3), ID_COMPRLEVEL_AUTO, ID_COMPRLEVEL_9, LOWORD(wParam), MF_BYCOMMAND);
			SetComprLevel(3);
			break;
		case ID_COMPRLEVEL_4:
			CheckMenuRadioItem(GetSubMenu(hMenu, 3), ID_COMPRLEVEL_AUTO, ID_COMPRLEVEL_9, LOWORD(wParam), MF_BYCOMMAND);
			SetComprLevel(4);
			break;
		case ID_COMPRLEVEL_5:
			CheckMenuRadioItem(hMenu, ID_COMPRLEVEL_AUTO, ID_COMPRLEVEL_9, LOWORD(wParam), MF_BYCOMMAND);
			SetComprLevel(5);
			break;
		case ID_COMPRLEVEL_6:
			CheckMenuRadioItem(hMenu, ID_COMPRLEVEL_AUTO, ID_COMPRLEVEL_9, LOWORD(wParam), MF_BYCOMMAND);
			SetComprLevel(6);
			break;
		case ID_COMPRLEVEL_7:
			CheckMenuRadioItem(hMenu, ID_COMPRLEVEL_AUTO, ID_COMPRLEVEL_9, LOWORD(wParam), MF_BYCOMMAND);
			SetComprLevel(7);
			break;
		case ID_COMPRLEVEL_8:
			CheckMenuRadioItem(hMenu, ID_COMPRLEVEL_AUTO, ID_COMPRLEVEL_9, LOWORD(wParam), MF_BYCOMMAND);
			SetComprLevel(8);
			break;
		case ID_COMPRLEVEL_9:
			CheckMenuRadioItem(hMenu, ID_COMPRLEVEL_AUTO, ID_COMPRLEVEL_9, LOWORD(wParam), MF_BYCOMMAND);
			SetComprLevel(9);
			break;
		case ID_JPEGEC:
			{
				if(RDPVersion<1.2)
				{
					MessageBox(hwnd, "����˰汾��֧��", "����", MB_ICONINFORMATION);
					break;
				}
				m_bUseJpegEncode = !m_bUseJpegEncode;
				SendAction(RDP_JPEGENCODE, m_bUseJpegEncode);

				CheckMenuItem(hMenu, ID_JPEGEC, MF_BYCOMMAND|(m_bUseJpegEncode?MF_CHECKED:MF_UNCHECKED));

			}
			break;


			///////
		case ID_SETPIXEL_4:
			if(pbiBitInfo->bmiHeader.biBitCount >= 4)
			{
				if(!SendAction(RDP_SETPIXEL, 4))
					PostMessage(hwnd, WM_CLOSE, 0, 0);
			}
			break;
		case ID_SETPIXEL_8:
			if(pbiBitInfo->bmiHeader.biBitCount >= 8)
			{
				if(!SendAction(RDP_SETPIXEL, 8))
					PostMessage(hwnd, WM_CLOSE, 0, 0);
			}
			break;
		case ID_SETPIXEL_16:
			if(pbiBitInfo->bmiHeader.biBitCount >= 16)
			{
				if(!SendAction(RDP_SETPIXEL, 16))
					PostMessage(hwnd, WM_CLOSE, 0, 0);
			}
			break;
		case ID_SETPIXEL_32:
			if(pbiBitInfo->bmiHeader.biBitCount >= 32)
			{
				if(!SendAction(RDP_SETPIXEL, 32))
					PostMessage(hwnd, WM_CLOSE, 0, 0);
			}
			break;

		case ID_DISPLAY_HALFTONE:
			CheckMenuItem(hMenu, ID_DISPLAY_HALFTONE, MF_BYCOMMAND|MF_CHECKED);
			CheckMenuItem(hMenu, ID_DISPLAY_DELETESCANS, MF_BYCOMMAND|MF_UNCHECKED);
			CheckMenuItem(hMenu, ID_DISPLAY_FULLSCR, MF_BYCOMMAND|MF_UNCHECKED);
			CheckMenuItem(hMenu, ID_DISPLAY_NORMAL, MF_BYCOMMAND|MF_UNCHECKED);

			m_DisplayMode = ID_DISPLAY_STRETCH;
			SetStretchBltMode(m_viewerDC, HALFTONE);
			SetBrushOrgEx(m_viewerDC, 0, 0, 0);
			PositionChildWindow();
			SetWindowPos(m_hwnd1, HWND_TOP, 0, 0,
							srvscrX/2,
							srvscrY/2, SWP_SHOWWINDOW);
			break;
		case ID_DISPLAY_DELETESCANS:
			CheckMenuItem(hMenu, ID_DISPLAY_HALFTONE, MF_BYCOMMAND|MF_UNCHECKED);
			CheckMenuItem(hMenu, ID_DISPLAY_DELETESCANS, MF_BYCOMMAND|MF_CHECKED);
			CheckMenuItem(hMenu, ID_DISPLAY_FULLSCR, MF_BYCOMMAND|MF_UNCHECKED);
			CheckMenuItem(hMenu, ID_DISPLAY_NORMAL, MF_BYCOMMAND|MF_UNCHECKED);

			m_DisplayMode = ID_DISPLAY_STRETCH;
			SetStretchBltMode(m_viewerDC, STRETCH_DELETESCANS);
			PositionChildWindow();
			SetWindowPos(m_hwnd1, HWND_TOP, 0, 0,
							srvscrX/2,
							srvscrY/2, SWP_SHOWWINDOW);
			break;

		case ID_DISPLAY_FULLSCR:
			CheckMenuItem(hMenu, ID_DISPLAY_HALFTONE, MF_BYCOMMAND|MF_UNCHECKED);
			CheckMenuItem(hMenu, ID_DISPLAY_DELETESCANS, MF_BYCOMMAND|MF_UNCHECKED);
			CheckMenuItem(hMenu, ID_DISPLAY_FULLSCR, MF_BYCOMMAND|MF_CHECKED);
			CheckMenuItem(hMenu, ID_DISPLAY_NORMAL, MF_BYCOMMAND|MF_UNCHECKED);

			m_DisplayMode = ID_DISPLAY_FULLSCR;
			RealiseFullScreenMode(0);
			break;

		case ID_DISPLAY_NORMAL:
			{
			CheckMenuItem(hMenu, ID_DISPLAY_HALFTONE, MF_BYCOMMAND|MF_UNCHECKED);
			CheckMenuItem(hMenu, ID_DISPLAY_DELETESCANS, MF_BYCOMMAND|MF_UNCHECKED);
			CheckMenuItem(hMenu, ID_DISPLAY_FULLSCR, MF_BYCOMMAND|MF_UNCHECKED);
			CheckMenuItem(hMenu, ID_DISPLAY_NORMAL, MF_BYCOMMAND|MF_CHECKED);
			SetStretchBltMode(m_viewerDC, STRETCH_DELETESCANS);

			m_DisplayMode = ID_DISPLAY_NORMAL;
			RECT clientrt, windowrt;
			GetClientRect(m_hwnd1, &clientrt);
			GetWindowRect(m_hwnd1, &windowrt);

			if(GetSystemMetrics(SM_CXFULLSCREEN)>srvscrX && GetSystemMetrics(SM_CYFULLSCREEN)>srvscrY)
			{

			SetWindowPos(m_hwnd1, HWND_TOP, 0, 0,
							(clientrt.left-windowrt.left)+(windowrt.right-clientrt.right)+srvscrX,
							(windowrt.bottom-clientrt.bottom)+(clientrt.top-windowrt.top)+srvscrY, SWP_SHOWWINDOW);
			}else
			{
			SetWindowPos(m_hwnd1, HWND_TOP, 0, 0,
							GetSystemMetrics(SM_CXFULLSCREEN),
							GetSystemMetrics(SM_CYDLGFRAME)*2+GetSystemMetrics(SM_CYMENU)+GetSystemMetrics(SM_CYFULLSCREEN), 
							SWP_SHOWWINDOW);

			}
		//	PositionChildWindow();
		//	PostMessage(hwnd, WM_SYSCOMMAND, SC_MAXIMIZE, 0);

			}
			break;


		case SC_RESTORE:
			if(InFullScreenMode())
			{
				m_DisplayMode = ID_DISPLAY_NORMAL;
				RealiseFullScreenMode(0);
				PostMessage(hwnd, WM_COMMAND, ID_DISPLAY_NORMAL, 0);
			}
			break;

		case ID_MODE_CTRL:
			if(EnableControlMode())
			{
				CheckMenuItem(hMenu, ID_MODE_CTRL, MF_BYCOMMAND|MF_CHECKED);
				CheckMenuItem(hMenu, ID_MODE_VIEW, MF_BYCOMMAND|MF_UNCHECKED);

				SetFocus(hwnd);
			}
			break;
		case ID_MODE_VIEW:
			CheckMenuItem(hMenu, ID_MODE_CTRL, MF_BYCOMMAND|MF_UNCHECKED);
			CheckMenuItem(hMenu, ID_MODE_VIEW, MF_BYCOMMAND|MF_CHECKED);
			DisableControlMode();
			break;

		case ID_CAPTUREBLT:
			{
				if(bCaptureBltState())
					CheckMenuItem(hMenu, ID_CAPTUREBLT, MF_BYCOMMAND|MF_UNCHECKED);
				else
					CheckMenuItem(hMenu, ID_CAPTUREBLT, MF_BYCOMMAND|MF_CHECKED);
				
				SetCaptureBlt(!bCaptureBltState());
				if(!SendAction(RDP_SETCAPTUREBLT, bCaptureBltState()))
					PostMessage(hwnd, WM_CLOSE, 0, 0);

			}
			break;

		case ID_GETCLIPDATA:
			if(!SendAction(RDP_GETCUTTEXT, 1))
				PostMessage(hwnd, WM_CLOSE, 0, 0);
			break;

		case ID_KE_CTRLALTDEL:

			if(!InControlMode())
				return 0;

			if(!SendAction(RDP_KEYBDEVENT, ke_CTRL_ALT_DEL))
				PostMessage(hwnd, WM_CLOSE, 0, 0);
			break;

		case ID_CURSOR_HIDE:
			CheckMenuItem(hMenu, ID_CURSOR_HIDE, MF_BYCOMMAND|MF_CHECKED);
			CheckMenuItem(hMenu, ID_CURSOR_SHOW, MF_BYCOMMAND|MF_UNCHECKED);

			SetCursorState(0);
			if(!SendAction(RDP_CAPTURECURSOR, 0))
				PostMessage(hwnd, WM_CLOSE, 0, 0);
			break;
		case ID_CURSOR_SHOW:
			CheckMenuItem(hMenu, ID_CURSOR_HIDE, MF_BYCOMMAND|MF_UNCHECKED);
			CheckMenuItem(hMenu, ID_CURSOR_SHOW, MF_BYCOMMAND|MF_CHECKED);

			SetCursorState(5);
			if(!SendAction(RDP_CAPTURECURSOR, 1))
				PostMessage(hwnd, WM_CLOSE, 0, 0);
			break;

		case ID_CMD_REMOVEWALLPAPER:
			if(!SendAction(RDP_REMOVEWALLPAPER, 1))
				PostMessage(hwnd, WM_CLOSE, 0, 0);

			break;

		case ID_TAKESNAPSHOT:
			{
				SYSTEMTIME stm;
				GetLocalTime(&stm);
				TCHAR szFileName[MAX_PATH];
				sprintf(
					szFileName,
					"%04u.%02u.%02u-%02u-%02u-%02u.bmp",
					stm.wYear, stm.wMonth, stm.wDay,
					stm.wHour, stm.wMinute, stm.wSecond
					);

				if(GetSavePath(m_hwnd, "BMP Files (*.BMP)\0*.BMP\0\0", "����Ϊ...", szFileName))
				{
					char *pext = strstr(szFileName, ".bmp");
					if(!pext || pext[4])
						strcat(szFileName, ".bmp");
					bDbgBmDump(szFileName, (BYTE*)bmpbuf, pbiBitInfo);
				}
			}
			break;
		case ID_LOGONASSYS:
			{
				if(!InControlMode())
					return 0;
				if(RDPVersion<1.1)
				{
					MessageBox(hwnd, "����˰汾��֧��", "����", MB_ICONINFORMATION);
					return 0;
				}

				if(!SendAction(RDP_LOGINASSYSTEM, 0))
					PostMessage(hwnd, WM_CLOSE, 0, 0);
			}
			break;
		}
		break;

	case WM_CLOSE:		

		Shutdown(m_socket);
		DestroyWindow(hwnd);
		runFlag = 0;
		return 0;					  
	case WM_DESTROY:

		Shutdown(m_socket);
        ChangeClipboardChain(m_hwnd, m_hwndNextViewer); 
		runFlag = 0;
		return 0;						 
		}
	return DefWindowProc(hwnd, iMsg, wParam, lParam);
}

int RDVIEWER::UpdateLocalClipboard()
{
	_tagZLIBINFO zinfo;

	_rdpBuffer decomprBuffer;
	_rdpBuffer TextBuffer;

	__printf("UpdateLocalClipboard....\r\n");

	if(rdph.dataSize == 0)
	{
		MessageBox(m_hwnd, "Զ�̼������ǿյ�.", "ע��", MB_ICONINFORMATION);
		return 0;
	}

	if(rdph.flag == us_NULL)
	{
		if(!TextBuffer.checkBufferSize(rdph.dataSize, false))
			return 0;

		if(!Recv(m_socket, TextBuffer, rdph.dataSize))
			return -1;
	}else //us_ZLIB
	{
		if(!Recv(m_socket, (char*)&zinfo, sizeof(zinfo)))
			return -1;
		if(!decomprBuffer.checkBufferSize(rdph.dataSize, false))
			return 0;
		if(!TextBuffer.checkBufferSize(zinfo.uncomprLen, false))
			return 0;

		if(!Recv(m_socket, decomprBuffer, rdph.dataSize))
			return -1;

		if(uncompress(TextBuffer, &zinfo.uncomprLen, decomprBuffer, rdph.dataSize) != 0)
			return 0;
	}

	if (!OpenClipboard(m_hwnd)) {
		return 0;
	}
	if (!EmptyClipboard()) {
		CloseClipboard();
		return 0;
	}

	// Allocate a global memory object for the text. 
	HGLOBAL hglbCopy = GlobalAlloc(GMEM_DDESHARE, TextBuffer.GetSize()+1);
	if (hglbCopy != NULL) { 
		// Lock the handle and copy the text to the buffer.  
		LPTSTR lptstrCopy = (LPTSTR) GlobalLock(hglbCopy); 
		memcpy(lptstrCopy, (BYTE*)TextBuffer, TextBuffer.GetSize()); 
		lptstrCopy[TextBuffer.GetSize()] = (TCHAR) 0;    // null character 
		GlobalUnlock(hglbCopy);          // Place the handle on the clipboard.  
		SetClipboardData(CF_TEXT, hglbCopy); 
	}

	CloseClipboard();

	MessageBox(m_hwnd, "Զ�̼����������Ѹ��µ����ؼ�����. ʹ�� CTRL+V", "ע��", MB_ICONINFORMATION);

	return 1;
	
}

int RDVIEWER::ProcessLocalClipboardChange()
{
	if(!InControlMode())
		return 0;
	HWND hOwner = GetClipboardOwner();
	if (hOwner == m_hwnd) {
		return 0;
	}
	__printf("ProcessLocalClipboardChange....\r\n");

	int ret;
	_rdpBufferEncodeZlib zlib;
	_tagZLIBINFO zinfo;
	_tagRDPHEAD rdph;

	if (OpenClipboard(m_hwnd)) { 
		HGLOBAL hglb = GetClipboardData(CF_TEXT); 
		if (hglb == NULL) {
			CloseClipboard();
			return 0;
		} else {
			LPSTR lpstr = (LPSTR) GlobalLock(hglb);  
			
			DWORD textlen = strlen(lpstr);
			DWORD zbufsize;

			if(textlen == 0)
				return 0;

			textlen ++;
			zbufsize = textlen+1024;

			//if(textlen < 50)
			//	textlen = 50;

			BYTE *contents = new BYTE[textlen];
			BYTE *zlibcontents = new BYTE[zbufsize];
			if(contents == NULL || zlibcontents == NULL)
			{
				GlobalUnlock(hglb); 
				CloseClipboard();       		
				delete [] contents; 
				delete [] zlibcontents;	
				return 0;
			}
			//if(textlen <= 50)
			//	memset(contents, 0, textlen);
			memcpy(contents, lpstr, textlen);
			GlobalUnlock(hglb); 
			CloseClipboard();   
			
			__try
			{
				ret = 0;

				zinfo.uncomprLen = textlen;

				if(zlib.do_gzip(zlibcontents, &zbufsize, 
					contents, textlen, 8) != 0)
				{
					ret = 0;
					__leave;
				}

				rdph.action = RDP_NEWCUTTEXT;
				rdph.flag = us_ZLIB;//always == us_ZLIB
				rdph.dataSize = zbufsize;

				if(!sockdata.SendDataGZip(&rdph, &zinfo, zlibcontents, zbufsize))
				{
					ret = -1;
					__leave;
				}


				ret = 1;

			}__finally
			{
				delete [] contents; 
				delete [] zlibcontents;

				return ret;
			}
		}
	}
	return 1;//make complier happy:)
}


int RDVIEWER::SendMouseEvent(UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	if(!InControlMode())
		return 0;

	_tagRDPHEAD rh;

	DWORD localX, localY;
	DWORD remoteX, remoteY;

	localX = (DWORD)LOWORD(lParam);
	localY = (DWORD)HIWORD(lParam);


	//ID_DISPLAY_NORMAL  ID_DISPLAY_STRETCH  ID_DISPLAY_FULLSCR
	if(m_DisplayMode == ID_DISPLAY_NORMAL)
	{
		remoteX = localX + m_hScrollPos;
		remoteY = localY + m_vScrollPos;
	}else if(m_DisplayMode == ID_DISPLAY_STRETCH)
	{
		remoteX = localX*srvscrX/(rt.right-rt.left);
		remoteY = localY*srvscrY/(rt.bottom-rt.top);
	}else if(m_DisplayMode == ID_DISPLAY_FULLSCR)
	{
		remoteX = localX*srvscrX/(rt.right-rt.left);
		remoteY = localY*srvscrY/(rt.bottom-rt.top);
	}else
	{
		return 0;
	}
/*
	_WINMSG event;
	event.uMsg = iMsg;
	event.wParam = wParam;
	event.lParam = MAKEWPARAM(remoteX, remoteY);

	rh.action = RDP_MOUSEEVENT;
	rh.dataSize = sizeof(event);

	if(!sockdata.SendData(&rh, (BYTE*)&event, sizeof(event)))
		return -1;
*/
	rh.action = RDP_MOUSEEVENT;
	rh.dataSize = MAKEWPARAM(remoteX, remoteY);

	switch(iMsg)
	{
		case WM_LBUTTONDOWN:
			rh.flag = 0;
			break;
		case WM_LBUTTONUP:
			rh.flag = 1;
			break;
		case WM_RBUTTONDOWN:
			rh.flag = 2;
			break;
		case WM_RBUTTONUP:
			rh.flag = 3;
			break;

		case WM_MBUTTONDOWN:
			rh.flag = 4;
			break;
		case WM_MBUTTONUP:
			rh.flag = 5;
			break;

		case WM_MOUSEWHEEL:
			if((long)wParam < 0)
				rh.flag = 6;
			else
				rh.flag = 7;
			break;

		case WM_MOUSEMOVE:
			rh.flag = 8;
			break;
	}
	
	if(!sockdata.SendAction(&rh))
		return -1;

	return 1;
}

int RDVIEWER::SendKeybdEvent(UINT iMsg, WPARAM wParam, LPARAM lParam)
{

	_tagRDPHEAD rh;
/*	
	_WINMSG event;
	event.uMsg = iMsg;
	event.wParam = wParam;
	event.lParam = lParam;

	rh.action = RDP_KEYBDEVENT;
	rh.dataSize = sizeof(event);


	if(!sockdata.SendData(&rh, (BYTE*)&event, sizeof(event)))
		return -1;
*/

	rh.action = RDP_KEYBDEVENT;
	rh.dataSize = wParam;
	
	switch(iMsg)
	{
		case WM_KEYDOWN:
		case WM_SYSKEYDOWN:
			rh.flag = 1;
			break;
		case WM_KEYUP:
		case WM_SYSKEYUP:
			rh.flag = 0;
			break;
	}

	if(!sockdata.SendAction(&rh))
		return -1;

	return 1;
}



LRESULT CALLBACK RDVIEWER::_WndProc(HWND hwnd, UINT iMsg, 
					   WPARAM wParam, LPARAM lParam) 
{	

	switch (iMsg) {


	case WM_PAINT:
		{
			PAINTSTRUCT paint;
			BeginPaint(hwnd, &paint);


			DoBlt(&paint.rcPaint);

			EndPaint(hwnd, &paint);

		}
		return 0;

	case WM_MOUSELEAVE:
		return 0;
		break;

	case WM_SETCURSOR:
		{
			if(!InControlMode())
			{
				SetCursor(hDenyCursor);
			}else
			{
				if(m_CursorlMode)
				{
					SetCursor(hDotCursor);
				}else
				{
					SetCursor(hNormalCursor);
				}

			}
		}
		return 0;

	case WM_MOUSEMOVE:
	case WM_LBUTTONDOWN:
	case WM_LBUTTONUP:
	case WM_MBUTTONDOWN:
	case WM_MBUTTONUP:
	case WM_RBUTTONDOWN:
	case WM_RBUTTONUP:
	case WM_MOUSEWHEEL:
		{
			if (GetFocus() != hwnd && GetFocus() != m_hwnd1)
				return 0;
			SetFocus(hwnd);

			if(!InControlMode())
			{
				return 0;
			}

			if (iMsg == WM_MOUSEWHEEL) {
				POINT coords;
				coords.x = LOWORD(lParam);
				coords.y = HIWORD(lParam);
				// Convert coordinates to position in our client area,
				// make sure the pointer is inside the client area.
				if ( WindowFromPoint(coords) != hwnd ||
					 !ScreenToClient(hwnd, &coords) ||
					 coords.x < 0 || coords.y < 0 ||
					 coords.x >= m_cliwidth ||
					 coords.y >= m_cliheight ) {
					return 0;
				}

				lParam = MAKEWPARAM(coords.x, coords.y);
			} else {
				// Make sure the high-order word in wParam is zero.
				wParam = MAKEWPARAM(LOWORD(wParam), 0);
			}

			if(SendMouseEvent(iMsg, wParam, lParam) < 0)
				PostMessage(m_hwnd1, WM_CLOSE, 0, 0);

			return 0;
		}

		//���̹�����Ϣ
	case ZX_KEYEVENT:
		{
			if(wParam == VK_F12 && InFullScreenMode())
			{
				PostMessage(m_hwnd1, WM_SYSCOMMAND, SC_RESTORE, 0);
				return 0;
			}
			if(!InControlMode())
				return 0;

			if(m_MenuState) // �˵�����
				return 0;

			//��ǰ����û����ʱ�յ�����Ϣ ��Ҫ���͵�Զ�̼����
			if(GetFocus() != hwnd)
				return 0;

			UINT keymsg;

			if(lParam&LLKHF_UP)//any keys pressed
				keymsg = WM_KEYUP;
			else
				keymsg = WM_KEYDOWN;

			if(SendKeybdEvent(keymsg, wParam, 0) < 0)
				PostMessage(m_hwnd1, WM_CLOSE, 0, 0);

			return TRUE;

		}

	case WM_KEYDOWN:
	case WM_KEYUP:
	case WM_SYSKEYDOWN:
	case WM_SYSKEYUP:
		{
			if(wParam == VK_F12 && InFullScreenMode())
			{
				PostMessage(m_hwnd1, WM_SYSCOMMAND, SC_RESTORE, 0);
				return 0;
			}
			if(!InControlMode())
				return 0;
			if(SendKeybdEvent(iMsg, wParam, lParam) < 0)
				PostMessage(m_hwnd1, WM_CLOSE, 0, 0);
			return 0;
			//break;
		}

	case WM_DEADCHAR:
	case WM_SYSDEADCHAR:
	  return 0;

	case WM_SETFOCUS:
		{
		if (InFullScreenMode())
			SetWindowPos(hwnd, HWND_TOPMOST, 0,0,100,100, SWP_NOMOVE | SWP_NOSIZE);

		if(!InControlMode())
			return 0;

		//��ý���ʱ���ü��̹��ӣ�����һЩ��ϼ�
		if(lowKeybdHook.LoadDll())
			lowKeybdHook.SetHook(m_hwnd);

		}
		return 0;
	case WM_KILLFOCUS:
		{
			if (InFullScreenMode()) {
				// We must top being topmost, but we want to choose our
				// position carefully.
				HWND foreground = GetForegroundWindow();
				HWND hwndafter = NULL;
				if ((foreground == NULL) || 
					(GetWindowLong(foreground, GWL_EXSTYLE) & WS_EX_TOPMOST)) {
					hwndafter = HWND_NOTOPMOST;
				} else {
					hwndafter = GetNextWindow(foreground, GW_HWNDNEXT); 
				}

				SetWindowPos(m_hwnd1, hwndafter, 0,0,100,100, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
			}

			return 0;
		}
	case WM_DESTROY:
		{
			//ж�ؼ��̹���
			lowKeybdHook.UnSetHook();
			break;
		}

	case WM_DRAWCLIPBOARD:
		if(ProcessLocalClipboardChange() < 0)
			PostMessage(m_hwnd1, WM_CLOSE, 0, 0);
		return 0;

	case WM_CHANGECBCHAIN:
		{
			// The clipboard chain is changing
			HWND hWndRemove = (HWND) wParam;     // handle of window being removed 
			HWND hWndNext = (HWND) lParam;       // handle of next window in chain 
			// If next window is closing, update our pointer.
			if (hWndRemove == m_hwndNextViewer)  
				m_hwndNextViewer = hWndNext;  
			// Otherwise, pass the message to the next link.  
			else if (m_hwndNextViewer != NULL) 
				::SendMessage(m_hwndNextViewer, WM_CHANGECBCHAIN, 
				(WPARAM) hWndRemove,  (LPARAM) hWndNext );  
			return 0;
		}
	}

	return DefWindowProc(hwnd, iMsg, wParam, lParam);
}
