#define _WIN32_WINNT 0x0502
#define WINVER 0x0502


#include <winsock2.h>
#include <stdio.H>
#include <windows.H>
#include <iostream>
#include <fstream>

#pragma comment(lib, "ws2_32.lib")


#define   BYTE3INT(X)     (         (   X[0]   &   0x000000FF   )   \
                                              |   (   (   X[1]   &   0x000000FF   )   <<     8   )   \
                                              |   (   (   X[2]   &   0x000000FF   )   <<   16   ))   
    
#define   BYTE4INT(X)     (         (   X[0]   &   0x000000FF   )   \
                                              |   (   (   X[1]   &   0x000000FF   )   <<     8   )   \
                                              |   (   (   X[2]   &   0x000000FF   )   <<   16   )   \
                                              |   (   (   X[3]   &   0x000000FF   )   <<   24   )     )   
    
			
struct   INDEXITEM     
{   
      unsigned   char   ip[4];   
      unsigned   char   offset[3];   
};   

int   Compare(unsigned   char   pA[4],   unsigned   char   pB[4])   
{   
      unsigned   int   a   =   BYTE4INT(pA);   
      unsigned   int   b   =   BYTE4INT(pB);   

      if   (   a   >   b   )   
              return   1;   
      else   if   (   a   <   b   )   
              return   -1;   
      else   
              return   0;   
}   

void   GetData(unsigned   char*   str,   FILE*   pFile,   int   max)   
{   
      int   i   =   0;   
      while   (   (*(str+i)=fgetc(pFile))   &&   (i<(max-2))   )   
              i++;   
      str[i]   =   0;   
}   

struct   INDEXITEM   LookForIndexItem(struct   INDEXITEM*   const   pAimItem,     
  FILE*   pFile,     
  unsigned   int   indexBasePos,     
  unsigned   int   indexAmount   )   
{
	struct   INDEXITEM   tmp;   
	int   i   =   0;   
	int   j   =   indexAmount;   
	int   s   =   (int)sizeof(struct   INDEXITEM);   
	while   (   i   <   j   -   1   )     
	{   
		int   k   =   (int)   (i+j)/2;   
		int   offset   =   (int)(   k   *   s   );   
		fseek(pFile,   indexBasePos+offset,   SEEK_SET);   
		fread(&tmp,   s,   1,   pFile);   
		int   c   =   Compare(   tmp.ip,   pAimItem->ip   );   
		if   (   c   >   0   )   
			j   =   k;   
		else   if   (   c   <   0   )   
			i   =   k;   
		else     
		{   
			i   =   k;   
			j   =   k;   
		}   
	}   

	fseek(pFile,   indexBasePos+i*s,   SEEK_SET);   
	fread(&tmp,   s,   1,   pFile);   
	return   tmp;   
}   

void   RetrieveContent(struct   INDEXITEM*   const   pIndexItem,     
					   unsigned   char   ip[4],   
					   FILE*   pFile,     
					   char*   content   )   
{   
	//   to   get   the   pos   from   the   offset   array   
	long   tmp   =   0;   
	unsigned   char   buf[80];   

	int   pos   =   BYTE3INT(pIndexItem->offset);   
	fseek(pFile,   pos,   SEEK_SET);   
	fread(buf,   4,   1,   pFile);   
	if   (   Compare(ip,   buf)   >   0   )     
	{   
		strcat(content,   "δ֪");   
		//printf("δ֪����\n");   
		return;   
	}   

	//   ��ȡ����   
	fread(buf,   1,   1,   pFile);   
	if   (   buf[0]   ==   0x01   )     
	{   //   ���ҵ������ظ�,   ��ת���µ�ַ   
		fread(buf,   3,   1,   pFile);   
		pos   =   BYTE3INT(buf);   
		fseek(pFile,   pos,   SEEK_SET);   
		fread(buf,   1,   1,   pFile);   
	}   

	//   ��ȡ����   
	if   (   buf[0]   ==   0x02   )     
	{   
		//   ��ȡ����ƫ��   
		fread(buf,   3,   1,   pFile);   
		//   ���������Ϣ   
		tmp   =   ftell(pFile);   
		pos   =   BYTE3INT(buf);   
		fseek(pFile,   pos,   SEEK_SET);   
		fread(buf,   1,   1,   pFile);   
	}   
	if   (   buf[0]   ==   0x01   ||   buf[0]   ==   0x02   )     
	{   
		strcat(content,   "δ֪");   
		//printf("There   is   something   wrong....\n");   
		return;   
	}   

	if   (   buf[0]   )   
		GetData(buf+1,   pFile,   40);   
	strcat(content,   (char*)buf);   
	//printf("%s\t",   buf);   

	//   ��ȡ����   
	if   (   tmp   )   
		fseek(pFile,   tmp,   SEEK_SET);   
	fread(buf,   1,   1,   pFile);   
	while   (   buf[0]   ==   0x02   )     
	{   
		//   ��ȡ����ƫ��   
		fread(buf,   3,   1,   pFile);   
		pos   =   BYTE3INT(buf);   
		fseek(pFile,   pos,   SEEK_SET);   
		fread(buf,   1,   1,   pFile);   
	}   
	if   (   buf[0]   ==   0x01   ||   buf[0]   ==   0x02   )     
	{   
		strcat(content,   "δ֪");   
		//printf("There   is   something   wrong....\n");   
		return;   
	}   
	if   (   buf[0]   )   
		GetData(buf+1,   pFile,   40);   
    //   strcat(content,"                 ");   
	strcat(content,   (char*)buf);   

	return;   
}   

int   LocalityFromIP2(char *szIP, char *retbuf)
{   
	int   i   =   0,   j   =   16,   k   =   0,   l,   IP[4];   
	const   char*   p   =   (LPCTSTR)szIP;   
	FILE*   ipfp   =   NULL;   
	
	ipfp   =   fopen("qqwry.dat",   "rb");   
	if(   ipfp   ==   NULL   )   
		return   -1;   
	char   pbuf[256]   =   {0};   
	fseek(ipfp,   0,   SEEK_SET);   

	unsigned   int   indexHeadPos   =   0;   
	unsigned   int   indexTailPos   =   0;   

	struct   INDEXITEM   target;
	DWORD dwip = ntohl(inet_addr(szIP));
	memcpy(target.ip, &dwip, 4);

	fread(&indexHeadPos,   sizeof(indexHeadPos),   1,   ipfp);   
	fread(&indexTailPos,   sizeof(indexTailPos),   1,   ipfp);   

	int   amount   =   (indexTailPos   -   indexHeadPos)/sizeof(struct   INDEXITEM);   
	struct   INDEXITEM   start   =   LookForIndexItem(&target,   ipfp,   indexHeadPos,   amount);   

	retbuf[0] = 0;
	RetrieveContent(&start,   target.ip,   ipfp,   retbuf);   


	fclose(ipfp);   
	return   0;   
}   
/*
void main(int argc,char *argv[])
{

	char buf[128] = "210.38.32.2";
	LocalityFromIP2(buf, buf);

	printf("%s\r\n", buf);
}
*/