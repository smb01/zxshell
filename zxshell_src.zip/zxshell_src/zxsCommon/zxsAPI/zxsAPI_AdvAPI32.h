#include <windows.H>

/*
	
ADVAPI32.dll
	RegOpenKeyExA  ord:492 rva: 0001E004
	CreateProcessAsUserA  ord:95 rva: 0001E038
	DuplicateTokenEx  ord:180 rva: 0001E040
	SetTokenInformation  ord:582 rva: 0001E044
	RegCreateKeyA  ord:464 rva: 0001E048
	RegSetValueExA  ord:516 rva: 0001E050
	RegOpenKeyA  ord:491 rva: 0001E054
	OpenServiceA  ord:431 rva: 0001E08C
	RegCreateKeyExA  ord:465 rva: 0001E098
	StartServiceA  ord:585 rva: 0001E09C
	CreateServiceA  ord:100 rva: 0001E0A0
	RegSaveKeyA  ord:510 rva: 0001E0C4
	RegRestoreKeyA  ord:508 rva: 0001E0C8
*/

typedef
BOOL WINAPI _ZXOpenThreadToken(
  HANDLE ThreadHandle,
  DWORD DesiredAccess,
  BOOL OpenAsSelf,
  PHANDLE TokenHandle
);


typedef
BOOL WINAPI _ZXLookupAccountSid(
  LPCTSTR lpSystemName,
  PSID lpSid,
  LPTSTR lpName,
  LPDWORD cchName,
  LPTSTR lpReferencedDomainName,
  LPDWORD cchReferencedDomainName,
  PSID_NAME_USE peUse
);

typedef
WINADVAPI
BOOL
WINAPI
_ZXLookupAccountSidW(
    __in_opt LPCWSTR lpSystemName,
    __in PSID Sid,
    __out_ecount_part_opt(*cchName, *cchName + 1) LPWSTR Name,
    __inout  LPDWORD cchName,
    __out_ecount_part_opt(*cchReferencedDomainName, *cchReferencedDomainName + 1) LPWSTR ReferencedDomainName,
    __inout LPDWORD cchReferencedDomainName,
    __out PSID_NAME_USE peUse
    );

typedef
BOOL WINAPI _ZXRevertToSelf(void);

typedef
BOOL WINAPI _ZXLookupPrivilegeValue(
  LPCTSTR lpSystemName,
  LPCTSTR lpName,
  PLUID lpLuid
);

typedef
BOOL WINAPI _ZXAdjustTokenPrivileges(
  HANDLE TokenHandle,
  BOOL DisableAllPrivileges,
  PTOKEN_PRIVILEGES NewState,
  DWORD BufferLength,
  PTOKEN_PRIVILEGES PreviousState,
  PDWORD ReturnLength
);

typedef
BOOL WINAPI _ZXImpersonateLoggedOnUser(
  HANDLE hToken
);

typedef
SC_HANDLE WINAPI _ZXOpenSCManager(
  LPCTSTR lpMachineName,
  LPCTSTR lpDatabaseName,
  DWORD dwDesiredAccess
);

typedef
LONG WINAPI _ZXRegQueryValueEx(
  HKEY hKey,
  LPCTSTR lpValueName,
  LPDWORD lpReserved,
  LPDWORD lpType,
  LPBYTE lpData,
  LPDWORD lpcbData
);









typedef
LONG WINAPI _ZXRegRestoreKey(
  HKEY hKey,
  LPCTSTR lpFile,
  DWORD dwFlags
);


typedef
LONG WINAPI _ZXRegSaveKey(
  HKEY hKey,
  LPCTSTR lpFile,
  LPSECURITY_ATTRIBUTES lpSecurityAttributes
);


typedef
SC_HANDLE WINAPI _ZXCreateService(
  SC_HANDLE hSCManager,
  LPCTSTR lpServiceName,
  LPCTSTR lpDisplayName,
  DWORD dwDesiredAccess,
  DWORD dwServiceType,
  DWORD dwStartType,
  DWORD dwErrorControl,
  LPCTSTR lpBinaryPathName,
  LPCTSTR lpLoadOrderGroup,
  LPDWORD lpdwTagId,
  LPCTSTR lpDependencies,
  LPCTSTR lpServiceStartName,
  LPCTSTR lpPassword
);

typedef
BOOL WINAPI _ZXStartService(
  SC_HANDLE hService,
  DWORD dwNumServiceArgs,
  LPCTSTR* lpServiceArgVectors
);

typedef
LONG WINAPI _ZXRegCreateKeyEx(
  HKEY hKey,
  LPCTSTR lpSubKey,
  DWORD Reserved,
  LPTSTR lpClass,
  DWORD dwOptions,
  REGSAM samDesired,
  LPSECURITY_ATTRIBUTES lpSecurityAttributes,
  PHKEY phkResult,
  LPDWORD lpdwDisposition
);

typedef
LONG WINAPI _ZXRegOpenKey(
  HKEY hKey,
  LPCTSTR lpSubKey,
  PHKEY phkResult
);

typedef
LONG WINAPI _ZXRegSetValueEx(
  HKEY hKey,
  LPCTSTR lpValueName,
  DWORD Reserved,
  DWORD dwType,
  const BYTE* lpData,
  DWORD cbData
);


typedef LONG WINAPI _ZXRegOpenKeyEx(
  HKEY hKey,
  LPCTSTR lpSubKey,
  DWORD ulOptions,
  REGSAM samDesired,
  PHKEY phkResult
);

typedef BOOL WINAPI _ZXCreateProcessAsUser(
  HANDLE hToken,
  LPCTSTR lpApplicationName,
  LPTSTR lpCommandLine,
  LPSECURITY_ATTRIBUTES lpProcessAttributes,
  LPSECURITY_ATTRIBUTES lpThreadAttributes,
  BOOL bInheritHandles,
  DWORD dwCreationFlags,
  LPVOID lpEnvironment,
  LPCTSTR lpCurrentDirectory,
  LPSTARTUPINFO lpStartupInfo,
  LPPROCESS_INFORMATION lpProcessInformation
);

typedef
BOOL WINAPI _ZXDuplicateTokenEx(
  HANDLE hExistingToken,
  DWORD dwDesiredAccess,
  LPSECURITY_ATTRIBUTES lpTokenAttributes,
  SECURITY_IMPERSONATION_LEVEL ImpersonationLevel,
  TOKEN_TYPE TokenType,
  PHANDLE phNewToken
);

typedef
BOOL WINAPI _ZXSetTokenInformation(
  HANDLE TokenHandle,
  TOKEN_INFORMATION_CLASS TokenInformationClass,
  LPVOID TokenInformation,
  DWORD TokenInformationLength
);

typedef
LONG WINAPI _ZXRegCreateKey(
  HKEY hKey,
  LPCTSTR lpSubKey,
  PHKEY phkResult
);


typedef LONG (WINAPI*ZXRegOpenKey)(
  HKEY hKey,
  LPCTSTR lpSubKey,
  PHKEY phkResult
);

typedef SERVICE_STATUS_HANDLE (WINAPI*ZXRegisterServiceCtrlHandler)(
  LPCTSTR lpServiceName,
  LPHANDLER_FUNCTION lpHandlerProc
);

