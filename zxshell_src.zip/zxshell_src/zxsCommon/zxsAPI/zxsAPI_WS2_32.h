#include <winsock2.h>
#include <windows.H>


typedef int WINAPI _ZXWSADuplicateSocket(
  SOCKET s,
  DWORD dwProcessId,
  void *lpProtocolInfo
);


typedef SOCKET WINAPI _ZXWSASocket(
  int af,
  int type,
  int protocol,
  void * lpProtocolInfo,
  unsigned int g,
  DWORD dwFlags
);


typedef SOCKET (WINAPI*ZXsocket)(
  int af1,
  int type1,
  int protocol1
);


typedef int (WINAPI*ZXlisten)(
  SOCKET s,
  int backlog
);

typedef int (WINAPI*ZXconnect)(
  SOCKET s,
  const struct sockaddr* name,
  int namelen
);

typedef int (WINAPI*ZXbind)(
  SOCKET s,
  const struct sockaddr* name,
  int namelen
);

typedef SOCKET (WINAPI*ZXaccept)(
  SOCKET s,
  struct sockaddr* addr,
  int* addrlen
);

typedef int WINAPI _ZXsend(
  SOCKET s,
  const char* buf,
  int len,
  int flags
);

typedef int WINAPI _ZXrecv(
  SOCKET s,
  char* buf,
  int len,
  int flags
);

typedef int WINAPI _ZXrecvfrom(
  SOCKET s,
  char* buf,
  int len,
  int flags,
  struct sockaddr* from,
  int* fromlen
);

typedef int WINAPI _ZXsendto(
  SOCKET s,
  const char* buf,
  int len,
  int flags,
  const struct sockaddr* to,
  int tolen
);

typedef int WINAPI _ZXclosesocket(
  SOCKET s
);

