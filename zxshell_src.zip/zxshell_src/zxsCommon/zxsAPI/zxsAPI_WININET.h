#include <windows.H>
#include <wininet.H>


/*
WININET.dll
	InternetOpenA  ord:146 rva: 0001E4BC
	FtpOpenFileA  ord:50 rva: 0001E4C8
	InternetConnectA  ord:111 rva: 0001E4C0
	InternetOpenUrlA  ord:147 rva: 0001E4D8
	InternetWriteFile  ord:186 rva: 0001E4D4
	InternetCloseHandle  ord:105 rva: 0001E4C4
	InternetQueryDataAvailable  ord:150 rva: 0001E4CC
	InternetReadFile  ord:154 rva: 0001E4D0


  */
typedef
HINTERNET WINAPI _ZXInternetOpenUrl(
  HINTERNET hInternet,
  LPCTSTR lpszUrl,
  LPCTSTR lpszHeaders,
  DWORD dwHeadersLength,
  DWORD dwFlags,
  DWORD_PTR dwContext
);


typedef
BOOL WINAPI _ZXInternetWriteFile(
  HINTERNET hFile,
  LPCVOID lpBuffer,
  DWORD dwNumberOfBytesToWrite,
  LPDWORD lpdwNumberOfBytesWritten
);



typedef
BOOL WINAPI _ZXInternetReadFile(
  HINTERNET hFile,
  LPVOID lpBuffer,
  DWORD dwNumberOfBytesToRead,
  LPDWORD lpdwNumberOfBytesRead
);

typedef
BOOL WINAPI _ZXInternetQueryDataAvailable(
  HINTERNET hFile,
  LPDWORD lpdwNumberOfBytesAvailable,
  DWORD dwFlags,
  DWORD_PTR dwContext
);

typedef
HINTERNET WINAPI _ZXFtpOpenFile(
  HINTERNET hConnect,
  LPCTSTR lpszFileName,
  DWORD dwAccess,
  DWORD dwFlags,
  DWORD_PTR dwContext
);

typedef
BOOL WINAPI _ZXInternetCloseHandle(
  HINTERNET hInternet
);

typedef
HINTERNET WINAPI _ZXInternetConnect(
  HINTERNET hInternet,
  LPCTSTR lpszServerName,
  INTERNET_PORT nServerPort,
  LPCTSTR lpszUsername,
  LPCTSTR lpszPassword,
  DWORD dwService,
  DWORD dwFlags,
  DWORD_PTR dwContext
);


typedef
HINTERNET WINAPI _ZXInternetOpen(
  LPCTSTR lpszAgent,
  DWORD dwAccessType,
  LPCTSTR lpszProxyName,
  LPCTSTR lpszProxyBypass,
  DWORD dwFlags
);
