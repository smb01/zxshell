#include <windows.H>

/*
GDI32.dll
!	GetStockObject  ord:421 rva: 000160C0
!	CreateCompatibleDC  ord:45 rva: 000160C4
!	CreateCompatibleBitmap  ord:44 rva: 000160C8
!	DeleteDC  ord:140 rva: 000160CC
!	GdiFlush  ord:283 rva: 000160D0
!	BitBlt  ord:18 rva: 000160D4
!	GetDIBits  ord:362 rva: 000160D8
!	DeleteObject  ord:143 rva: 000160DC
!	GetBitmapBits  ord:330 rva: 000160E0
!	SetPixel  ord:561 rva: 000160E4
!	SelectObject  ord:526 rva: 000160E8
!	CreateBitmap  ord:39 rva: 000160EC
!	GetObjectA  ord:405 rva: 000160F0
!	GetDeviceCaps  ord:363 rva: 000160F4
!	RealizePalette  ord:499 rva: 000160F8
!	SelectPalette  ord:527 rva: 000160FC
!	CreatePalette  ord:69 rva: 00016100
!	GetSystemPaletteEntries  ord:425 rva: 00016104
	*/

typedef HGDIOBJ (WINAPI* ZXGetStockObject)(
  int fnObject   // stock object type
);

typedef HDC (WINAPI* ZXCreateDC)(
  LPCTSTR lpszDriver,        // driver name
  LPCTSTR lpszDevice,        // device name
  LPCTSTR lpszOutput,        // not used; should be NULL
  CONST DEVMODE* lpInitData  // optional printer data
);

typedef HDC (WINAPI* ZXCreateCompatibleDC)(
  HDC hdc   // handle to DC
);

typedef HBITMAP (WINAPI* ZXCreateCompatibleBitmap)(
  HDC hdc,        // handle to DC
  int nWidth,     // width of bitmap, in pixels
  int nHeight     // height of bitmap, in pixels
);

typedef BOOL (WINAPI* ZXDeleteDC)(
  HDC hdc   // handle to DC
);

typedef BOOL (WINAPI* ZXGdiFlush)(VOID);

typedef BOOL (WINAPI* ZXBitBlt)(
  HDC hdcDest, // handle to destination DC
  int nXDest,  // x-coord of destination upper-left corner
  int nYDest,  // y-coord of destination upper-left corner
  int nWidth,  // width of destination rectangle
  int nHeight, // height of destination rectangle
  HDC hdcSrc,  // handle to source DC
  int nXSrc,   // x-coordinate of source upper-left corner
  int nYSrc,   // y-coordinate of source upper-left corner
  DWORD dwRop  // raster operation code
);

typedef int (WINAPI* ZXGetDIBits)(
  HDC hdc,           // handle to DC
  HBITMAP hbmp,      // handle to bitmap
  UINT uStartScan,   // first scan line to set
  UINT cScanLines,   // number of scan lines to copy
  LPVOID lpvBits,    // array for bitmap bits
  LPBITMAPINFO lpbi, // bitmap data buffer
  UINT uUsage        // RGB or palette index
);

typedef BOOL (WINAPI* ZXDeleteObject)(
  HGDIOBJ hObject   // handle to graphic object
);

typedef LONG (WINAPI* ZXGetBitmapBits)(
  HBITMAP hbmp,      // handle to bitmap
  LONG cbBuffer,     // number of bytes to copy
  LPVOID lpvBits     // buffer to receive bits
);

typedef COLORREF (WINAPI* ZXSetPixel)(
  HDC hdc,           // handle to DC
  int X,             // x-coordinate of pixel
  int Y,             // y-coordinate of pixel
  COLORREF crColor   // pixel color
);

typedef HGDIOBJ (WINAPI* ZXSelectObject)(
  HDC hdc,          // handle to DC
  HGDIOBJ hgdiobj   // handle to object
);

typedef HBITMAP (WINAPI* ZXCreateBitmap)(
  int nWidth,         // bitmap width, in pixels
  int nHeight,        // bitmap height, in pixels
  UINT cPlanes,       // number of color planes
  UINT cBitsPerPel,   // number of bits to identify color
  CONST VOID *lpvBits // color data array
);

typedef int (WINAPI* ZXGetObject)(
  HGDIOBJ hgdiobj,  // handle to graphics object
  int cbBuffer,     // size of buffer for object information
  LPVOID lpvObject  // buffer for object information
);


typedef int (WINAPI* ZXGetDeviceCaps)(
  HDC hdc,     // handle to DC
  int nIndex   // index of capability
);

typedef UINT (WINAPI* ZXRealizePalette)(
  HDC hdc   // handle to DC
);

typedef HPALETTE (WINAPI* ZXSelectPalette)(
  HDC hdc,                // handle to DC
  HPALETTE hpal,          // handle to logical palette
  BOOL bForceBackground   // foreground or background mode
);

typedef HPALETTE (WINAPI* ZXCreatePalette)(
  CONST LOGPALETTE *lplgpl   // logical palette
);


typedef UINT (WINAPI* ZXGetSystemPaletteEntries)(
  HDC hdc,              // handle to DC
  UINT iStartIndex,     // first entry to be retrieved
  UINT nEntries,        // number of entries to be retrieved
  LPPALETTEENTRY lppe   // array that receives entries
);





