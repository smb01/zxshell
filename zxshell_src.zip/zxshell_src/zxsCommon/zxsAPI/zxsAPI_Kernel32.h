#include <windows.H>
#include <TlHelp32.H>

/*

KERNEL32.dll
	CreateFileA  ord:83 rva: 0001E148
	MoveFileA  ord:622 rva: 0001E160
	WinExec  ord:917 rva: 0001E164
	LoadLibraryExA  ord:595 rva: 0001E16C
	OpenProcess  ord:646 rva: 0001E180
	ReadProcessMemory  ord:696 rva: 0001E1A0
	CreateProcessA  ord:102 rva: 0001E1BC
	TerminateProcess  ord:862 rva: 0001E1C8
	CreateRemoteThread  ord:106 rva: 0001E1CC
	WriteProcessMemory  ord:941 rva: 0001E1D0
	CreatePipe  ord:101 rva: 0001E1F4
	MoveFileExA  ord:623 rva: 0001E240
	FindFirstFileA  ord:210 rva: 0001E250
	LoadLibraryA  ord:594 rva: 0001E280
	CreateThread  ord:111 rva: 0001E29C
==============================================
KERNEL32.dll
	CreateMutexA  ord:96 rva: 0001510C
	FindClose  ord:206 rva: 00015110
	SetFileAttributesA  ord:793 rva: 00015114
	SetFileTime  ord:799 rva: 00015118
	FindNextFileA  ord:220 rva: 0001511C
	GetLastError  ord:369 rva: 00015120
	GetDriveTypeA  ord:339 rva: 00015124
	DeleteFileA  ord:131 rva: 00015128
	CreateDirectoryA  ord:75 rva: 0001512C
	ReadFile  ord:693 rva: 00015130
	CreateFileA  ord:83 rva: 00015134
	Process32Next  ord:664 rva: 00015138
	Process32First  ord:662 rva: 0001513C
	CreateToolhelp32Snapshot  ord:114 rva: 00015140
	LocalAlloc  ord:600 rva: 00015144
	WriteFile  ord:932 rva: 00015148
	GetTempFileNameA  ord:467 rva: 0001514C
	GetTempPathA  ord:469 rva: 00015150
	GetFileSize  ord:355 rva: 00015154
!	lstrcpyA  ord:966 rva: 00015158
	lstrlenA  ord:972 rva: 0001515C
	GetPrivateProfileStringA  ord:412 rva: 00015160
	InterlockedExchangeAdd  ord:554 rva: 00015164
	FormatMessageA  ord:243 rva: 00015168
!	GetModuleHandleA  ord:383 rva: 0001516C
	GetFileSizeEx  ord:356 rva: 00015170
	SetFilePointerEx  ord:796 rva: 00015174
	SetEndOfFile  ord:784 rva: 00015178
	GetVersionExA  ord:489 rva: 0001517C
	GlobalMemoryStatus  ord:516 rva: 00015180
	GetFileTime  ord:357 rva: 00015184
	SetErrorMode  ord:789 rva: 00015188
	SetFilePointer  ord:795 rva: 0001518C
	GetSystemTime  ord:456 rva: 00015190
	SystemTimeToTzSpecificLocalTime  ord:860 rva: 00015194
	FileTimeToSystemTime  ord:197 rva: 00015198
	GetDateFormatA  ord:327 rva: 0001519C
	GetCurrentThreadId  ord:326 rva: 000151A0
!	GetCurrentProcess  ord:322 rva: 000151A4
	MultiByteToWideChar  ord:629 rva: 000151A8
	lstrlenW  ord:973 rva: 000151AC
	WideCharToMultiByte  ord:916 rva: 000151B0
	LocalFree  ord:604 rva: 000151B4
	CloseHandle  ord:52 rva: 000151B8
	GlobalLock  ord:515 rva: 000151BC
	GlobalUnlock  ord:522 rva: 000151C0
	GlobalAlloc  ord:504 rva: 000151C4
	LoadLibraryA  ord:594 rva: 000151C8
~	GetProcAddress  ord:416 rva: 000151CC
	FreeLibrary  ord:248 rva: 000151D0
	SetEvent  ord:790 rva: 000151D4
	CreateEventA  ord:79 rva: 000151D8
	GetTickCount  ord:479 rva: 000151DC
	Sleep  ord:854 rva: 000151E0
	EnterCriticalSection  ord:152 rva: 000151E4
	LeaveCriticalSection  ord:593 rva: 000151E8
	DeleteCriticalSection  ord:129 rva: 000151EC
	InitializeCriticalSection  ord:547 rva: 000151F0
	WaitForSingleObject  ord:912 rva: 000151F4
!	GetModuleFileNameA  ord:381 rva: 000151F8
	
	
*/

typedef DWORD WINAPI _ZXResumeThread(
  HANDLE hThread
);

typedef BOOL WINAPI _ZXSetThreadContext(
  HANDLE hThread,
  const CONTEXT* lpContext
);

typedef BOOL WINAPI _ZXVirtualProtectEx(
  HANDLE hProcess,
  LPVOID lpAddress,
  SIZE_T dwSize,
  DWORD flNewProtect,
  PDWORD lpflOldProtect
);

typedef SIZE_T WINAPI _ZXVirtualQueryEx(
  HANDLE hProcess,
  LPCVOID lpAddress,
  PMEMORY_BASIC_INFORMATION lpBuffer,
  SIZE_T dwLength
);

typedef BOOL WINAPI _ZXGetThreadContext(
  HANDLE hThread,
  LPCONTEXT lpContext
);

typedef BOOL WINAPI _ZXVirtualFree(
  LPVOID lpAddress,
  SIZE_T dwSize,
  DWORD dwFreeType
);


typedef BOOL WINAPI _ZXVirtualProtect(
  LPVOID lpAddress,
  SIZE_T dwSize,
  DWORD flNewProtect,
  PDWORD lpflOldProtect
);

typedef BOOL WINAPI _ZXHeapDestroy(
  HANDLE hHeap
);


typedef BOOL WINAPI _ZXFreeLibrary(
  HMODULE hModule
);


typedef LPVOID WINAPI _ZXVirtualAlloc(
  LPVOID lpAddress,
  SIZE_T dwSize,
  DWORD flAllocationType,
  DWORD flProtect
);


typedef HANDLE WINAPI _ZXCreateMutex(
  LPSECURITY_ATTRIBUTES lpMutexAttributes,
  BOOL bInitialOwner,
  LPCTSTR lpName
);


typedef BOOL WINAPI _ZXGetVersionEx(
  LPOSVERSIONINFO lpVersionInfo
);

typedef DWORD WINAPI _ZXGetEnvironmentVariable(
  WCHAR *lpName,
  WCHAR *lpBuffer,
  DWORD nSize
);


typedef FARPROC (WINAPI*WinGetProcAddress)(
  HMODULE hModule,
  LPCSTR lpProcName
);

typedef HANDLE (WINAPI*ZXCreateFile)(
  LPCTSTR lpFileName,
  DWORD dwDesiredAccess,
  DWORD dwShareMode,
  LPSECURITY_ATTRIBUTES lpSecurityAttributes,
  DWORD dwCreationDisposition,
  DWORD dwFlagsAndAttributes,
  HANDLE hTemplateFile
);


typedef BOOL (WINAPI*ZXRemoveDirectory)(
  LPCTSTR lpPathName
);

typedef BOOL (WINAPI*ZXMoveFile)(
  LPCTSTR lpExistingFileName,
  LPCTSTR lpNewFileName
);

typedef UINT (WINAPI*ZXWinExec)(
  LPCSTR lpCmdLine,
  UINT uCmdShow
);

typedef HMODULE (WINAPI*ZXLoadLibraryEx)(
  LPCTSTR lpFileName,
  HANDLE hFile,
  DWORD dwFlags
);


typedef HANDLE WINAPI _ZXCreateToolhelp32Snapshot(
  DWORD dwFlags,
  DWORD th32ProcessID
);


typedef HANDLE (WINAPI*ZXOpenProcess)(
  DWORD dwDesiredAccess,
  BOOL bInheritHandle,
  DWORD dwProcessId
);

typedef BOOL (WINAPI*ZXReadProcessMemory)(
  HANDLE hProcess,
  LPCVOID lpBaseAddress,
  LPVOID lpBuffer,
  SIZE_T nSize,
  SIZE_T* lpNumberOfBytesRead
);

typedef BOOL (WINAPI*ZXCreateProcess)(
  LPCTSTR lpApplicationName,
  LPTSTR lpCommandLine,
  LPSECURITY_ATTRIBUTES lpProcessAttributes,
  LPSECURITY_ATTRIBUTES lpThreadAttributes,
  BOOL bInheritHandles,
  DWORD dwCreationFlags,
  LPVOID lpEnvironment,
  LPCTSTR lpCurrentDirectory,
  LPSTARTUPINFO lpStartupInfo,
  LPPROCESS_INFORMATION lpProcessInformation
);

typedef BOOL (WINAPI*ZXTerminateProcess)(
  HANDLE hProcess,
  UINT uExitCode
);


typedef HANDLE (WINAPI*ZXCreateRemoteThread)(
  HANDLE hProcess,
  LPSECURITY_ATTRIBUTES lpThreadAttributes,
  SIZE_T dwStackSize,
  LPTHREAD_START_ROUTINE lpStartAddress,
  LPVOID lpParameter,
  DWORD dwCreationFlags,
  LPDWORD lpThreadId
);

typedef BOOL (WINAPI*ZXWriteProcessMemory)(
  HANDLE hProcess,
  LPVOID lpBaseAddress,
  LPCVOID lpBuffer,
  SIZE_T nSize,
  SIZE_T* lpNumberOfBytesWritten
);

typedef BOOL (WINAPI*ZXCreatePipe)(
  PHANDLE hReadPipe,
  PHANDLE hWritePipe,
  LPSECURITY_ATTRIBUTES lpPipeAttributes,
  DWORD nSize
);

typedef BOOL (WINAPI*ZXMoveFileEx)(
  LPCTSTR lpExistingFileName,
  LPCTSTR lpNewFileName,
  DWORD dwFlags
);


typedef HANDLE (WINAPI*ZXFindFirstFile)(
  LPCTSTR lpFileName,
  LPWIN32_FIND_DATA lpFindFileData
);


typedef HMODULE (WINAPI*ZXLoadLibrary)(
  LPCTSTR lpFileName
);


typedef HANDLE (WINAPI*ZXCreateThread)(
  LPSECURITY_ATTRIBUTES lpThreadAttributes,
  SIZE_T dwStackSize,
  LPTHREAD_START_ROUTINE lpStartAddress,
  LPVOID lpParameter,
  DWORD dwCreationFlags,
  LPDWORD lpThreadId
);


typedef BOOL (WINAPI*ZXOpenProcessToken)(
  HANDLE ProcessHandle,
  DWORD DesiredAccess,
  PHANDLE TokenHandle
);

typedef LPTSTR (WINAPI*ZXlstrcpy)(
	LPTSTR lpString1,
	LPTSTR lpString2
);

typedef HANDLE (WINAPI*ZXGetCurrentProcess)(void);

typedef HMODULE (WINAPI*ZXGetModuleHandle)(
  LPCTSTR lpModuleName
);

typedef DWORD (WINAPI*ZXGetModuleFileName)(
  HMODULE hModule,
  LPTSTR lpFilename,
  DWORD nSize
);


typedef BOOL (WINAPI*ZXWriteFile)(
  HANDLE hFile,
  LPCVOID lpBuffer,
  DWORD nNumberOfBytesToWrite,
  LPDWORD lpNumberOfBytesWritten,
  LPOVERLAPPED lpOverlapped
);

typedef BOOL (WINAPI*ZXReadFile)(
  HANDLE hFile,
  LPVOID lpBuffer,
  DWORD nNumberOfBytesToRead,
  LPDWORD lpNumberOfBytesRead,
  LPOVERLAPPED lpOverlapped
);

typedef BOOL WINAPI _ZXCloseHandle(
  HANDLE hObject
);

typedef LPVOID WINAPI _ZXVirtualAllocEx(
  HANDLE hProcess,
  LPVOID lpAddress,
  SIZE_T dwSize,
  DWORD flAllocationType,
  DWORD flProtect
);
