#include <windows.H>

typedef void *  __cdecl _vc_memcpy(void *, const void *, size_t);
typedef int __cdecl _vc_stricmp(const char *, const char *);


typedef int __cdecl _vc_sprintf (
        char *string,
        const char *format,
        ...
        );


typedef int __cdecl _vc__snprintf (
        char *string,
        size_t count,
        const char *format,
        ...
        );

typedef int     __cdecl _vc_memcmp(const void *, const void *, size_t);
typedef void *  __cdecl _vc_memset(void *, int, size_t);
typedef char *  __cdecl _vc_strcpy(char *, const char *);
typedef char *  __cdecl _vc_strcat(char *, const char *);
typedef size_t  __cdecl _vc_strlen(const char *);

