#include <windows.H>


/*
USER32.dll
	GetKeyState  ord:289 rva: 0001E424
	GetAsyncKeyState  ord:242 rva: 0001E428
	MapVirtualKeyA  ord:470 rva: 0001E488
	*/

typedef BOOL (WINAPI*ZXExitWindowsEx)(
  UINT uFlags,
  DWORD dwReason
);


typedef SHORT WINAPI _ZXGetKeyState(          int nVirtKey
);


typedef SHORT WINAPI _ZXGetAsyncKeyState(          int vKey
);


typedef UINT WINAPI _ZXMapVirtualKeyEx(          UINT uCode,
    UINT uMapType,
    HKL dwhkl
);
