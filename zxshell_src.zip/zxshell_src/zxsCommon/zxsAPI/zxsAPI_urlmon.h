#include <windows.H>

#include <urlmon.h>



typedef BOOL (WINAPI*ZXURLDownloadToFile)(
	LPUNKNOWN argv1,
	LPCSTR argv2,
	LPCSTR argv3,
	DWORD argv4,
	LPBINDSTATUSCALLBACK argv5);

