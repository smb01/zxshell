#include <windows.H>
#include <LMaccess.h>


/*
NETAPI32.dll
	NetUserAdd  ord:241 rva: 0001E38C
	NetLocalGroupAddMembers  ord:166 rva: 0001E390
	NetUserSetInfo  ord:251 rva: 0001E394
	


  */

typedef NET_API_STATUS WINAPI  _ZXNetUserAdd (
    IN  LPCWSTR     servername OPTIONAL,
    IN  DWORD      level,
    IN  LPBYTE     buf,
    OUT LPDWORD    parm_err OPTIONAL
    );

typedef
NET_API_STATUS WINAPI 
_ZXNetLocalGroupAddMembers (
    IN  LPCWSTR     servername OPTIONAL,
    IN  LPCWSTR     groupname,
    IN  DWORD      level,
    IN  LPBYTE     buf,
    IN  DWORD      totalentries
    );

typedef
NET_API_STATUS WINAPI 
_ZXNetUserSetInfo (
    IN  LPCWSTR    servername OPTIONAL,
    IN  LPCWSTR    username,
    IN  DWORD     level,
    IN  LPBYTE    buf,
    OUT LPDWORD   parm_err OPTIONAL
    );


typedef
NET_API_STATUS WINAPI _ZXNetUserDel(
  LPCWSTR servername,
  LPCWSTR username
);

typedef
NET_API_STATUS WINAPI _ZXNetApiBufferFree(
  LPVOID Buffer
);

typedef
NET_API_STATUS WINAPI _ZXNetUserEnum(
  LPCWSTR servername,
  DWORD level,
  DWORD filter,
  LPBYTE* bufptr,
  DWORD prefmaxlen,
  LPDWORD entriesread,
  LPDWORD totalentries,
  LPDWORD resume_handle
);
