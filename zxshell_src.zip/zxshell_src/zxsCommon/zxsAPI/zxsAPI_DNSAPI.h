#include <windows.H>
#include <WinDNS.h>

/*
	

DNSAPI.dll
	DnsQuery_A  ord:71 rva: 0001E0EC

*/


typedef
DNS_STATUS
WINAPI
_ZXDnsQuery(
    IN      PCSTR           pszName,
    IN      WORD            wType,
    IN      DWORD           Options,
    IN      PIP4_ARRAY      aipServers            OPTIONAL,
    IN OUT  PDNS_RECORD *   ppQueryResults        OPTIONAL,
    IN OUT  PVOID *         pReserved             OPTIONAL
    );

typedef
VOID
WINAPI
_ZXDnsRecordListFree(
    IN OUT  PDNS_RECORD     pRecordList,
    IN      DNS_FREE_TYPE   FreeType
    );