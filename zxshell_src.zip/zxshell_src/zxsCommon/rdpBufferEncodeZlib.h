#if !defined _RDPBUFFERENCODEZLIB
#define _RDPBUFFERENCODEZLIB

#include "zlib\zlib.h"
#include "rdpBuffer.h"


class _rdpBufferEncodeZlib
{
private:
	int m_level;
public:
	_rdpBufferEncodeZlib(){ m_level = 8; };
	//~_rdpBuffer();

	int SetCompressLevel(int level){ return m_level = level; };

	int do_gzip(BYTE *dest, DWORD *destsize, BYTE *src, DWORD srcsize, int level);
	int do_gzip(BYTE *dest, DWORD *destsize, BYTE *src, DWORD srcsize);

};

#endif