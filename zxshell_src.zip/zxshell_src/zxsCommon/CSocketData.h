#if !defined _CSOCKETDATA
#define _CSOCKETDATA

#include "sock.h"
#include "rdp.h"

class CSocketData
{
protected:

	SOCKET m_socket;
	HANDLE hSendEv, hRecvEv;

public:
	CSocketData();
	~CSocketData();
	BOOL init(SOCKET s);

	BOOL SendAction(_tagRDPHEAD *pHead);
	BOOL SendData(_tagRDPHEAD *pHead, BYTE *buf, DWORD len);
	BOOL SendDataGZip(_tagRDPHEAD *pHead, _tagZLIBINFO *pZI, BYTE *buf, DWORD len);
/*
	BOOL RecvAction(_tagRDPHEAD *pHead);
	BOOL RecvData(_tagRDPHEAD *pHead, BYTE *buf, DWORD len);
	BOOL RecvDataGZip(_tagRDPHEAD *pHead, _tagZLIBINFO *pZI, BYTE *buf, DWORD len);
*/

};


#endif