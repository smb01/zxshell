#ifndef _SPAMCODE__H_
#define _SPAMCODE__H_

#include "zxsWinAPI.h"

#if defined _INSERT_SPAM_CODE
	#define SPAMFUNCTION  SpamFunction();
#else
	#define SPAMFUNCTION
#endif


inline void SpamFunction()
{
	_asm
	{
		jmp _RET

_emit 0xD2
_emit 0x51
_emit 0x92
_emit 0xA5
_emit 0x32
_emit 0x2C
_emit 0xFA
_emit 0x4A
_emit 0x8A
_emit 0x91
_emit 0x56
_emit 0x50
_emit 0xED
_emit 0xB5
_emit 0xF7

_RET:
		
	}
	
}



#endif