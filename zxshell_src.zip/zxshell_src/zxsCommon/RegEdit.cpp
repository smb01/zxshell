#include "zxsWinAPI.h"
#include "RegEdit.h"

//�򵥵�ע�����д����
char *DelSpace(char *szData)
{
	int i=0 ;
	while(1)
	{
		if(!strncmp(szData+i," ",1))
			i++;
		else 
			break;
	}
	return (szData+i);
}
int  ReadReg(HKEY MainKey,LPCTSTR Subkey,LPCTSTR Vname,void *szData, DWORD dwSize)
{
	HKEY   hKey;

	if(ZXSAPI::RegOpenKey(MainKey,Subkey,&hKey) == ERROR_SUCCESS)
	{
		if(RegQueryValueEx(hKey,Vname,NULL,NULL,(LPBYTE)szData,&dwSize) != ERROR_SUCCESS)
		{
			dwSize = 0;
		}
		RegCloseKey(hKey);  
	}else
	{
		dwSize = 0;
	}

	return dwSize;
}

int WriteReg(HKEY MainKey,LPCTSTR Subkey,LPCTSTR Vname,DWORD Type, LPCTSTR  szBuf,DWORD dwData,int Mode)
{
	HKEY hKey;
	BOOL bError = FALSE;

	if (Mode == 0)
	{
		if ( ZXSAPI::RegCreateKey(MainKey,Subkey, &hKey) != ERROR_SUCCESS) 
			goto exit;
	}
	else
	{
		if (ZXSAPI::RegOpenKey(MainKey,Subkey, &hKey) != ERROR_SUCCESS) 
			goto exit;
		//����һ��ֵʱ�����ֵ�������򷵻�false
		//���������ʱҪ����һ�������ʱMode=0����RegCreateKey����þ��
		if (RegQueryValueEx(hKey, Vname, 0, &Type, NULL, NULL) != ERROR_SUCCESS)
			goto exit;
	}

	if (Mode == 2)
	{
		if (RegDeleteValue(hKey,Vname) != ERROR_SUCCESS)
		{
			goto exit;
		}
	}

	if (Type == REG_SZ || Type == REG_EXPAND_SZ)
	{
		if (ZXSAPI::RegSetValueEx(hKey,Vname,0,Type,(LPBYTE) szBuf, strlen(szBuf) + 1) != ERROR_SUCCESS)  
		{
			goto exit;
		}
	}

	if(Type == REG_DWORD)
	{
		if (ZXSAPI::RegSetValueEx(hKey,Vname,0,Type,(LPBYTE) &dwData,sizeof(DWORD)) != ERROR_SUCCESS)
		{
			goto exit;
		}
	}

	bError = TRUE;
	exit:
	RegCloseKey(hKey);

	return bError;
}