// Author: LZX
// E-mail: LZX@qq.com
// QQ: 5088090
// Test PlatForm: WinXP SP2
// Last Modified: 2007-5-24

//////////////////////////////////////////////////////////////
#include "CPUUsage.h"


CCPUUsage::CCPUUsage()
{
	memset(this, 0, sizeof(CCPUUsage));

    NtQuerySystemInformation = (LPNTQUERYSYSTEMINFORMATION)GetProcAddress(
                                            GetModuleHandle("ntdll.dll"),
                                            "NtQuerySystemInformation"
                                            );
}

CCPUUsage::~CCPUUsage()
{

}

UINT CCPUUsage::GetCPUUsage()
{
    if(!NtQuerySystemInformation)
       return 0;

///////////////////

	SYSTEM_BASIC_INFORMATION sbi;
	SYSTEM_TIME_OF_DAY_INFORMATION sti;
	SYSTEM_PROCESSOR_TIMES spt;

	NTSTATUS ret;
	ULONG retsize;

	ret = NtQuerySystemInformation(SystemBasicInformation, &sbi, sizeof(sbi), &retsize);
	if(ret != NO_ERROR)
		return 0;
	ret = NtQuerySystemInformation(SystemTimeOfDayInformation, &sti, sizeof(sti), &retsize);
	if(ret != NO_ERROR)
		return 0;
	ret = NtQuerySystemInformation(SystemProcessorTimes, &spt, sizeof(spt), &retsize);
	if(ret != NO_ERROR)
		return 0;

	Interval.QuadPart = sti.CurrentTime.QuadPart - prevSystemTime.QuadPart;
	IdleTime.QuadPart = spt.IdleTime.QuadPart - prevIdleTime.QuadPart;

	if(Interval.QuadPart == 0)
		return 100;

	CpuUsage.QuadPart = (Interval.QuadPart-IdleTime.QuadPart)*100/Interval.QuadPart/sbi.NumberProcessors;

	if(prevSystemTime.QuadPart == 0)
	{
		prevSystemTime = sti.CurrentTime;
		prevIdleTime = spt.IdleTime;
		return 0;
	}

	prevSystemTime = sti.CurrentTime;
	prevIdleTime = spt.IdleTime;

	return (UINT)CpuUsage.QuadPart;
}

//example
/*

void main()
{

	CCPUUsage cpu;

	while(1)
	{
		printf("%3d%%\r\n", cpu.GetCPUUsage());

		Sleep(1000);
	}


}
*/