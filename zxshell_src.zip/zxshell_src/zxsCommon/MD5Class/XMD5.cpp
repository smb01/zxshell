#include "XMD5.h"


bool XMD5::Open(LPCSTR lpFileName)
{
	hFile = CreateFile(lpFileName, 
        GENERIC_READ, 
        FILE_SHARE_READ, 
        NULL, 
        OPEN_EXISTING, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		return false;
	}
	MD5Init (&context);
	return true;
}

char *XMD5::GetFileMD5String(char *output)
{
	MD5Final (digest, &context);
	int i;
	for (i = 0; i < 16; i++)
	{
		sprintf(&(output1[2*i]),"%02x",(unsigned char)digest[i]);
		//	sprintf(&(output1[2*i+1]),"%02x",(unsigned char)(digest[i]<<4));
  	}
	for(i=0; i<32; i++)
		output[i]=output1[i];
	output[i] = '\0';
	return output;
}

void XMD5::Close()
{
	CloseHandle(hFile);
}

bool XMD5::HashFile()
{
	if(! ReadFile(hFile, buffer, sizeof(buffer), &len, NULL))
		return false;
	if(!len)
		return false;

	MD5Update (&context, buffer, len);

	return true;
}