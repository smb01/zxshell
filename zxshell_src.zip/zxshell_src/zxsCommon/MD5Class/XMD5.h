#include "Md5A.h"

class XMD5: public CMd5A
{
private:
	HANDLE hFile;

	unsigned long len;
	unsigned char buffer[8192], digest[16];
	int i;
	char output1[33];
	MD5_CTX context;

public:
	bool Open(LPCSTR lpFileName);
	bool HashFile();
	void Close();
	char * GetFileMD5String(char *output);
};