#include "CSocketData.h"
#include <stdio.h>


CSocketData::CSocketData()
{
	m_socket = ~0;
	hSendEv = NULL;
//	hRecvEv = NULL;
}

CSocketData::~CSocketData()
{
	CloseHandle(hSendEv);
	//CloseHandle(hRecvEv);
}

BOOL CSocketData::init(SOCKET s)
{
	m_socket = s;
	hSendEv = CreateEvent(0, 0, 1, 0);
//	hRecvEv = CreateEvent(0, 0, 1, 0);

//	return (hSendEv != NULL) && (hRecvEv != NULL);
	return (hSendEv != NULL);
}

BOOL CSocketData::SendAction(_tagRDPHEAD *pHead)
{
	WaitForSingleObject(hSendEv, -1);
	int ret;

	ret = Send(m_socket, (char*)pHead, sizeof(_tagRDPHEAD));

	SetEvent(hSendEv);

	return ret;
}

BOOL CSocketData::SendData(_tagRDPHEAD *pHead, BYTE *buf, DWORD len)
{
	WaitForSingleObject(hSendEv, -1);

	int ret = 0;
	__try{
		if(!Send(m_socket, (char*)pHead, sizeof(_tagRDPHEAD)))
			__leave;
		if(!Send(m_socket, (char*)buf, len))
			__leave;

		ret = 1;
	}__finally{
		SetEvent(hSendEv);
		return ret;
	}
}

BOOL CSocketData::SendDataGZip(_tagRDPHEAD *pHead, _tagZLIBINFO *pZI, BYTE *buf, DWORD len)
{
	WaitForSingleObject(hSendEv, -1);

	int ret = 0;
	__try{
		if(!Send(m_socket, (char*)pHead, sizeof(_tagRDPHEAD)))
			__leave;
		if(!Send(m_socket, (char*)pZI, sizeof(_tagZLIBINFO)))
			__leave;
		if(!Send(m_socket, (char*)buf, len))
			__leave;

		ret = 1;
	}__finally{
		SetEvent(hSendEv);
		return ret;
	}
	return 0;
}

