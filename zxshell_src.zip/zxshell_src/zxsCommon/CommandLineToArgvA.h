// CommandLineToArgvA.h: interface for the CommandLineToArgvA class.
// ��һ���ַ���ת��Ϊchar **argv
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COMMANDLINETOARGVA_H__C8382A9F_3323_4CEF_A17A_81AC51CE6BD1__INCLUDED_)
#define AFX_COMMANDLINETOARGVA_H__C8382A9F_3323_4CEF_A17A_81AC51CE6BD1__INCLUDED_

#include <windows.h>

struct MainPara{
	unsigned int Socket;
	LPSTR lpCmd;
};

class ARGWTOARGVA
{
protected:
	char *lpCmdLine;
	int Argc;
	char **Argv;
private:
	char *pNew;
	char **CommandLineToArgvA();
public:
	ARGWTOARGVA();
	ARGWTOARGVA(LPSTR lpCmd);
	~ARGWTOARGVA();
	int GetArgc();
	char **GetArgv();
};


/*
class ARGWTOARGVA
{
protected:
	char szCmdLine[MAX_PATH];
	char *lpCmdLine;
	int Argc;
	char **Argv;
private:
	char *pCmd;
	DWORD *Addr;
	char **CommandLineToArgvA();
public:
	ARGWTOARGVA();
	ARGWTOARGVA(LPSTR lpCmd);
	~ARGWTOARGVA();
	int GetArgc();
	char **GetArgv();
};
inline ARGWTOARGVA::ARGWTOARGVA()
{
	lpCmdLine = GetCommandLine();
	Argc = 0;
	pCmd = NULL;
	Addr = NULL;
	Argv = CommandLineToArgvA();
}
inline ARGWTOARGVA::ARGWTOARGVA(LPSTR lpCmd)
{
	strcpy(szCmdLine, lpCmd);
	lpCmdLine = szCmdLine;
	Argc = 0;
	pCmd = NULL;
	Addr = NULL;
	Argv = CommandLineToArgvA();
}
inline ARGWTOARGVA::~ARGWTOARGVA()
{
	delete [] pCmd;
	delete [] Addr;
}

inline int ARGWTOARGVA::GetArgc()
{
	return Argc;
}
inline char **ARGWTOARGVA::GetArgv()
{
	return Argv;
}
inline char **ARGWTOARGVA::CommandLineToArgvA()
{
	int argc, ret, i;
	WCHAR wBuf[MAX_PATH];
	ret = MultiByteToWideChar(CP_ACP, MB_ERR_INVALID_CHARS, lpCmdLine, lstrlen(lpCmdLine)+1, wBuf, sizeof(wBuf));
	WCHAR **argvW = CommandLineToArgvW(wBuf, &argc);
	Argc = argc;
	//��̬�����ά���� start
	int row, col;
	row = argc;
	col = MAX_PATH;
	pCmd = new char [row * col];
	Addr = new DWORD [row];

	memset(pCmd, 0, row * col);
	char *Para = pCmd;
	for(i=0; i<row; i++)
	{
		Addr[i] = (DWORD)Para;
		Para += col;
	}
	char **argv = (char**)Addr;
	//end
	for(i=0; i<argc; i++)
	{
		WideCharToMultiByte(CP_ACP, 0, argvW[i], lstrlenW(argvW[i])+1, argv[i], MAX_PATH, NULL, NULL);
	}
	return argv;
}
*/

#endif // !defined(AFX_COMMANDLINETOARGVA_H__C8382A9F_3323_4CEF_A17A_81AC51CE6BD1__INCLUDED_)
