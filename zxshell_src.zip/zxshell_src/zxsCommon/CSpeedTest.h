#if !defined _RD_CSPEEDTEST
#define _RD_CSPEEDTEST

#include <windows.h>

class CSpeedTest
{
protected:
	DWORD unitDataSize;
	DWORD baseTime, prevTime, currTime;

	DWORD umusedTime;
	DWORD umSpeed;
public:
	CSpeedTest();
	~CSpeedTest();

	void Start(DWORD datasize);
	void Stop(DWORD datasize);
	DWORD GetumSpeed();
	int GetRCMLevel(DWORD speed, WORD bits);
};


#endif