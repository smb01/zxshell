// CommandLineToArgvA.h: interface for the CommandLineToArgvA class.
// ��һ���ַ���ת��Ϊchar **argv
//////////////////////////////////////////////////////////////////////

#include "CommandLineToArgvA.h"

ARGWTOARGVA::ARGWTOARGVA()
{
	lpCmdLine = GetCommandLine();
	Argc = 0;
	pNew = NULL;
	Argv = CommandLineToArgvA();
}
ARGWTOARGVA::ARGWTOARGVA(LPSTR lpCmd)
{
	lpCmdLine = new char [strlen(lpCmd)+1];
	strcpy(lpCmdLine, lpCmd);
	pNew = lpCmdLine;
	Argc = 0;
	Argv = CommandLineToArgvA();
}
ARGWTOARGVA::~ARGWTOARGVA()
{
	delete [] pNew;
	LocalFree(Argv);// Free memory allocated for CommandLineToArgvW arguments.
}

int ARGWTOARGVA::GetArgc()
{
	return Argc;
}

char **ARGWTOARGVA::GetArgv()
{
	return Argv;
}

//M$ û�ṩCommandLineToArgvA�����ǿ��ַ�ռ�õĿռ�ȵ��ֽڴ�һ����ֻ�轫����תΪ���ֽڵģ���ǿ��ת��ָ�뼴��
char **ARGWTOARGVA::CommandLineToArgvA()
{
	int argc, ret, i, cmdlen;

	cmdlen = strlen(lpCmdLine)+1;
	WCHAR *wBuf = new WCHAR[cmdlen*sizeof(WCHAR)];
	memset(wBuf, 0, cmdlen*sizeof(WCHAR));

	ret = MultiByteToWideChar(CP_ACP, MB_ERR_INVALID_CHARS, lpCmdLine, cmdlen, wBuf, cmdlen*sizeof(WCHAR));
	WCHAR **argvW = CommandLineToArgvW(wBuf, &argc);
	Argc = argc;

	if(argvW == NULL)
		goto exit;

	for(i=0; i<argc; i++)
	{
		int arglenW = lstrlenW(argvW[i])*sizeof(WCHAR)+2;
		WCHAR *tmp = new WCHAR [arglenW];
		memset(tmp, 0, arglenW);
		memcpy(tmp, argvW[i], arglenW);
		WideCharToMultiByte(CP_ACP, 0, tmp, arglenW, (char*)argvW[i], arglenW, NULL, NULL);
		delete [] tmp;
	}

exit:
	delete [] wBuf;

	return (char**)argvW;

}
