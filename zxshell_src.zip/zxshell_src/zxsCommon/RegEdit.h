#if !defined _SIMPLE_REGEDIT
#define _SIMPLE_REGEDIT

#include <windows.h>


//�򵥵�ע�����д����
char *DelSpace(char *szData);
int  ReadReg(HKEY MainKey,LPCTSTR Subkey,LPCTSTR Vname,void *szData, DWORD dwSize);

int WriteReg(HKEY MainKey,LPCTSTR Subkey,LPCTSTR Vname,DWORD Type, LPCTSTR  szBuf,DWORD dwData,int Mode);


#endif