#if !defined _CAPPHDR
#define _CAPPHDR

#define CAPP_DEVICESTATUS  0
//flag 0=ok,otherwise = error{ 1=no capdevice, 2=cap stopped, 3=cap error}

#define CAPP_SETCAPTUREDRV 1
#define CAPP_SETCOMPRLEVEL 2
#define CAPP_BITMAPINFO    3
#define CAPP_UPDATEVIDEO   4
#define CAPP_CAPSTOP   5
#define CAPP_VERSION   6
#define CAPP_CAPDEVLIST   7

#endif