
#include "debugoutput.h"
#include <stdio.h>
#include <windows.h>

int __printf(const char *fmt, ...)
{
#if !defined _DEBUG && !defined _OUTPUTDEBUG
		return 0;
#endif
	va_list args;
	int n;
	char TempBuf[8192];
	va_start(args, fmt);
	n = vsprintf(TempBuf, fmt, args);
	va_end(args);

	OutputDebugString(TempBuf);

	return printf(TempBuf);
	//printf(TempBuf);
	////return DebufLog.Print(TempBuf);
}

////////////////////////////////////////////////////

_ZXS_LOG DebufLog("C:\\windows\\system32\\test.log", 0);

_ZXS_LOG::_ZXS_LOG(char *file, int mode)
{
	SetLogFile(file, mode);
}

int _ZXS_LOG::SetLogFile(char *file, int mode)
{
	m_mode = mode;

	int i = 0;

	do{
		m_filename[i] = file[i];
	}while(file[i++]);

	return Print("start");

}

int _ZXS_LOG::Print(const char *fmt, ...)
{
	if(m_mode == 0)
		return 0;

	va_list args;
	int n;
	char TempBuf[8192];
	va_start(args, fmt);
	n = vsprintf(TempBuf, fmt, args);
	va_end(args);

	SYSTEMTIME	st;
	GetLocalTime(&st);

	FILE *fp;

	fp = fopen(m_filename, "a+");

	if(fp == NULL)
		return 0;

	n = fprintf(fp,
				"%.2d-%.2d-%.2d %.2d:%.2d:%.2d\r\n"
				"%s\r\n", 
				st.wYear, st.wMonth, st.wDay,
				st.wHour, st.wMinute, st.wSecond,
				TempBuf
				);
	
	fflush(fp);

	fclose(fp);

	return n;
}