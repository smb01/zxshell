#include "rdpBuffer.h"



_rdpBuffer::_rdpBuffer()
{
	m_buffer = NULL;
	size = 0;
	maxsize = 1024*1024*15;
}

_rdpBuffer::~_rdpBuffer()
{
	if(size > 0)
	{
		delete [] m_buffer;
	}

}


//ReAlloc ��־�Ƿ���ԭ��������
bool _rdpBuffer::checkBufferSize(DWORD requiredSize, bool ReAlloc)
{
	if(size < requiredSize)
	{
		if(requiredSize > maxsize)
			return false;

		BYTE *tmp;
		tmp = new BYTE[requiredSize];
		if(tmp == NULL)
			return false;
		

		if(ReAlloc)
		{
			if(m_buffer == NULL)
			{
				memset(tmp, 0, requiredSize);
			}else
			{
				memcpy(tmp, m_buffer, size);
				delete [] m_buffer;
			}
			m_buffer = tmp;
			size = requiredSize;
			return true;
		}else
		{
			delete [] m_buffer;
			m_buffer = tmp;
			size = requiredSize;
			memset(m_buffer, 0, size);
			return true;
		}
	}

	return true;
}
