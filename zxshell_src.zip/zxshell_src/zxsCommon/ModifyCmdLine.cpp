/*
�޸������е����в���
*/
#include <windows.h>
#include <stdio.h>

#define ProcessBasicInformation 0


typedef struct
{
    USHORT Length;
    USHORT MaximumLength;
    PWSTR  Buffer;
} UNICODE_STRING, UNICODE_STRING_p, *PUNICODE_STRING_p;

/*typedef struct _UNICODE_STRING
{
    USHORT Length;
    USHORT MaximumLength;
#ifdef MIDL_PASS
    [size_is(MaximumLength / 2), length_is((Length) / 2) ] USHORT * Buffer;
#else // MIDL_PASS
    PWSTR  Buffer;
#endif // MIDL_PASS
} UNICODE_STRING;
*/
typedef struct _CURDIR
{
    UNICODE_STRING DosPath;
    PVOID Handle;
} CURDIR, *PCURDIR;

typedef struct RTL_DRIVE_LETTER_CURDIR
{
    USHORT Flags;
    USHORT Length;
    ULONG TimeStamp;
    UNICODE_STRING DosPath;
} RTL_DRIVE_LETTER_CURDIR, *PRTL_DRIVE_LETTER_CURDIR;

typedef struct _PEB_FREE_BLOCK
{
    struct _PEB_FREE_BLOCK* Next;
    ULONG Size;
} PEB_FREE_BLOCK, *PPEB_FREE_BLOCK;

/* RTL_USER_PROCESS_PARAMETERS.Flags */
#define PPF_NORMALIZED (1)
typedef struct _RTL_USER_PROCESS_PARAMETERS
{
    ULONG  MaximumLength;            //  00h
    ULONG  Length;                    //  04h
    ULONG  Flags;                    //  08h
    ULONG  DebugFlags;                //  0Ch
    PVOID  ConsoleHandle;            //  10h
    ULONG  ConsoleFlags;            //  14h
    HANDLE  InputHandle;            //  18h
    HANDLE  OutputHandle;            //  1Ch
    HANDLE  ErrorHandle;            //  20h
    CURDIR  CurrentDirectory;        //  24h
    UNICODE_STRING DllPath;            //  30h
    UNICODE_STRING CommandLine;    //  38h
    UNICODE_STRING ImagePathName;        //  40h
    PWSTR  Environment;                //  48h
    ULONG  StartingX;                //  4Ch
    ULONG  StartingY;                //  50h
    ULONG  CountX;                    //  54h
    ULONG  CountY;                    //  58h
    ULONG  CountCharsX;                //  5Ch
    ULONG  CountCharsY;                //  60h
    ULONG  FillAttribute;            //  64h
    ULONG  WindowFlags;                //  68h
    ULONG  ShowWindowFlags;            //  6Ch
    UNICODE_STRING WindowTitle;        //  70h
    UNICODE_STRING DesktopInfo;        //  78h
    UNICODE_STRING ShellInfo;        //  80h
    UNICODE_STRING RuntimeInfo;        //  88h
    RTL_DRIVE_LETTER_CURDIR DLCurrentDirectory[0x20]; // 90h
} RTL_USER_PROCESS_PARAMETERS, *PRTL_USER_PROCESS_PARAMETERS;

typedef struct
{
    ULONG               AllocationSize;
    ULONG               Unknown1;
    HINSTANCE           ProcessHinstance;
    PVOID               ListDlls;
    PRTL_USER_PROCESS_PARAMETERS ProcessParameters;
    ULONG               Unknown2;
    HANDLE              Heap;
} PEB, *PPEB;

typedef struct
{
    DWORD ExitStatus;
    PPEB  PebBaseAddress;
    DWORD AffinityMask;
    DWORD BasePriority;
    ULONG UniqueProcessId;
    ULONG InheritedFromUniqueProcessId;
}   PROCESS_BASIC_INFORMATION;

typedef struct _PEB_LDR_DATA
{
    ULONG Length;
    BOOLEAN Initialized;
    PVOID SsHandle;
    LIST_ENTRY InLoadOrderModuleList;
    LIST_ENTRY InMemoryOrderModuleList;
    LIST_ENTRY InInitializationOrderModuleList;
} PEB_LDR_DATA, *PPEB_LDR_DATA;

typedef LONG (WINAPI *PROCNTQSIP)(HANDLE,UINT,PVOID,ULONG,PULONG);

BOOL ModifyCmdLine(DWORD dwPId, char *szData)
{
    LONG                      status;
    HANDLE                    hProcess;
    PROCESS_BASIC_INFORMATION pbi;
    PPEB                      pPeb;
    PRTL_USER_PROCESS_PARAMETERS        PProcParam;
    RTL_USER_PROCESS_PARAMETERS        ProcParam;
    DWORD                     dwDummy;
    DWORD                     dwSize;
    LPVOID                    lpAddress;
    BOOL                      bRet = FALSE;
	PPEB_LDR_DATA             pLdr;
	LIST_ENTRY                *ple;

	PROCNTQSIP NtQueryInformationProcess;

	BYTE UNK[0x50];
	void *pComandLine;
	WCHAR PATH[520];
	memset(PATH, 0, 520);
	
	MultiByteToWideChar(CP_ACP, 0, szData, lstrlen(szData)+1, PATH, 520);

    NtQueryInformationProcess = (PROCNTQSIP)GetProcAddress(
                                            GetModuleHandle("ntdll"),
                                            "NtQueryInformationProcess"
                                            );

    if (!NtQueryInformationProcess)
       return FALSE;

    // Get process handle
    hProcess = OpenProcess(PROCESS_ALL_ACCESS,FALSE,dwPId);
    if (!hProcess)
       return FALSE;

    // Retrieve information
    status = NtQueryInformationProcess( hProcess,
                                        ProcessBasicInformation,
                                        (PVOID)&pbi,
                                        sizeof(PROCESS_BASIC_INFORMATION),
                                        NULL
                                      );


    if (status)
       goto cleanup;

    if (!ReadProcessMemory( hProcess,
                            (BYTE*)pbi.PebBaseAddress+0xc,//Ldr
                            &pLdr,
                            sizeof(pLdr),
                            &dwDummy
                          )
       )
       goto cleanup;

    if (!ReadProcessMemory( hProcess,
                            (BYTE*)pLdr+0x14,//InMemoryOrderModuleList
                            &ple,
                            sizeof(ple),
                            &dwDummy
                          )
       )
       goto cleanup;

    if (!ReadProcessMemory( hProcess,
                            (BYTE*)ple-0x8,
                            UNK,
                            sizeof(UNK),
                            &dwDummy
                          )
       )
       goto cleanup;

    if (!ReadProcessMemory( hProcess,
                            (BYTE*)pbi.PebBaseAddress+0x010,//ProcessParameters
                            &PProcParam,
                            4,
                            &dwDummy
                          )
       )
       goto cleanup;

    if (!ReadProcessMemory( hProcess,
                            PProcParam,//ProcessParameters
                            &ProcParam,
                            sizeof(ProcParam),
                            &dwDummy
                          )
       )
       goto cleanup;

	pComandLine =::VirtualAllocEx (hProcess, 0, 520, MEM_COMMIT, PAGE_READWRITE);

    if (!WriteProcessMemory( hProcess,
                            pComandLine,
                            PATH,
                            sizeof(PATH),
                            &dwDummy
                          )
       )
	   goto cleanup;

    if (!WriteProcessMemory( hProcess,
                            (DWORD*)(*(DWORD*)(&UNK[0x50-0x28])),
                            PATH,
                            wcslen(PATH)+2,
                            &dwDummy
                          )
       )
	   goto cleanup;

	if (!WriteProcessMemory( hProcess,
                            ProcParam.CommandLine.Buffer,
                            PATH,
                            sizeof(PATH),
                            &dwDummy
                          )
       )
	   goto cleanup;

	if (!WriteProcessMemory( hProcess,
                            ProcParam.ImagePathName.Buffer,
                            PATH,
                            sizeof(PATH),
                            &dwDummy
                          )
       )
	   goto cleanup;

	ProcParam.CommandLine.Length = 520-2;
	ProcParam.CommandLine.MaximumLength = 520;
	ProcParam.CommandLine.Buffer = (WCHAR*)pComandLine;
//	ProcParam.CommandLine.Buffer = 0;

	ProcParam.ImagePathName.Length = 520-2;
	ProcParam.ImagePathName.MaximumLength = 520;
	ProcParam.ImagePathName.Buffer = (WCHAR*)pComandLine;

    if (!WriteProcessMemory( hProcess,
                            PProcParam,//ProcessParameters
                            &ProcParam,
                            sizeof(ProcParam),
                            &dwDummy
                          )
       )
	   goto cleanup;


	*(WORD*)(&UNK[0x50-0x2a]) = 520;
	*(WORD*)(&UNK[0x50-0x2c]) = 520;
	*(DWORD*)(&UNK[0x50-0x28]) = (DWORD)pComandLine;

    if (!WriteProcessMemory( hProcess,
                            (BYTE*)ple-0x8,
                            UNK,
                            sizeof(UNK),
                            &dwDummy
                          )
       )
	   goto cleanup;

    bRet = TRUE;

cleanup:

    CloseHandle (hProcess);

     
    return bRet;
} 