#if !defined _DEBUGOUTPUT
#define _DEBUGOUTPUT

//#include <windows.h>
//#include <stdio.h>
//#include <atltrace.h>

#define TRACE ATLTRACE

int __printf(const char *fmt, ...);



class _ZXS_LOG
{
protected:

	int m_mode;
	char m_filename[260];

public:
	_ZXS_LOG(char *file, int mode);

	int SetLogFile(char *file, int mode);

	int Print(const char *fmt, ...);

};

extern _ZXS_LOG DebufLog;

#endif