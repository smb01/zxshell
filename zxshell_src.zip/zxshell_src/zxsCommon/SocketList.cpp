#include "SocketList.h"
#include "link.h"

int C_SOCKETLIST::AddSocket(SOCKET s)
{
	EnterCriticalSection(&cs);
	int ret = Add(s);
	LeaveCriticalSection(&cs);
	return ret;
}

int C_SOCKETLIST::DelSocket(SOCKET s)
{
	int ret = 0;
	EnterCriticalSection(&cs);
	_Node<SOCKET> *curr = Head;
	for(int n=0; n<Count; n++)
	{
		if(curr->data == s)
		{
			Delp(curr);
			ret = 1;
			break;
		}
		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);
	return ret;
}

int C_SOCKETLIST::IsSocketInList(SOCKET s)
{
	int ret = 0;
	EnterCriticalSection(&cs);
	_Node<SOCKET> *curr = Head;
	for(int n=0; n<Count; n++)
	{
		if(curr->data == s)
		{
			ret = 1;
			break;
		}
		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);
	return ret;
}

int C_SOCKETLIST::CloseAllSocket()
{
	int ret = 0;
	EnterCriticalSection(&cs);
	_Node<SOCKET> *curr = Head;

	for(int n=0; n<Count; n++)
	{
		shutdown(curr->data, 0x02);//SD_BOTH
		curr = curr->Next;
		ret++;
	}
	LeaveCriticalSection(&cs);

	return ret;
}