#if !defined _RDPBUFFER
#define _RDPBUFFER

#include <windows.h>

class _rdpBuffer
{
private:
	BYTE *m_buffer;
	DWORD size;
	DWORD maxsize;
public:
	_rdpBuffer();
	virtual ~_rdpBuffer();

	bool checkBufferSize(DWORD requiredSize, bool ReAlloc);
	operator BYTE*(){return m_buffer;};
	operator char*(){return (char*)m_buffer;};
	BYTE *operator +(int p){return m_buffer+p;};

	BYTE *GetBuffer(){ return m_buffer;}
	DWORD GetSize(){ return size;}

	DWORD LimiteMaxSize(DWORD max){
		maxsize = max;
		return maxsize;
	}
};


#endif