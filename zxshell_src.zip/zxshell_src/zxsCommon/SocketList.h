#ifndef C_SOCKETLIST_H
#define C_SOCKETLIST_H

#include <windows.h>
#include "link.h"

class C_SOCKETLIST:public LINKTABLE<SOCKET>
{
protected:
	CRITICAL_SECTION cs;
public:
	C_SOCKETLIST()
	{
		InitializeCriticalSection(&cs);
	}
	~C_SOCKETLIST()
	{
		DeleteCriticalSection(&cs);
	}
	int AddSocket(SOCKET s);
	int DelSocket(SOCKET s);
	int IsSocketInList(SOCKET s);
	int CloseAllSocket();

};

#endif