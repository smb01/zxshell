#if !defined _EVLOCK
#define _EVLOCK

#include <windows.h>

//CEventLock �� CMutexLock ���ʡ�����һ��

class CEventLock
{
protected:

	HANDLE hEvent;

public:
	CEventLock();
	CEventLock(HANDLE hEv);
	CEventLock(CEventLock &cel);
	~CEventLock();
	HANDLE GetEventHandle(){ return hEvent;}

	BOOL Init();
	void Destroy();
};

class CMutexLock
{
protected:

	HANDLE hMutex;

public:
	CMutexLock();
	CMutexLock(HANDLE hMx);
	CMutexLock(CMutexLock &cml);
	~CMutexLock();
	HANDLE GetMutexHandle(){ return hMutex;}

	BOOL Init();
	void Destroy();
};

class CMyCriticalSection
{
protected:
	bool bInited;
	CRITICAL_SECTION cs;

public:
	CMyCriticalSection();
	CMyCriticalSection(CRITICAL_SECTION *lpcs);
	CMyCriticalSection(CMyCriticalSection &mycs);
	~CMyCriticalSection();
	CRITICAL_SECTION * GetCS(){ return &cs;}
	BOOL Init();
	void Destroy();

	void lock();
	void unlock();
};


class CCountLock
{
protected:
	HANDLE handle;
	LONG count;

public:
	CCountLock();
	CCountLock(CCountLock &cl);
	~CCountLock();
	HANDLE GetHandle(){ return handle;}
	LONG GetCount(){ return count;}
	void add();
	void dec();
	void dealEvent(int val);
	BOOL Init();
	void Wait();
	//void Destroy();
};

class CZXCount
{
private:
	CCountLock *pcl;
public:
	CZXCount(CCountLock &cl);
	~CZXCount();
};

#endif