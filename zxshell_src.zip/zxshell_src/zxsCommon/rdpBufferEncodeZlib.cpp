
#include "zlib\zlib.h"
#include "rdpBufferEncodeZlib.h"


int _rdpBufferEncodeZlib::do_gzip(BYTE *dest, DWORD *destsize, BYTE *src, DWORD srcsize, int level)
{
	return compress2(dest, destsize, src, srcsize, level);
}

int _rdpBufferEncodeZlib::do_gzip(BYTE *dest, DWORD *destsize, BYTE *src, DWORD srcsize)
{
	return compress2(dest, destsize, src, srcsize, m_level);
}

