#include "CSpeedTest.h"
#include <stdio.h>
#include "debugoutput.h"

#define TIMEUNIT 5000

CSpeedTest::CSpeedTest()
{
	memset(this, 0, sizeof(CSpeedTest));

	baseTime = prevTime = currTime = GetTickCount();
}

CSpeedTest::~CSpeedTest()
{

}

void CSpeedTest::Start(DWORD datasize)
{

}

void CSpeedTest::Stop(DWORD datasize)
{

	DWORD tmp;
	currTime = GetTickCount();

	unitDataSize += datasize;
	umusedTime = currTime-prevTime;

	if(umusedTime >= 1000)
	{
		if(currTime-baseTime < TIMEUNIT)
		{
			umSpeed = max(unitDataSize / umusedTime, umSpeed);
			__printf("maxsp: %9d\r\n", umSpeed*1000/1024);
		}
		else
		{
			umSpeed = unitDataSize / umusedTime;
			baseTime = currTime;
			__printf("sp: %9d\r\n", umSpeed*1000/1024);
		}

		prevTime = currTime;

		unitDataSize = 0;

	}

//	__printf("sp: %9d\r\n", umSpeed*1000/1024);

}

DWORD CSpeedTest::GetumSpeed()
{
	if(GetTickCount()-currTime > TIMEUNIT)
		return 0;
	else
		return umSpeed*1000/1024;
}


int CSpeedTest::GetRCMLevel(DWORD speed, WORD bits)
{
	if(bits == 32)
	{
		if(speed > 1024*3) 
			return 0;
		if(speed > 930)
			return 1;
		if(speed > 800)
			return 2;
		if(speed > 630)
			return 3;
		if(speed > 500)
			return 4;
		if(speed > 300)
			return 5;
		if(speed > 120)
			return 6;
		if(speed > 60)
			return 7;
		if(speed > 24)
			return 8;
	}else
/*	if(bits == 24)
	{
		if(speed > 768*3) 
			return 0;
		if(speed > 700)
			return 1;
		if(speed > 620)
			return 2;
		if(speed > 500)
			return 3;
		if(speed > 420)
			return 4;
		if(speed > 280)
			return 5;
		if(speed > 120)
			return 6;
		if(speed > 72)
			return 7;
		if(speed > 26)
			return 8;
	}else*/
	if(bits == 16)
	{
		if(speed > 1200) 
			return 0;
		if(speed > 500)
			return 1;
		if(speed > 400)
			return 2;
		if(speed > 290)
			return 3;
		if(speed > 250)
			return 4;
		if(speed > 150)
			return 5;
		if(speed > 50)
			return 6;
		if(speed > 20)
			return 7;
		if(speed > 8)
			return 8;
	}else
	if(bits == 8)
	{
		if(speed > 600) 
			return 0;
		if(speed > 250)
			return 1;
		if(speed > 190)
			return 2;
		if(speed > 130)
			return 3;
		if(speed > 80)
			return 4;
		if(speed > 50)
			return 5;
		if(speed > 21)
			return 6;
		if(speed > 12)
			return 7;
		if(speed > 5)
			return 8;
	}else
	if(bits == 4)
	{
		if(speed > 380) 
			return 0;
		if(speed > 120)
			return 1;
		if(speed > 90)
			return 2;
		if(speed > 75)
			return 3;
		if(speed > 64)
			return 4;
		if(speed > 28)
			return 5;
		if(speed > 15)
			return 6;
		if(speed > 8)
			return 7;
		if(speed > 3)
			return 8;
	}
	return 9;
}