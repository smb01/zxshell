#include "evlock.h"


CEventLock::CEventLock()
{
	hEvent = NULL;
}

CEventLock::CEventLock(HANDLE hEv)
{
	hEvent = hEv;

	WaitForSingleObject(hEvent, -1);

}

CEventLock::CEventLock(CEventLock &cel)
{
	hEvent = cel.GetEventHandle();

	WaitForSingleObject(hEvent, -1);

}

CEventLock::~CEventLock()
{
	SetEvent(hEvent);
}

BOOL CEventLock::Init()
{
	hEvent = CreateEvent(0, 0, 1, 0);

	return hEvent != NULL;
}

void CEventLock::Destroy()
{
	CloseHandle(hEvent);
}

//////////////////


CMutexLock::CMutexLock()
{
	hMutex = NULL;
}

CMutexLock::CMutexLock(HANDLE hMx)
{
	hMutex = hMx;

	WaitForSingleObject(hMutex, INFINITE);

}

CMutexLock::CMutexLock(CMutexLock &cml)
{
	hMutex = cml.GetMutexHandle();

	WaitForSingleObject(hMutex, INFINITE);

}

CMutexLock::~CMutexLock()
{
	ReleaseMutex(hMutex);
}

BOOL CMutexLock::Init()
{
	hMutex = CreateMutex(NULL, FALSE, NULL);

	return hMutex != NULL;
}

void CMutexLock::Destroy()
{
	CloseHandle(hMutex);
}

///////////////////////////////////


CMyCriticalSection::CMyCriticalSection()
{
	memset(this, 0, sizeof(CMyCriticalSection));
}

CMyCriticalSection::CMyCriticalSection(CRITICAL_SECTION *lpcs)
{
	EnterCriticalSection(lpcs);
}

CMyCriticalSection::CMyCriticalSection(CMyCriticalSection &mycs)
{
	cs = *mycs.GetCS();

	EnterCriticalSection(&cs);
}

CMyCriticalSection::~CMyCriticalSection()
{
	if(bInited)
		LeaveCriticalSection(&cs);
}


BOOL CMyCriticalSection::Init()
{
	if(bInited == false)
	{
		InitializeCriticalSection(&cs);
		bInited = true;
		return TRUE;
	}else
	{
		return FALSE;
	}
}

void CMyCriticalSection::Destroy()
{
	if(bInited)
	{
		DeleteCriticalSection(&cs);
		bInited = false;
	}
}

void CMyCriticalSection::lock()
{
	EnterCriticalSection(&cs);
}

void CMyCriticalSection::unlock()
{
	LeaveCriticalSection(&cs);
}

//////////////

CCountLock::CCountLock()
{
	count = 0;
//	handle = CreateEvent(NULL, 1, 1, NULL);
}

CCountLock::~CCountLock()
{
	if(handle)
		CloseHandle(handle);
}

CCountLock::CCountLock(CCountLock &cl)
{

}
BOOL CCountLock::Init()
{
	count = 0;
	handle = CreateEvent(NULL, 1, 1, NULL);
	return handle != NULL;
}
/*

void CCountLock::Destroy()
{
}
*/

void CCountLock::Wait()
{
	DWORD ret = WaitForSingleObject(handle, INFINITE);
}

void CCountLock::add()
{
	InterlockedExchangeAdd(&count, 1);
	ResetEvent(handle);
}

void CCountLock::dec()
{
	if(InterlockedExchangeAdd(&count, -1) == 1)
		SetEvent(handle);
}


CZXCount::CZXCount(CCountLock &cl)
{
	pcl = &cl;
	pcl->add();
}

CZXCount::~CZXCount()
{
	pcl->dec();
}