// _link.h: interface for the _link class.
//ѭ��������ջ���ж� ģ����
//����: LZX
//////////////////////////////////////////////////////////////////////

#if !defined(AFX__LINK_H__496FD3BC_76DC_4610_86D5_411D485E1FB2__INCLUDED_)
#define AFX__LINK_H__496FD3BC_76DC_4610_86D5_411D485E1FB2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include <windows.h>

#if (_MSC_VER >= 1300)

#include <iostream>

using namespace std;

#else

#include <iostream.h>

#endif


template<typename T>
struct _Node		//�ڵ�ṹ
{
	_Node<T> *Prev;
	_Node<T> *Next;
	T data;
};

template<typename T>
class LINKTABLE		//������
{
public:
	LINKTABLE();
	~LINKTABLE();

	int Add(T data);
	int Delp(_Node<T> *pNode);
	int GetCount();
	int List(int n);
	void Swap(_Node<T> *X, _Node<T> *Y);
	void RemoveAll();

protected:
	int Count;
	_Node<T> *Head;
	_Node<T> *Tail;

private:
	int Insert(_Node<T> *p, _Node<T> *data);
	int InsertHead(_Node<T> *data);
	int InsertTail(_Node<T> *data);
};
///////////////////////////////////


template<typename T>
inline LINKTABLE<T>::LINKTABLE()
{
	Count = 0;
	Head = NULL;
	Tail = NULL;
}

template<typename T>
inline LINKTABLE<T>::~LINKTABLE()
{
	RemoveAll();
}

template<typename T>
inline void LINKTABLE<T>::Swap(_Node<T> *X, _Node<T> *Y)
{
	if(X==Y) return;
	T tmp;
	bool f;
	tmp = X->data;
	f = X->flag;
	X->data = Y->data;
	X->flag = Y->flag;
	Y->data = tmp;
	Y->flag = f;
}

template<typename T>
inline int LINKTABLE<T>::GetCount()
{
	return Count;
}

template<typename T>
inline int LINKTABLE<T>::Add(T data)
{
	_Node<T> *tmp = new _Node<T>;
	if(tmp == NULL)
		return false;
	ZeroMemory(tmp, sizeof(_Node<T>));
	if(Count == 0){
		Head = tmp;
		Tail = tmp;
	}
	tmp->data = data;

	Tail->Next = tmp;
	tmp->Prev = Tail;
	tmp->Next = Head;
	Head->Prev = tmp;
	Tail = tmp;
	return ++Count;
}

template<typename T>
inline int LINKTABLE<T>::Delp(_Node<T> *pNode)
{
	if(Count == 0)
		return 0;
	_Node<T> *tmp = pNode;
	pNode->Prev->Next = pNode->Next;
	pNode->Next->Prev = pNode->Prev;
	if(pNode == Head)
		Head = Head->Next;
	else if(pNode == Tail)
		Tail = Tail->Prev;
	delete tmp;
	return --Count;
}

template<typename T>
inline int LINKTABLE<T>::List(int n)
{
	if(Count == 0)
		return 0;
	_Node<T> *ls = Head;
	int c = 0;
	do{
		c++;
		cout << ls->data << " ";
		if(c%n == 0)
			cout << endl;
		ls = ls->Next;
	}while(ls != Head);
	return Count;
}

template<typename T>
inline void LINKTABLE<T>::RemoveAll()
{
	if(Count == 0)
		return;
	_Node<T> *tmp;
	for(int i=0; i<Count; i++)
	{
		tmp = Head->Next;
		delete Head;
		Head = tmp;
	}
	Count = 0;
}

template<typename T>
inline int LINKTABLE<T>::Insert(_Node<T> *p, _Node<T> *data)
{
	data->Next = p->Next;
	data->Prev = p;
	p->Next = data;
	return ++Count;
}

template<typename T>
inline int LINKTABLE<T>::InsertHead(_Node<T> *data)
{
	Insert(Head, data);
	Head = data;
	return ++Count;
}

template<typename T>
inline int LINKTABLE<T>::InsertTail(_Node<T> *data)
{
	Insert(Tail, data);
	Tail = data;
	return ++Count;
}

///////////////////////////////////

template<typename T>
class STACK: public LINKTABLE<T>	  //��ջ�࣬�̳���������
{
public:
	T Peek();
	T Pop();
	bool IsEmpty();
	int GetCount();
	int Push(T data);
};
///////////////////////////////////

template<typename T>
inline T STACK<T>::Peek()
{
	T tmp = Tail->data;
	return tmp;
}

template<typename T>
inline T STACK<T>::Pop()
{
	T tmp = Tail->data;
	Delp(Tail);
	return tmp;
}

template<typename T>
inline int STACK<T>::Push(T data)
{
	return Add(data);
}

template<typename T>
inline bool STACK<T>::IsEmpty()
{
	return Count == 0;
}

template<typename T>
inline int STACK<T>::GetCount()
{
	return Count;
}

///////////////////////////////////

///////////////////////////////////
template<typename T>
class QUEUE: public LINKTABLE<T>	  //�����࣬�̳���������
{
public:
	T DeQueue();
	T Peek();
	bool IsEmpty();
	int EnQueue(T data);
	int GetCount();

};

///////////////////////////////////
template<typename T>
inline T QUEUE<T>::Peek()
{
	T tmp = Head->data;
	return tmp;
}

template<typename T>
inline T QUEUE<T>::DeQueue()
{
	T tmp = Head->data;
	Delp(Head);
	return tmp;
}

template<typename T>
inline int QUEUE<T>::EnQueue(T data)
{
	return Add(data);
}

template<typename T>
inline bool QUEUE<T>::IsEmpty()
{
	return Count == 0;
}

template<typename T>
inline int QUEUE<T>::GetCount()
{
	return Count;
}

///////////////////////////////////

#endif // !defined(AFX__LINK_H__496FD3BC_76DC_4610_86D5_411D485E1FB2__INCLUDED_)
