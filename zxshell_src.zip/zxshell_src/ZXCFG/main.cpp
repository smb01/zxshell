#include "main.h"
#include "resource.h"
#include "..\zxsCommon\CRC32Class\CRC32.h"
#include "..\zxsCommon\Md5Class\Md5A.h"

//#include "SkinMagicLib.h"
//#pragma comment(lib, "SkinMagicTrial.lib")
//#define _useSkinMagic

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "shlwapi.lib")
#pragma comment(lib, "Dbghelp.lib")


MAIN Main;
char Temp[8192];
char FilePath[MAX_PATH];

char cfg_dllName[50];
char cfg_szIP[100];
int cfg_Port;
DWORD cfg_passwdCRC32;
BOOL cfg_AutoDel = TRUE;

int CALLBACK MainDlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

void err_display(char *msg)
{
	LPVOID lpMsgBuf;
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER|
		FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, GetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	int n = sprintf(Temp, "%s%s", msg, (LPCTSTR)lpMsgBuf);
	LocalFree(lpMsgBuf);
}

int Startup()
{
	INITCOMMONCONTROLSEX iccs;
	iccs.dwSize = sizeof(INITCOMMONCONTROLSEX);
	iccs.dwICC = ICC_ANIMATE_CLASS | ICC_BAR_CLASSES | ICC_COOL_CLASSES | ICC_DATE_CLASSES | ICC_HOTKEY_CLASS | ICC_INTERNET_CLASSES | ICC_LISTVIEW_CLASSES | ICC_PAGESCROLLER_CLASS | ICC_PROGRESS_CLASS | ICC_TAB_CLASSES | ICC_TREEVIEW_CLASSES | ICC_UPDOWN_CLASS | ICC_USEREX_CLASSES;

	if (!InitCommonControlsEx(&iccs))
		return false;

	Main.hWnd = CreateDialog(Main.hInst, MAKEINTRESOURCE(IDD_MAIN_DLG), NULL, MainDlgProc);

	if(!Main.hWnd)
		return false;

	SendDlgItemMessage(Main.hWnd, IDC_AUTODEL, BM_CLICK, 0, 0);
	SetDlgItemText(Main.hWnd, IDC_PORT, "1985");
	SetDlgItemText(Main.hWnd, IDC_URL, "www.xxx.com");
	
	SetFocus(GetDlgItem(Main.hWnd, IDC_CFGFILE));

#if defined _useSkinMagic
	//SkinMagic
	InitSkinMagicLib( Main.hInst, "Demo" , 
					  NULL,
					  NULL );
	LoadSkinFile("skin\\x-plus.smf"); 
	SetDialogSkin( "Dialog" );

	SetWindowSkin( Main.hWnd , "MainFrame" );
#endif

	return true;
}

char *DelSpace(char *szData)
{
	int i=0 ;
	while(1)
	{
		if(!strncmp(szData+i," ",1))
			i++;
		else 
			break;
	}
	return (szData+i);
}

void Cleanup()
{
}

char *GetStringFromEdit(HWND hWnd, UINT uEdit, char *RetBuf, int bufsize)
{
	if(GetDlgItemText(hWnd, uEdit, RetBuf, bufsize))
		return RetBuf;
	else
		return "";
}

int GetIntFromEdit(HWND hWnd, UINT uEdit)
{
	return GetDlgItemInt(hWnd, uEdit, NULL, FALSE);
}

BOOL SetDirPath(HWND hWnd, UINT uEdit, BOOL FileOrDir, char *RetPath)
{
	char PathBuf[MAX_PATH];
	BROWSEINFO bi;
	ZeroMemory(&bi, sizeof(BROWSEINFO));
	bi.hwndOwner = hWnd;
	bi.lpszTitle = FileOrDir ? "ѡ��Ŀ���ļ�." : "ѡ��Ŀ��Ŀ¼.";
	bi.ulFlags = BIF_DONTGOBELOWDOMAIN;
	bi.ulFlags |= FileOrDir ? BIF_BROWSEINCLUDEFILES : (BIF_RETURNONLYFSDIRS|BIF_NEWDIALOGSTYLE);
	ITEMIDLIST * pidl = SHBrowseForFolder(&bi);
	if (pidl)
	{
		SHGetPathFromIDList(pidl, PathBuf);
		SetDlgItemText(hWnd, uEdit, PathBuf);
		if(RetPath)
			strcpy(RetPath, PathBuf);
		return 1;
	}
	return 0;
}

bool GetDLLFileExports(LPCTSTR lpMemFile, char *FunctionName, DWORD *pFunOffSet)
{

    PIMAGE_DOS_HEADER pImg_DOS_Header;
    PIMAGE_NT_HEADERS pImg_NT_Header;
    PIMAGE_EXPORT_DIRECTORY pImg_Export_Dir;


    pImg_DOS_Header = (PIMAGE_DOS_HEADER)lpMemFile;
    pImg_NT_Header = (PIMAGE_NT_HEADERS)(
            (LONG)pImg_DOS_Header + (LONG)pImg_DOS_Header->e_lfanew);

    if(IsBadReadPtr(pImg_NT_Header, sizeof(IMAGE_NT_HEADERS))
            || pImg_NT_Header->Signature != IMAGE_NT_SIGNATURE)
    {
		return false;
    }

    pImg_Export_Dir = (PIMAGE_EXPORT_DIRECTORY)pImg_NT_Header->OptionalHeader
            .DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress;
    if(!pImg_Export_Dir)
    {
		return false;
    }
    // 63 63 72 75 6E 2E 63 6F 6D
    pImg_Export_Dir= (PIMAGE_EXPORT_DIRECTORY)ImageRvaToVa(pImg_NT_Header,
            pImg_DOS_Header, (DWORD)pImg_Export_Dir, 0);

    DWORD **ppdwNames = (DWORD **)pImg_Export_Dir->AddressOfNames;
	WORD **ppOrd = (WORD **)pImg_Export_Dir->AddressOfNameOrdinals;
	DWORD **dwAddr = (DWORD **)pImg_Export_Dir->AddressOfFunctions;

    ppdwNames = (PDWORD*)ImageRvaToVa(pImg_NT_Header,
            pImg_DOS_Header, (DWORD)ppdwNames, 0);
    ppOrd = (PWORD*)ImageRvaToVa(pImg_NT_Header,
            pImg_DOS_Header, (DWORD)ppOrd, 0);
    dwAddr = (PDWORD*)ImageRvaToVa(pImg_NT_Header,
            pImg_DOS_Header, (DWORD)dwAddr, 0);


    if(!ppdwNames || !ppOrd || !dwAddr)
    {
        return false;
    }
	UINT nCount = pImg_Export_Dir->NumberOfNames;
    for(UINT i=0; i < nCount; i++)
    {
        char *szFunc=(PSTR)ImageRvaToVa(pImg_NT_Header, pImg_DOS_Header, (DWORD)*ppdwNames, 0);

        if(strcmp(FunctionName, szFunc) == 0)
		{
			i = ((WORD*)ppOrd)[i]; 
			*pFunOffSet = ((DWORD*)dwAddr)[i];
			return true;
		}
        ppdwNames++;
    }

    return false;
}

void DoXOR(DWORD key, char *data, int len)
{
	while(len--)
		*(data++) ^= key;
}

bool GetConfigInfo()
{
	HANDLE hFile;
	HANDLE hFileMapping;
	LPVOID lpFileBase;

	hFile = CreateFile(FilePath, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE,
			NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		return false;
	}

	hFileMapping = CreateFileMapping(hFile, NULL, PAGE_READONLY, 0, 0, NULL);
	if(hFileMapping == 0)
	{
		CloseHandle(hFile);
		return false;
	}

	lpFileBase = MapViewOfFile(hFileMapping, FILE_MAP_READ, 0, 0, 0);
	if(lpFileBase == 0)
	{
		CloseHandle(hFileMapping);
		CloseHandle(hFile);
		return false;
	}
	///////////
	char *pFun_szIP, *pFun_dllName;
	int *pFun_Port;
	BOOL *pFun_AutoDel;
	DWORD szIPoffset, Portoffset, AutoDeloffset, dllNameoffset;

	if(!GetDLLFileExports((LPCTSTR)lpFileBase, "szIP", &szIPoffset))
	{
		sprintf(Temp, "ѡ����ļ�����ȷ��");
		goto error;
	}
	if(!GetDLLFileExports((LPCTSTR)lpFileBase, "Port", &Portoffset))
	{
		sprintf(Temp, "ѡ����ļ�����ȷ��");
		goto error;
	}
	if(!GetDLLFileExports((LPCTSTR)lpFileBase, "AutoDel", &AutoDeloffset))
	{
		sprintf(Temp, "ѡ����ļ�����ȷ��");
		goto error;
	}
	if(!GetDLLFileExports((LPCTSTR)lpFileBase, "dllName", &dllNameoffset))
	{
		sprintf(Temp, "ѡ����ļ�����ȷ��");
		goto error;
	}

	pFun_szIP = (char*)((BYTE*)lpFileBase + szIPoffset);
	pFun_dllName = (char*)((BYTE*)lpFileBase + dllNameoffset);
	pFun_Port = (int*)((BYTE*)lpFileBase + Portoffset);
	pFun_AutoDel = (BOOL*)((BYTE*)lpFileBase + AutoDeloffset);

	sprintf(Temp, "%d", *pFun_Port);
	SetDlgItemText(Main.hWnd, IDC_PORT, Temp);
	sprintf(Temp, "%s", pFun_szIP);
	DoXOR(0x1985, Temp, 99);

	SetDlgItemText(Main.hWnd, IDC_URL, Temp);

	sprintf(Temp, "%s", DelSpace(pFun_dllName));

	SetDlgItemText(Main.hWnd, IDC_DLLNAME, Temp);

	while((BST_CHECKED == IsDlgButtonChecked(Main.hWnd, IDC_AUTODEL)) != (*pFun_AutoDel!=0))
	{
		SendDlgItemMessage(Main.hWnd, IDC_AUTODEL, BM_CLICK, 0, 0);
	}


	UnmapViewOfFile(lpFileBase);
	CloseHandle(hFileMapping);
	CloseHandle(hFile);
	return true;
error:
	UnmapViewOfFile(lpFileBase);
	CloseHandle(hFileMapping);
	CloseHandle(hFile);
	return false;
}

bool ModifyFile()
{
	HANDLE hFile;
	HANDLE hFileMapping;
	LPVOID lpFileBase;

	hFile = CreateFile(FilePath, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE,
			NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		err_display("");
		return false;
	}

	hFileMapping = CreateFileMapping(hFile, NULL, PAGE_READWRITE, 0, 0, NULL);
	if(hFileMapping == 0)
	{
		err_display("");
		CloseHandle(hFile);
		return false;
	}

	lpFileBase = MapViewOfFile(hFileMapping, FILE_MAP_READ|FILE_MAP_WRITE, 0, 0, 0);
	if(lpFileBase == 0)
	{
		err_display("");
		CloseHandle(hFileMapping);
		CloseHandle(hFile);
		return false;
	}
	///////////
	char *pFun_szIP, *pFun_dllName;
	int *pFun_Port;
	BOOL *pFun_AutoDel;
	DWORD *pFun_vPasswd;
	DWORD szIPoffset, Portoffset, AutoDeloffset, dllNameoffset, vpasswdoffset;

	if(!GetDLLFileExports((LPCTSTR)lpFileBase, "szIP", &szIPoffset))
	{
		sprintf(Temp, "ѡ����ļ�����ȷ��");
		goto error;
	}
	if(!GetDLLFileExports((LPCTSTR)lpFileBase, "Port", &Portoffset))
	{
		sprintf(Temp, "ѡ����ļ�����ȷ��");
		goto error;
	}
	if(!GetDLLFileExports((LPCTSTR)lpFileBase, "AutoDel", &AutoDeloffset))
	{
		sprintf(Temp, "ѡ����ļ�����ȷ��");
		goto error;
	}
	if(!GetDLLFileExports((LPCTSTR)lpFileBase, "dllName", &dllNameoffset))
	{
		sprintf(Temp, "ѡ����ļ�����ȷ��");
		goto error;
	}
	if(!GetDLLFileExports((LPCTSTR)lpFileBase, "vPasswd", &vpasswdoffset))
	{
		sprintf(Temp, "ѡ����ļ�����ȷ��");
		goto error;
	}

	pFun_szIP = (char*)((BYTE*)lpFileBase + szIPoffset);
	pFun_dllName = (char*)((BYTE*)lpFileBase + dllNameoffset);
	pFun_Port = (int*)((BYTE*)lpFileBase + Portoffset);
	pFun_AutoDel = (BOOL*)((BYTE*)lpFileBase + AutoDeloffset);
	pFun_vPasswd = (DWORD*)((BYTE*)lpFileBase + vpasswdoffset);

	strcpy(pFun_szIP, cfg_szIP);
	strcpy(pFun_dllName, DelSpace(cfg_dllName));
	*pFun_Port = cfg_Port;
	*pFun_AutoDel = cfg_AutoDel;
	*pFun_vPasswd = cfg_passwdCRC32;

	UnmapViewOfFile(lpFileBase);
	CloseHandle(hFileMapping);
	CloseHandle(hFile);
	return true;
error:
	UnmapViewOfFile(lpFileBase);
	CloseHandle(hFileMapping);
	CloseHandle(hFile);
	return false;
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR lpCmd, int nShow)
{
	Main.hInst = hInst;

	if(!Startup())
		return 0;

	ShowWindow(Main.hWnd, nShow);


	MSG msg;
	while(GetMessage(&msg, NULL, 0, 0))
	{
		if(!IsDialogMessage(Main.hWnd, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	Cleanup();
	return msg.wParam;
}

void GetDropFile(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	char szFile[MAX_PATH];

	if(!DragQueryFile((HDROP)wParam, 0, szFile, sizeof(szFile)))
		return;

	SendMessage(GetDlgItem(Main.hWnd, IDC_CFGFILE), WM_SETTEXT, 0, (WPARAM)szFile);

	strcpy(FilePath, szFile);
	GetConfigInfo();

	return;
}

int CALLBACK MainDlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    RECT rcClient; 
    int i; 
 
	switch(uMsg)
	{
	case WM_INITDIALOG:

		//����Dialog�����ô������Ͻ�ͼ��
		SetClassLong(hWnd, GCL_HICON, (LONG)LoadIcon(Main.hInst, MAKEINTRESOURCE(IDI_ICON1)));

 		return TRUE;
	case WM_DROPFILES:
		GetDropFile(hWnd, uMsg, wParam, lParam);
		break;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{

		case IDC_AUTODEL:
			if(BST_CHECKED == IsDlgButtonChecked(hWnd, IDC_AUTODEL))
				cfg_AutoDel = TRUE;
			else
				cfg_AutoDel = FALSE;
			break;
		case IDC_FILEPATH:
			SetDirPath(hWnd, IDC_CFGFILE, 1, FilePath);
			GetConfigInfo();
			break;
		case IDOK:
			{
				CRC32 crc32;
				CMd5A Md5Pass;

				cfg_Port = GetIntFromEdit(hWnd, IDC_PORT);
				GetStringFromEdit(hWnd, IDC_URL, cfg_szIP, sizeof(cfg_szIP));
				GetStringFromEdit(hWnd, IDC_CFGFILE, FilePath, sizeof(FilePath));
				GetStringFromEdit(hWnd, IDC_DLLNAME, cfg_dllName, sizeof(FilePath));
				cfg_dllName[sizeof(FilePath)-1] = '\0';
				GetStringFromEdit(hWnd, IDC_PASSWD, Temp, sizeof(Temp));
				Md5Pass.MDString(Temp, Temp);
				cfg_passwdCRC32 = crc32.GetCrc32((BYTE*)Temp, strlen(Temp)+1);

				if(!strlen(FilePath))
				{
					MessageBox(hWnd, "��ѡ������õ��ļ�.", "ZXCFG", MB_ICONERROR);
					break;
				}
				if(!cfg_Port)
				{
					MessageBox(hWnd, "������˿�.", "ZXCFG", MB_ICONERROR);
					break;
				}
				if(!strlen(cfg_szIP))
				{
					MessageBox(hWnd, "����������.", "ZXCFG", MB_ICONERROR);
					break;
				}
				DoXOR(0x1985, cfg_szIP, 99);

				if(ModifyFile())
					MessageBox(hWnd, "���óɹ�.", "ZXCFG", MB_ICONINFORMATION);
				else
					MessageBox(hWnd, Temp, "ZXCFG", MB_ICONERROR);

			}

			break;
		case IDCANCEL:
			PostQuitMessage(0);
			break;
		}
		break;

	
	}

	return FALSE;
}
