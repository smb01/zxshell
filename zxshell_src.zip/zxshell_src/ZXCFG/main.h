#ifndef _MAIN_H
#define _MAIN_H

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <memory.h>
#include <commctrl.h>
#include <shlobj.h>
#include <Dbghelp.h>
#include <shellapi.h>
struct MAIN
{
	HINSTANCE hInst;
	HWND hWnd;
};

#endif
