//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by _resource.rc
//
#define IDD_MAIN_DLG                    101
#define IDI_ICON1                       104
#define IDR_WAVE_IN                     106
#define IDR_WAVE_OUT                    107
#define IDR_SHELLMAIN                   116
#define IDI_ICON2                       119
#define IDI_ICON3                       125
#define IDI_ICON4                       127
#define IDC_ONLINE                      1000
#define IDC_RESULT                      1001
#define IDC_PORT                        1005
#define IDC_STOP                        1007
#define IDC_START                       1008
#define IDC_QUIT                        1009
#define IDC_CMD                         1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
