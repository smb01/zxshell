#if !defined _SWITCHDESKTOP
#define _SWITCHDESKTOP

#include <windows.h>
#include "RunAs.h"


BOOL CALLBACK KillScreenSaverFunc(HWND hwnd, LPARAM lParam);
void KillScreenSaver();
BOOL SelectHDESK(HDESK new_desktop);
BOOL _SelectDesktop(char *name);
BOOL SelectDesktop(char *name);
BOOL _InputDesktopSelected();
BOOL InputDesktopSelected();
BOOL ChangeServiceDesktop(char *deskname);
void *SimulateCtrlAltDelThreadFn(void *context);

typedef DWORD (WINAPI* pWTSGetActiveConsoleSessionId)(void);
typedef BOOL (WINAPI* pWTSQueryUserToken)(ULONG SessionId, PHANDLE phToken);


extern pWTSGetActiveConsoleSessionId WTSGetActiveConsoleSessionId;
extern pWTSQueryUserToken _WTSQueryUserToken;


class CSelectSession
{
public:
	CSelectSession();

	DWORD GetMySessionId();
	DWORD GetActiveSessionId();


};

class CSelectDesktop
{
protected:

	DWORD prevTime, currTime;
	DWORD sysPID;
public:
	CSelectDesktop();
	int select(DWORD interval);

	static BOOL SelectSession(DWORD SessionId);

};


#endif