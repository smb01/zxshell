void AR(SOCKET Socket)
{
	char   RegInfo[MAX_PATH];
	HKEY   hKey;
	HKEY   MainKey = HKEY_LOCAL_MACHINE;
	LPCTSTR SubKey[] =
	{
	    "SOFTWARE\\Classes\\txtfile\\shell\\open\\command", 
        "SOFTWARE\\Classes\\inifile\\shell\\open\\command", 
        "SOFTWARE\\Classes\\inffile\\shell\\open\\command", 
        "SOFTWARE\\Classes\\exefile\\shell\\open\\command", 
        "SOFTWARE\\Classes\\*\\shell",
		"SOFTWARE\\Classes\\*",
	}; 
	 
	char *FileType[4] =
	{
		"TXT",
		"INI",
		"INF",
		"EXE",
	};
    
    char *RegData[5] =
	{    
		"%SystemRoot%\\System32\\NOTEPAD.EXE %1",
        "%SystemRoot%\\System32\\NOTEPAD.EXE %1",
		"%SystemRoot%\\System32\\NOTEPAD.EXE %1",      
		"\"%1\" %*",
		"Shell",
	};
    
	char *WriteData[4] =
	{  
		"Notepad.exe %1",
		"Notepad.exe %1",
		"Notepad.exe %1",
		"\"%1\" %*",
	};

	for(int i=0;i<4;i++)
	{
		memset(RegInfo,0,MAX_PATH);
		if(!ReadReg(MainKey,SubKey[i],NULL,RegInfo, sizeof(RegInfo)))
		{
			SendMessage(Socket, "Fail To Read The %s Association Setting\r\n",FileType[i]);
		    continue ;
		}
		if(!(stricmp(RegInfo,RegData[i])&&stricmp(RegInfo,WriteData[i])))
			SendMessage(Socket, "No Need To Change The %s Association Setting\r\n",FileType[i]);
		else
		{   
			int s = WriteReg(MainKey,SubKey[i],NULL,REG_SZ,WriteData[i], NULL,1);
			if(s)
				SendMessage(Socket, "%s Assiciation: %s -> %s\r\n",FileType[i],RegInfo,WriteData[i]);
			else
				SendMessage(Socket, "Fail To ReSet %s Assiciation\r\n",FileType[i]);			
		}
	}
	if(RegOpenKey(MainKey,SubKey[4],&hKey) == ERROR_SUCCESS)
	{
		SendMessage(Socket, "Probably Some Trojan Makes Use Of This Key To Hide,Deleting Is In Process.....\r\n");
		RegCloseKey(hKey);	
		if(RegOpenKey(MainKey,SubKey[5],&hKey) == ERROR_SUCCESS)
		{
             if(RegDeleteKey(hKey,RegData[4]) == ERROR_SUCCESS)
				 SendMessage(Socket, "Bingo.The Key Is Successfully Deleted\r\n");
		}
		else
			err_display(Socket, "RegOpenKey", 1);
	}
    else
		SendMessage(Socket, "No Trojan Makes Use Of This Key\r\n");

}