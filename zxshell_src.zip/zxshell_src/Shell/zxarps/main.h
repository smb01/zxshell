#if !defined _ZXARPS_MAIN

#define _ZXARPS_MAIN

#include "ARPSpoof.h"

extern CARPSpoof *pZXARPS;


int ZXARPS(MainPara *args);




#endif