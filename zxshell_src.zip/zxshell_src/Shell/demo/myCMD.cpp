#include<iostream.h>
#include <assert.h>
#include <WINSOCK2.H>
#include <string.h>
#include<windows.h>

#include<stdio.h>
#pragma comment(lib,"Ws2_32.lib")

#define BUFSIZE 8192

HANDLE hCONIN, hCONOUT, hCmd;

void DoExecute(char *Cmd)
{
	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	memset(&si,0,sizeof(si));

	si.cb = sizeof(si);
	si.dwFlags = STARTF_USESHOWWINDOW|STARTF_USESTDHANDLES;
	si.hStdInput = hCONIN;
	si.hStdOutput = si.hStdError = hCONOUT;
	si.wShowWindow=SW_SHOW;//
	si.lpDesktop = "winsta0\\default";

	if(CreateProcess(NULL,Cmd,NULL,NULL,TRUE,0,0,NULL,&si,&pi))
	{
		hCmd = pi.hProcess;
		return;
	}else
	{
		DWORD err = GetLastError();
	}
}

VOID main(VOID) 
{ 
   CHAR chBuf[BUFSIZE]; 
   DWORD dwRead, dwWritten; 
   HANDLE hStdin, hStdout; 
   BOOL fSuccess; 
 
   hStdout = GetStdHandle(STD_OUTPUT_HANDLE); 
   hStdin = GetStdHandle(STD_INPUT_HANDLE); 
   if ((hStdout == INVALID_HANDLE_VALUE) || 
      (hStdin == INVALID_HANDLE_VALUE)) 
      ExitProcess(1); 
 
	SECURITY_ATTRIBUTES SecuAttr;
	SecuAttr.nLength = sizeof(SECURITY_ATTRIBUTES);
	SecuAttr.lpSecurityDescriptor = NULL;
	SecuAttr.bInheritHandle = TRUE;

	SetHandleInformation(hStdin, 1, 0);
	SetHandleInformation(hStdout, 1, 0);

	hCONIN = CreateFile("conin$", GENERIC_READ | GENERIC_WRITE,FILE_SHARE_READ, 
		&SecuAttr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,0);
	hCONOUT = CreateFile("conout$", GENERIC_READ | GENERIC_WRITE,FILE_SHARE_WRITE, 
		&SecuAttr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,0);

   
   DoExecute("cmd");
   //WaitForSingleObject(hCmd, -1);

   for (;;) 
   { 
   // Read from standard input. 
      fSuccess = ReadFile(hCONIN, chBuf, BUFSIZE, &dwRead, NULL); 
      if (! fSuccess || dwRead == 0) 
         break; 
 
   // Write to standard output. 
      fSuccess = WriteFile(hCONOUT, chBuf, dwRead, &dwWritten, NULL); 
      if (! fSuccess) 
         break; 
   } 
	TerminateProcess(hCmd, 0);
}