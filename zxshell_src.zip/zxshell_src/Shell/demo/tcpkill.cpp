//********************************************************************** 
// Version: V1.0 
// Coder: WinEggDrop 
// Date Release: NULL 
// Purpose: Kill An Active TCP Connection 
// Test PlatForm: Win 2K Pro And Server SP4 
// Compiled On: LCC 3.0,May Compile On VC++ 6.0(Not Test Yet) 
//********************************************************************** 

#include <winsock.h> 
#include <windows.h> 
#include <stdio.h> 
#include <iphlpapi.h> 

// Function ProtoType Declaration 
//--------------------------------------------------------------------------------------------------------------------------- 
BOOL KillTCPConnection(const char *LocalAddress,const char *LocalPort,const char *RemoteAddress,const char *RemotePort); 
BOOL IsDigits(const char *String); 
void Usage(const char *Command); 
//--------------------------------------------------------------------------------------------------------------------------- 
// End Of Fucntion ProtoType Declaration 

// Main Function 
int main(int argc,char *argv[]) 
{ 
if (argc!=5)     // There Are Not 5 Arguement In Total 
{ 
    Usage(argv[0]);     // Display The Usage 
    return -1;    // Quit The Program 
} 

KillTCPConnection(argv[1],argv[2],argv[3],argv[4]);     // Kill The TCP Connection 
return 0;     // Quit The Program 
}// End Of Main Function 

//------------------------------------------------------------------------- 
// Purpose: To Display The Usage Of The Program 
// Return Type: Void 
// Parameters:  Const Char *Command 
//------------------------------------------------------------------------- 
void Usage(const char *Command) 
{ 
printf("\r\nUsage: %s LocalAddress LocalPort RemoteAddress,RemotePort\r\n",Command);     // Display The Usage 
printf("Example: %s 192.168.0.1 1234 12.12.12.12 22222\r\n",Command);     // Display A Example 
}// End Of Usage Function 

//------------------------------------------------------------------------- 
// Purpose: To Check Whether The String Is Really A Number 
// Return Type: Boolean 
// Parameters:  Const Char *String 
//------------------------------------------------------------------------- 
BOOL IsDigits(const char *String) 
{ 
int StringLength = strlen(String);    // Get The Length Of The String 

for (int i = 0;i < StringLength;i++)     // Check Every Character Of The String 
{ 
    if (String[i] < 48 || String[i] > 57)    // The Character Is Not A Digit 
    { 
       return FALSE;    // Return False 
    } 
} 
return TRUE;     // Return True As All Characters Are Digits 
}// End Of IsDigits Function 

//-------------------------------------------------------------------------------------------- 
// Purpose: To Kill An Active TCP Connection 
// Return Type: Boolean 
// Parameters: 
//            1.Const Char *LocalAddress  --> The Local Address Of The TCP Connection 
//            2.Const Char *LocalPort     --> The Local Port Of The TCP Connection 
//            3.Const Char *RemoteAddress --> The Remote Address Of The TCP Connection 
//            4.Const Char *RemotePort    --> The Remote Port Of The TCP Connection 
//-------------------------------------------------------------------------------------------- 
BOOL KillTCPConnection(const char *LocalAddress,const char *LocalPort,const char *RemoteAddress,const char *RemotePort) 
{ 
MIB_TCPROW  TcpRow;    // Declare A TCP Raw 

if (!IsDigits(LocalPort))    // The Local Port Is Not A Number 
{ 
    printf("Invalid Local Port\r\n");     // Display Error Message 
    return FALSE;    // Return False 
} 

if (atoi(LocalPort) < 0 || atoi(LocalPort) > 65535)     // The Local Port Is Out Of Bound 
{ 
    printf("Local Port Out Of Bound\r\n");      // Display Error Message 
    return FALSE;    // Return False 
} 

if (!IsDigits(RemotePort))      // The Remote Port Is Not A Number 
{ 
    printf("Invalid Remote Port\r\n");    // Display Error Message 
    return FALSE;    // Return False 
} 

if (atoi(RemotePort) < 0 || atoi(RemotePort) > 65535)      // The Remote Port Is Out Of Bound 
{ 
    printf("Remote Port Out Of Bound\r\n");     // Display Error Message 
    return FALSE;    // Return False 
} 

// Set The TCP Row Entry 
TcpRow.dwLocalPort = htons(atoi(LocalPort)); 
TcpRow.dwRemotePort = htons(atoi(RemotePort)); 
TcpRow.dwLocalAddr = inet_addr(LocalAddress); 
TcpRow.dwRemoteAddr = inet_addr(RemoteAddress); 
TcpRow.dwState = MIB_TCP_STATE_DELETE_TCB;     // Flag To Indicate The System To End That TCP Connection 

if (SetTcpEntry(&TcpRow) == NO_ERROR)    // Call The API With No Error 
{ 
    printf("Delete The TCP Connection %s:%s-->%s:%s Successfully\r\n",LocalAddress,LocalPort,RemoteAddress,RemotePort);    // Display Successful Message 
    return TRUE;     // Return True 
} 

// Some Error Must Be Occurred 
printf("Fail To Delete The TCP Connection Error Code:%d\r\n",GetLastError());      // Display The Error Code 
return FALSE;    // Return False 
}// End Of KillTCPConnection Function 
// End Of File