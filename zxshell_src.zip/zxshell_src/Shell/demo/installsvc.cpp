#include <windows.h>
#include <stdio.h>
#include "Debug.h"

LONG SaveRegistrySubKey(
    HKEY hKey,              // handle of key to save
    LPTSTR szSubKey,        // pointer to subkey name to save
    LPTSTR szSaveFileName   // pointer to save path/filename
    )
{
    HKEY hKeyToSave;    // Handle of subkey to save
    LONG rc;            // result code from RegXxx
    DWORD dwDisposition;

	DebugPrivilege(SE_BACKUP_NAME,TRUE);

    if((rc=RegCreateKeyEx(hKey,
                          szSubKey, // Name of subkey to open
                          0,
                          NULL,
                          REG_OPTION_BACKUP_RESTORE, // in winnt.h
                          KEY_QUERY_VALUE, // minimal access
                          NULL,
                          &hKeyToSave,
                          &dwDisposition)
                          ) == ERROR_SUCCESS)
    {
        // Save registry subkey.  If the registry is remote, files will
        // be saved on the remote machine
        rc=RegSaveKey(hKeyToSave, szSaveFileName, NULL);
        // close registry key we just tried to save
        RegCloseKey(hKeyToSave);
    }

	DebugPrivilege(SE_BACKUP_NAME,FALSE);
    // return the last registry result code
    return rc;
}

LONG RestoreRegistrySubKey(
    HKEY hKey,              // handle of key to save
    LPTSTR szSubKey,        // pointer to subkey name to save
    LPTSTR szSaveFileName   // pointer to save path/filename
    )
{
    HKEY hKeyToRestore;    // Handle of subkey to save
    LONG rc;            // result code from RegXxx
    DWORD dwDisposition;

	DebugPrivilege(SE_RESTORE_NAME,TRUE);

    if((rc=RegCreateKeyEx(hKey,
                          szSubKey, // Name of subkey to open
                          0,
                          NULL,
                          REG_OPTION_BACKUP_RESTORE, // in winnt.h
                          KEY_WRITE|KEY_SET_VALUE, // minimal access
                          NULL,
                          &hKeyToRestore,
                          &dwDisposition)
                          ) == ERROR_SUCCESS)
    {

        rc=RegRestoreKey(hKeyToRestore, szSaveFileName, REG_FORCE_RESTORE);

        RegCloseKey(hKeyToRestore);
    }
	DebugPrivilege(SE_RESTORE_NAME,FALSE);

    return rc;
}

LONG AddSvcToNetsvcs(char *SvcName)
{
	LONG rc;
	HKEY hKey;
	DWORD Type = REG_MULTI_SZ;
	PBYTE Buffer;
	DWORD cbData = 0, nLen;
	rc = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
		"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SvcHost",
		0,
		KEY_READ|KEY_WRITE,
		&hKey);
	if(rc == ERROR_SUCCESS)
	{
		rc = RegQueryValueEx(hKey, "netsvcs", 0, &Type, 0, &cbData);
		if(rc == ERROR_SUCCESS)
		{
			cbData += lstrlen(SvcName) + 1;
			nLen = cbData;
			Buffer = new BYTE [cbData];
			if(Buffer == NULL)
				return -1;
			memset(Buffer, 0, cbData);
			rc = RegQueryValueEx(hKey, "netsvcs", 0, &Type, Buffer, &cbData);
			if(rc == ERROR_SUCCESS)
			{
				strcpy((char *)Buffer+cbData-1, SvcName);
				rc = RegSetValueEx(hKey, "netsvcs", 0, Type, Buffer, nLen);
				if(rc == ERROR_SUCCESS)
				{
					printf("%s\r\n", "OK");
					RegCloseKey(hKey);
					return 0;
				}
			}
		}
	}
	return rc;
}

LONG AddNewNetsvcGroup(char *Group, char *SvcName)
{
	LONG rc;
	HKEY hKey;
	DWORD Type = REG_MULTI_SZ;
	DWORD cbData = lstrlen(SvcName);
	PBYTE Buffer = (PBYTE)SvcName;
	rc = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
		"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SvcHost",
		0,
		KEY_READ|KEY_WRITE,
		&hKey);
	if(rc == ERROR_SUCCESS)
	{

		rc = RegSetValueEx(hKey, Group, 0, Type, Buffer, cbData);
		if(rc == ERROR_SUCCESS)
		{
			printf("%s\r\n", "OK");
			RegCloseKey(hKey);
			return 0;
		}

	}
	return rc;
}

LONG DelNetsvcGroup(char *Group)
{
	LONG rc;
	HKEY hKey;
	DWORD Type = REG_MULTI_SZ;

	rc = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
		"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SvcHost",
		0,
		KEY_READ|KEY_WRITE,
		&hKey);
	if(rc == ERROR_SUCCESS)
	{

		rc = RegDeleteValue(hKey, Group);
		if(rc == ERROR_SUCCESS)
		{
			printf("%s\r\n", "OK");
			RegCloseKey(hKey);
			return 0;
		}

	}
	return rc;
}

LONG SetNetsvcParameters(char *SvcName, char *szData)
{
	LONG rc;
	HKEY hKey;
	DWORD dwDisposition;
	DWORD Type = REG_EXPAND_SZ;
	char svcPath[MAX_PATH];
	sprintf(svcPath, "SYSTEM\\CurrentControlSet\\Services\\%s\\Parameters", SvcName);
	rc = RegCreateKeyEx(HKEY_LOCAL_MACHINE,
                          svcPath, // Name of subkey to open
                          0,
                          NULL,
                          0,
                          KEY_WRITE|KEY_SET_VALUE, // minimal access
                          NULL,
                          &hKey,
                          &dwDisposition
                          );
	if(rc == ERROR_SUCCESS)
	{

		rc = RegSetValueEx(hKey, "ServiceDll", 0, Type, (PBYTE)szData, lstrlen(szData));
		if(rc != ERROR_SUCCESS)
		{
			return rc;
		}
		Type = REG_DWORD;
		rc = true;
		rc = RegSetValueEx(hKey, "ServiceDllUnloadOnStop", 0, Type, (PBYTE)&rc, sizeof(DWORD));
		if(rc != ERROR_SUCCESS)
		{
			return rc;
		}
		printf("SetNetsvcParameters %s\r\n", "OK");
		return 0;
	}
	return rc;
}

LONG Install()
{

}

int main(int argc, char **argv)
{

	return 0;
}
