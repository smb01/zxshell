#include <windows.h>
#include <stdio.h>
#include <tlhelp32.h>
#include <shlwapi.h>
#pragma comment (lib,"Advapi32.lib")
#pragma comment (lib,"shlwapi.lib")

//RemoteGetProcAddress by Metro_Mystery/Subsky

LPVOID RemoteGetProcAddress(HANDLE hProcess, DWORD dwPid, LPCSTR szModuleName, LPCSTR szFuncName)
{
    HANDLE hModsSnap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, dwPid);

    if(INVALID_HANDLE_VALUE == hModsSnap)
    {
        return NULL;
    }

    MODULEENTRY32 meModuleEntry;
    meModuleEntry.dwSize = sizeof(MODULEENTRY32);

    if(!Module32First(hModsSnap, &meModuleEntry))
    {
        CloseHandle(hModsSnap);
        return NULL;
    }

    do
    {
        PathStripPath(meModuleEntry.szExePath);

        if(0 == stricmp(meModuleEntry.szExePath, szModuleName))
        {
            DWORD dwImageBase = (DWORD)meModuleEntry.hModule;

            IMAGE_DOS_HEADER DosHeader;

            if(!ReadProcessMemory(hProcess, (LPVOID)dwImageBase, &DosHeader, 
                sizeof(DosHeader), NULL))
            {
                CloseHandle(hModsSnap);

                return NULL;
            }

            IMAGE_NT_HEADERS NTHeaders;

            if(!ReadProcessMemory(hProcess, (LPVOID)(dwImageBase + DosHeader.e_lfanew), &NTHeaders, 
                sizeof(NTHeaders), NULL))
            {
                CloseHandle(hModsSnap);

                return NULL;                    
            }

            IMAGE_DATA_DIRECTORY& expDir =
                NTHeaders.OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT];
            
            IMAGE_EXPORT_DIRECTORY ExpDir;

            if(!ReadProcessMemory(hProcess, (LPVOID)(dwImageBase + expDir.VirtualAddress), &ExpDir, 
                sizeof(ExpDir), NULL))
            {
                CloseHandle(hModsSnap);

                return NULL;                            
            }

            DWORD dwFuncName = 0;
            CHAR szExportFuncName[MAX_PATH];

            for (DWORD iName = 0; iName < ExpDir.NumberOfNames; iName++)
            {
                if(!ReadProcessMemory(hProcess, 
                    (PDWORD)((dwImageBase + (ExpDir.AddressOfNames)) + 
                    (iName * sizeof(ExpDir.AddressOfNames))), 
                    &dwFuncName, sizeof(DWORD), NULL))
                {
                    CloseHandle(hModsSnap);

                    return NULL;
                }

                if(!ReadProcessMemory(hProcess, (PDWORD)(dwImageBase + dwFuncName), 
                    szExportFuncName, sizeof(szExportFuncName), NULL))
                {
                    CloseHandle(hModsSnap);

                    return NULL;
                }

                if(0 == stricmp(szExportFuncName, szFuncName))
                {
                    DWORD dwFuncAddr;

                    if(!ReadProcessMemory(hProcess, 
                        (PDWORD)((dwImageBase + (ExpDir.AddressOfFunctions)) + 
                        (iName * sizeof(ExpDir.AddressOfFunctions))), 
                        &dwFuncAddr, sizeof(dwFuncAddr), NULL))
                    {
                        CloseHandle(hModsSnap);

                        return NULL;
                    }
                    else
                    {
                        CloseHandle(hModsSnap);

                        return (LPVOID)(dwFuncAddr + dwImageBase);
                    }
                }
            }
        }

    } while(Module32Next(hModsSnap, &meModuleEntry));

    CloseHandle(hModsSnap);

    return NULL;
}


int injectDll(DWORD pid, char *dll)
 
{
	PWSTR pszLibFileRemote = NULL;
	HANDLE hRemoteProcess = NULL,hRemoteThread = NULL;
	char CurPath[256];

	hRemoteProcess = OpenProcess(
		 PROCESS_QUERY_INFORMATION |   // Required by Alpha
         PROCESS_CREATE_THREAD     |   // For CreateRemoteThread
         PROCESS_VM_OPERATION      |   // For VirtualAllocEx/VirtualFreeEx
         PROCESS_VM_WRITE,             // For WriteProcessMemory
         FALSE, pid);

	if(hRemoteProcess == NULL)
	{
		printf("OpenProcess Error.\r\n");
		return 0;
	}

	//GetCurrentDirectory(256,CurPath);
	//strcat(CurPath,"\\");
	memset(CurPath, 0, sizeof(CurPath));
	strcat(CurPath, dll);

	int len = (strlen(CurPath)+1)*2;
	WCHAR wCurPath[256];
	MultiByteToWideChar(CP_ACP,0,CurPath,-1,wCurPath,256);

	pszLibFileRemote = (PWSTR) 
		VirtualAllocEx(hRemoteProcess, NULL, len, MEM_COMMIT, PAGE_READWRITE);

	if(!WriteProcessMemory(hRemoteProcess, pszLibFileRemote, 
		(PVOID) wCurPath, len, NULL))
	{
		printf("WriteProcessMemory Error.\r\n");
		CloseHandle(hRemoteProcess);
		return 0;
	}

	
	PTHREAD_START_ROUTINE pfnThreadRtn = (PTHREAD_START_ROUTINE)
         RemoteGetProcAddress(hRemoteProcess, pid, "Kernel32", "LoadLibraryW");

	if(!pfnThreadRtn)
	{
		printf("RemoteGetProcAddress Error.\r\n");
		CloseHandle(hRemoteProcess);
		return 0;
	}

	hRemoteThread = CreateRemoteThread(hRemoteProcess, NULL, 0, 
		pfnThreadRtn, pszLibFileRemote, 0, NULL);

	if(hRemoteThread)
	{
		CloseHandle(hRemoteThread);
	}

	CloseHandle(hRemoteProcess);
	return 0;
}

int main(int argc, char **argv)
{


	char *Usage = ""
		"Usage:\r\n"
		"    LoadDll <Pid> [DllName]\r\n"
		"Example:\r\n"
		"    LoadDll test.dll  (Load Dll in own process)\r\n"
		"    LoadDll 500 test.dll  (Inject test.dll to specified process)\r\n";

	if(argc < 2)
	{
		return 0;
	}
	if(argc == 2)
		LoadLibrary(argv[1]);
	else
		injectDll(atoi(argv[1]), argv[2]);
	return 1;
}