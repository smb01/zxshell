#include <winsock2.h>
#include <stdio.h>
#include <Mswsock.h>
#include "../link.h"
//#pragma comment(lib,"Mswsock.lib")

#pragma comment(lib,"ws2_32")

#define WM_SOCKET (WM_USER+1)

SOCKET ListenSock;
HWND hWnd;
int MaxThreadCount = 100;
long TotalCount = 0;
int GetCount = 0;
int g_TimeOut;
BOOL IsSaveToFile;
FILE *fPortScan;
char *SaveToFile = NULL;
char StrFormat[MAX_PATH] = "%s:%d";

CRITICAL_SECTION portscan_cs;

struct SCANINFO
{
	char *IP;
	char *Port;
};

struct TARGET
{
	DWORD dwIP;
	WORD wPort;
};

void OutPutResult(SOCKET s)
{
	EnterCriticalSection(&portscan_cs);

	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(clientaddr);

	if(getpeername(s, (SOCKADDR *)&clientaddr, &addrlen) == 0)
	{
		GetCount++;
		if(IsSaveToFile)
		{
			fPortScan = fopen(SaveToFile, "a+");
			if(fPortScan != NULL)
			{
				fprintf(fPortScan, StrFormat , inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port));
				fprintf(fPortScan, "\r\n");
				fclose(fPortScan);
			}
		}else
		{
			printf(StrFormat , inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port));
			printf("\r\n");
		}
	}

	LeaveCriticalSection(&portscan_cs);
}

const char *TakeOutStringByChar(IN const char *Source, OUT char *Dest, int buflen, char ch)
{
	if(Source == NULL)
		return NULL;

	const char *p = strchr(Source, ch);

	while(*Source == ' ')
		Source++;
	for(int i=0; i<buflen && *(Source+i) && *(Source+i) != ch; i++)
	{
		Dest[i] = *(Source+i);
	}
	if(i == 0)
		return NULL;
	else
		Dest[i] = '\0';

	const char *lpret = p ? p+1 : Source+i;

	while(Dest[i-1] == ' ' && i>0)
		Dest[i-- -1] = '\0';

	return lpret;
}


void ForceCloseSocket(SOCKET s)
{
	linger lg = {1, 0};
	WSAAsyncSelect(s, hWnd, 0, 0);
	setsockopt(s, SOL_SOCKET, SO_LINGER, (const char FAR *)&lg, sizeof(lg));
	closesocket(s);
}

BOOL GetdwIP(char *startip, char *endip, DWORD *IP_start, DWORD *IP_end)
{
	DWORD dwIP;

	dwIP = inet_addr(startip);
	if(dwIP == INADDR_NONE)
		return FALSE;

	*IP_start = ntohl(dwIP);

	dwIP = inet_addr(endip);
	if(dwIP == INADDR_NONE)
		return FALSE;

	*IP_end = ntohl(dwIP);

	if(*IP_start <= *IP_end)
		return TRUE;
	else
		return FALSE;
}


DWORD WINAPI Connecting(LPVOID lParam)
{
	InterlockedExchangeAdd(&TotalCount, 1);

	TARGET *Target = (TARGET*)lParam;
	struct sockaddr_in Server;
	memset(&Server, 0, sizeof(Server));

	Server.sin_family = AF_INET;
	Server.sin_port = htons(Target->wPort);
	Server.sin_addr.s_addr = Target->dwIP;

	SOCKET s;

	__try
	{
		// Create Socket
		s = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
		if (s == INVALID_SOCKET)
			__leave;

		int iMode = 1;//nonzero
		ioctlsocket(s, FIONBIO, (u_long FAR*) &iMode);//Enabled Nonblocking Mode

		struct timeval TimeOut;
		fd_set FdRead, FdWrite;
		FD_ZERO(&FdRead);
		FD_ZERO(&FdWrite);
		FD_SET(s,&FdRead);
		FD_SET(s,&FdWrite);

		TimeOut.tv_sec  = g_TimeOut;
		TimeOut.tv_usec = 0;

		connect(s, (const SOCKADDR *)&Server,sizeof(Server));

		if(select(0, &FdRead, &FdWrite, NULL, &TimeOut) <= 0)//���ó�ʱ
			__leave;

		//OK
		OutPutResult(s);

	}__finally
	{
		if(s != INVALID_SOCKET)
			ForceCloseSocket(s);

		InterlockedExchangeAdd(&TotalCount, -1);

		delete Target;
		return 0;
	}

}

DWORD WINAPI Scanning(LPVOID lParam)
{
	SCANINFO *scaninfo = (SCANINFO *)lParam;
	DWORD dwThreadId;
	HANDLE hThread;
	char szIP[MAX_PATH], szPort[MAX_PATH];
	char szIP_start[32], szIP_end[32]; 
	char szPort_start[10], szPort_end[10]; 

	const char *pNextIP = scaninfo->IP;
	const char *sNextIP;
	const char *pNextPort = scaninfo->Port;
	const char *sNextPort;

	DWORD dwip_start, dwip_end;
	WORD wPort_start, wPort_end;

	//get ip
	while(pNextIP = TakeOutStringByChar(pNextIP, szIP, sizeof(szIP), ','))
	{
		if(sNextIP = TakeOutStringByChar(szIP, szIP_start, sizeof(szIP_start), '-'))
		{
			if(TakeOutStringByChar(sNextIP, szIP_end, sizeof(szIP_end), '\0'))
			{
				//szIP_start, szIP_end
				if(!GetdwIP(szIP_start, szIP_end, &dwip_start, &dwip_end))
					continue;
			}else
			{
				//szIP_start
				if(!GetdwIP(szIP_start, szIP_start, &dwip_start, &dwip_end))
					continue;
			}
			//
			//get port
			pNextPort = scaninfo->Port;
			while(pNextPort = TakeOutStringByChar(pNextPort, szPort, sizeof(szPort), ','))
			{
				if(sNextPort = TakeOutStringByChar(szPort, szPort_start, sizeof(szPort_start), '-'))
				{
					if(TakeOutStringByChar(sNextPort, szPort_end, sizeof(szPort_end), '\0'))
					{
						//szPort_start, szPort_end
						wPort_start = atoi(szPort_start);
						wPort_end = atoi(szPort_end);
					}else
					{
						wPort_start = wPort_end = atoi(szPort_start);
					}
					/////////////////

					for(DWORD IP = dwip_start; IP<=dwip_end; IP++)
					{
						for(WORD wPort = wPort_start; wPort<=wPort_end; wPort++)
						{
							while(TotalCount >= MaxThreadCount)
								Sleep(100);
							
							TARGET *Target = new TARGET;
							if(Target == NULL)
								return 0;

							Target->dwIP = htonl(IP);
							Target->wPort = wPort;
							hThread = CreateThread(NULL, NULL, Connecting, (LPVOID)Target, 0, &dwThreadId);
							CloseHandle(hThread);

						}
					}

					/////////////////
				}
			}
		}
	}
	while(TotalCount > 0)
		Sleep(100);
	return 1;
}

BOOL CheckString(char *str)
{
	char *s = strstr(str, "%s");
	if(!s)
		return FALSE;
	char *d = strstr(s, "%d");
	if(!d)
		return FALSE;

	return TRUE;
}

//59.42.170.124
int main(int argc, char **argv)
{
	WSADATA  wsadata;
	WORD     version;

	version = MAKEWORD(2,2);
    if(WSAStartup( version , &wsadata )!= 0)
	   return FALSE;

	char *Usage = ""
		"TCP Port MultiScanner v1.0 By LZX.\r\n"
		"USAGE:\r\n"
		"    PortScan [-ip] <IP> [-p] <Port> [-f] <outputformat> [-timeout] sec [-thread] maxthread [-save] <filename>\r\n"
		"Example:\r\n"
		"    PortScan -ip 1.1.1.1-1.1.2.254 -p 80 -f \"IP: %s:%d\"\r\n"
		"    PortScan -ip 1.1.1.1-1.1.1.50,1.1.2.1-1.1.2.50 -p 21-23,3389\r\n"
		"    PortScan -ip 1.1.1.1,2.2.2.2 -p 1-65535 -save xx.txt -timeout 1 -thread 200\r\n";

	//init variable;
	fPortScan = NULL;
	TotalCount = 0;
	g_TimeOut = 4;

	char *pszIP = NULL;
	char *pszPort = NULL;
	SaveToFile = NULL;
	IsSaveToFile = FALSE;
	if(argc < 3)
	{
		printf("%s\r\n", Usage);
		return 1;
	}

	//��ȡ���� start
	for(int i=1; i<argc; i++)
	{
		if(argv[i][0] == '-')
		{
			switch(argv[i][1])
			{
			case 'l':
				//
				break;
			continue;
			}
		}
		else
		{
			if(i==1) continue;
			if(!stricmp(&argv[i-1][1], "f"))
			{
				if(CheckString(argv[i]))
					strcpy(StrFormat, argv[i]);
			}else if(!stricmp(&argv[i-1][1], "ip"))
			{
				pszIP = strdup(argv[i]);
			}else if(!stricmp(&argv[i-1][1], "p"))
			{
				pszPort = strdup(argv[i]);
			}else if(!stricmp(&argv[i-1][1], "thread"))
			{
				MaxThreadCount = atoi(argv[i]);
			}else if(!stricmp(&argv[i-1][1], "timeout"))
			{
				g_TimeOut = atoi(argv[i]);
			}else if(!stricmp(&argv[i-1][1], "save"))
			{
				IsSaveToFile = TRUE;
				SaveToFile = strdup(argv[i]);
			}

		}
	}//end

	if(!pszIP || !pszPort)
	{
		printf("%s\r\n", Usage);
		return 1;
	}

	DWORD dwStartTime, dwScanTime;
	DWORD dwThreadId;
	SCANINFO scaninfo;
	HANDLE hThread;

	scaninfo.IP = pszIP;
	scaninfo.Port = pszPort;

	if(IsSaveToFile)
	{
		fPortScan = fopen(SaveToFile, "a+");
		if(fPortScan == NULL)
		{
			printf("fopen %s error.\r\n", SaveToFile);
			goto exit;
		}
		fclose(fPortScan);
	}

	InitializeCriticalSection(&portscan_cs);

	dwStartTime = GetTickCount();
	hThread = CreateThread(NULL, NULL, Scanning, (LPVOID)&scaninfo, 0, &dwThreadId);

	WaitForSingleObject(hThread, -1);

	CloseHandle(hThread);

	dwScanTime = GetTickCount() - dwStartTime;

	printf("Found %d Host used %d ms.\n", GetCount, dwScanTime);

	
	DeleteCriticalSection(&portscan_cs);
exit:
	free(pszIP);
	free(pszPort);
	free(SaveToFile);

	return 0;
}