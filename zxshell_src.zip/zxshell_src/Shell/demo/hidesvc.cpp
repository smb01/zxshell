#include <windows.h>
#include <stdio.h>
#include <tlhelp32.h>
#include <Shlwapi.h>
#include <AccCtrl.h>
#include <Aclapi.h>
#include <Windows.h>
#include <stdio.h>
#include <Psapi.h>
#include "debug.h"
#pragma comment(lib, "Advapi32.lib")
#pragma comment(lib, "psapi.lib")

#define _WIN32_WINNT 0x0500
#include <Ntsecapi.h>
#include <Userenv.h>
#include <Sddl.h>
#include <lm.h>
#pragma comment(lib,"Rasapi32.lib")
#pragma comment(lib,"advapi32.lib")
#pragma comment(lib,"UserEnv.lib")
#pragma comment(lib,"netapi32.lib")
#pragma comment(lib,"Shlwapi.lib")

typedef struct _FAKE_SERVICE_RECORD { 
    struct _FAKE_SERVICE_RECORD  *Prev;          // linked list 
    struct _FAKE_SERVICE_RECORD  *Next;          // linked list 
    LPWSTR                  ServiceName;    // points to service name 
    LPWSTR                  DisplayName;    // 
} FAKE_SERVICE_RECORD, *PFAKE_SERVICE_RECORD, *LPFAKE_SERVICE_RECORD; 

#define FCHK(a)     if (!(a)) {printf(#a " failed %d\n", GetLastError()); return 0;}


BOOL
EnableDebugPriv( LPCTSTR szPrivilege )
{
  HANDLE hToken;
  LUID sedebugnameValue;
  TOKEN_PRIVILEGES tkp;

  if ( !OpenProcessToken( GetCurrentProcess(),
                          TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY,
                          &hToken ) )
  {
    return FALSE;
  }
  if ( !LookupPrivilegeValue( NULL, szPrivilege, &sedebugnameValue ) )
  {
    CloseHandle( hToken );
    return FALSE;
  }

  tkp.PrivilegeCount = 1;
  tkp.Privileges[0].Luid = sedebugnameValue;
  tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

  if ( !AdjustTokenPrivileges( hToken, FALSE, &tkp, sizeof tkp, NULL, NULL ) )
  {
    CloseHandle( hToken );
    return FALSE;
  }

  return TRUE;
}

/////////////////////////////////////////////////////////////////
// �������� :�Զ��幤�ߺ���
// ����ģ�� : 
////////////////////////////////////////////////////////////////
// ���� :ͨ��ָ���������õ������ ID
// ע�� : 
/////////////////////////////////////////////////////////////////
// ���� : sinister
// �����汾 : 1.00.00
// �������� : 2006.2.09
/////////////////////////////////////////////////////////////////
// ��   ��   ��   ��   ��   ʷ
////////////////////////////////////////////////////////////////
// �޸��� :
// �޸����� :
// �޸����� :
/////////////////////////////////////////////////////////////////

DWORD
GetProcessId( LPCTSTR szProcName )
{
  PROCESSENTRY32 pe;  
  DWORD dwPid;
  DWORD dwRet;
  BOOL bFound = FALSE;

  //
  // ͨ�� TOOHLP32 ����ö�ٽ���
  //

  HANDLE hSP = CreateToolhelp32Snapshot( TH32CS_SNAPPROCESS, 0 );
  if ( hSP )
  {
    pe.dwSize = sizeof( pe );

    for ( dwRet = Process32First( hSP, &pe );
          dwRet;
          dwRet = Process32Next( hSP, &pe ) )
    {
      //
      // ʹ�� StrCmpNI �Ƚ��ַ������ɺ��Դ�Сд
      //
      if ( strnicmp( szProcName, pe.szExeFile, strlen( szProcName ) ) == 0 )
      {
        dwPid = pe.th32ProcessID;
        bFound = TRUE;
        break;
      }
    }

    CloseHandle( hSP );

    if ( bFound == TRUE )
    {
      return dwPid;
    }
  }

  return NULL;
}

HMODULE GetModulesBaseAdrr( HANDLE hProcess )
{
	HMODULE hMods[1024];
	DWORD cbNeeded;
	HMODULE BaseAddr = 0;


	if( EnumProcessModules(hProcess, hMods, sizeof(hMods), &cbNeeded))
	{
		BaseAddr = hMods[0];
	}

	return BaseAddr;
}


DWORD search_ServiceRecordList(DWORD pid)
{
    HANDLE    hProc;
    DWORD    dwRead, i, dwAddr;
    BYTE    *pImage = NULL;
    MODULEINFO    mod;
    BOOL    bRet = FALSE, fSuccess = FALSE;
    DWORD    dwCount = 0, dwMaxCount=100;

	WCHAR *svcname = L"KVWSC";
	WCHAR *Buffer = (WCHAR*)malloc(256);
	memset(Buffer, 0, 266);
 
    FCHK ( hProc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid) );

    
    for(i=0x300000;i<0x5000000;i+=256)
    {

		if( ReadProcessMemory(hProc, (LPCVOID)i, (LPVOID)Buffer, 256, &dwRead) )
		{
			for(int k=0; k<dwRead; k++)
			{
				//printf("%d/%d\r\n", k, dwRead);
				if(wcscmp(Buffer+k, svcname) == 0)
				{
					fSuccess = TRUE;
					break;
				}
			}
			if(fSuccess)
			{
				break;
			}else
			{
				i -= 0x1000;
			}
		}else
		{
			i-=0x8000;
			i+=0x1000;
		}

    }
	free(Buffer);

    return dwCount;
}

void main()
{
	DebugPrivilege(SE_DEBUG_NAME,TRUE);
	DWORD dwPid = GetProcessId("services.exe");
	search_ServiceRecordList(dwPid);

}