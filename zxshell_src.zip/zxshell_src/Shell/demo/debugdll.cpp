#include <windows.h>
#include <stdio.h>

typedef void *(__stdcall * _GetAddress)(const char *IPstr);

int main()
{

	int err;
	HINSTANCE hDll = LoadLibrary(
		"E:\\SourceCode\\C++\\ZXSERVER\\ZXFtpServer\\ftpd\\Shell\\Debug\\shellmain3.exe");
	if(!hDll)
	{
		err = GetLastError();
		//SendMessage(Socket, "Can not load the file: %s.\r\n", argv[1]);
		return 0;
	}

	void *pFun = (void*)GetProcAddress(hDll, "IamHere");
	if(!pFun)
	{
		//SendMessage(Socket, "Can not get the main function entry.\r\n");
		return 0;
	}
	char szIP[] = "202.96.11.1";
	char *result = NULL;

	_GetAddress GetAddress = (_GetAddress)pFun;

	_asm call pFun;

	printf("%s\r\n", result);
}