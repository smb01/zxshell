//
// Coded By Napalm
// Modified By ZwelL
//
//#include <winsock2.h>
#include <windows.h>
#include <stdio.h>
#include <psapi.h>

#pragma comment(lib, "psapi.lib")
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "shlwapi.lib")
#pragma comment(lib, "ntdll.lib")
typedef LONG NTSTATUS;

typedef struct _IO_STATUS_BLOCK {
    union {
        NTSTATUS Status;
        PVOID Pointer;
    };
    ULONG Information;
} IO_STATUS_BLOCK, *PIO_STATUS_BLOCK;

typedef void (WINAPI * PIO_APC_ROUTINE)(PVOID, PIO_STATUS_BLOCK, DWORD);

typedef LONG TDI_STATUS;
typedef PVOID CONNECTION_CONTEXT;        // connection context

typedef struct _TDI_REQUEST {
    union {
        HANDLE AddressHandle;
        CONNECTION_CONTEXT ConnectionContext;
        HANDLE ControlChannel;
    } Handle;

    PVOID RequestNotifyObject;
    PVOID RequestContext;
    TDI_STATUS TdiStatus;
} TDI_REQUEST, *PTDI_REQUEST;

typedef struct _TDI_CONNECTION_INFORMATION {
    LONG UserDataLength;        // length of user data buffer
    PVOID UserData;            // pointer to user data buffer
    LONG OptionsLength;        // length of following buffer
    PVOID Options;             // pointer to buffer containing options
    LONG RemoteAddressLength;   // length of following buffer
    PVOID RemoteAddress;        // buffer containing the remote address
} TDI_CONNECTION_INFORMATION, *PTDI_CONNECTION_INFORMATION;

typedef struct _TDI_REQUEST_QUERY_INFORMATION {
    TDI_REQUEST Request;
    ULONG QueryType;             // class of information to be queried.
    PTDI_CONNECTION_INFORMATION RequestConnectionInformation;
} TDI_REQUEST_QUERY_INFORMATION, *PTDI_REQUEST_QUERY_INFORMATION;

#define CTL_CODE( DeviceType, Function, Method, Access ) (                 \
    ((DeviceType) << 16) | ((Access) << 14) | ((Function) << 2) | (Method) \
)

#define FILE_ANY_ACCESS                 0
#define METHOD_OUT_DIRECT               2
#define FILE_DEVICE_TRANSPORT           0x00000021
#define TDI_QUERY_ADDRESS_INFO           0x00000003
#define IOCTL_TDI_QUERY_INFORMATION      CTL_CODE(FILE_DEVICE_TRANSPORT, 4, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)

typedef VOID *POBJECT;

typedef struct _SYSTEM_HANDLE {
    ULONG       uIdProcess;
    UCHAR       ObjectType;    // OB_TYPE_* (OB_TYPE_TYPE, etc.)
    UCHAR       Flags;        // HANDLE_FLAG_* (HANDLE_FLAG_INHERIT, etc.)
    USHORT         Handle;
    POBJECT         pObject;
    ACCESS_MASK    GrantedAccess;
} SYSTEM_HANDLE, *PSYSTEM_HANDLE;

typedef struct _SYSTEM_HANDLE_INFORMATION {
    ULONG           uCount;
    SYSTEM_HANDLE     Handles[1];
} SYSTEM_HANDLE_INFORMATION, *PSYSTEM_HANDLE_INFORMATION;
/*
typedef struct _UNICODE_STRING {
    USHORT Length;
    USHORT MaximumLength;
    PWSTR Buffer;
} UNICODE_STRING;*/
typedef UNICODE_STRING *PUNICODE_STRING;
typedef const UNICODE_STRING *PCUNICODE_STRING;

typedef UNICODE_STRING OBJECT_NAME_INFORMATION;
typedef UNICODE_STRING *POBJECT_NAME_INFORMATION;

#define SystemHandleInformation           16
#define ObjectNameInformation           1
#define STATUS_SUCCESS                ((NTSTATUS)0x00000000L)
#define STATUS_INFO_LENGTH_MISMATCH       ((NTSTATUS)0xC0000004L)
#define STATUS_BUFFER_OVERFLOW           ((NTSTATUS)0x80000005L)
// -------------------------------------------------------------------------

#ifdef __cplusplus
extern "C" {
#endif
#define _KERNEL_MODE_
//#include <ntifs.h>

NTSYSAPI
NTSTATUS
NTAPI
NtQuerySystemInformation(DWORD SystemInformationClass, PVOID SystemInformation,
                                     DWORD SystemInformationLength, PDWORD ReturnLength);
NTSYSAPI
NTSTATUS
NTAPI
NtQueryObject(HANDLE ObjectHandle, DWORD ObjectInformationClass, PVOID ObjectInformation,
                                    DWORD Length, PDWORD ResultLength);
NTSYSAPI
NTSTATUS
NTAPI
NtDeviceIoControlFile(HANDLE FileHandle, HANDLE Event, PIO_APC_ROUTINE ApcRoutine, PVOID ApcContext,
                                  PIO_STATUS_BLOCK IoStatusBlock, DWORD IoControlCode,
                                  PVOID InputBuffer, DWORD InputBufferLength,
                                  PVOID OutputBuffer, DWORD OutputBufferLength);

#ifdef __cplusplus
}
#endif


LPWSTR GetObjectName(HANDLE hObject)
{
    LPWSTR lpwsReturn = NULL;

	DWORD dwSize = sizeof(OBJECT_NAME_INFORMATION);
	POBJECT_NAME_INFORMATION pObjectInfo = (POBJECT_NAME_INFORMATION) new BYTE[dwSize];
	NTSTATUS ntReturn = NtQueryObject(hObject, ObjectNameInformation, pObjectInfo, dwSize, &dwSize);
	if(ntReturn == STATUS_BUFFER_OVERFLOW){
		 delete [] pObjectInfo;
		 pObjectInfo = (POBJECT_NAME_INFORMATION) new BYTE[dwSize];
		 ntReturn = NtQueryObject(hObject, ObjectNameInformation, pObjectInfo, dwSize, &dwSize);
	}
	if((ntReturn >= STATUS_SUCCESS) && (pObjectInfo->Buffer != NULL))
	{
		 lpwsReturn = (LPWSTR) new BYTE[pObjectInfo->Length + sizeof(WCHAR)];
		 ZeroMemory(lpwsReturn, pObjectInfo->Length + sizeof(WCHAR));
		 CopyMemory(lpwsReturn, pObjectInfo->Buffer, pObjectInfo->Length);
	}
	delete [] pObjectInfo;

    return lpwsReturn;
} 

void OutputConnectionDetails(HANDLE hObject, in_addr *ip, DWORD *port)
{

	IO_STATUS_BLOCK IoStatusBlock;
	TDI_REQUEST_QUERY_INFORMATION tdiRequestAddress = {{0}, TDI_QUERY_ADDRESS_INFO};
	BYTE tdiAddress[128];

	HANDLE hEvent2 = CreateEvent(NULL, TRUE, FALSE, NULL);
	NTSTATUS ntReturn2 = NtDeviceIoControlFile(hObject, hEvent2, NULL, NULL, &IoStatusBlock, IOCTL_TDI_QUERY_INFORMATION,
		 &tdiRequestAddress, sizeof(tdiRequestAddress), &tdiAddress, sizeof(tdiAddress));
	if(hEvent2) CloseHandle(hEvent2);

	if(ntReturn2 == STATUS_SUCCESS){
		 struct in_addr *pAddr = (struct in_addr *)&tdiAddress[14];
		 *ip = *pAddr;
		 *port = ntohs(*(PUSHORT)&tdiAddress[12]);
	}

}

int GetPortList(SOCKET Socket, LPWSTR lpwsP)
{

	DWORD dwSize = sizeof(SYSTEM_HANDLE_INFORMATION);
	PSYSTEM_HANDLE_INFORMATION pHandleInfo = (PSYSTEM_HANDLE_INFORMATION) new BYTE[dwSize];
	NTSTATUS ntReturn = NtQuerySystemInformation(SystemHandleInformation, pHandleInfo, dwSize, &dwSize);
	if(ntReturn == STATUS_INFO_LENGTH_MISMATCH){
		 delete [] pHandleInfo;
		 pHandleInfo = (PSYSTEM_HANDLE_INFORMATION) new BYTE[dwSize];
		 ntReturn = NtQuerySystemInformation(SystemHandleInformation, pHandleInfo, dwSize, &dwSize);
	}
	if(ntReturn == STATUS_SUCCESS){
		 //printf(" Found %d Handles. Listing TCP/UDP Handles...\n\n", pHandleInfo->uCount);
		 //printf("  PID\tProto   Port   Process Name\n");
		 for(DWORD dwIdx = 0; dwIdx < pHandleInfo->uCount; dwIdx++)
		 {
			HANDLE hProcess = ZXSAPI::OpenProcess(PROCESS_ALL_ACCESS,
				 FALSE, pHandleInfo->Handles[dwIdx].uIdProcess);
			if(hProcess != INVALID_HANDLE_VALUE)
			{

				 HANDLE hObject = NULL;
				 if(DuplicateHandle(hProcess, (HANDLE)pHandleInfo->Handles[dwIdx].Handle,
					  ZXSAPI::GetCurrentProcess(), &hObject, STANDARD_RIGHTS_REQUIRED, FALSE, 0) != FALSE)
				  {
					 
					 LPWSTR lpwsName = GetObjectName(hObject);
					 if(lpwsName != NULL){
						 //wprintf(L"lpwsName: %s\n", lpwsName);
						 if(!wcscmp(lpwsName, lpwsP) )//|| !wcscmp(lpwsName, L"\\Device\\Udp")
						   {
							   LPSTR lpszProcess = new CHAR[MAX_PATH];
							   struct in_addr ipaddr;
							   DWORD port;

							   OutputConnectionDetails(hObject, &ipaddr, &port);
							   ZeroMemory(lpszProcess, MAX_PATH);
							   GetModuleFileNameEx(hProcess, NULL, lpszProcess, MAX_PATH);
							   SendMessage(Socket, "%5d   %ws   %15s:%-7d\t%s\n",
								   pHandleInfo->Handles[dwIdx].uIdProcess,
								   //pHandleInfo->Handles[dwIdx].Handle,
								   //((lstrlen(lpszProcess) > 0)?PathFindFileName(lpszProcess):"[System]"),
								   &lpwsName[8],
								   inet_ntoa(ipaddr),
								   port,
								   lpszProcess);
								   
							   delete [] lpszProcess;
						   }
						   delete [] lpwsName;
					  }
					  //CloseHandle(hObject);
				 }
				  CloseHandle(hProcess);
				
			}
		 }
		 printf("\n\n");
	}else{
		 printf("Error while trying to allocate memory for System Handle Information.\n");
	}
	delete [] pHandleInfo;

	return 1;
}

int fport(SOCKET Socket)
{
    DebugPrivilege(SE_DEBUG_NAME, TRUE);
	//printf("  PID\tProto         Address:Port\tProcess Path\n");
	SendMessage(Socket, "  PID\tProto         Address:Port\tProcess Path\n");
	GetPortList(Socket, L"\\Device\\Tcp");
	GetPortList(Socket, L"\\Device\\Udp");
	DebugPrivilege(SE_DEBUG_NAME, FALSE);
    return 0;
}
