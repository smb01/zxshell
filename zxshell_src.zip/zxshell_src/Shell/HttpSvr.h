/*
http ������ .h
*/
#include <winsock2.h>
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <memory.h>
#include <commctrl.h>
#include "..\zxsCommon\SocketList.h"

#pragma comment(lib, "ws2_32.lib")

C_SOCKETLIST httpSvrConn;

#define pTYPESIZE 25
char ContentType[][pTYPESIZE] ={
	"jpeg", "image/jpeg",
	"png", "image/png",
	"mpg", "video/mpeg",
	"asf", "video/x-ms-asf",
	"avi", "video/x-msvideo",
	"bmp", "image/bmp",
	"doc", "application/msword",
	"exe", "application/octet-stream",//14, 15
	"rar", "application/octet-stream",
	"zip", "application/zip",
	"jpg", "image/jpeg",
	"gif", "image/gif",
	"txt", "text/plain",
	"c", "text/plain",
	"h", "text/plain",
	"ico", "image/x-icon",
	"css", "text/css",
	"htm", "text/html",
	"html", "text/html"
};

class HttpHeader{
public:
	char		method[15];
	char		protocol[15];
	float		httpver;
	char		*useragent;		/* User-Agent: */
	char		*date;
	char		*path;			/* Path for get_dir */
	char		*connection;	/* Connection: */
	char		*ifmodifiedsince;/*If-Modified-Since:*/
	char		*lastmodified;
	char		*eTag;
	int			contenttype;	/* Content-Type: */
	int			rangeflag;
	__int64		rangestart;
	__int64		rangeend;
	__int64		rangetotal;
	unsigned __int64		contentlength;	/* Content-Length: */
	HttpHeader(){
		memset(method, 0, sizeof(HttpHeader));
	}
	~HttpHeader()
	{
		free(useragent);
		free(date);
		free(path);
		free(connection);
		free(lastmodified);
		free(ifmodifiedsince);
		free(eTag);
	}
};
/*
typedef struct _FILE_INFO{
    TCHAR           szFileName[MAX_PATH];
    DWORD           dwFileAttributes; 
    FILETIME        ftCreationTime; 
    FILETIME        ftLastAccessTime; 
    FILETIME        ftLastWriteTime; 
    DWORD           nFileSizeHigh; 
    DWORD           nFileSizeLow; 
} FILE_INFO, *LPFILE_INFO;

*/