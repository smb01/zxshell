/*
�˿�ɨ�裨�첽��
*/
#include <winsock2.h>
#include <stdio.h>
#include <Mswsock.h>
//#include "link.h"
//#pragma comment(lib,"Mswsock.lib")

#pragma comment(lib,"ws2_32")

#define WM_SOCKET (WM_USER+1)

HWND hWnd;
long TotalCount = 0;
int GetCount = 0;
int g_TimeOut;
BOOL IsSaveToFile;
FILE *fPortScan;
char *SaveToFile = NULL;
char StrFormat[MAX_PATH] = "%s:%d";


struct SCANINFO
{
	char *IP;
	char *Port;
};
/*
struct SCANSOCK
{
	SOCKET s;
	DWORD StartTime;
};

void ForceCloseSocket(SOCKET s);

class SCANSOCKLIST:public LINKTABLE<SCANSOCK>
{
private:
	CRITICAL_SECTION cs;
public:
	SCANSOCKLIST()
	{
		InitializeCriticalSection(&cs);
	}
	~SCANSOCKLIST()
	{
		DeleteCriticalSection(&cs);
	}
	int AddSocket(SOCKET s, DWORD NowTime);
	int DelSocket(DWORD NowTime, DWORD TimeOut);

};

SCANSOCKLIST g_socklist;

int SCANSOCKLIST::AddSocket(SOCKET s, DWORD NowTime)
{
	SCANSOCK data;
	data.s = s;
	data.StartTime = NowTime;

	EnterCriticalSection(&cs);
	int ret = Add(data);
	LeaveCriticalSection(&cs);

	return ret;
}

int SCANSOCKLIST::DelSocket(DWORD NowTime, DWORD TimeOut)
{
	int ret = 0;
	_Node<SCANSOCK> *curr = Head, *tmp;
	EnterCriticalSection(&cs);
	for(int n=0; n<Count; n++)
	{
		if(NowTime - curr->data.StartTime >= TimeOut)
		{
			ForceCloseSocket(curr->data.s);
			tmp = curr->Next;
			Delp(curr);
			curr = tmp;
			n--;
			ret++;
			continue;
		}
		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);
	return ret;
}

const char *TakeOutStringByChar(IN const char *Source, OUT char *Dest, int buflen, char ch)
{
	if(Source == NULL)
		return NULL;

	const char *p = strchr(Source, ch);

	while(*Source == ' ')
		Source++;
	for(int i=0; i<buflen && *(Source+i) && *(Source+i) != ch; i++)
	{
		Dest[i] = *(Source+i);
	}
	if(i == 0)
		return NULL;
	else
		Dest[i] = '\0';

	const char *lpret = p ? p+1 : Source+i;

	while(Dest[i-1] == ' ' && i>0)
		Dest[i-- -1] = '\0';

	return lpret;
}
*/
bool Connecting(SOCKET *ConnSock, DWORD dwIP, WORD wPort)
{
	struct sockaddr_in Server;
	memset(&Server, 0, sizeof(Server));

	Server.sin_family = AF_INET;
	Server.sin_port = htons(wPort);
	Server.sin_addr.s_addr = dwIP;
	// Create Socket
	SOCKET s = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	if (s == INVALID_SOCKET)
		return false;

	int	retval = WSAAsyncSelect(s, hWnd, WM_SOCKET, FD_CONNECT|FD_CLOSE);
	if(retval == SOCKET_ERROR)
	{
		closesocket(s);
		return false;
	}

	retval = connect(s, (const SOCKADDR *)&Server,sizeof(Server));
	
	*ConnSock = s;
	InterlockedExchangeAdd(&TotalCount, 1);

	return true;
}

BOOL IsOver()
{
	//printf("%d\n", TotalCount);
	if(TotalCount <= 0)
	{
		DestroyWindow(hWnd);
		return 1;
	}else
		return 0;
}

void ForceCloseSocket(SOCKET s)
{
	linger lg = {1, 0};
	WSAAsyncSelect(s, hWnd, 0, 0);
	setsockopt(s, SOL_SOCKET, SO_LINGER,
		(const char FAR *)&lg, sizeof(lg));
	closesocket(s);

	InterlockedExchangeAdd(&TotalCount, -1);
	IsOver();
}
BOOL GetdwIP(char *startip, char *endip, DWORD *IP_start, DWORD *IP_end)
{
	DWORD dwIP;

	dwIP = inet_addr(startip);
	if(dwIP == INADDR_NONE)
		return FALSE;

	*IP_start = ntohl(dwIP);

	dwIP = inet_addr(endip);
	if(dwIP == INADDR_NONE)
		return FALSE;

	*IP_end = ntohl(dwIP);

	if(*IP_start <= *IP_end)
		return TRUE;
	else
		return FALSE;
}


DWORD WINAPI Scanning(LPVOID lParam)
{
	SCANINFO *scaninfo = (SCANINFO *)lParam;

	char szIP[MAX_PATH], szPort[MAX_PATH];
	char szIP_start[32], szIP_end[32]; 
	char szPort_start[10], szPort_end[10]; 

	const char *pNextIP = scaninfo->IP;
	const char *sNextIP;
	const char *pNextPort = scaninfo->Port;
	const char *sNextPort;

	SOCKET ConnSock;

	DWORD dwip_start, dwip_end;
	WORD wPort_start, wPort_end;

	//get ip
	while(pNextIP = TakeOutStringByChar(pNextIP, szIP, sizeof(szIP), ','))
	{
		if(sNextIP = TakeOutStringByChar(szIP, szIP_start, sizeof(szIP_start), '-'))
		{
			if(TakeOutStringByChar(sNextIP, szIP_end, sizeof(szIP_end), '\0'))
			{
				//szIP_start, szIP_end
				if(!GetdwIP(szIP_start, szIP_end, &dwip_start, &dwip_end))
					continue;
			}else
			{
				//szIP_start
				if(!GetdwIP(szIP_start, szIP_start, &dwip_start, &dwip_end))
					continue;
			}
			//
			//get port
			pNextPort = scaninfo->Port;
			while(pNextPort = TakeOutStringByChar(pNextPort, szPort, sizeof(szPort), ','))
			{
				if(sNextPort = TakeOutStringByChar(szPort, szPort_start, sizeof(szPort_start), '-'))
				{
					if(TakeOutStringByChar(sNextPort, szPort_end, sizeof(szPort_end), '\0'))
					{
						//szPort_start, szPort_end
						wPort_start = atoi(szPort_start);
						wPort_end = atoi(szPort_end);
					}else
					{
						wPort_start = wPort_end = atoi(szPort_start);
					}
					/////////////////

					for(DWORD IP = dwip_start; IP<=dwip_end; IP++)
					{
						for(WORD wPort = wPort_start; wPort<=wPort_end; wPort++)
						{
							while(TotalCount >= 1024)
								Sleep(1000);
							
							if(Connecting(&ConnSock, htonl(IP), wPort))
							{
								//g_socklist.AddSocket(ConnSock, GetTickCount());
								//Sleep(1);
							}
							else
								Sleep(1000);
						}
					}

					/////////////////
				}
			}
		}
	}

	return 1;
}



void ProcessSocketMessage(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{

	int iMode = 0;
	int ret = 0;
	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(clientaddr);
	SOCKET Socket = *(SOCKET*)GetWindowLong(hWnd, GWL_USERDATA);///

	if(WSAGETSELECTERROR(lParam)){
		goto exit;
	}

	switch(WSAGETSELECTEVENT(lParam)){
	case FD_CONNECT:
		if(getpeername(wParam, (SOCKADDR *)&clientaddr, &addrlen) == 0)
		{
			GetCount++;
			if(IsSaveToFile)
			{
				fPortScan = fopen(SaveToFile, "a+");
				if(fPortScan != NULL)
				{
					fprintf(fPortScan, StrFormat , inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port));
					fprintf(fPortScan, "\r\n");
					fclose(fPortScan);
				}
			}else
			{
				SendMessage(Socket, StrFormat , inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port));
				SendMessage(Socket, "\r\n");
			}
		}
		break;
	case FD_CLOSE:

		break;
		}
exit:
	
	ForceCloseSocket(wParam);

}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
	case WM_SOCKET:
		ProcessSocketMessage(hWnd, uMsg, wParam, lParam);
		return 0;

/*	case WM_TIMER:
		switch(wParam) 
		{ 
		case 1:
			//printf("TotalCount: %d\r\n", TotalCount);
			g_socklist.DelSocket(GetTickCount(), g_TimeOut);
			break; 
		}
		break;
*/
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}


int Startup()
{
	WSAData wsa;
	if (WSAStartup(MAKEWORD(2, 0), &wsa))
		return false;
	WNDCLASS wndclass;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.hbrBackground = (HBRUSH)NULL;
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hInstance = NULL;
	wndclass.lpfnWndProc = WndProc;
	wndclass.lpszClassName = "ZXPortScan";
	wndclass.lpszMenuName = NULL;
	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	ATOM RegClass = RegisterClass(&wndclass);
	if(!RegClass) return false;

	hWnd = CreateWindow((TCHAR*)RegClass, "ZXPortScan",
		WS_OVERLAPPEDWINDOW, 0, 0, 32, 32,
		NULL, NULL, NULL, NULL);
	if(hWnd == NULL)
		return false;

	//SetTimer(hWnd, 1, 1000, (TIMERPROC)NULL); 

	return true;
}


DWORD RunApp()
{
	BOOL bRet;
	MSG msg;
	while( (bRet = GetMessage( &msg, hWnd, 0, 0 )) != 0)
	{
		IsOver();
		if (bRet == -1)
		{
			break;
		}
		else if(!IsDialogMessage(hWnd, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return msg.wParam;
}

BOOL CheckString(char *str)
{
	char *s = strstr(str, "%s");
	if(!s)
		return FALSE;
	char *d = strstr(s, "%d");
	if(!d)
		return FALSE;

	return TRUE;
}

//59.42.170.124
int PortScan(MainPara *args)
{
	SOCKET Socket = args->Socket;

	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();

	char *Usage = ""
		"TCP Port AsyncScanner v1.0\r\n"
		"USAGE:\r\n"
		"    PortScan [-ip] <IP> [-p] <Port> [-f] <outputformat> [-save] <filename>\r\n"
		"Example:\r\n"
		"    PortScan -ip 1.1.1.1-1.1.2.254 -p 80 -f \"IP: %s:%d\"\r\n"
		"    PortScan -ip 1.1.1.1-1.1.1.50,1.1.2.1-1.1.2.50 -p 21-23,3389\r\n"
		"    PortScan -ip 1.1.1.1,2.2.2.2 -p 1-65535 -save xx.txt\r\n";

	char *pszIP = NULL;
	char *pszPort = NULL;
	SaveToFile = NULL;
	IsSaveToFile = FALSE;
	if(argc < 3)
	{
		SendMessage(Socket, "%s\r\n", Usage);
		return 1;
	}

	//��ȡ���� start
	for(int i=1; i<argc; i++)
	{
		if(argv[i][0] == '-')
		{
			if(!stricmp(&argv[i][1], "quit"))
			{
				TotalCount = 0;
				break;
			continue;
			}
		}
		else
		{
			if(i==1) continue;
			if(!stricmp(&argv[i-1][1], "f"))
			{
				if(CheckString(argv[i]))
					strcpy(StrFormat, argv[i]);
			}else if(!stricmp(&argv[i-1][1], "ip"))
			{
				pszIP = strdup(argv[i]);
			}else if(!stricmp(&argv[i-1][1], "p"))
			{
				pszPort = strdup(argv[i]);
			}else if(!stricmp(&argv[i-1][1], "save"))
			{
				IsSaveToFile = TRUE;
				SaveToFile = strdup(argv[i]);
			}

		}
	}//end

	if(!pszIP || !pszPort)
	{
		SendMessage(Socket, "%s\r\n", Usage);
		return 1;
	}

	Startup();

	SetWindowLong(hWnd, GWL_USERDATA, (long)&Socket);
	SetWindowPos(hWnd, NULL, 0,0,0,0, SWP_FRAMECHANGED);

	DWORD dwStartTime, dwScanTime;
	DWORD dwThreadId;
	SCANINFO scaninfo;
	HANDLE hThread;

	scaninfo.IP = pszIP;
	scaninfo.Port = pszPort;

	if(IsSaveToFile)
	{
		fPortScan = fopen(SaveToFile, "a+");
		if(fPortScan == NULL)
		{
			SendMessage(Socket, "fopen %s error.\r\n", SaveToFile);
			goto exit;
		}
		fclose(fPortScan);
	}
	//g_TimeOut = 14 * 1000;

	SendMessage(Socket, "OK. PortScan is Scanning now.\r\n");

	dwStartTime = GetTickCount();
	hThread = CreateThread(NULL, NULL, Scanning, (LPVOID)&scaninfo, 0, &dwThreadId);
	Sleep(2000);
	CloseHandle(hThread);

	RunApp();

	dwScanTime = GetTickCount() - dwStartTime;

	SendMessage(Socket, "Found %d Host used %d ms.\n", GetCount, dwScanTime);
	if(IsSaveToFile)
	{
		SendMessage(Socket, "Saved To %s\r\n", SaveToFile);
	}
exit:
	free(pszIP);
	free(pszPort);
	free(SaveToFile);

	return 0;
}