// Author: LZX
// E-mail: LZX@qq.com
// Version: V1.3
// Purpose: A HTTP Proxy Supports GET && POST && CONNECT Methods
//
// Test PlatForm: WinXP SP2
// Compiled On: VC++ 6.0 
// Last Modified: 2006-8-31
// v1.4 2006-8-31   ChangeBanner => User-Agent: 
// v1.3 2006-8-8	��װΪһ��class
// v1.2 2006-7-28	��1.1ûʲô��ϵ��

#include <winsock2.h>
#include <windows.h>
#include <stdio.h>
#include <errno.h>
#include "..\zxsCommon\link.h"
#include ".\SpoofProcPath.h"
#include ".\common.h"
#include "common.h"
#pragma comment(lib,"Ws2_32.lib")

#define SERVERNAME "ZXHttpProxy"
#define VERSION "1.4"
#define DEFAULTPORT 8080
#define MAXBUFSIZE 8192
#define SSLCONN 8
#define WM_SOCKET (WM_USER+1)


struct CONNINFO{	//a Node of a connection.
	SOCKET	ClientSock;
	SOCKET	ServerSock;
	DWORD	HostIP;
	WORD	Port;
	BYTE	CloseFlag;
	BYTE	ProxyFlag;
	CONNINFO	*Next;
};
/*
////////A simple class of stack operator.  code start.....
template<typename T>
class STACK
{
#define MAXSTACK 1024*2

private:
	int top;
	T Data[MAXSTACK];
public:
STACK()
{
	top = -1;
}
bool IsEmpty()
{
	return top < 0;
}
bool Push(T data)
{
	if(top >= MAXSTACK)
		return false;
	top++;
	Data[top] = data;
	return true;
}
T Pop()
{
	return Data[top--];
}
	
};/////////////////////stack	end
*/
class HTTPPROXY		//HTTPPROXY class code start...........
{
private:
CRITICAL_SECTION cs;
HWND hWnd;
SOCKET ProxyServer;
WORD LisPort;
CONNINFO * LinkHead;
int nCount;
STACK<SOCKET> SocketStack;
char Banner[64];
public:

char *allowIP;
char *denyIP;

HTTPPROXY()
{
	memset(this, 0, sizeof(HTTPPROXY));
	LinkHead = NULL;
	LisPort = DEFAULTPORT;
	InitializeCriticalSection(&cs);
}

~HTTPPROXY()
{
	RemoveAll();
	closesocket(ProxyServer);
	DeleteCriticalSection(&cs);
}

void ViewInfo(char *buf)
{
	if(!IsServerRunning())
		sprintf(buf, "ZXHttpProxy Isn't Running.\r\n");
	else
		sprintf(buf, 
			"Listen Port: %d\r\n"
			"Now Connections: %d\r\n", 
			LisPort, nCount);
}

BOOL Push(SOCKET sock)
{
	return SocketStack.Push(sock);
}

SOCKET Pop()
{
	if(SocketStack.IsEmpty())
		return INVALID_SOCKET;
	return SocketStack.Pop();
}

CONNINFO *ConnAdd(CONNINFO *ConnInfo)
{
	EnterCriticalSection(&cs);//
	CONNINFO *ptr = NULL;
	ptr = new CONNINFO;
	if(ptr == NULL)
		goto exit;
	memset(ptr, 0, sizeof(CONNINFO));
	*ptr = *ConnInfo;
	ptr->Next = LinkHead;
	LinkHead = ptr;
	nCount++;

exit:
	LeaveCriticalSection(&cs);//
	return ptr;
}

CONNINFO *ConnSearch(CONNINFO *ConnInfo)
{
	EnterCriticalSection(&cs);//
	CONNINFO *curr = LinkHead;
	while(curr)
	{
		if((curr->HostIP==ConnInfo->HostIP) && (curr->Port == ConnInfo->Port) && (curr->ClientSock == ConnInfo->ClientSock))
			break;
		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);//
	return curr;
}

void ConnCloseAll()
{
	EnterCriticalSection(&cs);//
	CONNINFO *curr = LinkHead;
	while(curr)
	{
		shutdown(curr->ServerSock, 2);
		shutdown(curr->ClientSock, 2);

		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);//
}

void ConnClose(SOCKET ClientSock)
{
	EnterCriticalSection(&cs);//
	CONNINFO *tmp, *prev = NULL, *curr = LinkHead;
	linger lg = {1, 0};
	while(curr)
	{
		if(curr->ClientSock == ClientSock)
		{
			setsockopt(curr->ServerSock, SOL_SOCKET, SO_LINGER,
				(const char FAR *)&lg, sizeof(lg));

			closesocket(curr->ServerSock);
			tmp = curr->Next;
			if(prev)
				prev->Next = tmp;
			else
				LinkHead = tmp;

			delete curr;
			nCount--;
			curr = tmp;
			continue;
		}
		prev = curr;
		curr = curr->Next;
	}
	closesocket(ClientSock);
	
	LeaveCriticalSection(&cs);//
}

void RemoveAll()
{
	CONNINFO *curr = LinkHead;
	while(curr)
	{
		closesocket(curr->ClientSock);
		closesocket(curr->ServerSock);
		LinkHead = LinkHead->Next;
		delete curr;
		curr = LinkHead;
	}
}

int GetCount()
{
	return nCount;
}

BOOL IsServerRunning()
{
	return ProxyServer;
}

int GetRequest(SOCKET sock, char *RecvBuf, int BufSize)
{
	int nRecv=0;
	int Result;
	fd_set FdRead;

	while(1)
	{
		FD_ZERO(&FdRead);
		FD_SET(sock,&FdRead);
		Result = select(sock+1,&FdRead,NULL,NULL,NULL);
		if(Result <= 0)
			return 0;
		Result = ZXSAPI::recv(sock,RecvBuf+nRecv,BufSize-nRecv-1,0);
		if(Result <= 0)
			return 0;
		nRecv += Result;
		RecvBuf[nRecv]='\0';
		if(strstr(RecvBuf,"\r\n\r\n")!=NULL || strstr(RecvBuf,"\n\n")!=NULL)
			break;
	}
	return nRecv;
}

int CheckRequest(const char *RecvBuf)
{
	if(!strnicmp(RecvBuf,"GET ",4))
		return 4;
	else if(!strnicmp(RecvBuf,"HEAD ",5))
		return 5;
	else if(!strnicmp(RecvBuf,"POST ",5))
		return 5;
	else if(!strnicmp(RecvBuf,"CONNECT ",8))
		return 8;
	else
		return 0;
}

int GetURL(char *URLBuf, const char *RecvBuf, int len)
{
	char tmpBuf[MAXBUFSIZE];
	memset(tmpBuf, 0, sizeof(tmpBuf));
	int plen = 0;
	const char *p = strchr(RecvBuf, ' ');
	if(p == NULL)
		return 0;
	if(!sscanf(p, "%s", tmpBuf))
		return 0;
	if(!strnicmp(tmpBuf, "http://", 7))
		plen = 7;
	strcpy(URLBuf, tmpBuf+plen);
	return strlen(tmpBuf+plen);
}

int GetConnFlag(const char *RecvBuf)
{
	char *str = "Proxy-Connection: ";
	const char *p = strstr(RecvBuf, str);
	if(p==NULL)
		return 0;
	return !strnicmp(p+strlen(str), "close", 5);
}

void GetHostIPAndPort(char *URL,int len,ULONG *HostIP,WORD *Port)
{
	char tmpBuf[MAXBUFSIZE];
	char *fp = URL;
	int i = 0;
	for(i = 0;i < len && *fp != ':' && *fp != '\0' && *fp != '\\' && *fp != '/';i++)
	{	
		tmpBuf[i]=*fp++;
		if(*fp == ':')
			*Port=atoi(fp+1);
		else *Port=80;
	}
	tmpBuf[i] = '\0';
	fp = DNS(tmpBuf);
	if(fp)
		*HostIP = inet_addr(fp);
}

int GetInfoFromHeader(CONNINFO *Node, const char *RecvBuf, int len)
{
	char URLBuf[MAXBUFSIZE];
	int n = GetURL(URLBuf, RecvBuf, len);
	GetHostIPAndPort(URLBuf, n, &Node->HostIP, &Node->Port);
	Node->CloseFlag = GetConnFlag(RecvBuf);

	return CheckRequest(RecvBuf);
}

int ModifyDataByTitle(char *HeaderBuf, int len, char *Header, char *NewData)
{
	char tmpBuf[MAXBUFSIZE];
	char *CRLF = "\r\n";
	char *ps, *pe;
	int DataLen, NewDataLen, BackupLen;
	pe = strstr(HeaderBuf, CRLF);
	if(pe == NULL)
		CRLF++;
	NewDataLen = lstrlen(NewData);
	ps = strstr(HeaderBuf, Header);
	if(ps == NULL)
		return len;
	ps += lstrlen(Header);
	pe = strstr(ps, CRLF);
	if(pe == NULL)
		return len;
	DataLen = pe - ps;
	BackupLen = len-(pe-HeaderBuf);
	strncpy(tmpBuf, pe, BackupLen);
	strcpy(ps, NewData);
	strncpy(ps+NewDataLen, tmpBuf, BackupLen);
	return len + (NewDataLen - DataLen);
}

int ModifyHeader(char *RecvBuf, int len)
{
	char tmpBuf[MAXBUFSIZE];
	int MethodLen = CheckRequest(RecvBuf);
	strncpy(tmpBuf, RecvBuf, MethodLen);
	char *pRoot = strchr(RecvBuf+MethodLen+7, '/');
	if(!pRoot)
		return 0;
	int HostLen = pRoot - RecvBuf - MethodLen - 7;
	strncpy(tmpBuf+MethodLen, pRoot, len - MethodLen - 7 - HostLen);
	int newlen = len - 7 - HostLen;
	tmpBuf[newlen] = '\0';
	char *pc = strstr(tmpBuf, "Proxy-Connection: ");
	if(pc)
	{
		strcpy(pc, pc+6);
		newlen -= 6;
	}
	if(*Banner)
		newlen = ModifyDataByTitle(tmpBuf, newlen, "User-Agent: ", Banner);

	strncpy(RecvBuf, tmpBuf, newlen);
	RecvBuf[newlen] = '\0';
	return newlen;
}

#if !defined _ZXSHELL

char *DNS(const char *HostName)
{
	HOSTENT *hostent = NULL;
	IN_ADDR iaddr;
	hostent = gethostbyname(HostName);
	if (hostent == NULL)
	{
		return NULL;
	}
	iaddr = *((LPIN_ADDR)*hostent->h_addr_list);
	return inet_ntoa(iaddr);
}

SOCKET ConnectToServer(const ULONG HostIP,const UINT Port)
{
	struct sockaddr_in Server;
	SOCKET sock;
	memset(&Server, 0, sizeof(Server));

	Server.sin_family = AF_INET;
	Server.sin_port = htons(Port);
	Server.sin_addr.s_addr = HostIP;

	sock = ZXSAPI::socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	if(sock == INVALID_SOCKET)
		return 0;
	if(ZXSAPI::connect(sock, (const SOCKADDR *)&Server,sizeof(Server)) == SOCKET_ERROR)
		return 0;

	return sock;
}

int DataSend(SOCKET s, const char *buff, int nBufSize)
{
    int nBytesLeft = nBufSize;
    int idx = 0, nBytes = 0;
	int iMode = 0;
	ioctlsocket(s, FIONBIO, (u_long FAR*) &iMode);
	while(nBytesLeft > 0) 
	{
		nBytes = ZXSAPI::send(s, &buff[idx], nBytesLeft, 0);
        if(nBytes <= 0) 
		{
            return idx;
        }
        nBytesLeft -= nBytes;
        idx += nBytes;
	}
    return idx;
}

#endif

DWORD TransmitData(LPVOID lparam)
{
	CONNINFO *Node = (CONNINFO *)lparam;
	SOCKET ClientSock = Node->ClientSock;
	SOCKET ServerSock = Node->ServerSock;
	char RecvBuf[MAXBUFSIZE];
	int nRecv=0, nSent=0;
	int Result;
	fd_set FdRead;

	while(1)
	{
		FD_ZERO(&FdRead);

		FD_SET(ClientSock,&FdRead);
		FD_SET(ServerSock,&FdRead);
		Result = select(0, &FdRead, NULL, NULL, NULL);
		if(Result <= 0)
			return 0;
		if(FD_ISSET(ServerSock, &FdRead))
		{
			nRecv = ZXSAPI::recv(ServerSock, RecvBuf, MAXBUFSIZE, 0);
			if(nRecv <= 0)
				return 0;
			else
			{
				nSent = DataSend(ClientSock, RecvBuf, nRecv);
				if(nSent != nRecv)
					return 0;
			}
		}
		if(FD_ISSET(ClientSock, &FdRead))
		{
			if(Node->ProxyFlag != SSLCONN)
				return 1;
			nRecv = ZXSAPI::recv(ClientSock, RecvBuf, MAXBUFSIZE, 0);
			if(nRecv <= 0)
				return 0;
			else
			{
				nSent = DataSend(ServerSock, RecvBuf, nRecv);
				if(nSent != nRecv)
					return 0;
			}
		}
	}

	return 0;
}

void Config(WORD Port, char *allowip, char *denyip)
{
	LisPort = Port;
	allowIP = allowip;
	denyIP = denyip;
}

void ChangeBanner(char *newBanner)
{
	_snprintf(Banner, sizeof(Banner), "%s", newBanner);
}

//A main ProxyThread
static DWORD WINAPI ProxyThread(LPVOID lparam)
{	

	CONNINFO Node={0}, *pNode = NULL;
	char RecvBuf[MAXBUFSIZE];
	int ret, nRecv, len;

	HTTPPROXY *HttpProxy = (HTTPPROXY*)lparam;
	SOCKET sock = HttpProxy->Pop();//ȡ���׽���
	while(!Node.CloseFlag)//�ж� Proxy-Connection: ��־
	{
		memset(RecvBuf, 0, sizeof(RecvBuf));
		memset(&Node, 0, sizeof(Node));
		Node.ClientSock = sock;

		nRecv = HttpProxy->GetRequest(Node.ClientSock, RecvBuf, sizeof(RecvBuf));//����һ����������
		if(!nRecv)
			goto exit;
		ret = HttpProxy->GetInfoFromHeader(&Node, RecvBuf, nRecv);//�ӽ��յ������ݷ���������Ŀ�����Ϣ
		if(!ret)		
			goto exit;

		if(ret == SSLCONN)//CONNECT ģʽ
		{
			Node.ServerSock = ConnectHost(Node.HostIP, Node.Port);
			if(!Node.ServerSock)
				goto exit;
			DataSend(Node.ClientSock, "HTTP/1.0 200 OK\r\n\r\n", 20);

			Node.ProxyFlag = SSLCONN;

			pNode = HttpProxy->ConnAdd(&Node);

			if(!pNode)
				goto exit;
			HttpProxy->TransmitData((LPVOID)pNode);
			goto exit;

		}else//GET or POST ����
		{
			len = HttpProxy->ModifyHeader(RecvBuf, nRecv);//�޸�HTTP PROXY�����ݸ�ʽΪHTTPЭ������ݸ�ʽ
			if(!len)
				goto exit;

			pNode = HttpProxy->ConnSearch(&Node);//�������в��ҽڵ�
			if(pNode)//��������ѽ��������Ϸ������µ���������Ҫ���º�Զ�̽���������
			{
				ret = DataSend(pNode->ServerSock, RecvBuf, len);
				if(ret != len)
					goto exit;
			}else//����������Ŀ������ӣ���ת����������
			{
				Node.ServerSock = ConnectHost(Node.HostIP, Node.Port);
				if(!Node.ServerSock)
					goto exit;

				pNode = HttpProxy->ConnAdd(&Node);
				if(!pNode)
					goto exit;

				ret = DataSend(pNode->ServerSock, RecvBuf, len);
				if(ret != len)
					goto exit;
			}

			if(! HttpProxy->TransmitData((LPVOID)pNode))//��������ת��ģʽ
				goto exit;
		}
	}

exit:
	HttpProxy->ConnClose(Node.ClientSock);//�ر�����
	return 1;
}


BOOL Startup()
{
	//printf("%s %s By LZX.\r\n",SERVERNAME, VERSION);

	WSAData wsa;
	if (WSAStartup(MAKEWORD(2, 0), &wsa))
		return false;

	WNDCLASS wnd;
	ZeroMemory(&wnd, sizeof(WNDCLASS));

	wnd.hbrBackground = (HBRUSH)COLOR_WINDOW;
	wnd.hCursor = LoadCursor(NULL, IDC_ARROW);
	wnd.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wnd.hInstance = NULL;
	wnd.lpfnWndProc = MainWndProc;
	wnd.lpszClassName = "ZXProxyClass";
	wnd.lpszMenuName = NULL;

	RegisterClass(&wnd);

	hWnd = CreateWindow((TCHAR*)"ZXProxyClass", SERVERNAME,
		WS_OVERLAPPEDWINDOW, 0, 0, 32, 32,
		NULL, NULL, NULL, NULL);

	if(!hWnd)
		return false;
	SetWindowLong(hWnd, GWL_USERDATA, (long)this);
	SetWindowPos(hWnd, NULL, 0,0,0,0, SWP_FRAMECHANGED);
	return true;
}

void Cleanup()
{
	WSACleanup();
}

BOOL InitSocket()
{
#ifdef _AntiBadFirewall
	AntiBadFirewall antibadfw;
#endif

	int retval;
	BOOL nLevel = 1;
	SOCKADDR_IN serveraddr;

	ProxyServer = ZXSAPI::socket(AF_INET, SOCK_STREAM, 0);
	if(ProxyServer == INVALID_SOCKET){
		goto error;
	}

	retval = WSAAsyncSelect(ProxyServer, hWnd, WM_SOCKET, FD_ACCEPT|FD_CLOSE);
	if(retval == SOCKET_ERROR) {
		goto error;
	}
	ZeroMemory(&serveraddr, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(LisPort);
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);

    if (setsockopt(ProxyServer, SOL_SOCKET, SO_EXCLUSIVEADDRUSE,
        (const char FAR *)&nLevel, sizeof(nLevel)) != 0) {
        goto error;
    }

	retval = ZXSAPI::bind(ProxyServer, (SOCKADDR *)&serveraddr, sizeof(serveraddr));
	if(retval == SOCKET_ERROR){
		goto error;
	}

	retval = ZXSAPI::listen(ProxyServer, SOMAXCONN);
	if(retval == SOCKET_ERROR){
		goto error;
	}
	return 1;
error:
	closesocket(ProxyServer);
	ProxyServer = 0;
	return 0;
}

DWORD Quit(SOCKET ClientSock)
{
	if(ProxyServer)
	{
		SendMessage(hWnd, WM_CLOSE, 0, 0);
		DestroyWindow(hWnd);
		ConnCloseAll();
		closesocket(ProxyServer);
		ProxyServer = 0;
		SendMessage(ClientSock, "Proxy Service Ended Successfully.\r\n");
	}else
	{
		SendMessage(ClientSock, "Proxy Service Isn't Running.\r\n");
	}
	return 0;
}

DWORD RunApp()
{
	BOOL bRet;
	MSG msg;
	while( (bRet = GetMessage( &msg, NULL, 0, 0 )) != 0)
	{ 
		if (bRet == -1)
		{
			break;
		}
		else
		{
			TranslateMessage(&msg); 
			DispatchMessage(&msg); 
		}
	}

	Cleanup();
	return msg.wParam;
}

static void ProcessSocketMessage(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	SOCKET AcceptSocket;
	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(clientaddr);
	HTTPPROXY *HttpProxy = (HTTPPROXY *)GetWindowLong(hWnd, GWL_USERDATA);///
	int retval = 0;
	HANDLE hThread;
	DWORD dwThreadID;
	if(WSAGETSELECTERROR(lParam)){
		return;
	}

	switch(WSAGETSELECTEVENT(lParam)){
	case FD_ACCEPT:
		{

		AcceptSocket = ZXSAPI::accept(wParam, (SOCKADDR *)&clientaddr, &addrlen);

		//filter
		if(! IP_Filter(AcceptSocket, HttpProxy->allowIP, HttpProxy->denyIP))
		{
			closesocket(AcceptSocket);
			return;
		}
		if(AcceptSocket == INVALID_SOCKET){
			return;
		}

		retval = WSAAsyncSelect(AcceptSocket, hWnd, 0, 0);
		if(retval == SOCKET_ERROR){
			return;
		}

		if(! HttpProxy->SocketStack.Push(AcceptSocket))
		{
			closesocket(AcceptSocket);
			break;
		}
		retval = ioctlsocket(AcceptSocket, FIONBIO, (u_long FAR*) &retval);
		hThread = ZXSAPI::CreateThread(NULL, NULL, ProxyThread, (LPVOID)HttpProxy, 0, &dwThreadID);
		if(hThread == NULL)
			closesocket(AcceptSocket);
		else
			CloseHandle(hThread);

		}
		break;

	case FD_CLOSE:
		WSAAsyncSelect(wParam, hWnd, 0, 0);
		closesocket(wParam);
		break;
	}
}

static LRESULT CALLBACK MainWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
	case WM_SOCKET:
		ProcessSocketMessage(hWnd, uMsg, wParam, lParam);
		return 0;
	case WM_COMMAND:
		break;

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

};//class HTTPPROXY end

int HTTPPROXY_Usage(SOCKET ClientSock)
{
	char tmp[8192];
	sprintf(tmp, "\
%s %s.\r\n\
Usage:\r\n\
      ZXHttpProxy [-p] <Port> [-a] <allowIP> [-d] <denyIP> [-b] <User-Agent> [-v] [-q]\r\n\
\r\n\
Example:\r\n\
      %s -p 8080 -a 61.8.8.*,202.96.* -d 202.96.4.*\r\n\
      %s -p 8000 -d 61.8.8.13-61.8.9.28 -b Googlebot\r\n\
      %s -p 8000 (All IP Is Acceptable.)\r\n\
      %s -v (View Server Info)\r\n\
      %s -q (End Proxy Service.)\r\n\
", SERVERNAME, VERSION, SERVERNAME, SERVERNAME, SERVERNAME, SERVERNAME, SERVERNAME);

	//printf("%s", tmp);
	SendMessage(ClientSock, tmp);
	return 0;
}

//ȫ�ֶ���
HTTPPROXY HttpProxy;

DWORD WINAPI ZXHttpProxy(MainPara *args)
{
	SOCKET ClientSock = args->Socket;

	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();

	delete args;//!!!!!!


	int LisPort = 0;
	char *allowip = NULL;
	char *denyip = NULL;
	char *banner = NULL;

	if(argc < 2)
		return HTTPPROXY_Usage(ClientSock);

/*
	for(int i=1; i<argc; i++)
	{
		if(argv[i][0] == '-' || argv[i][0] == '/')
		{
			if(argv[i][1] == 'q')
				return HttpProxy.Quit(ClientSock);
			if(argv[i][1] == 'v')
			{
				HttpProxy.ViewInfo(Temp);
				return SendMessage(ClientSock, Temp);
			}
			else
				continue;
		}
		else
		{
			if(HttpProxy.IsServerRunning())
				return SendMessage(ClientSock, "ZXHttpProxy is running.\r\n");
			if(i==1) continue;
			switch(argv[i-1][1])
			{
			case 'a':
				allowip = argv[i];
				break;
			case 'b':
				banner = argv[i];
				break;
			case 'd':
				denyip = argv[i];
				break;
			case 'p':
				LisPort = atoi(argv[i]);
				break;
			default:
				return HTTPPROXY_Usage(ClientSock);
			}
		}
	}
*/
	CGetOpt cmdopt(argc, argv, false);

	if(cmdopt.checkopt("q"))
	{
		return HttpProxy.Quit(ClientSock);
	}else if(cmdopt.checkopt("v"))
	{
		HttpProxy.ViewInfo(Temp);
		return SendMessage(ClientSock, Temp);
	}

	if(HttpProxy.IsServerRunning())
		return SendMessage(ClientSock, "ZXHttpProxy is running.\r\n");

	if(cmdopt.getstr("a"))
	{
		allowip = cmdopt;
	}
	if(cmdopt.getstr("b"))
	{
		banner = cmdopt;
	}
	if(cmdopt.getstr("d"))
	{
		denyip = cmdopt;
	}
	if(cmdopt.getstr("p"))
	{
		LisPort = cmdopt.getint("p");
	}	
	
	if(LisPort == 0)
		return HTTPPROXY_Usage(ClientSock);

	HttpProxy.Config(LisPort, allowip, denyip);
	if(banner)
		HttpProxy.ChangeBanner(banner);//Change User-Agent
	/*if(!HttpProxy.Startup())
	{
		//printf("Startup Failed. Maybe ZXHttpProxy is running.\r\n");
		SendMessage(ClientSock, "Startup Failed. Maybe ZXHttpProxy is running.\r\n");
		return 0;
	}*/
	HttpProxy.Startup();
	if(!HttpProxy.InitSocket())
	{
		//printf("InitSocket Failed. Try to change a Port and then try again.\r\n");
		SendMessage(ClientSock, "InitSocket Failed.\r\nMaybe ZXHttpProxy is running or Try to change a Port and then try again.\r\n");
		return 0;
	}
	SendMessage(ClientSock, "ZXHttpProxy Started Successfully.\r\n");

	HttpProxy.ViewInfo(Temp);
	SendMessage(ClientSock, Temp);

	return HttpProxy.RunApp();
}



/*
��Source�ַ�������ָ��char�ֶ�д�絽Dest�������С�
����ֵΪSource�е���һ���ε����ָ��
��:
Source = "1234  , 321, 43,333"
Dest���õ� "1234"
����ָ��ָ��" 321, 43,333"
*/
/*
static const char *TakeOutStringByChar(IN const char *Source, OUT char *Dest, int buflen, char ch)
{
	if(Source == NULL)
		return NULL;

	const char *p = strchr(Source, ch);

	while(*Source == ' ')
		Source++;
	for(int i=0; i<buflen && *(Source+i) && *(Source+i) != ch; i++)
	{
		Dest[i] = *(Source+i);
	}
	if(i == 0)
		return NULL;
	else
		Dest[i] = '\0';

	const char *lpret = p ? p+1 : Source+i;

	while(Dest[i-1] == ' ' && i>0)
		Dest[i---1] = '\0';

	return lpret;
}



//destIP = "22.22.22.1-22.22.*"
static BOOL Is_szIP_in_range(char *sourceIP, char *destIP)
{
	BOOL flag = TRUE;
	char *sip = sourceIP;
	char *dip = destIP;
	while(sip && dip)
	{
		if(*dip == '*')
			break;
		if(*sip != *dip)
		{
			flag = FALSE;
			break;
		}
		if(*sip =='\0' && *dip == '\0')
			break;
		sip++;
		dip++;
	}
	return flag;
}

//destIP = "22.22.22.1-22.22.22.7"
static BOOL Is_dwIP_in_range(char *sourceIP, char *destIP)
{
	const char *nextip;
	char startip[32], endip[32];

	nextip = TakeOutStringByChar(destIP, startip, sizeof(startip), '-');

	if(nextip)
		TakeOutStringByChar(nextip, endip, sizeof(endip), NULL);
	else
		return FALSE;

	DWORD dwIP, srcIP, IP_start, IP_end;

	dwIP = inet_addr(sourceIP);
	if(dwIP == INADDR_NONE)
		return FALSE;

	srcIP = ntohl(dwIP);

	dwIP = inet_addr(startip);
	if(dwIP == INADDR_NONE)
		return FALSE;

	IP_start = ntohl(dwIP);

	dwIP = inet_addr(endip);
	if(dwIP == INADDR_NONE)
		return FALSE;

	IP_end = ntohl(dwIP);

	if(srcIP >= IP_start && srcIP <= IP_end)
		return TRUE;
	else
		return FALSE;
}

static BOOL Is_IP_in_range(char *sourceIP, char *destIP)
{
	if(strchr(destIP, '-'))
	{
		if(Is_dwIP_in_range(sourceIP, destIP))
			return TRUE;
		else
			return FALSE;
	}else
	{
		if(Is_szIP_in_range(sourceIP, destIP))
			return TRUE;
		else
			return FALSE;
	}
}

static BOOL IP_Filter(SOCKET s, const char *AllowedIP, const char *DeniedIP)
{
	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(clientaddr);
	if(getpeername(s, (SOCKADDR *)&clientaddr, &addrlen) == SOCKET_ERROR)
		return FALSE;
	IN_ADDR iaddr = clientaddr.sin_addr;
	char *IP = inet_ntoa(iaddr);
	char filterIP[64] = {0};
	BOOL IsAllowed;
	const char *p;
	p = TakeOutStringByChar(AllowedIP, filterIP, sizeof(filterIP), ',');
	if(p)
		IsAllowed = FALSE;
	else
		IsAllowed = TRUE;
	while(p)
	{
		if(Is_IP_in_range(IP, filterIP))
		{
			IsAllowed = TRUE;
			break;
		}
		p = TakeOutStringByChar(p, filterIP, sizeof(filterIP), ',');
	}
	p = DeniedIP;
	while(p = TakeOutStringByChar(p, filterIP, sizeof(filterIP), ','))
	{
		if(Is_IP_in_range(IP, filterIP))
			return FALSE;
	}
	return IsAllowed;
}

*/