#ifndef C_SHELLLIST_H
#define C_SHELLLIST_H

#include <windows.h>
#include "..\zxsCommon\link.h"

class _tagSHELL{

public:
	SOCKET Socket;
	DWORD dwID;
	float ver;
	bool bAuth;
public:
	_tagSHELL();
	bool GetAuthMode(){ return bAuth;}

};

class C_SHELLLIST:public LINKTABLE<_tagSHELL>
{
protected:
	CRITICAL_SECTION cs;
public:
	C_SHELLLIST()
	{
		InitializeCriticalSection(&cs);
	}
	~C_SHELLLIST()
	{
		DeleteCriticalSection(&cs);
	}
	int AddSocket(_tagSHELL s);
	int DelSocket(SOCKET s);
	float GetShellVersion(SOCKET s);
	_tagSHELL * IsSocketInList(SOCKET s);
	int CloseAllSocket();
	DWORD GetParentID(SOCKET s);

};

#endif