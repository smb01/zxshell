#include ".\rportmap\server\server.h"

int rPortMap(SOCKET actionSocket)
{
	SPAMFUNCTION
		
	CSREALPORTMAP srpm(actionSocket, NULL);

	if(!srpm.RecvConfigInfo())
	{
		srpm.stop();
		return 0;
	}
	if(!srpm.start())
	{
		srpm.stop();
		return 0;
	}

	srpm.wait();

	if(srpm.GetErrorCode())
	{
		//printf(srpm.GetErrorString());
	}
	srpm.stop();

	return 0;
}