#ifndef C_MAPSERVER_H
#define C_MAPSERVER_H

#include "connMapList.h"
#include "common.h"

class CSREALPORTMAP
{
private:
	SOCKET m_socket;//�������ݴ����õ��׽���

	CRITICAL_SECTION cs;
	HANDLE hMainThread;
	char ErrorString[50];
	DWORD ErrorCode;
	int ProVer;
public:

	C_CONNMAPLIST m_connmaplist;//�������ӵ�����
	_TARGET addr;

	CSREALPORTMAP(SOCKET s, _TARGET *pADDR);
	~CSREALPORTMAP();
	void SetProVersion(int ver);
	void XORData(char *p, int n);

	DWORD GetErrorCode(){ return ErrorCode;}
	void SetErrorCode(DWORD code){ ErrorCode = code;}
	char *GetErrorString(){ return ErrorString;}
	void SetErrorString(char *str){ strcpy(ErrorString, str);}

	void SetThreadHandle(HANDLE hThread){hMainThread = hThread;}
	SOCKET GetSocket(){ return m_socket;};
	BOOL RecvConfigInfo();

	BOOL udpconnThread(CONNMAP *lpconnmap);
	static DWORD WINAPI _udpconnThread(LPVOID lParam);
	BOOL mainThread();
	static DWORD WINAPI _mainThread(LPVOID lParam);
	BOOL connThread(CONNMAP *lpconnmap);
	static DWORD WINAPI _connThread(LPVOID lParam);
	BOOL Send(char *buf, int len);
	void DelConn(WORD Id);

	void wait();
	int start();
	int stop();
};

#endif