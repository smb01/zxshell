#ifndef C_CONNMAPCOMMON_H
#define C_CONNMAPCOMMON_H


#include <windows.h>
#include <stdio.h>


#define MAXSZIPLEN 49

#define PRO_FLAG	0x8B

#pragma pack(push, 1)
struct PROHEADER
{
	BYTE flag;
	WORD connID;
	WORD dataLength;
};

struct _TARGET
{
	char szIP[50];
	WORD wPort;
};
#pragma pack(pop)

int UDPSend(SOCKET s, char *buff, int nBufSize, DWORD dwIP, WORD wPort);
SOCKET CreateUDPSocket(DWORD *LPIP, WORD *LPPort);
char *GetInetIP(char *OutIP);


int SetTimeOut(SOCKET Socket,int nTimeOut);
int RecvMessage(SOCKET Socket, char *RecvBuf, int DataLen, int TimeOut_sec);
int DataSend(SOCKET s, char *DataBuf, int DataLen, int TimeOut_sec);
int DataSend(SOCKET s, char *DataBuf, int DataLen);//��DataBuf�е�DataLen���ֽڷ���sȥ
SOCKET ConnectHost(DWORD dwIP, WORD wPort);//����ָ��IP�Ͷ˿�
char *DNS(char *HostName);
SOCKET ConnectHost(char *szIP, WORD wPort);
SOCKET CreateSocket(DWORD dwIP, WORD wPort);//��dwIP�ϰ�wPort�˿�
SOCKET CreateTmpSocket(WORD *wPort);//����һ����ʱ���׽���,ָ��wPort��ô�������ʱ�˿�
BOOL InitSock();
SOCKET DoAccept(SOCKET s, int nTimeOut);



#endif