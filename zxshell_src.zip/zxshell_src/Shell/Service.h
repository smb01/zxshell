/*
windows services manage
*/
BOOL  EnumService(SOCKET Socket, IN SC_HANDLE  schSCManager)
{
	DWORD       dwServiceType;
	DWORD       dwServiceState;
	DWORD       dwIndex;
	DWORD       cbBufSize;
	DWORD       ResumeHandle;
	DWORD       cbBytesNeeded;
	DWORD       ServicesReturned;
	ENUM_SERVICE_STATUS   EnumStatus[512];

	dwServiceType    = SERVICE_WIN32;
	dwServiceState   = SERVICE_STATE_ALL;
	cbBufSize        = sizeof(EnumStatus);
	cbBytesNeeded    = 0;
	ServicesReturned = 0;
	ResumeHandle     = 0;
	if(!EnumServicesStatus(schSCManager,dwServiceType,dwServiceState,EnumStatus,cbBufSize,&cbBytesNeeded, &ServicesReturned,&ResumeHandle))
	{
        cbBufSize += cbBytesNeeded;
		if(!EnumServicesStatus(schSCManager,dwServiceType,dwServiceState,EnumStatus,cbBufSize,&cbBytesNeeded,&ServicesReturned,&ResumeHandle))
		{
			//sprintf(Temp,"EnumServicesStatus Error: %d\r\n",GetLastError());
			//SendMessage(Socket,Temp);
			err_display(Socket, "EnumServicesStatus", 1);
			return FALSE;
		}
		else
		{
           	SendMessage(Socket, "Services:\t %d\r\n",ServicesReturned);
		}
	}

	SendMessage(Socket, "%-18s\t%-8s%s\r\n","ServiceName","Status","DisplayName");
	SendMessage(Socket, "-------------------------------------------------------------------------------\r\n");

	for(dwIndex = 0;dwIndex < ServicesReturned; dwIndex ++)
	{
		SendMessage(Socket, "%-18s\t",EnumStatus[dwIndex].lpServiceName);

		switch(EnumStatus[dwIndex].ServiceStatus.dwCurrentState)
		{
		case SERVICE_STOPPED:
			SendMessage(Socket, "%-8s","Stopped");
			break;
		case SERVICE_START_PENDING:
			SendMessage(Socket, "%-8s","Starting");
			break;
		case SERVICE_STOP_PENDING:
			SendMessage(Socket, "%-8s","Stopping");
			break;
		case SERVICE_RUNNING:
			SendMessage(Socket, "%-8s","Running");
			break;
		case SERVICE_CONTINUE_PENDING:
			SendMessage(Socket, "%-8s","Continue");
			break;
		case SERVICE_PAUSE_PENDING:
			SendMessage(Socket, "%-8s","Pausing");
			break;
		case SERVICE_PAUSED:
			SendMessage(Socket, "%-8s","Paused");
			break;
		default:
			SendMessage(Socket, "%-8s","");
			break;
		}
		SendMessage(Socket, "%s\r\n",EnumStatus[dwIndex].lpDisplayName);
	}
	sprintf(Temp,"\r\nList Services Compeleted\r\n");
	SendMessage(Socket,Temp);

    memset(Temp,0,MAX_BUFF);
	return TRUE;
}

BOOL  ViewService(SOCKET Socket, IN SC_HANDLE schSCManager, char *szServiceName)
{
	SC_HANDLE                schService;
	DWORD                    dwBytesNeeded;
	LPQUERY_SERVICE_CONFIG   lpServiceConfig      = NULL;
    SERVICE_STATUS           ServiceStatus;

	schService = OpenService(schSCManager,szServiceName,SERVICE_ALL_ACCESS);
	if(schService == NULL)
	{
		if(GetLastError() == ERROR_INVALID_NAME)
		{
			sprintf(Temp,"%s No Found !\r\n",szServiceName);
			SendMessage(Socket,Temp);
			return TRUE;
		}
		//sprintf(Temp,"OpenService Error: %d\r\n",GetLastError());
		//SendMessage(Socket,Temp);
		err_display(Socket, "qc->OpenService", 1);
		return FALSE;
	}

    lpServiceConfig = (LPQUERY_SERVICE_CONFIG)malloc(1024*8);

	if(!QueryServiceConfig(schService,lpServiceConfig,1024*8,&dwBytesNeeded))
	{
		//sprintf(Temp,"QueryServiceConfig Error: %d\n",GetLastError());
		err_display(Socket, "qc->QueryServiceConfig", 0);
	}
	else
	{   sprintf(Temp,"Service Information:\r\n\r\n");
    	SendMessage(Socket,Temp);
		sprintf(Temp,"ServiceName:\t %s\r\n",szServiceName);
		SendMessage(Socket,Temp);
		sprintf(Temp,"DisplayName:\t %s\r\n",lpServiceConfig->lpDisplayName);
		SendMessage(Socket,Temp);
		sprintf(Temp,"FilePath:\t %s\r\n",lpServiceConfig->lpBinaryPathName);
		SendMessage(Socket,Temp);
		sprintf(Temp,"StartType:\t ");
		SendMessage(Socket,Temp);
		switch(lpServiceConfig->dwStartType)
		{
		case SERVICE_AUTO_START:
			sprintf(Temp,"Auto Start\r\n");
			break;
		case SERVICE_BOOT_START:
			sprintf(Temp,"Boot Start\r\n");
			break;
		case SERVICE_DEMAND_START:
			sprintf(Temp,"Demand Start\r\n");
			break;
		case SERVICE_DISABLED:
			sprintf(Temp,"Disabled\r\n");
			break;
		case SERVICE_SYSTEM_START:
			sprintf(Temp,"System Start\r\n");
			break;
		default:
			sprintf(Temp,"\r\n");
			break;
		}
		SendMessage(Socket,Temp);
	}
    if(!QueryServiceStatus(schService,&ServiceStatus))
	{
		//sprintf(Temp,"QueryServiceStatus Error: %d\r\n",GetLastError());
		//SendMessage(Socket,Temp);
		err_display(Socket, "qc->QueryServiceStatus", 1);
	}
	else
	{
		sprintf(Temp,"CurrentState:\t ");
		SendMessage(Socket,Temp);
		switch(ServiceStatus.dwCurrentState)
		{
		case SERVICE_CONTINUE_PENDING:
			sprintf(Temp,"Continue\r\n");
			break;
		case SERVICE_PAUSE_PENDING:
			sprintf(Temp,"Pausing\r\n");
			break;
		case SERVICE_PAUSED:
			sprintf(Temp,"Paused\r\n");
			break;
		case SERVICE_RUNNING:
			sprintf(Temp,"Running\r\n");
			break;
		case SERVICE_START_PENDING:
			sprintf(Temp,"Starting\r\n");
			break;
		case SERVICE_STOP_PENDING:
			sprintf(Temp,"Stopping\r\n");
			break;
		case SERVICE_STOPPED:
			sprintf(Temp,"Stopped\r\n");
			break;
        default:
			sprintf(Temp,"\r\n");
			break;
		}
		SendMessage(Socket,Temp);
	}
	sprintf(Temp,"\r\nService Information Completed\r\n");
	SendMessage(Socket,Temp);
	if(lpServiceConfig != NULL)
	{
		free(lpServiceConfig);
	}
	if(schService != NULL)
	{
		CloseServiceHandle(schService);
	}
    memset(Temp,0,MAX_BUFF);
	return TRUE;
}

BOOL  ViewService(MainPara *args, IN SC_HANDLE  SchSCManager)
{
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;
	if(argc < 3)
	{
		sprintf(Temp,"Usage: %s %s ServiceKeyName\r\n", argv[0], argv[1]);
		SendMessage(Socket, Temp);
		return FALSE;
	}
	return ViewService(Socket, SchSCManager, argv[2]);
}

BOOL  DeleteService(SOCKET Socket, IN SC_HANDLE schSCManager, char *szServiceName)
{
	BOOL Ret = FALSE;
	SC_HANDLE         schService;
    SERVICE_STATUS    ServiceStatus;

	schService = OpenService(schSCManager,szServiceName,SERVICE_ALL_ACCESS);
	if(schService == NULL)
	{
		if(GetLastError() == ERROR_INVALID_NAME)
		{
			sprintf(Temp,"%s No Found\r\n",szServiceName);
			SendMessage(Socket,Temp);
			return FALSE;
		}
		//sprintf(Temp,"OpenService Error: %d\r\n",GetLastError());
		//SendMessage(Socket,Temp);
		err_display(Socket, "OpenService", 1);
		return FALSE;
	}

	if(!QueryServiceStatus(schService,&ServiceStatus))
	{
		//sprintf(Temp,"QueryServiceStatus Error: %d\r\n",GetLastError());
		//SendMessage(Socket,Temp);
		err_display(Socket, "QueryServiceStatus", 1);
	}
	else
	{
    	if(ServiceStatus.dwCurrentState != SERVICE_STOPPED)
		{
			if(!ControlService(schService,SERVICE_CONTROL_STOP,&ServiceStatus))
			{
				//sprintf(Temp,"Stop Service %s Error: %d\r\n",szServiceName,GetLastError());
				//SendMessage(Socket,Temp);
				err_display(Socket, "ControlService", 1);
				return FALSE;
			}
		}

		if(!DeleteService(schService))
		{
			err_display(Socket, "DeleteService", 0);
			//sprintf(Temp,"Delete Service %s Error: %d\r\n",szServiceName,GetLastError());
		}
		else
		{
			sprintf(Temp,"Delete Service %s Successfully\r\n",szServiceName);
			Ret = TRUE;
		}
		SendMessage(Socket,Temp);
	}

	if(schService != NULL)
	{
		CloseServiceHandle(schService);
	}

	return Ret;
}

BOOL  DeleteService(MainPara *args, IN SC_HANDLE  SchSCManager)
{
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;
	if(argc < 3)
	{
		sprintf(Temp,"Usage: %s %s ServiceKeyName\r\n", argv[0], argv[1]);
		SendMessage(Socket,Temp);
		return FALSE;
	}
	return DeleteService(Socket,SchSCManager,argv[2]);
}


BOOL StartService(SOCKET Socket, IN SC_HANDLE schSCManager, IN LPCTSTR ServiceName)
{
    SC_HANDLE  schService;
    BOOL       ret;
    DWORD      err;
    SERVICE_STATUS_PROCESS ssStatus; 
    DWORD dwOldCheckPoint; 
    DWORD dwStartTickCount;
    DWORD dwWaitTime;
    DWORD dwBytesNeeded;

    schService = OpenService(schSCManager,ServiceName,SERVICE_ALL_ACCESS);

    if (schService == NULL)
    {
        //sprintf(Temp, "failure: OpenService (0x %x)\n", GetLastError());
		//SendMessage(Socket,Temp);
		err_display(Socket, "OpenService", 1);
        return FALSE;
    }

    ret = ZXSAPI::StartService (schService,    // service identifier
                        0,             // number of arguments
                        NULL           // pointer to arguments
                        );
    if (ret==0)
    {
		err_display(Socket, "StartService", 0);

    }else
	{
/*
	   if (!QueryServiceStatusEx( 
				schService,             // handle to service 
				SC_STATUS_PROCESS_INFO, // info level
				(LPBYTE)&ssStatus,              // address of structure
				sizeof(SERVICE_STATUS_PROCESS), // size of structure
				&dwBytesNeeded ) )              // if buffer too small
		{
		   ret = FALSE;
		   err_display(Socket, "StartService", 0);
		   goto exit;
		}
 
		// Save the tick count and initial checkpoint.

		dwStartTickCount = GetTickCount();
		dwOldCheckPoint = ssStatus.dwCheckPoint;

		while (ssStatus.dwCurrentState == SERVICE_START_PENDING) 
		{ 
			// Do not wait longer than the wait hint. A good interval is 
			// one tenth the wait hint, but no less than 1 second and no 
			// more than 10 seconds. 
 
			dwWaitTime = ssStatus.dwWaitHint / 10;

			if( dwWaitTime < 1000 )
				dwWaitTime = 1000;
			else if ( dwWaitTime > 10000 )
				dwWaitTime = 10000;

			Sleep( dwWaitTime );

			// Check the status again. 
 
		if (!QueryServiceStatusEx( 
				schService,             // handle to service 
				SC_STATUS_PROCESS_INFO, // info level
				(LPBYTE)&ssStatus,              // address of structure
				sizeof(SERVICE_STATUS_PROCESS), // size of structure
				&dwBytesNeeded ) )              // if buffer too small
				break; 
 
			if ( ssStatus.dwCheckPoint > dwOldCheckPoint )
			{
				// The service is making progress.

				dwStartTickCount = GetTickCount();
				dwOldCheckPoint = ssStatus.dwCheckPoint;
			}
			else
			{
				if(GetTickCount()-dwStartTickCount > ssStatus.dwWaitHint)
				{
					// No progress made within the wait hint
					break;
				}
			}
		} 
*/
//		if (ssStatus.dwCurrentState == SERVICE_RUNNING) 
		{
			sprintf(Temp, "Service [%s] Started.\r\n", ServiceName);
		}
/*		else
		{
			sprintf(Temp, "StartService [%s] failed.\r\n", ServiceName);
		}
*/
	}

exit:
	SendMessage(Socket,Temp);
    CloseServiceHandle (schService);
    return ret;
}

BOOL  StartService(MainPara *args, IN SC_HANDLE  SchSCManager)
{
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;
	if(argc < 3)
	{
		SendMessage(Socket, "Usage: %s %s ServiceKeyName\r\n", argv[0], argv[1]);
		return FALSE;
	}
	return StartService(Socket, SchSCManager, argv[2]);
}

BOOL  StopService(SOCKET Socket, IN SC_HANDLE schSCManager, char *szServiceName)
{
	SC_HANDLE         schService;
    SERVICE_STATUS    ServiceStatus;

	schService = OpenService(schSCManager,szServiceName,SERVICE_ALL_ACCESS);
	if(schService == NULL)
	{
		/*if(GetLastError() == ERROR_INVALID_NAME)
		{
			sprintf(Temp,"%s No Found\r\n",szServiceName);
			SendMessage(Socket,Temp);
			return TRUE;
		}
		sprintf(Temp,"OpenService Error: %d\r\n",GetLastError());
		SendMessage(Socket,Temp);*/
		err_display(Socket, "OpenService", 1);
		return FALSE;
	}

	if(!QueryServiceStatus(schService,&ServiceStatus))
	{
		//sprintf(Temp,"QueryServiceStatus Error: %d\r\n",GetLastError());
		err_display(Socket, "QueryServiceStatus", 1);
		goto exit;
	}
	else
	{
		if(ServiceStatus.dwCurrentState == SERVICE_STOPPED)
		{
			SendMessage(Socket, "failure: StopService, SERVICE_STOPPED.\r\n");
			goto exit;
		}else
		{
			if(!ControlService(schService,SERVICE_CONTROL_STOP,&ServiceStatus))
			{
				//sprintf(Temp,"Stop Service %s Error: %d\r\n",szServiceName,GetLastError());
				err_display(Socket, "ControlService", 1);
				goto exit;
			}
		}

		SendMessage(Socket, "Stop Service %s Successfully\r\n",szServiceName);
	}
exit:
	CloseServiceHandle(schService);
	return TRUE;
}

BOOL  StopService(MainPara *args, IN SC_HANDLE  SchSCManager)
{
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;
	if(argc < 3)
	{
		SendMessage(Socket, "Usage: %s %s ServiceKeyName\r\n", argv[0], argv[1]);
		return FALSE;
	}
	return StopService(Socket, SchSCManager, argv[2]);
}

BOOL InstallService(SOCKET Socket, 
					IN SC_HANDLE  SchSCManager,
					IN LPCTSTR    lpServiceName,
					IN LPCTSTR    lpDisplayName,
					IN LPCTSTR    ServiceExe,
					IN DWORD      dwServiceType,
					IN DWORD      dwStartType)
{
    SC_HANDLE  schService;
    DWORD      err;

    schService = ZXSAPI::CreateService (SchSCManager, lpServiceName, // name of service
		lpDisplayName, // name to display
		SERVICE_ALL_ACCESS,
		dwServiceType, // service type
		SERVICE_AUTO_START,  // start type
		SERVICE_ERROR_NORMAL,  // error control type
		ServiceExe,            // service's binary
		NULL,                  // no load ordering group
		NULL,                  // no tag identifier
		NULL,                  // no dependencies
		NULL,                  // LocalSystem account
		NULL                   // no password
		);

    if (schService == NULL)
    {
        err = GetLastError();

        if (err == ERROR_SERVICE_EXISTS)
        {
			SendMessage(Socket, "failure: CreateService, ERROR_SERVICE_EXISTS\n");
        }
        else
        {
            //sprintf(Temp, "failure: CreateService (0x %x)\n",err);
			err_display(Socket, "CreateService", 1);
        }
        return FALSE;
    }
	SendMessage(Socket, "success: Service Installed Successfully.\n");
    CloseServiceHandle (schService);

    return TRUE;
}

BOOL CreateService(MainPara *args, IN SC_HANDLE  SchSCManager)
{
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;
	DWORD      dwServiceType;
	DWORD      dwStartType;
	if(argc < 7)
	{
		SendMessage(Socket, 
			"Usage: \r\n"
			"       %s %s KeyName DisplayName BinPath ServiceType dwStartType\r\n"
			"       ServiceType: SERVICE_WIN32 = 0, KERNEL_DRIVER = 1\r\n"
			"       dwStartType: auto = 0, demand = 1, disable = 2\r\n"
			"example:\r\n"
			"       sc create keyname servicename c:\\a.exe 0 0\r\n",
			argv[0],
			argv[1]);
		return FALSE;
	}
	if(atoi(argv[5]))
		dwServiceType = SERVICE_KERNEL_DRIVER;
	else
		dwServiceType = SERVICE_WIN32_OWN_PROCESS|SERVICE_INTERACTIVE_PROCESS;
	switch(atoi(argv[6]))
	{
	case 0:
		dwStartType = SERVICE_AUTO_START;
	case 1:
		dwStartType = SERVICE_DEMAND_START;
	case 2:
		dwStartType = SERVICE_DISABLED;
	default:
		dwStartType = SERVICE_DEMAND_START;
	}
	return InstallService(Socket, SchSCManager, argv[2], argv[3], argv[4], dwServiceType, dwStartType);
}

BOOL GetServiceDisplayName(MainPara *args, IN SC_HANDLE  SchSCManager)
{
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;
	if(argc < 3)
	{
		SendMessage(Socket, "Usage: %s %s ServiceDisplayName\r\n", argv[0], argv[1]);
		return FALSE;
	}
	char szDisplayName[MAX_PATH];
	memset(szDisplayName, 0, sizeof(szDisplayName));
	DWORD lpcchBuffer = sizeof(szDisplayName);
	if(GetServiceDisplayName(SchSCManager, argv[2], szDisplayName, &lpcchBuffer))
		SendMessage(Socket, "GetServiceDisplayName SUCCESS  Name = %s\r\n", szDisplayName);
	else
		//sprintf(Temp, "GetServiceDisplayName FAILED %d.\r\n", GetLastError());
		err_display(Socket, "GetServiceDisplayName", 1);

	return TRUE;
}

BOOL GetServiceKeyName(MainPara *args, IN SC_HANDLE  SchSCManager)
{
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;
	if(argc < 3)
	{
		SendMessage(Socket, "Usage: %s %s ServiceKeyName\r\n", argv[0], argv[1]);
		return FALSE;
	}
	char szKeyName[MAX_PATH];
	memset(szKeyName, 0, sizeof(szKeyName));
	DWORD lpcchBuffer = sizeof(szKeyName);
	if(GetServiceKeyName(SchSCManager, argv[2], szKeyName, &lpcchBuffer))
		SendMessage(Socket, "GetServiceKeyName SUCCESS  Name = %s\r\n", szKeyName);
	else
		//sprintf(Temp, "GetServiceKeyName FAILED %d.\r\n", GetLastError());
		err_display(Socket, "GetServiceKeyName", 1);

	return TRUE;
}

BOOL GetServiceDescription(MainPara *args, IN SC_HANDLE  SchSCManager)
{
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;
	if(argc < 3)
	{
		SendMessage(Socket, "Usage: %s %s ServiceKeyName\r\n", argv[0], argv[1]);
		return FALSE;
	}
	char szDescription[1024];
	char KeyPath[MAX_PATH] = {"SYSTEM\\CurrentControlSet\\Services\\"};
	memset(szDescription, 0, sizeof(szDescription));
	strcat(KeyPath, argv[2]);
	if(ReadReg(HKEY_LOCAL_MACHINE,	KeyPath, "Description", szDescription, sizeof(szDescription)))
		SendMessage(Socket, "SERVICE_NAME: %s\r\nDESCRIPTION: %s\r\n", argv[2], szDescription);
	else
		SendMessage(Socket, "GetServiceDescription: FAILED.\r\n");

	return TRUE;
}

BOOL ChangeServiceDescription(MainPara *args, IN SC_HANDLE  SchSCManager)
{
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;
	if(argc < 4)
	{
		SendMessage(Socket, "Usage: %s %s ServiceKeyName description\r\n", argv[0], argv[1]);
		return FALSE;
	}

	char KeyPath[MAX_PATH] = {"SYSTEM\\CurrentControlSet\\Services\\"};
	strcat(KeyPath, argv[2]);
	if(WriteReg(HKEY_LOCAL_MACHINE, KeyPath, "Description", REG_SZ, argv[3], NULL, 1))
		SendMessage(Socket, "ChangeServiceDescription: %s SUCCESS.\r\n", argv[2]);
	else
		SendMessage(Socket, "ChangeServiceDescription: FAILED.\r\n");

	return TRUE;
}

BOOL ChangeServiceConfig(
  SC_HANDLE  SchSCManager,
  SC_HANDLE hService,
  DWORD dwServiceType,
  DWORD dwStartType,
  LPCTSTR lpBinaryPathName,
  LPCTSTR lpDisplayName
)
{
	BOOL bError = TRUE;
	SC_LOCK sclLock; 

	// Need to acquire database lock before reconfiguring. 

	sclLock = LockServiceDatabase(SchSCManager); 

	// If the database cannot be locked, report the details. 

	if (sclLock == NULL) 
		return FALSE;

    bError = ChangeServiceConfig( 
        hService,          // handle of service 
        dwServiceType,
        dwStartType,
        SERVICE_NO_CHANGE, // error control: no change 
        lpBinaryPathName,
        NULL,              // load order group: no change 
        NULL,              // tag ID: no change 
        NULL,              // dependencies: no change 
        NULL,              // account name: no change 
        NULL,              // password: no change 
        lpDisplayName);

	UnlockServiceDatabase(sclLock); 
	return bError;
}


BOOL ReconfigureService(MainPara *args, IN SC_HANDLE  SchSCManager)
{
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;

	BOOL bError = TRUE;
	BOOL ret = FALSE;
	char *Usage = ""
		"sc config ServiceKeyName <option1> <option2>...\r\n"
		"-type  <own=0|share=1|interact=2|kernel=3|filesys=4>\r\n"
		"-start  <boot=0|system=1|auto=2|demand=3|disabled=4>\r\n"
		"-binPath  <BinaryPathName>\r\n"
		"-DisplayName  <display name>\r\n"
		"example:\r\n"
		"sc config svcname -start 2 -displayname newname\r\n"
		"sc config svcname -type 0 -type 2 -binPath newpath\r\n";
	if(argc < 4)
	{
		SendMessage(Socket,Usage);
		return FALSE;
	}
	DWORD dwServiceType = SERVICE_NO_CHANGE;
	DWORD dwStartType = SERVICE_NO_CHANGE;
	LPCTSTR lpBinaryPathName = NULL;
	LPCTSTR lpDisplayName = NULL;

    SC_HANDLE  schService;

    schService = OpenService(SchSCManager, argv[2], SERVICE_ALL_ACCESS);

    if (schService == NULL)
    {
        //sprintf(Temp, "failure: OpenService (0x %x)\n", GetLastError());
		//SendMessage(Socket,Temp);
		err_display(Socket, "ReconfigureService->OpenService", 1);
        return FALSE;
    }
	for(int i=2; i<argc; i++)
	{
		if(argv[i][0] == '-')
		{
			continue;
		}
		else
		{
			if(i==1) continue;
			if(!stricmp(&argv[i-1][1], "type"))
			{
				bError = FALSE;
				if(dwServiceType == SERVICE_NO_CHANGE)//��һ������
					dwServiceType = 0;
				switch(atoi(argv[i]))
				{
				case 0://own
					dwServiceType |= SERVICE_WIN32_OWN_PROCESS;
					break;
				case 1://share
					dwServiceType |= SERVICE_WIN32_SHARE_PROCESS;
					break;
				case 2://interact
					dwServiceType |= SERVICE_INTERACTIVE_PROCESS;
					break;
				case 3://kernel
					dwServiceType |= SERVICE_KERNEL_DRIVER;
					break;
				case 4://filesys
					dwServiceType |= SERVICE_FILE_SYSTEM_DRIVER;
					break;
				default:
					bError = TRUE;
				}
			}else if(!stricmp(&argv[i-1][1], "start"))
			{ //boot=0|system=1|auto=2|demand=3|disabled=4
				bError = FALSE;
				switch(atoi(argv[i]))
				{
				case 0:
					dwStartType = SERVICE_BOOT_START;
					break;
				case 1:
					dwStartType = SERVICE_SYSTEM_START;
					break;
				case 2:
					dwStartType = SERVICE_AUTO_START;
					break;
				case 3:
					dwStartType = SERVICE_DEMAND_START;
					break;
				case 4:
					dwStartType = SERVICE_DISABLED;
					break;
				}
			}else if(!stricmp(&argv[i-1][1], "binPath"))
			{
				bError = FALSE;
				lpBinaryPathName = argv[i];
			}else if(!stricmp(&argv[i-1][1], "DisplayName"))
			{
				bError = FALSE;
				lpDisplayName = argv[i];
			}
		}
	}
	if(bError == TRUE)
		SendMessage(Socket,Usage);
	else
	{
		ret = ChangeServiceConfig(SchSCManager, schService, dwServiceType, dwStartType, lpBinaryPathName, lpDisplayName);

		if(ret)
			SendMessage(Socket, "ChangeServiceConfig OK.\r\n");
		else
			SendMessage(Socket, "ChangeServiceConfig Unknown Error.\r\n");
	}

	CloseServiceHandle(schService);

	return TRUE;
}

int ServiceController(MainPara *args)
{
	SPAMFUNCTION
		
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;
	char *Usage = ""
"sc [ create | delete | start | stop | config | qc | query | qdescription |\r\n"
"     description | GetDisplayName | GetKeyName ]\r\n"
"create----------Creates a service. (adds it to the registry).\r\n"
"delete----------Deletes a service (from the registry).\r\n"
"start-----------Starts a service.\r\n"
"stop------------Sends a STOP request to a service.\r\n"
"config----------Modifies a service entry in the registry and Service Database.\r\n"
"qc--------------Queries the configuration information for a service.\r\n"
"query-----------Enumerates the info for all of the services.\r\n"
"qdescription----Queries the description for a service.\r\n"
"description-----Changes the description of a service.\r\n"
"GetDisplayName--Gets the DisplayName for a service.\r\n"
"GetKeyName------Gets the ServiceKeyName for a service.\r\n"
;
	if(argc < 2)
	{
		SendMessage(Socket, Usage);
		return 0;
	}
	BOOL nRet;
    SC_HANDLE   SchSCManager;

	SchSCManager = ZXSAPI::OpenSCManager(NULL,NULL,SC_MANAGER_ALL_ACCESS);
	if(SchSCManager == NULL)
	{
		//sprintf(Temp, "OpenschManager Error: %d\r\n",GetLastError());
		//SendMessage(Socket,Temp);
		err_display(Socket, "sc->OpenSCManager", 1);
		return FALSE;
	}

	if(!stricmp(argv[1], "create"))
		nRet = CreateService(args, SchSCManager);
	else if(!stricmp(argv[1], "delete"))
		nRet = DeleteService(args, SchSCManager);
	else if(!stricmp(argv[1], "start"))
		nRet = StartService(args, SchSCManager);
	else if(!stricmp(argv[1], "stop"))
		nRet = StopService(args, SchSCManager);
	else if(!stricmp(argv[1], "config"))
		nRet = ReconfigureService(args, SchSCManager);
	else if(!stricmp(argv[1], "qc"))
		nRet = ViewService(args, SchSCManager);
	else if(!stricmp(argv[1], "query"))
		nRet = EnumService(Socket, SchSCManager);
	else if(!stricmp(argv[1], "GetDisplayName"))
		nRet = GetServiceDisplayName(args, SchSCManager);
	else if(!stricmp(argv[1], "GetKeyName"))
		nRet = GetServiceKeyName(args, SchSCManager);
	else if(!stricmp(argv[1], "qdescription"))
		nRet = GetServiceDescription(args, SchSCManager);
	else if(!stricmp(argv[1], "description"))
		nRet = ChangeServiceDescription(args, SchSCManager);
	else
		SendMessage(Socket, Usage);

	CloseServiceHandle(SchSCManager);
	return nRet;

}

