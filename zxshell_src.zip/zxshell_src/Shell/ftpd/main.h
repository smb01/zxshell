#ifndef _MAIN_H
#define _MAIN_H

#include <winsock2.h>
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <memory.h>

#pragma comment(lib, "ws2_32.lib")

#endif