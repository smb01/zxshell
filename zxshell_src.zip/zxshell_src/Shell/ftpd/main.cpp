#define _WIN32_WINNT 0x0500 
#include "main.h"

#include "ZXFTPD.cpp"
#include "CONN.cpp"
#include "FTPSERVER.cpp"

int Usage(SOCKET Socket)
{
	char tmp[8192];
	sprintf(tmp, "\
ZXFtpServer v1.0.\r\n\
Usage:\r\n\
      ZXFtpServer [ListenPort] [DataPort] [UserName] [Password] [HomeDir] -IsAnony <1|0> -Access <RWLCD> -VirPath <virname|path> -AllowIP <IP> -DenyIP <IP> [-quit] [-view]\r\n\
\r\n\
Example:\r\n\
      ZXFtpServer 21 20 zx ok c:\\ -IsAnony 1 -Access RL -VirPath MyDir1|C:\\aa,MyDir2|C:\\bb\r\n\
      ZXFtpServer 21 20 zx hi c:\\ -IsAnony 0 -Access RWLCD -VirPath MyComputer -AllowIP 202.* -DenyIP 202.4.*\r\n\
      ZXFtpServer -view (View Server Info)\r\n\
      ZXFtpServer -quit (End The Server)\r\n\
");

	//printf("%s", tmp);
	SendMessage(Socket, tmp);
	return 0;
}


ZXFTPD ZXFtp;//Global Variable


DWORD WINAPI ZXFtpServer(MainPara *args)
{
	SOCKET Socket = args->Socket;

	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();

	int CtrlPort, DataPort, IsAnony = 0;
	char *UserName, *Password, *HomeDir;
	char *AllowIP = NULL, *DenyIP = NULL;
	char *Access = "RWLCD";
	char *VirPath = "";
//////////////////////

	for(int i=1; i<argc; i++)
	{
		if(argv[i][0] == '-' || argv[i][0] == '/')
		{
			if(!stricmp(&argv[i][1], "quit"))
			{
				ZXFtp.Quit(Socket);
				return 0;
			}
			if(!stricmp(&argv[i][1], "view"))
			{
				ZXFtp.View(Socket);
				return 0;
			}
		}
		else
		{
			if(i==1) continue;
			if(!stricmp(&argv[i-1][1], "help"))
			{
				return Usage(Socket);
			}else if(!stricmp(&argv[i-1][1], "AllowIP"))
			{
				AllowIP = argv[i];
			}else if(!stricmp(&argv[i-1][1], "DenyIP"))
			{
				DenyIP = argv[i];
			}else if(!stricmp(&argv[i-1][1], "IsAnony"))
			{
				IsAnony = atoi(argv[i]);
			}else if(!stricmp(&argv[i-1][1], "Access"))
			{
				Access = argv[i];
			}else if(!stricmp(&argv[i-1][1], "VirPath"))
			{
				VirPath = argv[i];
			}

		}
	}

	if(argc < 6)
		return Usage(Socket);

	if(ZXFtp.IsFtpRunning())
		return SendMessage(Socket, "FtpServer Is Already Running.\r\n");

	CtrlPort = atoi(argv[1]);
	DataPort = atoi(argv[2]);
	UserName = argv[3];
	Password = argv[4];
	HomeDir = argv[5];
	ZXFtp.Config(CtrlPort, DataPort, HomeDir, Access, VirPath, AllowIP, DenyIP);
	ZXFtp.SetUserPassword(UserName, Password);
	ZXFtp.SetAnonymousAccess(IsAnony);

	ZXFtp.Startup();

	if(! ZXFtp.InitSocket())
	{
		SendMessage(Socket, "InitSocket Failed. Try to change a Port and then try again.\r\n");
		return 0;
	}
	SendMessage(Socket, "ZXFtpServer Started Successfully.\r\n");
	return ZXFtp.RunApp();

}
