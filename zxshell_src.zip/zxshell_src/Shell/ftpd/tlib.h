#ifndef TLIB_H
#define TLIB_H
#include "main.h"
#include "..\..\zxsCommon\link.h"
#include "..\..\zxsCommon\MD5Class\MD5A.cpp"
#include "..\..\zxsCommon\MD5Class\XMD5.cpp"

#include "..\..\zxsCommon\CRC32Class\CRC32.cpp"
#include "..\..\zxsCommon\CRC32Class\CRCFile.cpp"

static CRITICAL_SECTION cs;
#define MAXBUFSIZE 8192
#define WM_SOCKET (WM_USER+1)


#define MAX_NAME_LEN    128
#define MAX_PWD_LEN     128
#define MAX_RESP_LEN    1024
#define MAX_REQ_LEN     256
#define MAX_IP_LEN      80

class FTPCONFIG
{
public:
	TCHAR HomeDir[MAX_PATH];
	TCHAR UserName[128];
	TCHAR Password[128];
	char LocalAddr[32];
	TCHAR VirPath[MAX_PATH];
	WORD DataPort;
	BOOL IsAllowedAnonymous;
	DWORD FtpAccess;
};

typedef struct _FILE_INFO{
    TCHAR           szFileName[MAX_PATH];
    DWORD           dwFileAttributes; 
    FILETIME        ftCreationTime; 
    FILETIME        ftLastAccessTime; 
    FILETIME        ftLastWriteTime; 
    DWORD           nFileSizeHigh; 
    DWORD           nFileSizeLow; 
} FILE_INFO, *LPFILE_INFO;

struct VIRPATHINFO
{
	char *VirName;
	char *VirPath;
VIRPATHINFO()
{
	VirName = VirPath = NULL;
}
};

class VIRDIRECTORY:public LINKTABLE<VIRPATHINFO>
{
public:
	~VIRDIRECTORY();
	BOOL GetVirPathByVirName(char *VirName, char *VirPath, int buflen);
	void GetAllVirDirName(QUEUE<char *> *DirName);
};


class FTPSERVER
{
protected:

	char CmdBuf[MAX_PATH];
	char TempBuf[MAX_PATH];
	char CurrPath[MAX_PATH];
	char szMsgBuf[MAX_RESP_LEN];
	char *HomeDir;
	char *VirPath;
	char *UserName;
	char *Password;

	WORD DataPort;
	WORD PasvPort;
	DWORD IdleTimeOut;

	int recvbytes;
	int sendbytes;
	int BytesToSend;
	int BytesSent;

	char USER[MAX_NAME_LEN];
	char PASS[MAX_PWD_LEN];

	BOOL IsGetUser;
	BOOL IsLoggedIn;

	DWORD FtpAccess;
	BOOL AnonymousAccess;

public:
	SOCKET ClientSock;
	SOCKET PasvSock;
	SOCKET DataSock;
	BOOL TransferMode;
	VIRDIRECTORY VirDir;

	FTPSERVER();
	~FTPSERVER();
	void Init(FTPCONFIG *pFtpCfg, SOCKET s);
	int Welcome();
	DWORD SetAccess(char *strAccess);
	BOOL VerifyAccess(DWORD Access);
	BOOL Loginsvc(char *User, char *Pass);
	int SetTimeOut(SOCKET Socket,int nTimeOut);
	BOOL GetLocalAddress(char *OutIP);
	int GetCMD();
	int ParseCMD();
	BOOL CaseCmd(char *CMD, char *Msg);
	int DataSend(SOCKET s, const char *buff, int len);
	int DataRecv(SOCKET s, char *buff, int bufsize);
	int WriteToFile(HANDLE hFile, char *Buff, int Datalen);
	int SendResponse(int StateNum, char *szMsg);
	__int64 FindFile(char *lpFileName);
	int GetLocalPath(char *szLocal, int bufsize, char *szParam);
	SOCKET CreateSocket(const char *HostIP, const WORD Port);
	int FileInfoToList(LPFILE_INFO pFI, int FileNum, char *buff, int bufsize);
	int GetFileList(char *szParam);
	int MakeFileList(LPFILE_INFO lpFI, char *buff, char *DirPath, BOOL IsListSubDir);
	BOOL IsInHomeDir(char *lpFileName);
	int GetAllVirDirName(QUEUE<char *> *DirName);
	__int64 Transmitfile(SOCKET sd, HANDLE hFile, __int64 size);
	BOOL IsAbort();
	BOOL ReadVirPathInfo();

	DWORD dwIP;
	WORD wPort;
	BOOL CMD_PORT(char *szParam);
	BOOL CMD_PASV();
	BOOL PasvAccept();
	BOOL ConnectRemote();
	BOOL OpenDataConn();
	void CloseDataConn();

	BOOL CMD_HELP();
	BOOL CMD_SYST();
	BOOL CMD_PWD();
	BOOL CMD_CWD(char *szParam);
	BOOL CMD_LIST(char *szParam);
	BOOL CMD_TYPE(char *szParam);
	BOOL CMD_ABOR();
	BOOL CMD_SIZE(char *szParam);

	__int64 Marker;
	BOOL CMD_MDTM(char *szParam);
	BOOL CMD_REST(char *szParam);//
	BOOL CMD_RETR(char *szParam);//
	BOOL CMD_STOR(char *szParam);//
	BOOL CMD_APPE(char *szParam);
	


	BOOL CMD_MKD(char *szParam);
	BOOL CMD_RMD(char *szParam);
	BOOL CMD_DELE(char *szParam);
	BOOL IsGetRN;
	char FileForRename[MAX_PATH];
	BOOL CMD_RNFR(char *szParam);
	BOOL CMD_RNTO(char *szParam);

	BOOL CMD_FEAT();
	BOOL CMD_XMD5(char *szParam);
	BOOL CMD_XCRC(char *szParam);

};



enum{CTRLCONN, DATACONN, ACCEPTSOCK};

class CONN: public LINKTABLE<FTPSERVER*>
{
private:
	CRITICAL_SECTION cs_conn;
public:
	CONN();
	~CONN();
	int AddObject(FTPSERVER *Ftpsvr);
	int DelObject(FTPSERVER *Ftpsvr);
	int CloseAllObject();
};



class ZXFTPD
{
protected:
	HWND hWnd;
	SOCKET ListenSock;
	WORD ListenPort;

public:
	BOOL IsFtpRunning();
	void Quit(SOCKET Socket);
	void View(SOCKET Socket);

	char *AllowedIP;
	char *DeniedIP;
	FTPCONFIG FtpCfg;
	friend class FTPSERVER;

	SOCKET ListenSocket(){ return ListenSock;};
	BOOL Startup();
	BOOL Config(WORD lPort, WORD dPort, TCHAR *HomeDir, char *strAccess, char *VirPath, TCHAR *allowIP, TCHAR *denyIP);
	void SetAnonymousAccess(BOOL Flag);
	BOOL SetUserPassword(TCHAR *User, TCHAR *Pass);
	BOOL InitSocket();
	DWORD RunApp();
	void Cleanup();
	DWORD SetAccess(char *strAccess);

private:


	BOOL SetHomeDir(TCHAR *DirPath);
	BOOL GetLocalAddress();
	static LRESULT CALLBACK MainWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	static void ProcessSocketMessage(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	static DWORD WINAPI FtpServerThread(LPVOID lparam);

};

static BOOL DebugPrint(char *string)
{
	HANDLE hStdOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	DWORD nBytesToWrite = lstrlen(string);
	DWORD nBytesWritten;
	return WriteConsole(hStdOutput, string, nBytesToWrite, &nBytesWritten, NULL);
}
#endif
