#include "tlib.h"

#define	ReadAccess		0x01
#define	WriteAccess		0x02
#define	ListAccess		0x04
#define	CreateAccess	0x08
#define	DeleteAccess	0x10
#define	AppendAccess	0x20
#define	ExecuteAccess	0x40

CONN ClientList;

inline BOOL ZXFTPD::SetHomeDir(TCHAR *DirPath)
{
	int ret;
	char tmp[MAX_PATH];
	ret = SetCurrentDirectory(DirPath);
	if(! ret)
		return 0;
	else
	{
		GetCurrentDirectory(MAX_PATH, tmp);
		ZXSAPI::lstrcpy(FtpCfg.HomeDir, tmp);
	}
	return 1;
}

inline BOOL ZXFTPD::Config(WORD lPort, WORD dPort, TCHAR *HomeDir, char *strAccess, char *VirPath, TCHAR *allowIP, TCHAR *denyIP)
{
	ListenPort = lPort;
	FtpCfg.FtpAccess = SetAccess(strAccess);
	FtpCfg.DataPort = dPort;
	strcpy(FtpCfg.VirPath, VirPath);
	AllowedIP = allowIP;
	DeniedIP = denyIP;
	return SetHomeDir(HomeDir);
}

inline void ZXFTPD::SetAnonymousAccess(BOOL Flag)
{
	FtpCfg.IsAllowedAnonymous = Flag;
	return;
}

inline DWORD ZXFTPD::SetAccess(char *strAccess)//set user access
{
	DWORD FtpAccess = 0;
	for(char *p = strAccess; p && *p; p++)
	{
		switch(*p)
		{
		case 'R':
		case 'r':
			FtpAccess |= ReadAccess;
			break;
		case 'W':
		case 'w':
			FtpAccess |= WriteAccess;
			break;
		case 'L':
		case 'l':
			FtpAccess |= ListAccess;
			break;
		case 'C':
		case 'c':
			FtpAccess |= CreateAccess;
			break;
		case 'D':
		case 'd':
			FtpAccess |= DeleteAccess;
			break;
		case 'A':
		case 'a':
			FtpAccess |= AppendAccess;
			break;
		case 'E':
		case 'e':
			FtpAccess |= ExecuteAccess;
			break;
		}
	}
	return FtpAccess;
}

inline BOOL ZXFTPD::SetUserPassword(TCHAR *User, TCHAR *Pass)
{
	return _snprintf(FtpCfg.UserName, sizeof(FtpCfg.UserName), User) 
		&& _snprintf(FtpCfg.Password, sizeof(FtpCfg.Password), Pass);
}

inline BOOL ZXFTPD::Startup()
{
	WSAData wsa;
	if (WSAStartup(MAKEWORD(2, 0), &wsa))
		return false;

	WNDCLASS wnd;
	ZeroMemory(&wnd, sizeof(WNDCLASS));

	wnd.hbrBackground = (HBRUSH)COLOR_WINDOW;
	wnd.hCursor = LoadCursor(NULL, IDC_ARROW);
	wnd.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wnd.hInstance = NULL;
	wnd.lpfnWndProc = MainWndProc;
	wnd.lpszClassName = (TCHAR*)"ZXFtpServer";
	wnd.lpszMenuName = NULL;

	RegisterClass(&wnd);

	hWnd = CreateWindow((TCHAR*)"ZXFtpServer", "ZXFtpServer",
		WS_OVERLAPPEDWINDOW, 0, 0, 32, 32,
		NULL, NULL, NULL, NULL);

	if(!hWnd)
		return false;

	SetWindowLong(hWnd, GWL_USERDATA, (long)this);
	SetWindowPos(hWnd, NULL, 0,0,0,0, SWP_FRAMECHANGED);
	return true;
}

inline BOOL ZXFTPD::InitSocket()
{
	int retval;
	SOCKADDR_IN serveraddr;

	ListenSock = ZXSAPI::socket(AF_INET, SOCK_STREAM, 0);
	if(ListenSock == INVALID_SOCKET){
		goto error;
	}

	retval = WSAAsyncSelect(ListenSock, hWnd, WM_SOCKET, FD_ACCEPT|FD_CLOSE);
	if(retval == SOCKET_ERROR) {
		goto error;
	}
	
	ZeroMemory(&serveraddr, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(ListenPort);
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
	retval = ZXSAPI::bind(ListenSock, (SOCKADDR *)&serveraddr, sizeof(serveraddr));
	if(retval == SOCKET_ERROR){
		goto error;
	}

	retval = ZXSAPI::listen(ListenSock, SOMAXCONN);
	if(retval == SOCKET_ERROR){
		goto error;
	}
	return 1;
error:
	closesocket(ListenSock);
	ListenSock = 0;
	return 0;
}

inline void ZXFTPD::Cleanup()
{
	WSACleanup();
}

inline BOOL ZXFTPD::IsFtpRunning()
{
	return ListenSock;
}

inline void ZXFTPD::Quit(SOCKET Socket)
{
	if(!IsFtpRunning())
	{
		SendMessage(Socket, "FtpServer Is Not Running.\r\n");
		return;
	}
	ClientList.CloseAllObject();
	closesocket(ListenSock);
	ListenSock = 0;
	SendMessage(hWnd, WM_CLOSE, 0, 0);
	SendMessage(Socket, "FtpServer Ended Successfully.\r\n");

}

inline void ZXFTPD::View(SOCKET Socket)
{
	if(!IsFtpRunning())
	{
		SendMessage(Socket, "FtpServer Is Not Running.\r\n");
		return;
	}
	SendMessage(Socket,""
		"ListenPort: %d\r\n"
		"DataPort: %d\r\n"
		"UserName: %s\r\n"
		"Password: %s\r\n"
		"HomeDir:  %s\r\n"
		"AnonymousAccess: %s\r\n"
		"AllowedIP: %s\r\n"
		"DeniedIP:  %s\r\n"
		"Now Connections: %d\r\n",
		ListenPort,
		FtpCfg.DataPort,
		FtpCfg.UserName,
		FtpCfg.Password,
		FtpCfg.HomeDir,
		FtpCfg.IsAllowedAnonymous ? "Yes" : "No",
		AllowedIP,
		DeniedIP,
		ClientList.GetCount()
		);

}

inline DWORD ZXFTPD::RunApp()
{
	BOOL bRet;
	MSG msg;
	while( (bRet = GetMessage( &msg, NULL, 0, 0 )) != 0)
	{
		if (bRet == -1)
		{
			break;
		}
		else if(!IsDialogMessage(hWnd, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}
	Cleanup();
	return msg.wParam;
}
inline DWORD WINAPI ZXFTPD::FtpServerThread(LPVOID lparam)
{
	FTPSERVER *Ftpsvr = (FTPSERVER *)lparam;
	int retval;

	ClientList.AddObject(Ftpsvr);

	if(! Ftpsvr->Welcome())
		goto exit;
	while(1)
	{
		if(! Ftpsvr->GetCMD())
			goto exit;
		if(! Ftpsvr->ParseCMD())
			goto exit;
	}

exit:
	ClientList.DelObject(Ftpsvr);
	delete Ftpsvr;
	return 0;
}



int FormatPathString(char *Source, char *Dest, int buflen, bool flag)
{
#define IS_PATH_SEPARATOR(ch) ((ch == '\\') || (ch == '/'))
#define IS_DOT(s) ( s[0] == '.' && ( IS_PATH_SEPARATOR(s[1]) || s[1] == '\0') )
#define IS_DOT_DOT(s) ( s[0] == '.' && s[1] == '.' && ( IS_PATH_SEPARATOR(s[2]) || s[2] == '\0') )

	char ch = flag ? '\\' : '/';
	char *lpRetBuf = Dest;
	char *lproot = Dest;
	bool IsGetlpRoot = false;
	while ( *Source ) {
		switch ( *Source ) {

		case '\\' :
		case '/' :
			if  ( *(Dest-1) != ch ) {
				if(!IsGetlpRoot)
				{
					lproot = Dest;
					IsGetlpRoot = true;
				}
				*Dest++ = ch;

				if(Dest - lpRetBuf >= buflen -1)
					goto exit;
			}
			Source++;
			break;
            case '.' :
                //
                // Ignore dot in a leading //./
                // Eat single dots as in /./
                // Double dots back up one level as in /../
                // Any other . is just a filename character
                //

                if ( IS_DOT(Source) ) {
                    Source++;
                    if (IS_PATH_SEPARATOR(*Source)) {
                        Source++;
                        }
                    break;
                    }
                else if ( IS_DOT_DOT(Source) ) {

                    //
                    // backup destination string looking for
                    // a \
                    //

                    while (*Dest != ch && Dest > lpRetBuf)
						Dest--;

                    //
                    // backup to previous component..
                    // \a\b\c\.. to \a\b
                    //

                    do {

                        //
                        // If we bump into root prefix, then
                        // stay at root
                        //

                        if (Dest == lproot) {
                            break;
                            }

                        Dest--;

                        } while (*Dest != ch);
                    if ( Dest ==  lproot && *Dest == ch) {
                        Dest++;
                        }

                    //
                    // Advance source past ..
                    //

                    Source += 2;

                    break;
                    }

                //
                // FALLTHRU
                //
		default:
			while ( *Source && !IS_PATH_SEPARATOR(*Source)) {
				*Dest++ = *Source++;

				if(Dest - lpRetBuf >= buflen -1)
					goto exit;
			}
		}
	}
exit:
	*Dest = '\0';
	return Dest - lpRetBuf;
}

unsigned long getsockdwIP(SOCKET s)
{
	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(clientaddr);
	if(getpeername(s, (SOCKADDR *)&clientaddr, &addrlen) == SOCKET_ERROR)
		return 0;
	return clientaddr.sin_addr.S_un.S_addr;
}

unsigned short getsockport(SOCKET s)
{
	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(clientaddr);
	if(getpeername(s, (SOCKADDR *)&clientaddr, &addrlen) == SOCKET_ERROR)
		return 0;
	return ntohs(clientaddr.sin_port);
}

//"c:\windows\notepad.exe" return "c:\windows\"
char *GetPath(char *FullPath, char *Path)
{
	char *sp = FullPath;
	int Len=0;
	sp += strlen(FullPath) - 1;
	while(*sp != '\\' && sp > FullPath){
		sp--;
		Len++;
	}
	strncpy(Path, FullPath, strlen(FullPath)-Len);
	Path[strlen(FullPath)-Len] = '\0';
	return Path;
}

/*
��Source�ַ�������ָ��char�ֶ�д�絽Dest�������С�
����ֵΪSource�е���һ���ε����ָ��
��:
Source = "1234  , 321, 43,333"
Dest���õ� "1234"
����ָ��ָ��" 321, 43,333"
*/
static const char *TakeOutStringByChar(IN const char *Source, OUT char *Dest, int buflen, char ch)
{
	if(Source == NULL)
		return NULL;

	const char *p = strchr(Source, ch);

	while(*Source == ' ')
		Source++;
	for(int i=0; i<buflen && *(Source+i) && *(Source+i) != ch; i++)
	{
		Dest[i] = *(Source+i);
	}
	if(i == 0)
		return NULL;
	else
		Dest[i] = '\0';

	const char *lpret = p ? p+1 : Source+i;

	while(Dest[i-1] == ' ' && i>0)
		Dest[i---1] = '\0';

	return lpret;
}



//destIP = "22.22.22.1-22.22.*"
static BOOL Is_szIP_in_range(char *sourceIP, char *destIP)
{
	BOOL flag = TRUE;
	char *sip = sourceIP;
	char *dip = destIP;
	while(sip && dip)
	{
		if(*dip == '*')
			break;
		if(*sip != *dip)
		{
			flag = FALSE;
			break;
		}
		if(*sip =='\0' && *dip == '\0')
			break;
		sip++;
		dip++;
	}
	return flag;
}

//destIP = "22.22.22.1-22.22.22.7"
static BOOL Is_dwIP_in_range(char *sourceIP, char *destIP)
{
	const char *nextip;
	char startip[32], endip[32];

	nextip = TakeOutStringByChar(destIP, startip, sizeof(startip), '-');

	if(nextip)
		TakeOutStringByChar(nextip, endip, sizeof(endip), NULL);
	else
		return FALSE;

	DWORD dwIP, srcIP, IP_start, IP_end;

	dwIP = inet_addr(sourceIP);
	if(dwIP == INADDR_NONE)
		return FALSE;

	srcIP = ntohl(dwIP);

	dwIP = inet_addr(startip);
	if(dwIP == INADDR_NONE)
		return FALSE;

	IP_start = ntohl(dwIP);

	dwIP = inet_addr(endip);
	if(dwIP == INADDR_NONE)
		return FALSE;

	IP_end = ntohl(dwIP);

	if(srcIP >= IP_start && srcIP <= IP_end)
		return TRUE;
	else
		return FALSE;
}

static BOOL Is_IP_in_range(char *sourceIP, char *destIP)
{
	if(strchr(destIP, '-'))//example: xx.xx.xx.1-xx.xx.xx.5
	{
		if(Is_dwIP_in_range(sourceIP, destIP))
			return TRUE;
		else
			return FALSE;
	}else//example: 202.96.*
	{
		if(Is_szIP_in_range(sourceIP, destIP))
			return TRUE;
		else
			return FALSE;
	}
}

static BOOL IP_Filter(SOCKET s, const char *AllowedIP, const char *DeniedIP)
{
	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(clientaddr);
	if(getpeername(s, (SOCKADDR *)&clientaddr, &addrlen) == SOCKET_ERROR)
		return FALSE;
	IN_ADDR iaddr = clientaddr.sin_addr;
	char *IP = inet_ntoa(iaddr);
	char filterIP[64] = {0};
	BOOL IsAllowed;
	const char *p;
	p = TakeOutStringByChar(AllowedIP, filterIP, sizeof(filterIP), ',');
	if(p)
		IsAllowed = FALSE;
	else
		IsAllowed = TRUE;
	while(p)
	{
		if(Is_IP_in_range(IP, filterIP))
		{
			IsAllowed = TRUE;
			break;
		}
		p = TakeOutStringByChar(p, filterIP, sizeof(filterIP), ',');
	}
	p = DeniedIP;
	while(p = TakeOutStringByChar(p, filterIP, sizeof(filterIP), ','))
	{
		if(Is_IP_in_range(IP, filterIP))
			return FALSE;
	}
	return IsAllowed;
}


inline void ZXFTPD::ProcessSocketMessage(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{

	SOCKET AcceptSocket;
	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(clientaddr);
	ZXFTPD *pZXFTPD = (ZXFTPD *)GetWindowLong(hWnd, GWL_USERDATA);///
	int retval = 0;
	FTPSERVER *Ftpsvr;
	HANDLE hThread;
	DWORD dwThreadID;
	if(WSAGETSELECTERROR(lParam)){
		return;
	}

	switch(WSAGETSELECTEVENT(lParam)){
	case FD_ACCEPT:

		AcceptSocket = ZXSAPI::accept(wParam, (SOCKADDR *)&clientaddr, &addrlen);
		if(!IP_Filter(AcceptSocket, pZXFTPD->AllowedIP, pZXFTPD->DeniedIP))
		{
			closesocket(AcceptSocket);
			return;
		}
		if(AcceptSocket == INVALID_SOCKET){
			return;
		}

		Ftpsvr = new FTPSERVER;
		if(Ftpsvr == NULL)
			return;
		Ftpsvr->Init(&pZXFTPD->FtpCfg, AcceptSocket);

		retval = WSAAsyncSelect(AcceptSocket, hWnd, 0, 0);
		if(retval == SOCKET_ERROR){
			return;
		}
		retval = ioctlsocket(AcceptSocket, FIONBIO, (u_long FAR*) &retval);
		hThread = ZXSAPI::CreateThread(NULL, NULL, FtpServerThread, (LPVOID)Ftpsvr, 0, &dwThreadID);
		if(hThread == NULL)
			delete Ftpsvr;
		else
			CloseHandle(hThread);

		break;

	case FD_CLOSE:
		WSAAsyncSelect(wParam, hWnd, 0, 0);
		closesocket(wParam);
		break;
	}
}
inline LRESULT CALLBACK ZXFTPD::MainWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
	case WM_SOCKET:
		ProcessSocketMessage(hWnd, uMsg, wParam, lParam);
		return 0;
	case WM_COMMAND:
		break;

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}