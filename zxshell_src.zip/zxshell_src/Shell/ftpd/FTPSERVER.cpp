#include "tlib.h"

#define USER_OK         331
#define LOGGED_IN       230
#define LOGIN_FAILED    530
#define CMD_OK          200
#define TRANS_COMPLETE  226
#define FTP_QUIT        221
#define DIR_OK          257
#define DIR_CHANGED     250
#define OS_TYPE         215
#define FILE_SIZE       213
#define REPLY_MARKER    504

#define PASSIVE_MODE    227
#define PORT_MODE		150

#define MAX_FILE_NUM	128
#define DATA_BUFSIZE	MAX_FILE_NUM*(MAX_PATH+64)


inline FTPSERVER::FTPSERVER()
{
	memset(this, 0, sizeof(FTPSERVER));
}
inline FTPSERVER::~FTPSERVER()
{
	closesocket(ClientSock);
	if(DataSock)
		closesocket(DataSock);
	if(PasvSock)
		closesocket(PasvSock);
}
inline void FTPSERVER::Init(FTPCONFIG *pFtpCfg, SOCKET s)
{
	HomeDir = pFtpCfg->HomeDir;
	strcpy(CurrPath, "/");
	VirPath = pFtpCfg->VirPath;
	UserName = pFtpCfg->UserName;
	Password = pFtpCfg->Password;
	DataPort = pFtpCfg->DataPort;
	PasvPort = pFtpCfg->DataPort;
	FtpAccess = pFtpCfg->FtpAccess;
	AnonymousAccess = pFtpCfg->IsAllowedAnonymous;
	ClientSock = s;
	IdleTimeOut = 777;
}

inline BOOL FTPSERVER::GetLocalAddress(char *OutIP)
{
	struct hostent* pHostent; 
    struct in_addr  addr ;
	int    i = 0;
	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(clientaddr);
	if(getpeername(ClientSock, (SOCKADDR *)&clientaddr, &addrlen) == SOCKET_ERROR)
		return 0;
	if(clientaddr.sin_addr.S_un.S_un_b.s_b1 == 127)//�ͻ����Ǳ��ص����
	{
		strcpy(OutIP, inet_ntoa(clientaddr.sin_addr));
		return 1;
	}
	pHostent = gethostbyname(NULL);

	if(pHostent != NULL)
	{
    	while(pHostent->h_addr_list[i] != NULL)
		{
			memcpy(&addr, pHostent->h_addr_list[i], sizeof(addr));
            if(addr.S_un.S_un_b.s_b1 == 192 && addr.S_un.S_un_b.s_b2 == 168)
			{
				strcpy(OutIP, inet_ntoa(addr));
				//return true if the client ip is also LAN ip;
				if(clientaddr.sin_addr.S_un.S_un_b.s_b1 == 192 && clientaddr.sin_addr.S_un.S_un_b.s_b2 == 168)
					return 1;
			}
		    else if(addr.S_un.S_un_b.s_b1 == 172 && addr.S_un.S_un_b.s_b2 >= 16 && addr.S_un.S_un_b.s_b2 <= 131)
			{
				strcpy(OutIP, inet_ntoa(addr));
				if(clientaddr.sin_addr.S_un.S_un_b.s_b1 == 172 && clientaddr.sin_addr.S_un.S_un_b.s_b2 >= 16 && clientaddr.sin_addr.S_un.S_un_b.s_b2 <= 131)
					return 1;
			}
		    else if(addr.S_un.S_un_b.s_b1 == 10)
			{
				strcpy(OutIP, inet_ntoa(addr));
				if(clientaddr.sin_addr.S_un.S_un_b.s_b1 == 10)
					return 1;
			}
            else
			{
				strcpy(OutIP, inet_ntoa(addr));
				return 1;
			}
		    i++;
		}
		return 1;
	}
	return 0;
}


inline int FTPSERVER::Welcome()
{
	char *szWelMsg = "Welcome to ZXFtpServer Shell Edition 1.1";
	return SendResponse(220, szWelMsg);
}

inline int FTPSERVER::GetCMD()
{
    int nRetVal = 0;
	int cmdlen = 0;
	char *RecvBuf = CmdBuf;
	while(1)
	{
		nRetVal = SetTimeOut(ClientSock, IdleTimeOut);
		if(nRetVal == SOCKET_ERROR)
		{
			SendResponse(426, "Connection closed; transfer aborted.");
			return 0;
		}else if(nRetVal == 0)
		{
			SendResponse(421, "Connection timed out - closing.");
			return 0;
		}
		nRetVal = recv(ClientSock, RecvBuf+cmdlen, MAX_CMD_LEN - cmdlen - 1, 0);
		if(nRetVal <= 0)
			return 0;
		RecvBuf[cmdlen+nRetVal] = '\0';

		char *pCmd = RecvBuf+cmdlen;
		///////////////����β�ַ�������лس������򷵻�
		char *pCR = NULL, *pLF = NULL;
		pCR = strchr(pCmd, '\r');
		if(pCR)
			*pCR = '\0';
		pLF = strchr(pCmd, '\n');
		if(pLF)
			*pLF = '\0';
		if(pCR || pLF)
			return 1;
		//////////////
		cmdlen += nRetVal;
	}
    return 0;
}

inline int FTPSERVER::DataSend(SOCKET s, const char *buff, int len)
{
    int nBytesLeft = len;
    int idx = 0, nBytes = 0;

	int Result;
	fd_set FdWrtie;
	while(nBytesLeft > 0) 
	{
		FD_ZERO(&FdWrtie);
		FD_SET(s,&FdWrtie);
		Result = select(s+1,NULL,&FdWrtie,NULL,NULL);
		if(Result <= 0)
			return 0;
		nBytes = ZXSAPI::send(s, &buff[idx], nBytesLeft, 0);
        if(nBytes <= 0) 
		{
            return idx;
        }
        nBytesLeft -= nBytes;
        idx += nBytes;
	}
    return idx;
}
inline int FTPSERVER::SetTimeOut(SOCKET Socket,int nTimeOut)
{   
	fd_set FdRead;
	struct timeval TimeOut;
	FD_ZERO(&FdRead);
	FD_SET(Socket,&FdRead);
	TimeOut.tv_sec  = nTimeOut;
	TimeOut.tv_usec = 0;
	return select(Socket+1,&FdRead,NULL,NULL,&TimeOut);
}
inline int FTPSERVER::SendResponse(int StateNum, char *szMsg)
{
	int nRetVal;

	nRetVal = _snprintf(szMsgBuf, sizeof(szMsgBuf), 
			"%d %s\r\n", StateNum, szMsg);

	return DataSend(ClientSock, szMsgBuf, nRetVal);
}


BOOL FTPSERVER::VerifyAccess(DWORD Access)//verify user access
{
	return FtpAccess & Access;
}

inline BOOL FTPSERVER::Loginsvc(char *CMD, char *szParam)
{
    IsLoggedIn = FALSE;

	if(stricmp(CMD, "USER") && stricmp(CMD, "PASS"))
	{
		SendResponse(LOGIN_FAILED, "Please login with USER and PASS.");
		return 0;
	}
	if(! stricmp(CMD, "USER"))
	{
		_snprintf(USER, sizeof(USER), "%s", szParam);
		IsGetUser = strlen(szParam);
			
		if(! stricmp(szParam, "anonymous") && AnonymousAccess)
			_snprintf(TempBuf, sizeof(TempBuf), 
				"Anonymous access allowed, send identity (e-mail name) as password.");
		else
			_snprintf(TempBuf, sizeof(TempBuf), 
				"Password required for %s.", USER);
		SendResponse(USER_OK, TempBuf);
		return 1;
	}
	if(! IsGetUser)
	{
		SendResponse(503, "Login with USER first.");
		return 0;
	}
	if(! stricmp(CMD, "PASS"))
	{
		_snprintf(PASS, sizeof(PASS), "%s", szParam);
		//do authorization
		IsLoggedIn = !stricmp(USER, UserName) && !strcmp(PASS, Password);
		if(! stricmp(USER, "anonymous") && AnonymousAccess)
			IsLoggedIn = TRUE;
		if(IsLoggedIn)
		{
			_snprintf(TempBuf, sizeof(TempBuf), 
				"%s user logged in.", USER);
			SendResponse(LOGGED_IN, TempBuf);
			if(! stricmp(USER, "anonymous"))
			{
				FtpAccess = 0;
				FtpAccess |= ReadAccess;
				FtpAccess |= ListAccess;
			}
			ReadVirPathInfo();
		}
		else
		{
			_snprintf(TempBuf, sizeof(TempBuf), 
				"User %s cannot log in.", USER);
			SendResponse(LOGIN_FAILED, TempBuf);
		}
		IsGetUser = 0;
		
		return 1;
	}
    return 1;
}

inline BOOL FTPSERVER::CMD_HELP()
{
	char Help[] =
"214-The following  commands are recognized\n\
   QUIT\n\
   USER\n\
   ABOR\n\
   NOOP\n\
   SYST\n\
   TYPE\n\
   PASV\n\
   PORT\n\
   LIST\n\
   PWD\n\
   XPWD\n\
   CWD\n\
   XCWD\n\
   CDUP\n\
   XCUP\n\
   MKD\n\
   XMKD\n\
   RMD\n\
   XRMD\n\
   DELE\n\
   RNFR\n\
   RNTO\n\
   NLST\n\
   SIZE\n\
   MDTM\n\
   REST\n\
   RETR\n\
   STOR\n\
   APPE\n\
   XCRC\n\
   XMD5\n\
";
	DataSend(ClientSock, Help, sizeof(Help)-1);
	return SendResponse(214, "HELP command successful.");
}

inline BOOL FTPSERVER::CaseCmd(char *CMD, char *Msg)
{
	return !stricmp(CMD, Msg);
}

inline int FTPSERVER::ParseCMD()
{
	char CMD[MAX_PATH], szParam[MAX_PATH];
	memset(CMD, 0, sizeof(CMD));
	memset(szParam, 0, sizeof(szParam));

	const char *p = TakeOutStringByChar(CmdBuf, CMD, MAX_PATH, ' ');
	if(p)
		_snprintf(szParam, sizeof(szParam), "%s", p);

	if(CaseCmd(CMD, "QUIT"))
	{
		SendResponse(FTP_QUIT, "Farewell.");
		return 0;
	}else if(CaseCmd(CMD, "HELP"))
		CMD_HELP();
	else if(! IsLoggedIn || CaseCmd(CMD, "USER"))
		Loginsvc(CMD, szParam);
	else if(CaseCmd(CMD, "ABOR"))
		return CMD_ABOR();
	else if(CaseCmd(CMD, "SYST"))
		CMD_SYST();
	else if(CaseCmd(CMD, "FEAT"))
		CMD_FEAT();
	else if(CaseCmd(CMD, "TYPE"))
		CMD_TYPE(szParam);
	else if(CaseCmd(CMD, "PWD") || CaseCmd(CMD, "XPWD"))
		CMD_PWD();
	else if(CaseCmd(CMD, "CWD") || CaseCmd(CMD, "XCWD"))
		CMD_CWD(szParam);
	else if(CaseCmd(CMD, "CDUP") || CaseCmd(CMD, "XCUP"))
		CMD_CWD("..");
	else if(CaseCmd(CMD, "NOOP"))
		SendResponse(CMD_OK, "NOOP command successful.");
	else if(CaseCmd(CMD, "PASV"))
		CMD_PASV();
	else if(CaseCmd(CMD, "PORT"))
		CMD_PORT(szParam);
	else if(CaseCmd(CMD, "LIST") || CaseCmd(CMD, "NLST"))
		CMD_LIST(szParam);
	else if(CaseCmd(CMD, "SIZE"))
		CMD_SIZE(szParam);
	else if(CaseCmd(CMD, "MDTM"))
		CMD_MDTM(szParam);
	else if(CaseCmd(CMD, "REST"))
		CMD_REST(szParam);
	else if(CaseCmd(CMD, "RETR"))
		CMD_RETR(szParam);
	else if(CaseCmd(CMD, "STOR"))
		CMD_STOR(szParam);
	else if(CaseCmd(CMD, "APPE"))
		CMD_APPE(szParam);
	else if(CaseCmd(CMD, "MKD") || CaseCmd(CMD, "XMKD"))
		CMD_MKD(szParam);
	else if(CaseCmd(CMD, "RMD") || CaseCmd(CMD, "XRMD"))
		CMD_RMD(szParam);
	else if(CaseCmd(CMD, "DELE"))
		CMD_DELE(szParam);
	else if(CaseCmd(CMD, "RNFR"))
		CMD_RNFR(szParam);
	else if(CaseCmd(CMD, "RNTO"))
		CMD_RNTO(szParam);
	else if(CaseCmd(CMD, "XMD5"))//////////
		CMD_XMD5(szParam);
	else if(CaseCmd(CMD, "XCRC"))//////////
		CMD_XCRC(szParam);
	else
	{
		_snprintf(TempBuf, sizeof(TempBuf),
				"'%s': command not understood.", CMD);
		SendResponse(500, TempBuf);
	}
	return 1;
}

inline BOOL FTPSERVER::CMD_TYPE(char *szParam)
{
	if(lstrlen(szParam) == 0)
	{
		_snprintf(TempBuf, sizeof(TempBuf), 
			"Type set to %s.", "A");
	}else
	{
		_snprintf(TempBuf, sizeof(TempBuf), 
			"Type set to %s.", szParam);
	}
	return SendResponse(CMD_OK, TempBuf);
}

inline BOOL FTPSERVER::CMD_SYST()
{
	DWORD dwVersion = GetVersion();
	
	// Get the Windows version.

	DWORD dwWindowsMajorVersion =  (DWORD)(LOBYTE(LOWORD(dwVersion)));
	DWORD dwWindowsMinorVersion =  (DWORD)(HIBYTE(LOWORD(dwVersion)));

	// Get the build number.

	if (dwVersion < 0x80000000)              
		return SendResponse(OS_TYPE, "Windows_NT");
	else                                     // Windows Me/98/95
		return SendResponse(OS_TYPE, "Windows Me/98/95");;

}


inline SOCKET FTPSERVER::CreateSocket(const char *HostIP, const WORD Port)
{
	if(PasvSock != 0)//��ֹ�ظ�����
		return PasvSock;
	struct sockaddr_in Local;
	SOCKET sock;
	int nLevel = 1;
	SOCKET Accepts = INVALID_SOCKET;
	memset(&Local, 0, sizeof(Local));

	Local.sin_family = AF_INET;
	Local.sin_port = htons(Port);
	Local.sin_addr.s_addr = inet_addr(HostIP);

	sock = ZXSAPI::WSASocket(PF_INET, SOCK_STREAM,IPPROTO_TCP,NULL,0,0);
	if(sock == INVALID_SOCKET)
		return 0;
    if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR,
        (const char FAR *)&nLevel, sizeof(nLevel)) != 0) {
        goto error;
    }
	if(ZXSAPI::bind(sock, (const SOCKADDR *)&Local,sizeof(Local)) == SOCKET_ERROR)
		goto error;
	if(ZXSAPI::listen(sock, SOMAXCONN) == SOCKET_ERROR)
		goto error;

	PasvSock = sock;
	return sock;
error:
	closesocket(sock);
	return 0;
}

inline BOOL FTPSERVER::CMD_PORT(char *szParam)
{
	char Addr[32] = {0}, Port[8] = {0};
	char *p = szParam;
	int i = 0, j = 0;
//127,0,0,1,4,1
	while(p = strchr(p, ','))
	{
		i++;
		*p = '.';
		if(i==4)
		{
			if(p-szParam < 32)
				strncpy(Addr, szParam, p-szParam);
			else
				goto error;
			strncpy(Port, p+1, 7);
		}
	}
	if(i != 5)
		goto error;

	dwIP = inet_addr(Addr);
	if(dwIP == SOCKET_ERROR)
		goto error;
	p = strchr(Port, ',');
	if(!p)
		goto error;
	*p = ' ';
	if(sscanf(Port, "%d %d", &i, &j) != 2)
		goto error;
	if( i > 256 || j > 256 )
		goto error;
	wPort = i*256 + j;
	if( (wPort < 1024 && wPort != 20) )
		goto error;
	TransferMode = PORT_MODE;


	return SendResponse(CMD_OK, "PORT command successful.");
error:
	return SendResponse(500, "Invalid PORT Command.");
}


//����������
inline BOOL FTPSERVER::OpenDataConn()
{
	int nRetVal = 0;

	if(TransferMode == PASSIVE_MODE)//����ģʽ
	{
		nRetVal = PasvAccept();
	}else//����ģʽ
	{
		nRetVal = ConnectRemote();
	}
	return nRetVal;
}

//�ر���������
inline void FTPSERVER::CloseDataConn()
{
	if(TransferMode == PASSIVE_MODE)
	{
		if(DataSock)
			closesocket(DataSock);
		if(PasvSock)
			closesocket(PasvSock);
		PasvSock = DataSock = 0;//�׽������㣬����CreateSocket����Ƿ��ظ�ִ��PASVָ��
	}
	else
	{
		if(DataSock)
			closesocket(DataSock);
		DataSock = 0;
	}
	return;
}

inline BOOL FTPSERVER::PasvAccept()
{
	int iMode = 1;//nonzero
	ioctlsocket(PasvSock, FIONBIO, (u_long FAR*) &iMode);//Enabled Nonblocking Mode

	struct timeval TimeOut;
	fd_set FdRead;
	FD_ZERO(&FdRead);
	FD_SET(PasvSock,&FdRead);
	TimeOut.tv_sec  = 12;//12 sec
	TimeOut.tv_usec = 0;
	if(select(0, &FdRead, NULL, NULL, &TimeOut) <= 0)//����accept��ʱ
	{
		SendResponse(425, "Can't open data connection.");
		return 0;
	}
	DataSock = ZXSAPI::accept(PasvSock, NULL, NULL);
	closesocket(PasvSock);
	PasvSock = 0;
	if(DataSock == INVALID_SOCKET)
	{
		SendResponse(425, "Can't open data connection.");
		return 0;
	}

	SendResponse(125, "Data connection already open; Transfer starting.");
	return 1;
}


inline BOOL FTPSERVER::ConnectRemote()
{
	struct sockaddr_in Local, Server;
	int nLevel = 1;

	memset(&Local, 0, sizeof(Local));
	memset(&Server, 0, sizeof(Server));

	Local.sin_family = AF_INET;
	Local.sin_port = htons(DataPort);
	Local.sin_addr.s_addr = 0;

	DataSock = ZXSAPI::socket(PF_INET, SOCK_STREAM,IPPROTO_TCP);
	if(DataSock == INVALID_SOCKET)
		goto error;
    if (setsockopt(DataSock, SOL_SOCKET, SO_REUSEADDR,
        (const char FAR *)&nLevel, sizeof(nLevel)) != 0) {
        goto error;
    }
	if(ZXSAPI::bind(DataSock, (const SOCKADDR *)&Local,sizeof(Local)) == SOCKET_ERROR)
		goto error;

	Server.sin_family = AF_INET;
	Server.sin_port = htons(wPort);
	Server.sin_addr.s_addr = dwIP;

	if(ZXSAPI::connect(DataSock, (const SOCKADDR *)&Server,sizeof(Server)) == SOCKET_ERROR)
		goto error;

	return 1;
error:
	SendResponse(425, "Can't open data connection.");
	return 0;
}
inline BOOL FTPSERVER::CMD_PASV()
{
	char PassiveAddr[MAX_IP_LEN] = {0};
	char LocalAddr[32];
	if(! GetLocalAddress(LocalAddr))
		return SendResponse(504, "PASV not implemented.");
	SOCKET sd = CreateSocket(LocalAddr, PasvPort);//���������׽���
	struct sockaddr_in addrin;
	int addrlen=sizeof(sockaddr_in);
	if(!sd)
		return SendResponse(504, "PASV not implemented.");

	//��ñ����׽��ֵĵ�ַ�ṹ��Ϣ
	if(getsockname(sd, (struct sockaddr *)&addrin, &addrlen) == SOCKET_ERROR)
		return SendResponse(504, "PASV not implemented.");

	_snprintf(PassiveAddr, sizeof(PassiveAddr),
		"%s,%d,%d", LocalAddr, ntohs(addrin.sin_port)/256, ntohs(addrin.sin_port)%256);
	for(char *p = PassiveAddr; *p; p++)
	{
		if(*p == '.')
			*p = ',';
	}
	_snprintf(TempBuf, sizeof(TempBuf),
		"Entering Passive Mode (%s).", PassiveAddr);

	TransferMode = PASSIVE_MODE;
	return SendResponse(PASSIVE_MODE, TempBuf);
}

//�������н���������Ŀ¼�����ָ���һ�ݵ�QUEUE<char *> *DirName�ж���
int FTPSERVER::GetAllVirDirName(QUEUE<char *> *DirName)
{
	VirDir.GetAllVirDirName(DirName);
	return VirDir.GetCount();
}

//�������ļ��е�����Ŀ¼���ö�ȡ��VirDir������
BOOL FTPSERVER::ReadVirPathInfo()
{
	char *AllVirPath = VirPath;

	char VirPathInfo[MAX_PATH*2], VirName[MAX_PATH], VirPath[MAX_PATH];
	char SysInfo[MAX_PATH];
    char szDisk[5];
	BOOL bError = FALSE;
	int i=0;
	const char *p = AllVirPath;
	const char *s;
	VIRPATHINFO pVirPathInfoStruct;

	while(p = TakeOutStringByChar(p, VirPathInfo, sizeof(VirPathInfo), ','))
	{
		if(s = TakeOutStringByChar(VirPathInfo, VirName, sizeof(VirName), '|'))
		{
			if(TakeOutStringByChar(s, VirPath, sizeof(VirPath), '\0'))
			{
				pVirPathInfoStruct.VirName = strdup(VirName);
				pVirPathInfoStruct.VirPath = strdup(VirPath);
				VirDir.Add(pVirPathInfoStruct);
				bError = TRUE;
			}else
			{
				if(!stricmp(VirName, "MyComputer"))
				{
///////////////////////
					for(int i=0;i<26;++i) 
					{  
						sprintf(szDisk,"%c:",'A'+i);
						UINT uType=GetDriveType(szDisk);
						switch(uType) 
						{        
						case 2: 
							sprintf(SysInfo,"RemovableDisk %s",szDisk); 
							break;
						case 3: 
							sprintf(SysInfo,"Disk %s",szDisk); 
							break;
						case 4: 
							sprintf(SysInfo,"NetDisk %s",szDisk); 
							break; 
						case 5: 
							sprintf(SysInfo,"CDROM %s",szDisk); 
							break; 
						} 
						if(uType!=1)
						{
							pVirPathInfoStruct.VirName = strdup(SysInfo);
							pVirPathInfoStruct.VirPath = strdup(szDisk);
							VirDir.Add(pVirPathInfoStruct);
						}
						memset(SysInfo,0,MAX_PATH);
					}
///////////////////////////
				}
			}
		}
	}

	return bError;
}

/*
����: �� szPath = "\aaa\bbb\ccc\" ��ȡ�� "aaa" ��RetBuf
*/
static char *TakeOutFirstDirName(char *szPath, char *RetBuf, int buflen)
{
	int len = 0;
	while(*szPath && *szPath == '/')
		szPath++;
	while(*szPath && *szPath != '/' && len < buflen)
		RetBuf[len++] = *(szPath++);
	RetBuf[len] = '\0';
	if(len == 0)
		return NULL;
	else
		return szPath;
}


inline BOOL FTPSERVER::GetLocalPath(char *szLocal, int bufsize, char *szParam)
{
    char lpFileName[MAX_PATH];
	char RealPath[MAX_PATH];
	if(*szParam == '\0')
	{
		SendResponse(500, "Invalid number of parameters.");
		return 0;	
	}
	if(*szParam == '/' || *szParam == '\\')
	{
		_snprintf(lpFileName, sizeof(lpFileName),	"%s", szParam);
	}else
	{
		_snprintf(lpFileName, sizeof(lpFileName),	"%s/%s", CurrPath, szParam);
	}
	FormatPathString(lpFileName, TempBuf, MAX_PATH, false);
	//if(!CheckPath(Back2Slash(TempBuf)))
	//{
	//	SendResponse(550, "Access is denied.");
	//	return 0;
	//}
	BOOL bError = FALSE;
	char *SecDir = TakeOutFirstDirName(TempBuf, lpFileName, sizeof(lpFileName));
	if(SecDir)
	{
		bError = VirDir.GetVirPathByVirName(lpFileName, RealPath, MAX_PATH);
	}
	if(bError)
	{
		_snprintf(lpFileName, sizeof(lpFileName),
			"%s/%s", RealPath, SecDir);
	}else
	{
		_snprintf(lpFileName, sizeof(lpFileName),
			"%s/%s", HomeDir, TempBuf);
	}
	return FormatPathString(lpFileName, szLocal, bufsize, false);

}
inline int FTPSERVER::FileInfoToList(LPFILE_INFO pFI, int FileNum, char *buff, int bufsize)
{
	char Link[128]="\0";
	SYSTEMTIME stUTC, stLocal;
	int ret = 0, len = 0;
	char *szT = "";
	if(! strnicmp(CmdBuf, "NLST", 4))
	{
		for(int i=0; i<FileNum; i++)
		{
			ret = sprintf(buff+len, "%s\r\n", pFI[i].szFileName);
			len += ret;
		}
		return len;
	}
	for(int i=0; i<FileNum; i++)
	{
		FileTimeToSystemTime(&(pFI[i].ftLastWriteTime), &stUTC);
		SystemTimeToTzSpecificLocalTime(NULL, &stUTC, &stLocal);
		if(stLocal.wYear >= 2000) 
			stLocal.wYear -= 2000;
		else 
			stLocal.wYear -= 1900;
		if(stLocal.wHour > 12)
		{
			stLocal.wHour -= 12;
			szT = "PM";
		}else
		{
			szT = "AM";
		}
		ret = sprintf(buff+len, "%02u-%02u-%02u  %02u:%02u%s ", 
			stLocal.wMonth, stLocal.wDay, stLocal.wYear, stLocal.wHour, stLocal.wMinute, szT);

		len += ret;
		if(pFI[i].dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
		{
			ret = sprintf(buff+len, "      %s          %s\r\n", "<DIR>", pFI[i].szFileName);
		}else{
			ret = sprintf(buff+len, "%20I64d %s\r\n", ((pFI[i].nFileSizeHigh * ((__int64)MAXDWORD+1)) + pFI[i].nFileSizeLow), pFI[i].szFileName);
		}
		len += ret;
	}
	return len;
}

BOOL FTPSERVER::IsInHomeDir(char *lpFileName)
{
	int n=0;
	while(*lpFileName && n <= 2)
	{
		if(*lpFileName++ == '/')
		{
			while(*lpFileName == '/')
				lpFileName++;
			n++;
		}
	}
	if(n < 2)
		return TRUE;
	else
		return FALSE;
}
//��Ŀ¼
int FTPSERVER::MakeFileList(LPFILE_INFO lpFI, char *buff, char *DirPath, BOOL IsListSubDir)
{	
	if(IsAbort())
	{
		ParseCMD();//ִ�н��յ��ж�ָ��.
		return -1;
	}
	int idx = 0,nFiles=0, len=0, ret = 0;
	char lpFileName[MAX_PATH];
	char SubDirPath[MAX_PATH];
	QUEUE<char *> DirName;
	WIN32_FIND_DATA wfd;
	int nCount_Dir, i;
	if(! GetLocalPath(lpFileName, sizeof(lpFileName), DirPath))
	{
		return -1;
	}
	if(IsInHomeDir(DirPath))
		GetAllVirDirName(&DirName);

    HANDLE hFile = FindFirstFile(lpFileName, &wfd);
    if (hFile == INVALID_HANDLE_VALUE) {
		nFiles = -1;
		goto ExtendList;
	}


	do{

		if ((!strcmp(wfd.cFileName, ".") || (!strcmp(wfd.cFileName, ".."))))
			continue;
		if (wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
		{
			if(IsListSubDir)
			{
				DirName.EnQueue(strdup(wfd.cFileName));//�����Ҫ�о���Ŀ¼�ͽ�Ŀ¼���ŵ��ж���
			}
		}

		lpFI[idx].dwFileAttributes = wfd.dwFileAttributes;
		ZXSAPI::lstrcpy(lpFI[idx].szFileName, wfd.cFileName);
		lpFI[idx].ftCreationTime   = wfd.ftCreationTime;
		lpFI[idx].ftLastAccessTime = wfd.ftLastAccessTime;
		lpFI[idx].ftLastWriteTime  = wfd.ftLastWriteTime;
		lpFI[idx].nFileSizeHigh    = wfd.nFileSizeHigh;
		lpFI[idx++].nFileSizeLow   = wfd.nFileSizeLow;
	
		if(idx==MAX_FILE_NUM)
		{
			len = FileInfoToList(lpFI, idx, buff, DATA_BUFSIZE);
			if(DataSend(DataSock, buff, len) != len)
			{//�����б������������˳�
				idx = 0;
				break;
			}
			nFiles+=idx;
			idx=0;
		}
        
    }while(FindNextFile(hFile, &wfd));
	if(idx > 0)
	{
		len = FileInfoToList(lpFI, idx, buff, DATA_BUFSIZE);
		DataSend(DataSock, buff, len);
		nFiles+=idx;
	}
	FindClose(hFile);

ExtendList:
	//DataSend(DataSock, "\r\n", 2);
	nCount_Dir = DirName.GetCount();//ȡ���ж��еĽڵ���
	nFiles += nCount_Dir;
	if(nCount_Dir > 0)
	{
		if(IsListSubDir)//�ݹ鷢����Ŀ¼�б�
		{
			DirPath[lstrlen(DirPath)-4] = '\0';
			for(i=0; i<nCount_Dir; i++, free(DirName.DeQueue()))//�ڵ��е�����������strdup�ģ���ȡ����free()��
			{
				ret = _snprintf(TempBuf, sizeof(TempBuf), "\r\n%s/%s:\r\n", DirPath, DirName.Peek());
				if(DataSend(DataSock, TempBuf, ret) != ret)
					continue;//����ʧ�ܣ�������break����ΪҪ���ж���ʣ�µ�free��
				_snprintf(SubDirPath, sizeof(SubDirPath), "%s/%s/*.*", DirPath, DirName.Peek());
				nFiles += MakeFileList(lpFI, buff, SubDirPath, IsListSubDir);
			}
		}else
		{
			for(i=0; i<nCount_Dir; i++, free(DirName.DeQueue()))//���ж��з�������Ŀ¼�б�
			{
				if(! strnicmp(CmdBuf, "NLST", 4))
				{
					ret = _snprintf(TempBuf, sizeof(TempBuf), "%s\r\n", DirName.Peek());
				}else
				{
					ret = sprintf(TempBuf, 
						"09-11-06  12:00AM       <DIR>          %s\r\n", DirName.Peek());
				}
				if(DataSend(DataSock, TempBuf, ret) != ret)
					continue;
			}
		}
	}
    return nFiles;
}
//�����Ŀ¼����
int FTPSERVER::GetFileList(char *szParam)
{
	char PathName[MAX_PATH] = "\0";
	BOOL IsListSubDir = FALSE;
	int nFiles = 0;

	if(szParam[0] == '-')
	{
		char *p = strstr(szParam, " ");
		if(p && *(p+1))
		{
			_snprintf(TempBuf, sizeof(TempBuf), "%s/*.*", p+1);
			*p = '\0';
		}else
		{
			_snprintf(TempBuf, sizeof(TempBuf), "%s/*.*", CurrPath);
		}
		
		if(strstr(szParam, "R"))//LIST -R �����о�Ŀ¼
			IsListSubDir = TRUE;

	}else if(szParam[0] == '\0')
	{
		_snprintf(TempBuf, sizeof(TempBuf), "%s/*.*", CurrPath);
	}else
	{
		if(szParam[strlen(szParam)-1] == '/')
			_snprintf(TempBuf, sizeof(TempBuf), "%s*.*", szParam);
		else
			_snprintf(TempBuf, sizeof(TempBuf), "%s", szParam);
	}

	FormatPathString(TempBuf, PathName, sizeof(PathName), false);

	char *FileListBuff = new char [DATA_BUFSIZE];//����б���Ϣ�Ļ�����
	LPFILE_INFO lpFI = new FILE_INFO[MAX_FILE_NUM];//����ļ����ԵĽṹ

	if(FileListBuff == NULL || lpFI == NULL)
		goto exit;

	nFiles = MakeFileList(lpFI, FileListBuff, PathName, IsListSubDir);

exit:
	delete [] FileListBuff;
	delete [] lpFI;
	return nFiles;
}

BOOL FTPSERVER::CMD_LIST(char *szParam)
{
	if(! VerifyAccess(ListAccess))
		return SendResponse(550, "ListAccess is denied.");

	int nRetVal;

	if(TransferMode == PORT_MODE)
	{
		_snprintf(TempBuf, sizeof(TempBuf), 
			"%s", "Opening ASCII mode data connection for /bin/ls.");
		SendResponse(150, TempBuf);
	}
	nRetVal = OpenDataConn();
	if(nRetVal)
	{
		if(GetFileList(szParam) == -1)
		{
			SendResponse(550, "Transfer Error.");
			goto exit;
		}
	}else
		goto exit;

	nRetVal = SendResponse(TRANS_COMPLETE, "Transfer complete.");
exit:
	CloseDataConn();
	return 1;
}

inline BOOL FTPSERVER::CMD_PWD()
{
	_snprintf(TempBuf, sizeof(TempBuf),
		"\"%s\" is current directory.", CurrPath);

	return SendResponse(DIR_OK, TempBuf);
}
inline BOOL FTPSERVER::CMD_CWD(char *szParam)
{
	int nRetVal;
	char lpFileName[MAX_PATH];

	if(*szParam == '\0' || *szParam == '\\')
		*szParam = '/';

	if(!GetLocalPath(lpFileName, sizeof(lpFileName), szParam))
		return 0;

////////////////
	nRetVal = SetCurrentDirectory(lpFileName);
	if(!nRetVal)
	{
		_snprintf(TempBuf, sizeof(TempBuf),
			"%s: The system cannot find the file specified.", szParam);
		return SendResponse(550, TempBuf);
	}else
	{
		if(*szParam == '/')
		{
			FormatPathString(szParam, CurrPath, MAX_PATH, false);
		}else
		{
			_snprintf(TempBuf, sizeof(TempBuf), "/%s/%s", CurrPath, szParam);
			FormatPathString(TempBuf, CurrPath, sizeof(CurrPath), false);
		}
	}
	return SendResponse(DIR_CHANGED, "CWD command successful.");
}

inline BOOL FTPSERVER::CMD_SIZE(char *szParam)
{
	if(! VerifyAccess(ReadAccess))
		return SendResponse(550, "ReadAccess is denied.");
    char lpFileName[MAX_PATH];
	if(!GetLocalPath(lpFileName, sizeof(lpFileName), szParam))
		return 0;
	__int64 FileSize = FindFile(lpFileName);
	if(FileSize == -1)
	{
		SendResponse(550, "No such FileName");
		return 0;
	}
	_i64toa(FileSize, TempBuf, 10);
	SendResponse(FILE_SIZE, TempBuf);
	return 1;
}
inline BOOL FTPSERVER::CMD_ABOR()
{
	SendResponse(225, "ABOR command successful.");
	
	if(DataSock)
	{
		closesocket(DataSock);
		DataSock = 0;
	}
	return TRUE;	
}

inline BOOL FTPSERVER::CMD_MKD(char *szParam)
{
	if(! VerifyAccess(CreateAccess))
		return SendResponse(550, "CreateAccess is denied.");
    char lpFileName[MAX_PATH];
	int nRetVal;
	if(!GetLocalPath(lpFileName, sizeof(lpFileName), szParam))
		return 0;
	nRetVal = CreateDirectory(lpFileName, NULL);
	if(! nRetVal)
	{
		 if(GetLastError() == ERROR_ALREADY_EXISTS)
		 {
			 nRetVal = _snprintf(TempBuf, sizeof(TempBuf), 
				 "%s: %s", szParam, "Cannot create a file when that file already exists.");
		 }else
		 {
			 nRetVal = _snprintf(TempBuf, sizeof(TempBuf), 
				 "%s: %s", szParam, "The filename, directory name, or volume label syntax is incorrect.");
		 }
		 return SendResponse(550, TempBuf);
	}
	_snprintf(TempBuf, sizeof(TempBuf), 
		"\"%s\" directory created.", szParam);
	return SendResponse(DIR_OK, TempBuf);
}
inline BOOL FTPSERVER::CMD_RMD(char *szParam)
{
	if(! VerifyAccess(DeleteAccess))
		return SendResponse(550, "DeleteAccess is denied.");
    char lpFileName[MAX_PATH];
	int nRetVal;
	if(!GetLocalPath(lpFileName, sizeof(lpFileName), szParam))
		return 0;
	nRetVal = ZXSAPI::RemoveDirectory(lpFileName);
	if(! nRetVal)
	{
		nRetVal = GetLastError();
			nRetVal = _snprintf(TempBuf, sizeof(TempBuf), 
			"%s: %s", szParam, "No such directory or it's not empty.");
		return SendResponse(550, TempBuf);
	}
	return SendResponse(CMD_OK, "RMD command successful.");
}
inline BOOL FTPSERVER::CMD_DELE(char *szParam)
{
	if(! VerifyAccess(DeleteAccess))
		return SendResponse(550, "DeleteAccess is denied.");
    char lpFileName[MAX_PATH];
	int nRetVal;
	if(!GetLocalPath(lpFileName, sizeof(lpFileName), szParam))
		return 0;
	nRetVal = DeleteFile(lpFileName);
	if(! nRetVal)
	{
		 nRetVal = _snprintf(TempBuf, sizeof(TempBuf), 
			 "%s: %s", szParam, "No such file.");
		 return SendResponse(550, TempBuf);
	}
	nRetVal = _snprintf(TempBuf, sizeof(TempBuf), 
		"File %s deleted.", szParam);

	return SendResponse(CMD_OK, TempBuf);
}
inline BOOL FTPSERVER::CMD_RNFR(char *szParam)
{
	if(! VerifyAccess(WriteAccess))
		return SendResponse(550, "WriteAccess is denied.");
	char lpFileName[MAX_PATH];
	int nRetVal;
	if(!GetLocalPath(lpFileName, sizeof(lpFileName), szParam))
		return 0;
	if(FindFile(lpFileName) == -1)
	{
		nRetVal = _snprintf(TempBuf, sizeof(TempBuf), 
			"%s: The system cannot find the file specified.", szParam);
		return SendResponse(550, TempBuf);
	}
	IsGetRN = TRUE;
	_snprintf(FileForRename, sizeof(FileForRename), "%s", szParam);
	return SendResponse(350, "File exists, ready for destination name.");
}
inline BOOL FTPSERVER::CMD_RNTO(char *szParam)
{
	if(! VerifyAccess(WriteAccess))
		return SendResponse(550, "WriteAccess is denied.");
	if(! IsGetRN)
		return SendResponse(503, "Bad sequence of commands.");

	char lpFileName[MAX_PATH];
	if(!GetLocalPath(lpFileName, sizeof(lpFileName), szParam))
		return 0;
	if(! ZXSAPI::MoveFile(FileForRename, lpFileName))
	{
		_snprintf(TempBuf, sizeof(TempBuf), 
			"%s: The system cannot find the file specified.", szParam);
		return SendResponse(550, TempBuf);
	}
	IsGetRN = FALSE;
	return SendResponse(DIR_CHANGED, "RNTO command successful.");
}

inline __int64 FTPSERVER::FindFile(char *lpFileName)
{
	WIN32_FIND_DATA  FileData;
	HANDLE hSearch=FindFirstFile(lpFileName, &FileData);
	if(hSearch == INVALID_HANDLE_VALUE)
		return -1;
	FindClose(hSearch);
	return (FileData.nFileSizeHigh * ((__int64)MAXDWORD+1)) + FileData.nFileSizeLow;
}

inline BOOL FTPSERVER::IsAbort()//ִ��ָ���ڼ�����ж�ָ��
{
	int Result;
	fd_set FdRead;
	struct timeval TimeOut = {0, 0};
	FD_ZERO(&FdRead);
	FD_SET(ClientSock,&FdRead);
	Result = select(0, &FdRead, NULL, NULL, &TimeOut);
	if(Result < 0)
		return TRUE;
	if(FD_ISSET(ClientSock, &FdRead))
	{
		Result = recv(ClientSock, CmdBuf, sizeof(CmdBuf), 0);
		if(Result <= 0)
			return TRUE;
		if(!strnicmp(CmdBuf, "ABOR", 4) || !strnicmp(CmdBuf, "REIN", 4))
		{
			CmdBuf[4] = '\0';
			return TRUE;
		}
	}
	return FALSE;
}

inline BOOL FTPSERVER::CMD_REST(char *szParam)
{
	Marker = _atoi64(szParam);

	_snprintf(TempBuf, sizeof(TempBuf), "Restarting at %I64d.", Marker);

	return SendResponse(350, TempBuf);
}


inline BOOL FTPSERVER::CMD_RETR(char *szParam)
{
	if(! VerifyAccess(ReadAccess))
		return SendResponse(550, "ReadAccess is denied.");

	int nRetVal;
	char lpFileName[MAX_PATH];
	__int64 FilePos = Marker, DataLen, SentLen;
	Marker = 0;
	LARGE_INTEGER LI;
	if(!GetLocalPath(lpFileName, sizeof(lpFileName), szParam))
		return 0;

	HANDLE hFile = ZXSAPI::CreateFile(lpFileName, 
        GENERIC_READ, 
        FILE_SHARE_READ, 
        NULL, 
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		nRetVal = _snprintf(TempBuf, sizeof(TempBuf), 
			"%s: The system cannot find the file specified.", szParam);
		return SendResponse(550, TempBuf);
	}
	BOOL bError = GetFileSizeEx(hFile, &LI);
	if(!bError)
	{
		SendResponse(550, "The data is invalid.");
		goto exit;
	}
	DataLen = LI.QuadPart - FilePos; //��Ҫ��������ݳ���
	LI.QuadPart = FilePos;//����LARGE_INTEGER���޸��ļ�ָ��
	bError = SetFilePointerEx(hFile, LI, NULL, FILE_BEGIN);
	if(!bError)
	{
		SendResponse(550, "The data is invalid.");
		goto exit;
	}
	if(TransferMode == PORT_MODE)//����ģʽ
	{
		_snprintf(TempBuf, sizeof(TempBuf), 
			"Opening BINARY mode data connection for %s(%I64d bytes).", szParam, DataLen);
		SendResponse(150, TempBuf);
	}
	nRetVal = OpenDataConn();

	if(! nRetVal)
		goto exit;

	SentLen = Transmitfile(DataSock, hFile, DataLen);
	if(SentLen < 0)
	{
		SendResponse(426, "Connection closed; transfer aborted.");
		if(SentLen == -2)//�յ��ж������˳���
			ParseCMD();
	}
	else
		SendResponse(TRANS_COMPLETE, "Transfer complete.");

exit:
	CloseDataConn();
	CloseHandle(hFile);
	return nRetVal;
}

inline int FTPSERVER::DataRecv(SOCKET s, char *buff, int bufsize)
{
	int Result;
	struct timeval TimeOut;
	TimeOut.tv_sec  = IdleTimeOut;
	TimeOut.tv_usec = 0;

	fd_set FdRead;
	FD_ZERO(&FdRead);
	FD_SET(s,&FdRead);
	Result = select(0, &FdRead, NULL, NULL, &TimeOut);
	if(Result <= 0)
		return 0;

	return recv(s, buff, bufsize, 0);
}

inline int FTPSERVER::WriteToFile(HANDLE hFile, char *Buff, int Datalen)
{
	DWORD nBytesLeft = Datalen;
	DWORD dwNumOfBytesWritten = 0;
	char *pBuf = Buff;
	while(nBytesLeft > 0) {
		if(!ZXSAPI::WriteFile(hFile, pBuf, nBytesLeft, &dwNumOfBytesWritten, NULL)) {
			return 0;
		}
		pBuf += dwNumOfBytesWritten;
		nBytesLeft -= dwNumOfBytesWritten;
	}
	return 1;
}

inline BOOL FTPSERVER::CMD_STOR(char *szParam)
{
	if(! VerifyAccess(WriteAccess))
		return SendResponse(550, "WriteAccess is denied.");
	int nRetVal, fSuccess = TRUE;
	char lpFileName[MAX_PATH];
	char RecvBuf[MAXBUFSIZE];
	__int64 FilePos = Marker;
	Marker = 0;
	__int64 TotalBytesRecv = 0;
	BOOL bError;

	if(!GetLocalPath(lpFileName, sizeof(lpFileName), szParam))
		return 0;

	HANDLE hFile = ZXSAPI::CreateFile(lpFileName, 
        GENERIC_WRITE, 
        FILE_SHARE_WRITE, 
        NULL, 
        OPEN_ALWAYS, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		nRetVal = _snprintf(TempBuf, sizeof(TempBuf), 
			"%s: The filename, directory name, or volume label syntax is incorrect.", szParam);
		return SendResponse(550, TempBuf);
	}
	LARGE_INTEGER LI;
	LI.QuadPart = FilePos;
	bError = SetFilePointerEx(hFile, LI, NULL, FILE_BEGIN);
	if(!bError)
	{
		SendResponse(550, "The data is invalid.");
		goto exit;
	}
	if(TransferMode == PORT_MODE)//����ģʽ
	{
		_snprintf(TempBuf, sizeof(TempBuf), 
			"Opening BINARY mode data connection for %s.", szParam);
		SendResponse(150, TempBuf);
	}
	nRetVal = OpenDataConn();
	if(! nRetVal)
		goto exit;

	while(1)
	{
		if(IsAbort())
		{
			SendResponse(426, "Connection closed; transfer aborted.");
			ParseCMD();
			fSuccess = FALSE;
			break;
		}
		nRetVal = DataRecv(DataSock, RecvBuf, sizeof(RecvBuf));
		if(nRetVal == SOCKET_ERROR)
		{
			SendResponse(426, "Connection closed; transfer aborted.");
			fSuccess = FALSE;
			break;
		}else if(nRetVal == 0)
		{
			SendResponse(226, "Transfer complete.");
			break;
		}
		else
		{
			TotalBytesRecv += nRetVal;
			nRetVal = WriteToFile(hFile, RecvBuf, nRetVal);
			if(!nRetVal)
			{
				SendResponse(550, "Write data to file error.");
				break;
			}
		}
	}
	SetEndOfFile(hFile);

exit:
	CloseDataConn();
    CloseHandle(hFile);
	//if(fSuccess == FALSE && !VerifyAccess(AppendAccess))
	//	DeleteFile(lpFileName);
	return 1;
}

inline __int64 FTPSERVER::Transmitfile(SOCKET sd, HANDLE hFile, __int64 size)
{
	__int64 tatolsize = size, len_sent = 0;
    DWORD len, nBytes;
	int ret;
    char buf[MAXBUFSIZE];

    while(len_sent < size)
    {
		if(IsAbort())
			return -2;
		if(tatolsize < (__int64)MAXBUFSIZE)
			nBytes = tatolsize;
		else
			nBytes = MAXBUFSIZE;
		if(!ZXSAPI::ReadFile(hFile, buf, nBytes, &len, NULL))
			return len_sent;
		ret = DataSend(sd, buf, len);
		if(ret != len || ret == 0)
		{
			return -1;
		}
		len_sent += len;
		tatolsize -= len;
    }
 	return 1;
}

inline BOOL FTPSERVER::CMD_FEAT()
{
	char CMDLIST[] =
"211-Extension supported\n\
 MDTM\n\
 SIZE\n\
 REST STREAM\n\
 LIST -R\n\
 XCRC filename;start;end\n\
 XMD5 filename\n\
";
	DataSend(ClientSock, CMDLIST, sizeof(CMDLIST)-1);
	return SendResponse(211, "End");
}

inline BOOL FTPSERVER::CMD_MDTM(char *szParam)
{
	if(! VerifyAccess(ReadAccess))
		return SendResponse(550, "ReadAccess is denied.");

	int nRetVal;
	char lpFileName[MAX_PATH];

	if(!GetLocalPath(lpFileName, sizeof(lpFileName), szParam))
		return 0;
	WIN32_FIND_DATA  FileData;
	SYSTEMTIME stUTC;
	HANDLE hSearch=FindFirstFile(lpFileName, &FileData);
	if(hSearch == INVALID_HANDLE_VALUE || (FileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
	{
		nRetVal = _snprintf(TempBuf, sizeof(TempBuf), 
			"%s: The system cannot find the file specified.", szParam);
		return SendResponse(550, TempBuf);
	}
	FileTimeToSystemTime(&FileData.ftLastWriteTime, &stUTC);
	_snprintf(TempBuf, sizeof(TempBuf), "%02u%02u%02u%02u%02u%02u", 
			stUTC.wYear, stUTC.wMonth, stUTC.wDay, stUTC.wHour, stUTC.wMinute, stUTC.wSecond);
	FindClose(hSearch);
	return SendResponse(213, TempBuf);
}
inline BOOL FTPSERVER::CMD_APPE(char *szParam)
{
	//if(! VerifyAccess(AppendAccess))
	//	return SendResponse(550, "AppendAccess is denied.");
	char lpFileName[MAX_PATH];
	if(!GetLocalPath(lpFileName, sizeof(lpFileName), szParam))
		return 0;
	__int64 FileSize = FindFile(lpFileName);
	if(FileSize == -1)
	{
		SendResponse(550, "No such FileName");
		return 0;
	}
	Marker = FileSize;
	return CMD_STOR(szParam);
}


//�����ļ���MD5Ч��ֵ
inline BOOL FTPSERVER::CMD_XMD5(char *szParam)
{
	if(! VerifyAccess(ReadAccess))
		return SendResponse(550, "ReadAccess is denied.");
	char lpFileName[MAX_PATH];

	XMD5 Md5File;

	if(!GetLocalPath(lpFileName, sizeof(lpFileName), szParam))
		return 0;
	__int64 FileSize = FindFile(lpFileName);
	if(FileSize == -1)
		goto error;

/*	CMd5A Md5File;
	if(Md5File.MDFile(lpFileName, TempBuf) == NULL)
		goto error;*/

	if(! Md5File.Open(lpFileName))
		goto error;

	while(Md5File.HashFile())
	{
		//�����ж�ָ��
		if(IsAbort())
		{
			ParseCMD();
			goto abort;
		}
	}
	Md5File.Close();
	Md5File.GetFileMD5String(TempBuf);
	return SendResponse(250, TempBuf);
abort:
	Md5File.Close();
	return 0;
error:
	SendResponse(550, "No such FileName");
	return 0;
}

//�����ļ���ѭ��������У��ֵ
inline BOOL FTPSERVER::CMD_XCRC(char *szParam)
{
	if(! VerifyAccess(ReadAccess))
		return SendResponse(550, "ReadAccess is denied.");
	char lpFileName[MAX_PATH];
	__int64 start, end;
	int argc = sscanf(szParam, "%s %I64d %I64d", lpFileName, &start, &end);
	if(!GetLocalPath(lpFileName, sizeof(lpFileName), lpFileName))
		return 0;

	FileCRC32 fc32;

	if(argc == 3)
	{
		if(!fc32.Open(lpFileName, start, end))
			goto error;
	}else
	{
		if(!fc32.Open(lpFileName))
			goto error;
	}
	
	while(fc32.DoFileCRC())
	{
		//�����ж�ָ��
		if(IsAbort())
		{
			ParseCMD();
			goto abort;
		}
	}
	SendResponse(250, fc32.GetCRCString());
	fc32.Close();
	return 1;
abort:
	fc32.Close();
	return 0;
error:
	SendResponse(550, "No such FileName");
	return 0;
}