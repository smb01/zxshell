/*
http ������
*/

#include "HttpSvr.h"
#include ".\SpoofProcPath.h"

#define SERVER "ZXHttpServer"
#define VER "2.2"

#define WM_SOCKET (WM_USER+1)

#define MAXBUFSIZE 8192

#define OK 200
#define BAD_REQUEST 400
#define ACCESS_DENIED 403
#define NOT_FOUND 404
#define RANGE_ERROR 416
#define NOT_IMPLEMENTED 501
#define NOT_MODIFIED 304
#define PARTIAL_CONTEN 206

#define GETFILE 0
#define LISTFOLDER 1
int ListenPort = 80;
bool fListFolder = true;
char RootDirectory[MAX_PATH];

//�Է��ʲ����ڵ��ļ���������Ӧ���ļ�
struct REDIR2FILE
{
	char postfix[15];
	char filename[MAX_PATH];
};

list<REDIR2FILE> m_redirectURL;

//const char *TakeOutStringByChar(IN const char *Source, OUT char *Dest, int buflen, char ch);
char *GetPathInRedirectList(char *postfix, list<REDIR2FILE> &rd);
int MakeRedirectList(char *str, list<REDIR2FILE> &rd);
//////////////////

class HTTPSERVER{
protected:
	SOCKET sock;
	HttpHeader header;
	char RecvBuf[MAXBUFSIZE];
public:

	void Init(SOCKET s);
	int GetRequest();
	int GetRange(char *src);
	int GetWhat();
	bool CheckPath(char *Path);
	int FillHeader(HANDLE hFile);
	char *FormatDateTime(SYSTEMTIME *stUTC);
	char *GetETag(FILETIME *ft, DWORD FileSize);
	int GetContentType(char *FileName);
	int ParseHeader();
	int GetFileList();
	__int64 Transmitfile(SOCKET sd, HANDLE hFile, __int64 size);
	int GetFile();
	int GetConnFlag();
	bool IsGet();
	bool Response(int id);
	void ChangeSymbol(char *from, char *to);
	void URLDecode(char *from, char *to);
	HTTPSERVER();
	~HTTPSERVER();

private:
	char *FormatSize(__int64 nSize, char *szSize);
	int FileInfoToHTML(LPFILE_INFO pFI, int FileNum, char *buff, int bufsize);
	int DataSend(SOCKET s, const char *buff, int len);

};

inline HTTPSERVER::HTTPSERVER()
{
	sock = 0;
	memset(RecvBuf, 0, sizeof(RecvBuf));
}

inline HTTPSERVER::~HTTPSERVER()
{
}

inline void HTTPSERVER::Init(SOCKET s)
{
	sock = s;
}

inline bool HTTPSERVER::IsGet()
{
	return stricmp("GET", header.method)==0;
}

inline int HTTPSERVER::GetWhat()
{
	int len = strlen(header.path);
	if(len<=0)
		return -1;
	if(header.path[len-1] == '\\')
		return LISTFOLDER;
	else
		return GETFILE;
}

inline int HTTPSERVER::GetRequest()
{
	int nRecv=0;
	int Result;
	fd_set FdRead;

	while(1)
	{
		FD_ZERO(&FdRead);
		FD_SET(sock,&FdRead);
		Result = select(sock+1,&FdRead,NULL,NULL,NULL);
		if(Result <= 0)
			return 0;
		if(!FD_ISSET(sock, &FdRead))
			return 0;
		Result = ZXSAPI::recv(sock,RecvBuf+nRecv,sizeof(RecvBuf)-nRecv-1,0);
		if(Result <= 0)
			return 0;
		nRecv += Result;
		RecvBuf[nRecv]='\0';
		if(strstr(RecvBuf,"\r\n\r\n")!=NULL || strstr(RecvBuf,"\n\n")!=NULL)
			break;
	}
	return 1;
}

inline bool HTTPSERVER::CheckPath(char *Path)
{
	int root = 0;
	char *p = strtok(Path, "\\");
	while(p)
	{
		if(!stricmp(p, ".."))
			root--;
		else if(stricmp(p, "."))
			root++;
		p = strtok(NULL, "\\");
		if(root < 0)
			return false;
	}
	return true;
}

inline int HTTPSERVER::ParseHeader()
{
	char GetURL[MAXBUFSIZE];
	char *ENDOFLINE = "\r\n";
	SYSTEMTIME stDate;

	GetSystemTime(&stDate);
	header.date = FormatDateTime(&stDate);

	if(strchr(RecvBuf, '\r\n') == NULL)
		ENDOFLINE += 1;//Э��涨\r\n���������ݴ�\n

	if(sscanf(RecvBuf, "%s %s %s", header.method, GetURL, header.protocol)!=3)
		return BAD_REQUEST;
	if(strnicmp(header.protocol, "HTTP/1.x", 7))
		return BAD_REQUEST;
	sscanf(header.protocol+5, "%f", &header.httpver);
	URLDecode(GetURL, GetURL);
	header.path = strdup(GetURL);
	if(!CheckPath(GetURL))
		return ACCESS_DENIED;
	char *s = strtok(RecvBuf, ENDOFLINE);
	while(s)
	{
		if (strnicmp(s, "User-Agent: ", 12) == 0)
			header.useragent = strdup(s+12);
		else if (strnicmp(s, "Connection: ", 12) == 0)
			header.connection = strdup(s+12);
		else if (strnicmp(s, "If-Modified-Since: ", 19) == 0)
			header.ifmodifiedsince = strdup(s+19);
		else if (strnicmp(s, "Content-Length: ", 16) == 0)
			header.contentlength = strtoul(s+16, NULL, 10);
		else if (strnicmp(s, "Range: ", 7) == 0)
			header.rangeflag = GetRange(s + 7);
		s = strtok(NULL, ENDOFLINE);
	}
	return OK;
}

inline bool HTTPSERVER::Response(int id)
{
	char HeaderBuf[MAXBUFSIZE];
	char *Content;
	int ret;
	memset(HeaderBuf, 0, sizeof(HeaderBuf));
	if(id == 400)
	{
		Content = "<html><head><title>Error</title></head><body>The parameter is incorrect. </body></html>";
		ret = sprintf(HeaderBuf,
"HTTP/1.1 400 Bad Request\r\n"
"Server: %s/%s\r\n"
"Date: %s\r\n"
"Connection: close\r\n"
"Content-Type: text/html\r\n"
"Content-Length: %d\r\n"
"\r\n"
"%s", SERVER, VER, header.date, strlen(Content), Content);
	}else if(id == 403)
	{
		char *Content1 = "<html><head><title>Directory Listing Denied</title></head>\
<body><h1>Directory Listing Denied</h1>This Virtual Directory does not allow contents to be listed.</body></html>";
		char *Content2 = "<html><head><title>Permission Denied</title></head>\
<body><h1>Permission Denied</h1>.This Virtual Path does not allow contents to be access</body></html>";
		Content = GetWhat() == LISTFOLDER ? Content1 : Content2;
		ret = sprintf(HeaderBuf,
"HTTP/1.1 403 Access Forbidden\r\n"
"Server: %s/%s\r\n"
"Date: %s\r\n"
"Connection: close\r\n"
"Content-Type: text/html\r\n"
"Content-Length: %d\r\n"
"\r\n"
"%s", SERVER, VER, header.date, strlen(Content), Content);
	}else if(id == 404)
	{
		Content = "<html><head><title>Object Not Found</title></head>\
<body><h1>Object Not Found</h1>File Not Found.</body></html>";
		ret = sprintf(HeaderBuf,
"HTTP/1.1 404 Object Not Found\r\n"
"Server: %s/%s\r\n"
"Date: %s\r\n"
"Connection: close\r\n"
"Content-Type: text/html\r\n"
"Content-Length: %d\r\n"
"\r\n"
"%s", SERVER, VER, header.date, strlen(Content), Content);
	}else if(id == 416)
	{
		Content = "<html><head><title>Requested Range Not Satisfiable</title></head><body><h1>HTTP/1.1 416 Requested Range Not Satisfiable</h1></body></html>";
		ret = sprintf(HeaderBuf,
"HTTP/1.1 416 Requested Range Not Satisfiable\r\n"
"Server: %s/%s\r\n"
"Date: %s\r\n"
"Connection: close\r\n"
"Content-Range: bytes */%I64d\r\n"
"Content-Type: text/html\r\n"
"Content-Length: %d\r\n"
"\r\n"
"%s", SERVER, VER, header.date, header.rangetotal, strlen(Content), Content);
	}else if(id == 501)
	{
		Content = "<body><h2>HTTP/1.1 501 Not Implemented</h2></body>";
		ret = sprintf(HeaderBuf,
"HTTP/1.1 501 Not Implemented\r\n"
"Server: %s/%s\r\n"
"Date: %s\r\n"
"Connection: close\r\n"
"Content-Type: text/html\r\n"
"Content-Length: %d\r\n"
"\r\n"
"%s", SERVER, VER, header.date, strlen(Content), Content);
	}else if(id == 304)
	{
		ret = sprintf(HeaderBuf,
"HTTP/1.1 304 Not Modified\r\n"
"Server: %s/%s\r\n"
"Date: %s\r\n"
"ETag: \"%s\"\r\n"
"Content-Length: %d\r\n"
"\r\n", SERVER, VER, header.date, header.eTag, 0);
	}else if(id == 200)
	{
		ret = sprintf(HeaderBuf,
"HTTP/1.1 200 OK\r\n"
"Server: %s/%s\r\n"
"Date: %s\r\n"
"%s"
"Content-Type: %s\r\n"
"Accept-Ranges: bytes\r\n"
"Last-Modified: %s\r\n"
"ETag: \"%s\"\r\n"
"Content-Length: %I64d\r\n"
"\r\n", SERVER, VER, header.date, GetConnFlag()?"":"Connection: close\r\n", ContentType[header.contenttype],
 header.lastmodified, header.eTag, header.contentlength);
	}else if(id == 206)
	{
		ret = sprintf(HeaderBuf,
"HTTP/1.1 206 Partial content\r\n"
"Server: %s/%s\r\n"
"Date: %s\r\n"
"%s"
"Content-Type: application/octet-stream\r\n"
"Last-Modified: %s\r\n"
"ETag: \"%s\"\r\n"
"Content-Length: %I64d\r\n"
"Content-Range: bytes %I64d-%I64d/%I64d\r\n"
"\r\n", SERVER, VER, header.date, GetConnFlag()?"":"Connection: close\r\n",
header.lastmodified, header.eTag, header.contentlength, header.rangestart, header.rangeend, header.rangetotal);
	}

	DataSend(sock, HeaderBuf, ret);
	return (id==200 || id==206 || id==304);
}

inline void HTTPSERVER::ChangeSymbol(char *from, char *to)
{
	char tmpBuf[8192];
	ZeroMemory(tmpBuf, sizeof(tmpBuf));
	char *tmp = tmpBuf;
	for(int i=0;*from != '\0'; i++,from++)
	{
		if((unsigned char) from[0]=='%'||(unsigned char) from[0]==' ')
			tmp += sprintf(tmp, "%%%x", from[0]);
		else
			*tmp++ = from[0];
	}
	strcpy(to, tmpBuf);
}

inline void HTTPSERVER::URLDecode(char *from, char *to)
{
	char tmpBuf[MAXBUFSIZE];
	WCHAR wBuf[MAXBUFSIZE];
	ZeroMemory(tmpBuf, sizeof(tmpBuf));
	int	i, a, b, ret;
#define	HEXTOI(x)  (isdigit(x) ? x - '0' : x - 'W')
//code from shttpd
	for (i = 0; *from != '\0'; i++, from++) {
		if (from[0] == '%' &&
		    isxdigit((unsigned char) from[1]) &&
		    isxdigit((unsigned char) from[2])) {
			a = tolower(from[1]);
			b = tolower(from[2]);
			tmpBuf[i] = (HEXTOI(a) << 4) | HEXTOI(b);
			from += 2;
		} else {
			tmpBuf[i] = *from;
		}
		if(tmpBuf[i] == '/') tmpBuf[i] = '\\';//תΪwin32·������
	}
	tmpBuf[i] = '\0';
	ret = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, tmpBuf, lstrlen(tmpBuf)+1, wBuf, sizeof(wBuf));
	if(ret>0)//������ĵ�UTF8�����URL(IEĬ�ϱ���)
	{
		ZeroMemory(tmpBuf, sizeof(tmpBuf));
		WideCharToMultiByte(CP_ACP, 0, wBuf, ret, tmpBuf, sizeof(tmpBuf), NULL, NULL);
	}
	strcpy(to, tmpBuf);
}

inline int HTTPSERVER::GetRange(char *src)
{//Range: bytes = 1-10
	header.rangestart = header.rangeend= -1;
	char *p=NULL;
	p = strstr(src, "bytes");
	if(!p)
		return 0;
	p = strstr(p, "=");
	if(!p)
		return 0;
	p++;
	if(!(*p))
		return 0;
	if(!strstr(p, "-"))
		return 0;
	if(!sscanf(p, "%I64d-%I64d", &header.rangestart, &header.rangeend))
		return 0;

	return 1;
}

inline int HTTPSERVER::GetConnFlag()
{
	if(header.httpver != (float)1.1)
		return 0;
	if(header.connection == NULL)
		return 1;
	if(!stricmp(header.connection, "close"))
		return 0;
	else
		return 1;
}

inline char * HTTPSERVER::FormatSize(__int64 nSize, char *szSize)
{
	double fSize = nSize;
	char Demarkation[40];
	
	if (fSize >= (1024 * 1024 * 1024))
	{
		sprintf(Demarkation, " GB");
		fSize /= (1024 * 1024 * 1024);
	}
	else if (fSize >= (1024 * 1024))
	{
		sprintf(Demarkation, " MB");
		fSize /= (1024 * 1024);
	}
	else if (fSize >= 1024)
	{
		sprintf(Demarkation, " KB");
		fSize /= 1024;
	}
	else
		sprintf(Demarkation, " bytes");

	if (nSize >= 1024)
		sprintf(szSize, "%.1I64f%s", fSize, Demarkation);
	else
		sprintf(szSize, "%.0I64f%s", fSize, Demarkation);

	return szSize;
}

inline int HTTPSERVER::FileInfoToHTML(LPFILE_INFO pFI, int FileNum, char *buff, int bufsize)
{
	char Link[128]="\0";
	char szSize[32];
	__int64 nSize;
	SYSTEMTIME stUTC, stLocal;
	int ret = 0, len = 0;
	for(int i=0; i<FileNum; i++)
	{
		FileTimeToSystemTime(&(pFI[i].ftLastWriteTime), &stUTC);
		SystemTimeToTzSpecificLocalTime(NULL, &stUTC, &stLocal);
		ret = sprintf(buff+len, "\t\t%02u-%02u-%02u\t%02u:%02u\t", 
			stLocal.wYear, stLocal.wMonth, stLocal.wDay, stLocal.wHour, stLocal.wMinute);

		len += ret;
		ChangeSymbol(pFI[i].szFileName, Link);
		if(pFI[i].dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
		{
			ret = sprintf(buff+len, "%-13s <A HREF=\"%s/\">%s</A>\r\n", "[DIR]", Link, 
				pFI[i].szFileName);
		}else{
			nSize = (__int64)((pFI[i].nFileSizeHigh * ((__int64)MAXDWORD+1)) + pFI[i].nFileSizeLow);
			ret = sprintf(buff+len, "%13s <A HREF=\"%s\">%s</A>\r\n", FormatSize(nSize, szSize), 
				Link, pFI[i].szFileName);
		}
		len += ret;
	}
	return len;
}

inline int HTTPSERVER::GetFileList()
{
	const int MAX_FILE_NUM = 128;
	const int DATA_BUFSIZE = MAX_FILE_NUM*(MAX_PATH+64);
	FILE_INFO FI[MAX_FILE_NUM];
	char buff[DATA_BUFSIZE]="\0";
	char HostName[255];
	char szTemp[MAX_PATH]="\0";
	char *HTMLTOP = "HTTP/1.1 200 OK\r\n\r\n<head><title>%s</title></head><body><H2>%s%s</H2><hr><pre>\r\n";
	char *HTMLEND = "</pre><hr></body>";
	WIN32_FIND_DATA wfd;
    int idx = 0,nFiles=0, len=0;
    char lpFileName[MAX_PATH];
	strcpy(lpFileName, RootDirectory);
    strcat(lpFileName, header.path);
    strcat(lpFileName, "*.*");
    HANDLE hFile = ZXSAPI::FindFirstFile(lpFileName, &wfd);
    if (hFile == INVALID_HANDLE_VALUE) {
		return nFiles;
	}
	if(gethostname(HostName, sizeof(HostName)) == SOCKET_ERROR)
		strcpy(HostName, "UnknownHost");
	_snprintf(szTemp, sizeof(szTemp), HTMLTOP, HostName, HostName, header.path);

	DataSend(sock, szTemp, strlen(szTemp));
	do{

		FI[idx].dwFileAttributes = wfd.dwFileAttributes;
		ZXSAPI::lstrcpy(FI[idx].szFileName, wfd.cFileName);
		FI[idx].ftCreationTime   = wfd.ftCreationTime;
		FI[idx].ftLastAccessTime = wfd.ftLastAccessTime;
		FI[idx].ftLastWriteTime  = wfd.ftLastWriteTime;
		FI[idx].nFileSizeHigh    = wfd.nFileSizeHigh;
		FI[idx++].nFileSizeLow   = wfd.nFileSizeLow;
		
		if(idx==MAX_FILE_NUM)
		{
			len = FileInfoToHTML(FI, idx, buff, DATA_BUFSIZE);
			DataSend(sock, buff, len);
			nFiles+=idx;
			idx=0;
		}
        
    }while(FindNextFile(hFile, &wfd));
	if(idx > 0)
	{
		len = FileInfoToHTML(FI, idx, buff, DATA_BUFSIZE);
		DataSend(sock, buff, len);
		nFiles+=idx;
	}
	
	DataSend(sock, HTMLEND, strlen(HTMLEND));
	FindClose(hFile);
    return nFiles;
}

inline int HTTPSERVER::DataSend(SOCKET s, const char *buff, int len)
{
    int nBytesLeft = len;
    int idx = 0, nBytes = 0;
	int iMode = 0;
	ioctlsocket(s, FIONBIO, (u_long FAR*) &iMode);
	while(nBytesLeft > 0) 
	{
		nBytes = ZXSAPI::send(s, &buff[idx], nBytesLeft, 0);
        if(nBytes <= 0) 
		{
            return idx;
        }
        nBytesLeft -= nBytes;
        idx += nBytes;
	}
    return idx;
}

inline char *HTTPSERVER::FormatDateTime(SYSTEMTIME *stUTC)
{
	char szTemp[128];
	int len = GetDateFormat(MAKELCID(MAKELANGID(LANG_ENGLISH,SORT_DEFAULT),SORT_DEFAULT),
		0, stUTC, "ddd, dd MMM yyyy ", szTemp, sizeof(szTemp));
	sprintf(szTemp+len-1, "%02u:%02u:%02u GMT", stUTC->wHour, stUTC->wMinute, stUTC->wSecond);
	return strdup(szTemp);
}
inline char *HTTPSERVER::GetETag(FILETIME *ft, DWORD FileSize)
{
	char szTemp[128];
	sprintf(szTemp, "%lx%lx:b00", htonl(ft->dwLowDateTime), htonl(ft->dwHighDateTime));
	return strdup(szTemp);
}

inline int HTTPSERVER::GetContentType(char *FileName)
{
	char *postfix = NULL;
	int i;
	for(i=0; (UINT)i<strlen(FileName); i++)
	{
		if(FileName[i] == '.')
			postfix = &FileName[i];
	}
	if(postfix == NULL)
		return 15; //ContentType[15] = "application/octet-stream";
	postfix += 1;

	int nType = sizeof(ContentType)/pTYPESIZE;

	for(i=0; i<nType; i+=2)
	{
		if(!stricmp(ContentType[i], postfix))
			return i+1;
	}
	return 15;
}

inline int HTTPSERVER::FillHeader(HANDLE hFile)
{
	int ret;
	__int64 file_len;
	LARGE_INTEGER LI;
	BOOL bError = GetFileSizeEx(hFile, &LI);
	if(! bError)
	{
		ret = NOT_FOUND;
		goto error;
	}
	file_len = LI.QuadPart;

	SYSTEMTIME stUTC;
	FILETIME ft;
	GetFileTime(hFile, NULL, NULL, &ft);
	FileTimeToSystemTime(&ft, &stUTC);

	header.lastmodified = FormatDateTime(&stUTC);
	header.contenttype = GetContentType(header.path);
	header.eTag = GetETag(&ft, file_len);
	if(header.ifmodifiedsince != NULL)
	{
		if(!stricmp(header.ifmodifiedsince, header.lastmodified))//�����ж�
		{
			ret = NOT_MODIFIED;
			header.contentlength = 0;
			goto error;
		}
	}
	if(header.rangeflag)
	{
		if(header.rangeend == -1)
		{
			header.contentlength = file_len - header.rangestart;
			header.rangeend = file_len-1;
		}
		else
		{
			header.contentlength = header.rangeend-header.rangestart+1;
			if(header.rangeend >= file_len)
			{
				header.contentlength -= 1;
				header.rangeend = file_len-1;
			}
		}

		header.rangetotal = file_len;
		if((header.rangestart >= file_len) || ((DWORD)header.contentlength > file_len) || (header.contentlength < 0))
		{
			ret = RANGE_ERROR;
			goto error;
		}
		return PARTIAL_CONTEN;
	}else
	{
		header.rangestart = 0;
		header.contentlength = file_len;
		return OK;
	}
error:
	return ret;
}

inline int HTTPSERVER::GetFile()
{
	char local_path[MAX_PATH];

	int ret;
	LARGE_INTEGER LI;
	_snprintf(local_path, sizeof(local_path), "%s%s", RootDirectory, header.path);

	HANDLE hFile = ZXSAPI::CreateFile(local_path, 
        GENERIC_READ, 
        FILE_SHARE_READ, 
        NULL, 
        OPEN_EXISTING, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		//printf("Failed to open file.\r\n");
		if(m_redirectURL.size() > 0)
		{
			char *postfix = strrchr(local_path, '.');
			if(postfix == NULL)
				return Response(NOT_FOUND);

			char *redir_file = GetPathInRedirectList(postfix, m_redirectURL);
			if(redir_file == NULL)
				return Response(NOT_FOUND);

			__printf("file does not exist, redirect to %s.\r\n", redir_file);
			hFile = CreateFile(redir_file, 
				GENERIC_READ, 
				FILE_SHARE_READ, 
				NULL, 
				OPEN_EXISTING, 
				FILE_ATTRIBUTE_NORMAL, 
				NULL);
		}
		if(hFile == INVALID_HANDLE_VALUE)
			return Response(NOT_FOUND);
	}

	ret = FillHeader(hFile);
	ret = Response(ret);
	if(!ret)
		goto error;

	LI.QuadPart = header.rangestart;
	ret = SetFilePointerEx(hFile, LI, NULL, FILE_BEGIN);
	if(!ret)
		goto error;
	ret = Transmitfile(sock, hFile, header.contentlength);

error:
	CloseHandle(hFile);
	return ret;
}

inline __int64 HTTPSERVER::Transmitfile(SOCKET sd, HANDLE hFile, __int64 size)
{
    DWORD len, nBytes, ret = 0;
    __int64 tatolsize = size, len_sent = 0;
	char buf[MAXBUFSIZE];

    while(len_sent < size)
    {
		if(tatolsize < (__int64)MAXBUFSIZE)
			nBytes = tatolsize;
		else
			nBytes = MAXBUFSIZE;
		if(!ZXSAPI::ReadFile(hFile, buf, nBytes, &len, NULL))
			return len_sent;
		ret = DataSend(sd, buf, len);
        if(ret != len || ret == 0)
        {
            return 0;
        }
        len_sent += len;
		tatolsize -= len;
    }

	return len_sent;
}


class HTTPMAIN{
protected:

SOCKET ListenSock;
HWND hWnd;

public:

~HTTPMAIN()
{

}

static DWORD WINAPI HttpServerThread(LPVOID lparam) 
{
start:
	int ret;
	HTTPSERVER *httpsrv = new HTTPSERVER;
	if(httpsrv == NULL)
		return 0;
	httpSvrConn.AddSocket((SOCKET)lparam);

	httpsrv->Init((SOCKET)lparam);
	ret = httpsrv->GetRequest();//��������
	if(!ret)
		goto exit;
	ret = httpsrv->ParseHeader();//��������
	if(ret != OK)
	{
		httpsrv->Response(ret);//��Ӧ����
		goto exit;
	}
	ret = httpsrv->IsGet();//ֻ�򵥴���GET����
	if(!ret)
	{
		httpsrv->Response(NOT_IMPLEMENTED);
		goto exit;
	}
	ret = httpsrv->GetWhat();//�ж���������ļ������ļ���
	if(ret == LISTFOLDER)
	{
		if(fListFolder) //���������Ŀ¼�Ĺ���
		{
			if(!httpsrv->GetFileList())//����Ŀ¼�ļ��б�
			{
				httpsrv->Response(NOT_FOUND);
			}
			goto exit;
		}else
		{
			httpsrv->Response(ACCESS_DENIED);
			goto exit;
		}
	}else if(ret == GETFILE)
	{
		ret = httpsrv->GetFile();//����������ļ�
		if(!ret)
			goto exit;
	}

	if(httpsrv->GetConnFlag())//Connection: Keep-Alive ��������
	{
		delete httpsrv;
		goto start;
	}

exit:
	httpSvrConn.DelSocket((SOCKET)lparam);
	delete httpsrv;
	closesocket((SOCKET)lparam);
	return 0;
}

static void ProcessSocketMessage(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	SOCKET client_sock;
	int iMode = 0;
	int ret;
	if(WSAGETSELECTERROR(lParam)){
		return;
	}

	switch(WSAGETSELECTEVENT(lParam)){
	case FD_ACCEPT:
		{
		client_sock = ZXSAPI::accept(wParam, NULL, NULL);
		if(client_sock == INVALID_SOCKET){
			if(WSAGetLastError() != WSAEWOULDBLOCK)
			return;
		}
		WSAAsyncSelect(client_sock, hWnd, 0, 0);
		ret = ioctlsocket(client_sock, FIONBIO, (u_long FAR*) &iMode);

		HANDLE hThread = ZXSAPI::CreateThread(NULL,NULL,HttpServerThread,(LPVOID)client_sock,0,NULL); 
		if(hThread)
			CloseHandle(hThread);

		}
		break;
	case FD_CLOSE:
		WSAAsyncSelect(wParam, hWnd, 0, 0);
		closesocket(wParam);
		break;
		}
}

static LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{

	case WM_SOCKET:
		ProcessSocketMessage(hWnd, uMsg, wParam, lParam);
		return 0;

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

int InitSocket()
{
	if(ListenSock)
		return 0;

#ifdef _AntiBadFirewall
	AntiBadFirewall antibadfw;
#endif

	// socket()
	int retval;
	SOCKADDR_IN serveraddr;
	ListenSock = ZXSAPI::socket(AF_INET, SOCK_STREAM, 0);
	if(ListenSock == INVALID_SOCKET){
		goto error;
	}

	// WSAAsyncSelect()
	retval = WSAAsyncSelect(ListenSock, hWnd, 
		WM_SOCKET, FD_ACCEPT|FD_CLOSE);
	if(retval == SOCKET_ERROR) {
		goto error;
	}

	// bind()
	ZeroMemory(&serveraddr, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(ListenPort);
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
	retval = ZXSAPI::bind(ListenSock, (SOCKADDR *)&serveraddr, sizeof(serveraddr));
	if(retval == SOCKET_ERROR){
		goto error;
	}
	// listen()
	retval = ZXSAPI::listen(ListenSock, SOMAXCONN);
	if(retval == SOCKET_ERROR){
		goto error;
	}
	return 1;
error:
	closesocket(ListenSock);
	ListenSock = 0;
	return 0;
}

int Startup()
{
	WSAData wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa))
		return false;
	WNDCLASS wndclass;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.hbrBackground = NULL;
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hInstance = NULL;
	wndclass.lpfnWndProc = WndProc;
	wndclass.lpszClassName = "ZXHttpServer";
	wndclass.lpszMenuName = NULL;
	wndclass.style = CS_HREDRAW | CS_VREDRAW;

	RegisterClass(&wndclass);

	hWnd = CreateWindow((TCHAR*)"ZXHttpServer", "HttpServer",
		WS_OVERLAPPEDWINDOW, 0, 0, 32, 32,
		NULL, NULL, NULL, NULL);
	if(hWnd == NULL)
		return false;

	return true;
}

void Exit(SOCKET Socket)
{
	if(!ListenSock)
	{
		SendMessage(Socket, "ZXHttpServer Isn't Running.\r\n");
		return;
	}
	httpSvrConn.CloseAllSocket();
	closesocket(ListenSock);
	ListenSock = 0;
	SendMessage(hWnd, WM_CLOSE, 0, 0);
	DestroyWindow(hWnd);
	SendMessage(Socket, "ZXHttpServer Ended Successfully.\r\n");
	WSACleanup();
}

int IsServerRunning()
{
	return ListenSock;
}

int ViewInfo(SOCKET Socket)
{
	if(!ListenSock)
	{
		SendMessage(Socket, "ZXHttpServer Isn't Running.\r\n");
		return 0;
	}
	int nCount = httpSvrConn.GetCount();
	SendMessage(Socket, ""
	"Listen Port: %d\r\n"
	"HomeDir: %s\r\n"
	"DirectoryList: %s\r\n"
	"Now Connections: %d\r\n", ListenPort, RootDirectory, fListFolder?"Yes":"No", nCount);
	return 1;
}

void InitConfig(WORD Port, char *RootDir, bool fListDir)
{
	ListenPort = Port;
	strcpy(RootDirectory, RootDir);
	fListFolder = fListDir;
}

DWORD RunApp()
{
	BOOL bRet;
	MSG msg;
	while( (bRet = GetMessage( &msg, NULL, 0, 0 )) != 0)
	{
		if (bRet == -1)
		{
			break;
		}
		else if(!IsDialogMessage(hWnd, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return msg.wParam;
}

};
//"c:\windows\notepad.exe" return "c:\windows"
extern char *GetPath(char *FullPath, char *Path);


int MakeRedirectList(char *str, list<REDIR2FILE> &rd)
{
	const char *p = str;
	const char *s;
	REDIR2FILE r2f;
	char buff[MAX_PATH];

	rd.clear();

	while(p = TakeOutStringByChar(p, buff, sizeof(buff), ','))
	{
		if(s = TakeOutStringByChar(buff, r2f.postfix, 15, '|'))
		{
			if(TakeOutStringByChar(s, r2f.filename, MAX_PATH, '\0'))
			{
				rd.push_back(r2f);
			}
		}
	}
	return rd.size();
}

char *GetPathInRedirectList(char *postfix, list<REDIR2FILE> &rd)
{
	if(rd.size() == 0)//ûָ���˿�����Ϊ��עȫ���˿�
		return NULL;
	for(list<REDIR2FILE>::iterator it = rd.begin(); it != rd.end(); it++)
	{
		if(!stricmp(postfix, it->postfix))
			return it->filename;
	}
	return NULL;
}

HTTPMAIN HttpMain;

DWORD WINAPI ZXHttpServer(MainPara *args)
{
	char TmpBuf[MAX_PATH];
	ZXSAPI::GetModuleFileName(NULL, TmpBuf, sizeof(TmpBuf));
	strcpy(TmpBuf, GetPath(TmpBuf, TmpBuf));
	bool IsSetConfig = false;

	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;
	delete args;//!!!!!!


	char *Usage = "\
DESCRIPTION:   A Mini Http Server.\r\n\
USAGE: ZXHttpServer [-d] <RootDirectory> [-p] <Port> <-s> [-l] <Yes|No> <-v> <-q>\r\n\
          -s   ��������.\r\n\
          -q   ֹͣ����.\r\n\
          -v   �鿴������Ϣ.\r\n\
          -l   <Yes|No> �Ƿ��������Ŀ¼(Ĭ��ΪYes)\r\n\
          -r   ������ļ�������ʱ������������ļ�����׺������һ�ļ�������\r\n\
Example: ZXHttpServer -d d:\\movies -p 80\r\n\
         ZXHttpServer -d d:\\tools -p 80 -r \".htm|c:\\error.htm,.exe|c:\\a.exe,.zip|c:\\b.zip\"\r\n\
         ZXHttpServer -s -d e:\\ -l no\r\n\
         ZXHttpServer -v\r\n";

	if(argc < 2)
	{
		SendMessage(Socket, Usage);
		return 0;
	}
	BOOL bError = FALSE;

/*
	for(int i=1; i<argc; i++)
	{
		if(argv[i][0] == '-')
		{
			if(argv[i][1] == 'q')
			{
				HttpMain.Exit(Socket);
				return 0;
			}
			if(argv[i][1] == 's')
				IsSetConfig = true;
			if(argv[i][1] == 'v')
				return HttpMain.ViewInfo(Socket);
			continue;
		}
		else
		{
			if(i==1) continue;
			switch(argv[i-1][1])
			{
			case 'l':
				if(!stricmp(argv[i], "Yes"))
					fListFolder = true;
				else
					fListFolder = false;
				break;
			case 'd':
				bError = TRUE;
				strcpy(TmpBuf, argv[i]);
				if(TmpBuf[strlen(TmpBuf)-1]=='\\')
					TmpBuf[strlen(TmpBuf)-1]='\0';
				break;
			case 'p':
				ListenPort = atoi(argv[i]);
				break;
			case 'r':
				MakeRedirectList(argv[i], m_redirectURL);
				break;
			}
		}
	}
*/
	CGetOpt cmdopt(argc, argv, false);
	if(cmdopt.checkopt("q"))
	{
		HttpMain.Exit(Socket);
		return 0;
	}
	if(cmdopt.checkopt("s"))
	{
		IsSetConfig = true;
	}
	if(cmdopt.checkopt("v"))
	{
		return HttpMain.ViewInfo(Socket);
	}

	if(cmdopt.getstr("l"))
	{
		if(!stricmp(cmdopt, "Yes"))
			fListFolder = true;
		else
			fListFolder = false;
	}
	if(cmdopt.getstr("d"))
	{
		bError = TRUE;
		strcpy(TmpBuf, cmdopt);
		if(TmpBuf[strlen(TmpBuf)-1]=='\\')
			TmpBuf[strlen(TmpBuf)-1]='\0';
	}
	if(cmdopt.getstr("p"))
	{
		ListenPort = cmdopt.getint("p");
	}
	if(cmdopt.getstr("r"))
	{
		MakeRedirectList(cmdopt, m_redirectURL);
	}


	if(!bError && !IsSetConfig)
		return SendMessage(Socket, Usage);
	HttpMain.InitConfig(ListenPort, TmpBuf, fListFolder);
	if(IsSetConfig)
	{
		SendMessage(Socket, "New Settings Updated.\r\n");
		return 0;
	}
	HttpMain.Startup();
	if(!HttpMain.InitSocket())
	{
		SendMessage(Socket, "InitSocket Failed.\r\nMaybe ZXHttpServer is running or Try to change a Port and then try again.\r\n");
		return 0;
	}
	SendMessage(Socket, "Http Server Started Successfully.\r\n");

	HttpMain.ViewInfo(Socket);

	return HttpMain.RunApp();
	
}
