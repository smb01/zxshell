/*
�г��������������ip
*/

DWORD ListIP(SOCKET Socket)
{
	char   HostName[256] = {0} ;  
	struct hostent* pHostent   ;
	struct in_addr  addr       ;
	int    i             = 0   ;
    
	DWORD Len = sizeof(HostName);
	GetComputerName(HostName,&Len);
	SendMessage(Socket, "Local Computer Name: %s\r\n",HostName);

	if(gethostname(HostName,256) == SOCKET_ERROR)
	{
		SendMessage(Socket, "Fail To GetHostName\r\n") ;
		return -1 ;
	}
	SendMessage(Socket, "Local Host Name: %s\r\n",HostName);

	pHostent = (struct hostent *)malloc(sizeof(struct hostent));
	pHostent = gethostbyname(HostName) ;
	while(pHostent->h_addr_list[i] != NULL)
	{
		memcpy(&addr, pHostent->h_addr_list[i], sizeof(addr));
		SendMessage(Socket, "Local IP Adress(%d): %s\r\n",i,inet_ntoa(addr));
        i++;
	}
	SendMessage(Socket, "List IP Completed\r\n");
	return 0;
}