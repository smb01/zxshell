#include "ShellList.h"
#include "..\zxsCommon\link.h"


_tagSHELL::_tagSHELL()
{
	memset(this, 0, sizeof(_tagSHELL));
}


int C_SHELLLIST::AddSocket(_tagSHELL s)
{
	EnterCriticalSection(&cs);
	int ret = Add(s);
	LeaveCriticalSection(&cs);
	return ret;
}

int C_SHELLLIST::DelSocket(SOCKET s)
{
	int ret = 0;
	EnterCriticalSection(&cs);
	_Node<_tagSHELL> *curr = Head;
	for(int n=0; n<Count; n++)
	{
		if(curr->data.Socket == s)
		{
			Delp(curr);
			ret = 1;
			break;
		}
		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);
	return ret;
}

_tagSHELL *C_SHELLLIST::IsSocketInList(SOCKET s)
{
	_tagSHELL * ret = NULL;
	EnterCriticalSection(&cs);
	_Node<_tagSHELL> *curr = Head;
	for(int n=0; n<Count; n++)
	{
		if(curr->data.Socket == s)
		{
			ret = &curr->data;
			break;
		}
		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);
	return ret;
}

DWORD C_SHELLLIST::GetParentID(SOCKET s)
{
	DWORD ret = 0;
	EnterCriticalSection(&cs);
	_Node<_tagSHELL> *curr = Head;
	for(int n=0; n<Count; n++)
	{
		if(curr->data.Socket == s)
		{
			ret = curr->data.dwID;
			break;
		}
		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);
	return ret;
}

float C_SHELLLIST::GetShellVersion(SOCKET s)
{
	float ver = 0;
	EnterCriticalSection(&cs);
	_Node<_tagSHELL> *curr = Head;
	for(int n=0; n<Count; n++)
	{
		if(curr->data.Socket == s)
		{
			ver = curr->data.ver;
			break;
		}
		curr = curr->Next;
	}
	LeaveCriticalSection(&cs);
	return ver;
}

int C_SHELLLIST::CloseAllSocket()
{
	int ret = 0;
	EnterCriticalSection(&cs);
	_Node<_tagSHELL> *curr = Head;

	for(int n=0; n<Count; n++)
	{
		shutdown(curr->data.Socket, 0x02);//SD_BOTH
		//closesocket(curr->data.Socket);
		curr = curr->Next;
		ret++;
	}
	LeaveCriticalSection(&cs);

	return ret;
}