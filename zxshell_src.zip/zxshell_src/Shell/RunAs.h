#if !defined _ZX_RUNAS_HEAD

#define _ZX_RUNAS_HEAD

#include <windows.h>
#include <stdio.h>
#include <tlhelp32.h>
#include <Shlwapi.h>
#include <AccCtrl.h>
#include <Aclapi.h>
#include <stdlib.h>
#include <tchar.h>

#include "debug.h"
#include "..\zxsCommon\CommandLineToArgvA.h"
#include "common.h"

#pragma comment(lib,"Shlwapi.lib")



#define MAX_PID_DIGITS 6

#define CheckAndLocalFree(ptr) \
            if (ptr != NULL) \
            { \
               LocalFree(ptr); \
               ptr = NULL; \
            }

BOOL __ImpersonateSystem();
BOOL ImpersonateSystem();
BOOL AdjustTokenSessionId(HANDLE *lphToken, int flag);

BOOL ModifySecurity(HANDLE hToken, DWORD dwAccess, PSECURITY_DESCRIPTOR *pOldSD);
BOOL ResetSecurity(HANDLE hToken, PSECURITY_DESCRIPTOR pSid);
BOOL BuildAdministratorsExplicitAccess(EXPLICIT_ACCESS *pExplicitAccess, DWORD dwAccess);

DWORD GetProcessId( LPCTSTR szProcName );

BOOL RunAsUser(TCHAR *lpzUser, TCHAR *lpPassword, TCHAR *lpProcessName);
BOOL RunAsPid(DWORD dwPid, TCHAR *lpProcessName);
BOOL _CreateProcessAsPid(DWORD dwPid, TCHAR *lpProcessName, int RunInThisSession, TCHAR *lpDesktop, LPPROCESS_INFORMATION lppi=NULL);
DWORD GetPIDBySessionId(LPCTSTR szProcName, DWORD sessionid);
BOOL HaveVisibleWnd(DWORD pid);

int RunAs(MainPara *args);

//ps.h
BOOL GetProcessUser(HANDLE hProc, TCHAR *szDomainName, TCHAR *szUserName, DWORD nNameLen);

class _CImpersonateSystem
{
public:
	_CImpersonateSystem();
	~_CImpersonateSystem();

};



#endif