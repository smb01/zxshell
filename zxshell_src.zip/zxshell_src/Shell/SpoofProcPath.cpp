#include "SpoofProcPath.h"
#include "ModifyCmdLine.cpp"


CSpoofProcPath::CSpoofProcPath()
{
	memset(this, 0, sizeof(CSpoofProcPath));
}

CSpoofProcPath::~CSpoofProcPath()
{

}

BOOL CSpoofProcPath::Modify()
{
	if(m_Pid == 0)
		return FALSE;

	return ModifyProcPath(m_Pid, newPath);
}

BOOL CSpoofProcPath::Restore()
{
	if(m_Pid == 0)
		return FALSE;

	return ModifyProcPath(m_Pid, oldPath);
}


//======================

AntiBadFirewall::AntiBadFirewall()
{
	IsOK = FALSE;
	m_spp.SetProcessId(GetCurrentProcessId());

	char szPath[MAX_PATH] = {0};
	int ret;

	//��ñ�����·��
	GetModuleFileName(NULL, szPath, MAX_PATH);

	m_spp.SetOldPath(szPath);

	//��ȡĬ���������·��
	ret = ReadReg(HKEY_LOCAL_MACHINE,
		"SOFTWARE\\Classes\\HTTP\\shell\\open\\command",
		"",
		szPath,
		MAX_PATH);

	if(ret == 0)
		return;

	ARGWTOARGVA arg(szPath);

	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();

	if(argc < 1)
		return;

	m_spp.SetNewPath(argv[0]);

	//�޸ı�����·��
	IsOK = m_spp.Modify();
}


AntiBadFirewall::~AntiBadFirewall()
{
	//�ָ�
	if(IsOK)
		m_spp.Restore();
}

