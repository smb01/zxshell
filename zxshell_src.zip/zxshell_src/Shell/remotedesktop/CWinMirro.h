#include <windows.h>
#include <stdio.h>
#include "..\..\zxsCommon\RDP.H"
#include "..\..\zxsCommon\rdpBuffer.h"

#pragma comment(lib, "Gdi32.lib")


//�ص�����ԭ��
/*
DataType
RDP_BITMAPINFO		0	buffer��������λͼ��Ϣͷ
RDP_UPDATESCREEN	2   buffer��������rect+DIB

��������true������false�򸸺���Ҳ����
*/
typedef int (WINAPI *MirrorCallBack)(int DataType, BYTE *buffer, int datalen, void *lParam);
typedef bool (WINAPI *_bitsmemcpy)(BYTE *dest, BYTE *src, int len, DWORD width, WORD *left, WORD *right);

bool WINAPI _memcpy1(BYTE *dest, BYTE *src, int len, DWORD width, WORD *left, WORD *right);
bool WINAPI _memcpy2(BYTE *dest, BYTE *src, int len, DWORD width, WORD *left, WORD *right);
bool WINAPI _memcpy3(BYTE *dest, BYTE *src, int len, DWORD width, WORD *left, WORD *right);
bool WINAPI _memcpy4(BYTE *dest, BYTE *src, int len, DWORD width, WORD *left, WORD *right);

typedef void (WINAPI * cbitXtoY)(void *src, void *dest, void *b434, int offset, int width);

class CWinMirror
{

protected:
	_tagRect UpdatedRect;

	_rdpBuffer bmpbuf;
	_rdpBuffer linebuf;
	_rdpBuffer rectbuf;

	_rdpBuffer c16_565_to_555_table; //16bits 565->555

	BITMAPINFO *pbiBitInfo;

	_BMPINFO BI;

	DWORD m_ScreenPixel;

	int m_PixelBits;
	int BitsPerPixel;

	int scanlinestartpos;
	
	bool bCaptureBlt;
	bool m_BmpUpdated;

	_bitsmemcpy _memcpy;
	cbitXtoY bitsXtoY;

	MirrorCallBack callbackFunc;
	void *cblParam;

	BYTE errTimes;

public:

	CWinMirror();
	~CWinMirror();

	void SetCaptureBlt(bool b){ bCaptureBlt = b;}
	int incErrTimes(){ return ++errTimes; }
	void zeroErrTimes(){ errTimes=0; }

	LPBITMAPINFO GetBmpInfo()
	{
		return pbiBitInfo;
	}
	int GetCurrentPixelBits();
	bool bBmpUpdated(){ return m_BmpUpdated;};
	int SetPixelBits(int bits);
	bool SetBitInfo(HDC hSrcDC, HDC hMemDC, HBITMAP hBitmap);

	int CaptureWindow(HWND hWnd, MirrorCallBack pURCBFunc, void *FuncParam);

private:
	int CaptureDC(HDC hSrcDC, HDC hMemDC, HBITMAP hBitmap, int startscan, int width, int height);
	int _GetDIBits(HDC hDC, HBITMAP hBitmap, BYTE *buf, LPBITMAPINFO lpBI);
	int GetUpdateRectDIB();

};
