#if !defined _RD_CURSOR
#define _RD_CURSOR

#include <windows.h>

class rd_Cursor
{
protected:
	DWORD interval;
	DWORD prevTime;
	DWORD currTime;
	POINT m_cpos;

public:
	rd_Cursor();
	~rd_Cursor();
	void SetInterval(DWORD t){ interval = t;};
	bool bPosChanged();
	bool bPosReallyChanged();
	DWORD GetCursorPos();
};

#endif