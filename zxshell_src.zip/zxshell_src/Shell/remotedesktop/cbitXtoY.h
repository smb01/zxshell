#if !defined _RA_PFUNC
#define _RA_PFUNC

#include <windows.h>

typedef unsigned char	u8;
typedef unsigned short	u16;
typedef unsigned long	u32;

u8 u8_32_to_8_grey(u32 clr);
u8 u8_16_555_to_8_grey(u16 clr);
u8 u8_16_565_to_8_grey(u16 clr);
u8 u8_32_to_8(u32 clr);
u8 u8_16_555_to_8(u16 clr);
u8 u8_16_565_to_8(u16 clr);
u8 u8_16_to_8(u32 clr);
u16 u16_565_to_555(u16 clr);
u16 u16_555_to_565(u16 clr);
void __stdcall cbit32to24(void *src, void *dest, void *b434, int offset, int width);
void __stdcall cbit32to8(void *src, void *dest, void *b434, int offset, int width);
void __stdcall cbit32to4(void *src, void *dest, void *b434, int offset, int width);
void __stdcall cbit24to8(void *src, void *dest, void *b434, int offset, int width);
void __stdcall cbit16_555_to8(void *src, void *dest, void *b434, int offset, int width);
void __stdcall cbit16_565_to8(void *src, void *dest, void *b434, int offset, int width);
void __stdcall cbit16_565to555(void *src, void *dest, void *b434, int offset, int width);
void __stdcall cbit16_565_to4(void *src, void *dest, void *b434, int offset, int width);
void __stdcall cbit16_555_to4(void *src, void *dest, void *b434, int offset, int width);
void __stdcall cbit32to16_555(void *src, void *dest, void *b434, int offset, int width);
void __stdcall pFun932100(void *src, void *dest, void *b434, int offset, int width);
void __stdcall pFun932030(void *src, void *dest, void *b434, int offset, int width);
void __stdcall pFun931fd0(void *src, void *dest, void *b434, int offset, int width);
void __stdcall pFun932150(void *src, void *dest, void *b434, int offset, int width);
void __stdcall pFun9320b0(void *src, void *dest, void *b434, int offset, int width);
void __stdcall pFun932060(void *src, void *dest, void *b434, int offset, int width);
void __stdcall bitbuf4to24(void *src, void *dest, void *b434, int height, int width);
void __stdcall bitbuf8to24(void *src, void *dest, void *b434, int height, int width);
void __stdcall bitbuf16_555_to_24(void *src, void *dest, void *b434, int height, int width);
void __stdcall bitbuf16_565_to_24(void *src, void *dest, void *b434, int height, int width);
void __stdcall bitbuf32to24(void *src, void *dest, void *b434, int height, int width);





#endif