#ifndef _JPEGENCODE_H__
#define _JPEGENCODE_H__

#include <Windows.h>



BOOL	Encode_DIBToJPEG(
						 OUT BYTE *JPEGBuf,
						 DWORD *cbSize,
						 void *lpDIB,
						 BITMAPINFO *lpBI,
						 DWORD dwWidth,
						 DWORD dwHeight,
						 int Pixelbits,
						 int iQuality
						 );


#endif