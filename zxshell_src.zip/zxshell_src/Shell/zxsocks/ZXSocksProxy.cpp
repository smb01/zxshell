// Author: LZX
// E-mail: LZX@qq.com
// Version: V1.1
// Purpose: SOCKS v4 && v5 Proxy
// Test PlatForm: WinXP SP2
// Compiled On: VC++ 6.0

#include "ZXSocksProxy.h"
#include "../shellmain.h"
#include "..\..\zxsCommon\zxsWinAPI.h"
#include ".\GetOpt.h"


///////////////////////////////////

int Authentication(SOCKET* CSsocket, char *ReceiveBuf,int DataLen)
{
	Socks5Req *sq;
	char Method[2]={0x05,0};
	sq=(Socks5Req *)ReceiveBuf;
	//printf("%d,%d,%d,%d,%d\n",sq->Ver,sq->nMethods,sq->Methods[0],sq->Methods[1],sq->Methods[2]);
	if(sq->Ver!=5)
		return sq->Ver;
	if((sq->Methods[0]==0)||(sq->Methods[0]==2))//00��������֤��01��GSSAPI��02����Ҫ�û�����PASSWORD
	{
		if(strlen(Username)==0)
			Method[1]=0x00;
		else
			Method[1]=0x02;
		if(ZXSAPI::send(CSsocket[0],Method,2,0) == SOCKET_ERROR)
			return 0;
	}else
		return 0;
	if(Method[1]==0x02)//00��������֤��01��GSSAPI��02����Ҫ�û�����PASSWORD
	{
		char USER[256];
		char PASS[256];
		memset(USER,0,sizeof(USER));
		memset(PASS,0,sizeof(PASS));
		DataLen = ZXSAPI::recv(CSsocket[0],ReceiveBuf,MAXBUFSIZE,0);
		if(DataLen == SOCKET_ERROR || DataLen == 0)
			return 0;
		AuthReq *aq=(AuthReq *)ReceiveBuf;
		if(aq->Ver!=1)
			return 0;
		if((aq->Ulen!=0)&&(aq->Ulen<=256))
			memcpy(USER,ReceiveBuf+2,aq->Ulen);
		int PLen=ReceiveBuf[2+aq->Ulen];
		if((PLen!=0)&&(PLen<=256))
			memcpy(PASS,ReceiveBuf+3+aq->Ulen,PLen);
		//printf("USER %s\nPASS %s\n",USER,PASS);
		//0=login successfully,0xFF=failure;
		if(!stricmp(Username,USER) && !strcmp(Password,PASS))
		{
			ReceiveBuf[1] = 0x00;
			//printf("Socks5 Authentication Passed\n");
		}
		else
		{
			ReceiveBuf[1] = (char)0xFF;
			//printf("Invalid Password\n");
		}
		if(ZXSAPI::send(CSsocket[0],ReceiveBuf,2,0) == SOCKET_ERROR)
			return 0;
	}
		
	return 1;
}
/*
char *GetInetIP(char *OutIP)
{
	// Get host adresses
	char addr[16];
	struct hostent * pHost; 
	pHost = gethostbyname(""); 
	for( int i = 0; pHost!= NULL && pHost->h_addr_list[i]!= NULL; i++ ) 
	{
		OutIP[0]=0;
		for( int j = 0; j < pHost->h_length; j++ ) 
		{
			if( j > 0 ) strcat(OutIP,".");
			sprintf(addr,"%u", (unsigned int)((unsigned char*)pHost->h_addr_list[i])[j]);
			strcat(OutIP,addr);
		}
	}
	return OutIP;
}

char *DNS(char *HostName)
{
	HOSTENT *hostent = NULL;
	IN_ADDR iaddr;
	hostent = gethostbyname(HostName);
	if (hostent == NULL)
	{
		return NULL;
	}
	iaddr = *((LPIN_ADDR)*hostent->h_addr_list);
	return inet_ntoa(iaddr);
}
*/
int GetAddressAndPort(char *ReceiveBuf, int DataLen, int ATYP, char *HostName, WORD *RemotePort)
{
	DWORD Socks5InfoSize = sizeof(Socks5Info); 
	DWORD dwIndex = 0;
	Socks4Req *Socks4Request=(Socks4Req *)ReceiveBuf;
	Socks5Info *Socks5Request=(Socks5Info *)ReceiveBuf; 
	struct sockaddr_in in;
	if(ATYP==2) //Socks v4 !!!
	{
		*RemotePort=ntohs(Socks4Request->wPort);
		if(ReceiveBuf[4]!=0x00)  //USERID !!
			in.sin_addr.s_addr = Socks4Request->dwIP;
		else
			in.sin_addr.s_addr = inet_addr(DNS((char*)&Socks4Request->other+1));
		memcpy(HostName, inet_ntoa(in.sin_addr),strlen(inet_ntoa(in.sin_addr)));
		return 1;
	}

	//ATYP=0x01����IP V4��ַ 0x03��������;
	if((Socks5Request->Ver==5)&&(ATYP==1))
	{
		IPandPort *IPP=(IPandPort *)&Socks5Request->IP_LEN;
		in.sin_addr.S_un.S_addr = IPP->dwIP;
		memcpy(HostName, inet_ntoa(in.sin_addr),strlen(inet_ntoa(in.sin_addr)));
		*RemotePort = ntohs(IPP->wPort);
	}
	else if((Socks5Request->Ver==5)&&(ATYP==3))
	{
		memcpy(HostName, &Socks5Request->szIP, Socks5Request->IP_LEN);
		memcpy(RemotePort, &Socks5Request->szIP+Socks5Request->IP_LEN, 2);
		*RemotePort=ntohs(*RemotePort);
	}else if((Socks5Request->Ver==0)&&(Socks5Request->CMD==0)&&(ATYP==1))
	{
		IPandPort *IPP=(IPandPort *)&Socks5Request->IP_LEN;
		in.sin_addr.S_un.S_addr = IPP->dwIP;
		memcpy(HostName, inet_ntoa(in.sin_addr),strlen(inet_ntoa(in.sin_addr)));
		*RemotePort = ntohs(IPP->wPort);
		return 10; //return Data point
	}else if((Socks5Request->Ver==0)&&(Socks5Request->CMD==0)&&(ATYP==3))
	{
		memcpy(HostName, &Socks5Request->szIP, Socks5Request->IP_LEN);
		memcpy(RemotePort, &Socks5Request->szIP+Socks5Request->IP_LEN, 2);
		*RemotePort=ntohs(*RemotePort);
		return 7+Socks5Request->IP_LEN; //return Data point
	}else
		return 0;

	return 1;

}
/*
BOOL ConnectToRemoteHost(SOCKET *ServerSocket,char *HostName,const WORD RemotePort)
{
	struct sockaddr_in Server;
	memset(&Server, 0, sizeof(Server));

	Server.sin_family = AF_INET;
	Server.sin_port = htons(RemotePort);

	if (inet_addr(HostName) != INADDR_NONE)
		Server.sin_addr.s_addr = inet_addr(HostName);
	else
	{
		if (DNS(HostName) != NULL)
			Server.sin_addr.s_addr = inet_addr(DNS(HostName));
		else //printf("Invalid Host Name\n");
			return FALSE;
	}
	// Create Socket
	*ServerSocket = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	if (*ServerSocket == INVALID_SOCKET)//printf("Fail To Create Server Socket\n");	
		return FALSE;
	
	if (connect(*ServerSocket, (const SOCKADDR *)&Server,sizeof(Server)) == SOCKET_ERROR)
	{
		//printf("Fail To Connect To Remote Host\n");
		closesocket(*ServerSocket);
		return FALSE;
	}

	return TRUE;
}*/

int TalkWithClient(SOCKET *CSsocket, char *ReceiveBuf, int DataLen, char *HostName, WORD *RemotePort)
{
	//CSsocket[0] ClientSocket
	//CSsocket[1] ServerSocket

	int Flag=0;
	//Username Password Authentication
	Flag = Authentication(CSsocket, ReceiveBuf, DataLen);
	if(Flag==0) return 0;
	if(Flag==4) //Processing Socks v4 requests......
	{//The third parameter ATYP==2 is not used for Socks5 protocol,I use it to flag the socks4 request.
		if(ReceiveBuf[1]!=0x01)  //socks4 connect command ,0x02==BIND,not support yet.
			return 0;
		if(!GetAddressAndPort(ReceiveBuf, DataLen, 2, HostName, RemotePort))
			return 0;
		return 4;
	}
	//Processing Socks v5 requests......
	DataLen = ZXSAPI::recv(CSsocket[0],ReceiveBuf,MAXBUFSIZE,0);

	if(DataLen == SOCKET_ERROR || DataLen == 0)
		return 0;
	Socks5Info *Socks5Request=(Socks5Info *)ReceiveBuf; 

	if (Socks5Request->Ver != 5) //Invalid Socks 5 Request
	{
		//printf("Invalid Socks 5 Request\n");
		return 0;
	} 
	//Get IP Type //0x01==IP V4��ַ 0x03��������;0x04����IP V6��ַ;not Support
	if((Socks5Request->ATYP==1)||(Socks5Request->ATYP==3))
	{
		if(!GetAddressAndPort(ReceiveBuf, DataLen, Socks5Request->ATYP, HostName, RemotePort))
			return 0;
	}else return 0;

	//Get and return the work mode. 1:TCP CONNECT   3:UDP ASSOCIATE
	if((Socks5Request->CMD == 1)||(Socks5Request->CMD == 3))
		return Socks5Request->CMD;	

	return 0;
}
/*
BOOL CreateUDPSocket(Socks5AnsConn *SAC, SOCKET *socks)
{
	char szIP[256];
	struct sockaddr_in 	UDPServer;
	struct sockaddr_in  in;
	memset(&in,0,sizeof(sockaddr_in));
	int structsize=sizeof(sockaddr_in);
	UDPServer.sin_family=AF_INET;
	UDPServer.sin_addr.s_addr= INADDR_ANY;
	UDPServer.sin_port=INADDR_ANY;
	SOCKET Locals = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if(Locals == SOCKET_ERROR)
	{
		//printf("UDP socket create failed.\n");
		return 0;
	}
	if(bind(Locals,(SOCKADDR*)&UDPServer, sizeof(UDPServer)) == SOCKET_ERROR)
	{
		//printf("UDP socket bind failed.\n");
		return 0;
	}
	UINT TimeOut = TIMEOUT;
	//setsockopt(Locals,SOL_SOCKET,SO_RCVTIMEO,(char *)&TimeOut,sizeof(TimeOut));
	*socks = Locals;
	getsockname(Locals,(struct sockaddr *)&in,&structsize);
	SAC->IPandPort.dwIP = inet_addr(GetInetIP(szIP));
	SAC->IPandPort.wPort = in.sin_port;
	//printf("UDP Bound to %s:%d\r\n", szIP, ntohs(in.sin_port));
	return 1;
}*/
/*
int UDPSend(SOCKET s, char *buff, int nBufSize, struct sockaddr_in *to,int tolen)
{
	int nBytesLeft = nBufSize;
	int idx = 0, nBytes = 0;
	int iMode = 0;
	ioctlsocket(s, FIONBIO, (u_long FAR*) &iMode);
	while(nBytesLeft > 0)
	{
		nBytes = sendto(s, &buff[idx], nBytesLeft, 0, (SOCKADDR *)to, tolen);
		if(nBytes == SOCKET_ERROR) 
		{
			//printf("Failed to send buffer to socket %d.\r\n", WSAGetLastError());
			return SOCKET_ERROR;
		}
		nBytesLeft -= nBytes;
		idx += nBytes;
	}
	return idx;
}
*/

void UDPTransfer(Socks5Para *sPara)////////////////!!!!!!!!!!!!!!!!
{
	struct	sockaddr_in SenderAddr;
	int		SenderAddrSize=sizeof(SenderAddr),DataLength=0,result;
	char	Buffer[MAXBUFSIZE+10];
	char *RecvBuf = Buffer+10;

	struct sockaddr_in 	UDPClient,UDPServer;
	memset(&UDPClient,0,sizeof(sockaddr_in));
	memset(&UDPServer,0,sizeof(sockaddr_in));

	UDPClient.sin_family = AF_INET;
	UDPClient.sin_addr.s_addr = sPara->Client.IPandPort.dwIP;
	UDPClient.sin_port = sPara->Client.IPandPort.wPort;
	/*//test
	Socks5UDPHead test;
	memset(&test,0,sizeof(Socks5UDPHead));
	test.RSV[0]=0x05;
	test.ATYP=0x01;
	test.IPandPort=sPara->Local.IPandPort;
	if(sendto(sPara->Local.socks,(char*)&test, 10,0,(struct sockaddr FAR *)&UDPClient,sizeof(UDPClient)) == SOCKET_ERROR)
	{
		printf("test sendto server error.\n");
		return;
	}*/
	//printf("UDPTransfer thread start......\n");

	fd_set readfd;
	while(1)
	{
		FD_ZERO(&readfd);
		FD_SET((UINT)sPara->Local.socks, &readfd);
		result=select(sPara->Local.socks+1,&readfd,NULL,NULL,NULL);
		if(result<=0)
		{
			//printf("Select error.\r\n");
			break;
		}
		if(FD_ISSET(sPara->Local.socks, &readfd))
		{

		DataLength=ZXSAPI::recvfrom(sPara->Local.socks, 
			RecvBuf, MAXBUFSIZE, 0, (struct sockaddr FAR *)&SenderAddr, &SenderAddrSize);
		if(DataLength <= 0)
		{
			//printf("UDPTransfer recvfrom error.\n");
			break;
		}
//printf("Data come from IP: %s:%d | %d Bytes.\n",
//	   inet_ntoa(SenderAddr.sin_addr),ntohs(SenderAddr.sin_port),DataLength);
//SenderAddr.sin_addr.s_addr==sPara->Client.IPandPort.dwIP&&
		if(SenderAddr.sin_port==sPara->Client.IPandPort.wPort)//Data come from client
		{
			//////����Ҫ���޸�udp���ݱ�ͷ
			WORD	RemotePort = 0;
			char	HostName[MAX_HOSTNAME];
			memset(HostName,0,MAX_HOSTNAME);
			int DataPoint=GetAddressAndPort(RecvBuf, DataLength, RecvBuf[3], HostName, &RemotePort);
			if(DataPoint)
			{
				//printf("Data come from client IP: %s:%d | %d Bytes.\n",
				//	inet_ntoa(SenderAddr.sin_addr),ntohs(SenderAddr.sin_port),DataLength);
				//send data to server
				//printf("IP: %s:%d || DataPoint: %d\n",HostName,RemotePort,DataPoint);
				//��¼��client���ݷ����ĵ�ַ��Ϣ
				UDPServer.sin_family=AF_INET;
				UDPServer.sin_addr.s_addr= inet_addr(DNS(HostName));
				UDPServer.sin_port=htons(RemotePort);

				if(RecvBuf[2] == 0)//FRAG ����û֧��SOCKS��Ƭ������Ƭ�Ļ�������
				{
					result=UDPSend(sPara->Local.socks,RecvBuf+DataPoint, DataLength-DataPoint,UDPServer.sin_addr.s_addr,RemotePort);
					if(result <= 0)
					{
						//printf("sendto server error\n");
						break;
					}
				}
				//printf("Data(%d) sent to server succeed.|| Bytes: %d\n",DataLength-DataPoint,result);
			}else break;
		}else if(SenderAddr.sin_port==UDPServer.sin_port)//Data come from server
		{//SenderAddr.sin_addr.s_addr==UDPServer.sin_addr.s_addr&&
			//send data to client
			//printf("Data come from server IP: %s:%d | %d Bytes.\n",
			//	inet_ntoa(SenderAddr.sin_addr),ntohs(SenderAddr.sin_port),DataLength);
			Socks5UDPHead *UDPHead = (Socks5UDPHead*)Buffer;
			memset(UDPHead,0,10);
			UDPHead->ATYP=0x01;
			UDPHead->IPandPort=sPara->Client.IPandPort;
			//UDPHead->IPandPort.dwIP =SenderAddr.sin_addr.s_addr;
			//UDPHead->IPandPort.wPort=SenderAddr.sin_port;
			//memcpy(&UDPHead->DATA-2,RecvBuf,DataLength);//UDPHead->DATA-2!!!!!!!!!!!!

			result=UDPSend(sPara->Local.socks,(char*)UDPHead,DataLength+10,UDPClient.sin_addr.s_addr,ntohs(UDPClient.sin_port));
			if(result <= 0)
			{
				//printf("sendto client error\n");
				break;
			}
			//printf("Data(%d) sent to client succeed.|| Bytes: %d\n",DataLength+10,result);
		}else
		{
			//printf("!!!!!The data are not from client or server.drop it.\n");
		}
		}
		//Sleep(5);
	}
	closesocket(sPara->Local.socks);
	closesocket(sPara->Client.socks);
}
DWORD WINAPI ZXSocksProxyThread(SOCKET* CSsocket)
{
	InterlockedExchangeAdd(&ConnCount, 1);
	ProxyConn.AddSocket(CSsocket[0]);
	DWORD  dwThreadID;
	static int t=0;
	WORD   RemotePort = 0;
	char *HostName = (char*)malloc(sizeof(char)*MAX_HOSTNAME);
	char *ReceiveBuf = (char*)malloc(sizeof(char)*MAXBUFSIZE);
	Socks4Req Socks4Request;
	Socks5AnsConn SAC;
	memset(HostName,0,MAX_HOSTNAME);
	memset(ReceiveBuf,0,MAXBUFSIZE);
	memset(&SAC,0,10);
	/////////////////////////UDP variable
	Socks5Para sPara;
	struct sockaddr_in in;
	memset(&sPara,0,sizeof(Socks5Para));
	memset(&in,0,sizeof(sockaddr_in));
	int structsize=sizeof(sockaddr_in);
	////////////////////////
	int DataLen = 0,Flag = 0,ProtocolVer=0;
	DataLen = ZXSAPI::recv(CSsocket[0],ReceiveBuf,MAXBUFSIZE,0);
	if(DataLen == SOCKET_ERROR || DataLen == 0)
		goto error;

	//Э�̣��ɹ��Ļ�HostName:RemotePortΪ������Ŀ��
	Flag=TalkWithClient(CSsocket, ReceiveBuf, DataLen, HostName, &RemotePort);
	if(!Flag)
	{
		SAC.Ver=0x05;
		SAC.REP=0x01;
		SAC.ATYP=0x01;
		ZXSAPI::send(CSsocket[0], (char *)&SAC, 10, 0);
		goto error;
	}
	else if(Flag==1)  //TCP CONNECT
	{
		if(!(SocksVer & PROVER5))
			goto error;
		ProtocolVer=5;
		if(!(CSsocket[1] = ConnectHost(HostName,RemotePort)))
			SAC.REP=0x01;
		SAC.Ver=5;
		SAC.ATYP=1;
		if(ZXSAPI::send(CSsocket[0], (char *)&SAC, 10, 0) == SOCKET_ERROR)
			goto error;
		if(SAC.REP==0x01) // general SOCKS server failure
			goto error;
	}
	else if(Flag==3)  //UDP ASSOCIATE
	{
		if(!(SocksVer & PROVER5))
			goto error;		
		//ProcessingUDPsession;
		ProtocolVer=5;
		//Save the client connection information(client IP and source port)
		getpeername(CSsocket[0],(struct sockaddr *)&in,&structsize);
		if(inet_addr(HostName)==0)
			sPara.Client.IPandPort.dwIP = in.sin_addr.s_addr;
		else
			sPara.Client.IPandPort.dwIP = inet_addr(DNS(HostName));
		sPara.Client.IPandPort.wPort= htons(RemotePort);/////////////////
		sPara.Client.socks=CSsocket[0];

		//UDP�����贴��������udp�׽��֣����ظ����ĸ�֪����IP�Ͷ˿�
		//if(!CreateUDPSocket(&SAC, &sPara.Local.socks)) //Create a local UDP socket
		if(!(sPara.Local.socks = CreateUDPSocket(&SAC.IPandPort.dwIP, &SAC.IPandPort.wPort))) //Create a local UDP socket
			SAC.REP=0x01;
		SAC.Ver=5;
		SAC.ATYP=1;
		//�ظ�����
		if(ZXSAPI::send(CSsocket[0], (char *)&SAC, 10, 0) == SOCKET_ERROR)
			goto error;
		if(SAC.REP==0x01) // general SOCKS server failure
			goto error;
		
		sPara.Local.IPandPort=SAC.IPandPort; //Copy local UDPsocket data structure to sPara.Local
		////// Create UDP Transfer thread
		HANDLE ThreadHandle = ZXSAPI::CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)UDPTransfer,(LPVOID)&sPara,0,&dwThreadID);
		if (ThreadHandle != NULL)
		{
			//printf("Socks%d UDP Session-> %s:%d\n",ProtocolVer,inet_ntoa(in.sin_addr),ntohs(sPara.Client.IPandPort.wPort));
			//////UDPTransfer �ڼ�������recv����TCP�Ự��״̬����ʱ��Ӧ�������ݽ���
			ZXSAPI::recv(CSsocket[0], ReceiveBuf, 1, 0);//���TCP close��ôrecv����,udpת������
			closesocket(sPara.Local.socks);
			//////
			WaitForSingleObject(ThreadHandle, INFINITE);
			CloseHandle(ThreadHandle);
			//printf("Thread %d Exit.!!!!!!!!!!!!\n",t++);
		}
		////////////////////
	}
	else if(Flag==4)  // Socks v4! I use the return value==4 to flag the Socks v4 request.
	{
		if(!(SocksVer & PROVER4))
			goto error;
		//printf("%s:%d\n",HostName,RemotePort);
		ProtocolVer=4;
		memset(&Socks4Request, 0, 9);
		if(!(CSsocket[1] = ConnectHost(HostName,RemotePort)))
			Socks4Request.REP = 0x5B; //REJECT
		else
			Socks4Request.REP = 0x5A; //GRANT
		if(ZXSAPI::send(CSsocket[0], (char *)&Socks4Request, 8, 0) == SOCKET_ERROR)
			goto error;
		if(Socks4Request.REP==0x5B)   //Connect To Remote Host failed,closesocket and free some point.
			goto error;
	}else
		goto error;

	if(CSsocket[0] && CSsocket[1])
	{
		//printf("Socks%d TCP Session-> %s:%d\n",ProtocolVer,HostName,RemotePort);
		TransmitData((LPVOID)CSsocket);
	}
error:
	ProxyConn.DelSocket(CSsocket[0]);
	closesocket(CSsocket[0]);
	closesocket(CSsocket[1]);
	free(CSsocket);
	free(HostName);
	free(ReceiveBuf);
	InterlockedExchangeAdd(&ConnCount, -1);
	return 0;
}

/*
int DataSend(SOCKET s, const char *buff, int nBufSize)
{
    int nBytesLeft = nBufSize;
    int idx = 0, nBytes = 0;
	int iMode = 0;
	ioctlsocket(s, FIONBIO, (u_long FAR*) &iMode);
	while(nBytesLeft > 0) 
	{
		nBytes = send(s, &buff[idx], nBytesLeft, 0);
        if(nBytes <= 0) 
		{
            return idx;
        }
        nBytesLeft -= nBytes;
        idx += nBytes;
	}
    return idx;
}

DWORD TransmitData(LPVOID lparam)
{
	SOCKET *psock = (SOCKET*)lparam;
	SOCKET ClientSock = psock[0];
	SOCKET ServerSock = psock[1];
	char RecvBuf[MAXBUFSIZE];
	int nRecv=0, nSent=0;
	int Result;
	fd_set FdRead;

	while(1)
	{
		FD_ZERO(&FdRead);

		FD_SET(ClientSock,&FdRead);
		FD_SET(ServerSock,&FdRead);
		Result = select(0, &FdRead, NULL, NULL, NULL);
		if(Result <= 0)
			return 0;
		if(FD_ISSET(ServerSock, &FdRead))
		{
			nRecv = recv(ServerSock, RecvBuf, MAXBUFSIZE, 0);
			if(nRecv <= 0)
				return 0;
			else
			{
				nSent = DataSend(ClientSock, RecvBuf, nRecv);
				if(nSent != nRecv)
					return 0;
			}
		}
		if(FD_ISSET(ClientSock, &FdRead))
		{
			nRecv = recv(ClientSock, RecvBuf, MAXBUFSIZE, 0);
			if(nRecv <= 0)
				return 0;
			else
			{
				nSent = DataSend(ServerSock, RecvBuf, nRecv);
				if(nSent != nRecv)
					return 0;
			}
		}
	}

	return 0;
}

*/

int InitSocket()
{
#ifdef _AntiBadFirewall
	AntiBadFirewall antibadfw;
#endif

	WSADATA WSAData;
	if(WSAStartup(MAKEWORD(2,2), &WSAData))
		return 0;

	struct sockaddr_in Server={0};

	ProxyServer = ZXSAPI::socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if(ProxyServer == INVALID_SOCKET)
		goto error;


	Server.sin_family = AF_INET;
	Server.sin_port = htons(LisPort);
	Server.sin_addr.S_un.S_addr = INADDR_ANY;

	if(ZXSAPI::bind(ProxyServer, (LPSOCKADDR)&Server, sizeof(Server)) == SOCKET_ERROR)
		goto error;

	if(ZXSAPI::listen(ProxyServer, DEFLISNUM) == SOCKET_ERROR)
		goto error;
	return 1;
error:
	closesocket(ProxyServer);
	ProxyServer = 0;
	return 0;
}

int Run()
{
	//printf("Socks Proxy V1.2 By LZX.\r\n");
	SOCKET AcceptSocket = INVALID_SOCKET;
	SOCKET *CSsocket;
	DWORD  dwThreadID;
	int iMode = 1, block = 0;//nonzero
	ioctlsocket(ProxyServer, FIONBIO, (u_long FAR*) &iMode);//Enabled Nonblocking Mode

	fd_set FdRead;
	while(1)
	{
		FD_ZERO(&FdRead);
		FD_SET(ProxyServer,&FdRead);
		if(select(0, &FdRead, NULL, NULL, NULL) <= 0)
			break;
		AcceptSocket = ZXSAPI::accept(ProxyServer, NULL, NULL);
		if(! IP_Filter(AcceptSocket, allowIP, denyIP))
		{
			closesocket(AcceptSocket);
			continue;
		}
		ioctlsocket(AcceptSocket, FIONBIO, (u_long FAR*) &block);
		//printf("Accepting New Requests: %d\n", AcceptSocket);
		CSsocket = (SOCKET*)malloc(sizeof(SOCKET)*2);
		if (CSsocket == NULL)
			continue;
		CSsocket[0] = AcceptSocket;
		CSsocket[1] = 0;
		HANDLE hThread = ZXSAPI::CreateThread (NULL,0, (LPTHREAD_START_ROUTINE)ZXSocksProxyThread,CSsocket,0, &dwThreadID);        // Create Thread To Handle Request
		CloseHandle(hThread);
	}
	while(ConnCount > 0)
		Sleep(500);
	ProxyServer = 0;
	return 0;
}

int SocksProxyQuit(SOCKET ClientSock)
{
	if(!ProxyServer)
	{
		SendMessage(ClientSock, "Proxy Service Isn't Running.\r\n");
		return 0;
	}
	ProxyConn.CloseAllSocket();
	closesocket(ProxyServer);
	SocksVer = 0;
	memset(allowIP, 0, sizeof(allowIP));
	memset(denyIP, 0, sizeof(denyIP));
	strcpy(Username, "zx");
	strcpy(Password, "hello");
	WSACleanup();
	SendMessage(ClientSock, "Proxy Service Ended Successfully.\r\n");
	return 0;
}

BOOL IsSocksProxyRunning()
{
	return (ProxyServer);
}

int ViewSocksProxyInfo(char *buf)
{
	if(!IsSocksProxyRunning())
		return sprintf(buf, "ZXSocksProxy Service Isn't Running.\r\n");
	sprintf(buf, ""
		"Listen Port: %d\r\n"
		"SocksVer: %s%s\r\n"
		"Allowed IP: %s\r\n"
		"Denied IP: %s\r\n"
		"Username: %s\r\n"
		"Password: %s\r\n"
		"Now Connections: %d\r\n",
		LisPort, 
		(SocksVer&PROVER4)?"4 ":"",
		(SocksVer&PROVER5)?"5":"",
		allowIP, denyIP, Username, Password, ConnCount);
	return 1;
}

int ZXSOCKSPROXY_Usage(SOCKET ClientSock)
{
	char tmp[8192];
	sprintf(tmp, "\
ZXSockProxy V1.2.\r\n\
Usage:\r\n\
      ZXSockProxy [-b] <Port> [-u] <Username> [-p] <Password> [-e] <SocksVer> [-a] <allowIP> [-d] <denyIP> [-q]\r\n\
\r\n\
Example:\r\n\
      ZXSockProxy -b 1080 -e 4 -a 61.8.8.*,202.96.* -d 202.96.4.*\r\n\
      ZXSockProxy -b 1080 -e 45 -d 61.8.8.13-61.8.9.28\r\n\
      ZXSockProxy -b 1080 -e 45 -u zx -p hi (All IP Is Acceptable.)\r\n\
      ZXSockProxy -v (View SocksProxy Server Info)\r\n\
      ZXSockProxy -q (End Proxy Service.)\r\n\
");

	//printf("%s", tmp);
	SendMessage(ClientSock, tmp);
	return 0;
}

//int main(int argc, char **argv)
DWORD WINAPI ZXSockProxy(MainPara *args)
{
	SOCKET ClientSock = args->Socket;

	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	delete args;


	if(argc < 2)
		return ZXSOCKSPROXY_Usage(ClientSock);
/*	for(int i=1; i<argc; i++)
	{
		if(argv[i][0] == '-' || argv[i][0] == '/')
		{
			if(argv[i][1] == 'q')
				return SocksProxyQuit(ClientSock);
			else if(argv[i][1] == 'v')
			{
				ViewSocksProxyInfo(Temp);
				return SendMessage(ClientSock, Temp);
			}
			else
				continue;
		}
		else
		{
			if(IsSocksProxyRunning())
				return SendMessage(ClientSock, "ZXSocksProxy Service Is Running.\r\n");
			if(i==1) continue;
			switch(argv[i-1][1])
			{
			case 'a':
				strcpy(allowIP, argv[i]);
				break;
			case 'd':
				strcpy(denyIP, argv[i]);
				break;
			case 'b':
				LisPort = atoi(argv[i]);
				break;
			case 'u':
				strcpy(Username, argv[i]);
				break;
			case 'p':
				strcpy(Password, argv[i]);
				break;
			case 'e':
				if(strstr(argv[i], "4"))
					SocksVer |= PROVER4;
				if(strstr(argv[i], "5"))
					SocksVer |= PROVER5;
				break;
			default:
				return ZXSOCKSPROXY_Usage(ClientSock);
			}
		}
	}
*/
///////////////////////���������в���
	CGetOpt cmdopt(argc, argv, false);

	if(cmdopt.checkopt("q"))
		return SocksProxyQuit(ClientSock);
	if(cmdopt.checkopt("v"))
	{
		ViewSocksProxyInfo(Temp);
		return SendMessage(ClientSock, Temp);
	}

	if(IsSocksProxyRunning())
		return SendMessage(ClientSock, "ZXSocksProxy Service Is Running.\r\n");

	if(cmdopt.getstr("a"))
	{
		strcpy(allowIP, cmdopt);
	}
	if(cmdopt.getstr("d"))
	{
		strcpy(denyIP, cmdopt);
	}

	LisPort = cmdopt.getint("b");

	if(cmdopt.getstr("u"))
	{
		strcpy(Username, cmdopt);
	}
	if(cmdopt.getstr("p"))
	{
		strcpy(Password, cmdopt);
	}
	if(cmdopt.getstr("e"))
	{
		if(strstr(cmdopt, "4"))
			SocksVer |= PROVER4;
		if(strstr(cmdopt, "5"))
			SocksVer |= PROVER5;
	}

///////////////////////

	if(LisPort == 0 || SocksVer == 0)
		return ZXSOCKSPROXY_Usage(ClientSock);
	if(!InitSocket())
	{
		//printf("InitSocket Failed. Try to change a Port and then try again.\r\n");
		SendMessage(ClientSock, "InitSocket Failed.\r\nTry to change a Port and then try again.\r\n");
		return 0;
	}
	//printf("Now listening on port: %d\r\n",LisPort);
	SendMessage(ClientSock, "ZXSocksProxy Started Successfully.\r\n");
	ViewSocksProxyInfo(Temp);
	SendMessage(ClientSock, Temp);
	return Run();
}