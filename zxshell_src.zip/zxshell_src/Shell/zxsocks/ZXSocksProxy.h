#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <winsock2.h> 
#include <windows.h> 
#include <errno.h>
#include "zxsockstlib.h"
#include "..\..\zxsCommon\zxsWinAPI.h"

#pragma comment(lib,"ws2_32.lib") 


extern BOOL IP_Filter(SOCKET s, const char *AllowedIP, const char *DeniedIP);
extern BOOL Is_IP_in_range(char *sourceIP, char *destIP);
extern BOOL Is_dwIP_in_range(char *sourceIP, char *destIP);

BOOL ConnectToRemoteHost(SOCKET *ServerSocket,char *HostName,const WORD RemotePort);
BOOL CreateUDPSocket(Socks5AnsConn *SAC, SOCKET *socks);
DWORD TransmitData(LPVOID lparam);
DWORD WINAPI ZXSocksProxyThread(SOCKET* CSsocket);
char *DNS(char *HostName);
char *GetInetIP(char *OutIP);
int Authentication(SOCKET* CSsocket, char *ReceiveBuf,int DataLen);
int DataSend(SOCKET s, const char *buff, int nBufSize);
int GetAddressAndPort(char *ReceiveBuf, int DataLen, int ATYP, char *HostName, WORD *RemotePort);
int InitSocket();

int Run();
int TalkWithClient(SOCKET *CSsocket, char *ReceiveBuf, int DataLen, char *HostName, WORD *RemotePort);
int UDPSend(SOCKET s, char *buff, int nBufSize, struct sockaddr_in *to,int tolen);

int SocksProxyQuit(SOCKET ClientSock);
void UDPTransfer(Socks5Para *sPara);////////////////!!!!!!!!!!!!!!!!
