#include "..\..\zxsCommon\link.h"
#include "..\common.h"
#include "..\..\zxsCommon\SocketList.h"
#include "..\..\zxsCommon\zxsWinAPI.h"

#define MAX_HOSTNAME	256
#define LISTENPORT		1080
#define DEFLISNUM		50
#define MAXBUFSIZE		8192
#define TIMEOUT			10000

#define PROVER4 1
#define PROVER5 2


long ConnCount;
int LisPort;
char allowIP[1024*4];
char denyIP[1024*4];
char Username[256]="zx";
char Password[256]="hello";
DWORD SocksVer = 0;

SOCKET ProxyServer;

C_SOCKETLIST ProxyConn;

#pragma pack(push, 1)//ȡ���ڴ��С�Զ�����


struct Socks4Req
{
    BYTE Ver;
    BYTE REP;
    WORD wPort;
    DWORD dwIP;
    BYTE other;
};

struct Socks5Req
{
    BYTE Ver;
    BYTE nMethods;
    BYTE Methods[255];
};

struct AuthReq
{
    BYTE Ver;
    BYTE Ulen;
    BYTE UserPass[1024];
};

typedef struct 
{
	BYTE Ver;      // Version Number 
	BYTE CMD;      // 0x01==TCP CONNECT,0x02==TCP BIND,0x03==UDP ASSOCIATE
	BYTE RSV;
	BYTE ATYP; 
	BYTE IP_LEN;
	BYTE szIP;
}Socks5Info;

typedef struct 
{ 
	DWORD dwIP;
	WORD wPort;
}IPandPort;

typedef struct 
{ 
	BYTE Ver;
	BYTE REP;      
	BYTE RSV;
	BYTE ATYP; 
	IPandPort IPandPort;
}Socks5AnsConn;

typedef struct 
{ 
	BYTE RSV[2];
	BYTE FRAG;      
	BYTE ATYP;
	IPandPort IPandPort;
	BYTE DATA;
}Socks5UDPHead;
struct SocketInfo
{
	SOCKET socks;
	IPandPort IPandPort;
};
typedef struct 
{
	SocketInfo Local;
	SocketInfo Client;
	SocketInfo Server;
}Socks5Para;

#pragma pack(pop)

/*
��Source�ַ�������ָ��char�ֶ�д�絽Dest�������С�
����ֵΪSource�е���һ���ε����ָ��
��:
Source = "1234  , 321, 43,333"
Dest���õ� "1234"
����ָ��ָ��" 321, 43,333"
*/
/*
const char *TakeOutStringByChar(IN const char *Source, OUT char *Dest, int buflen, char ch)
{
	if(Source == NULL)
		return NULL;

	const char *p = strchr(Source, ch);

	while(*Source == ' ')
		Source++;
	for(int i=0; i<buflen && *(Source+i) && *(Source+i) != ch; i++)
	{
		Dest[i] = *(Source+i);
	}
	if(i == 0)
		return NULL;
	else
		Dest[i] = '\0';

	const char *lpret = p ? p+1 : Source+i;

	while(Dest[i-1] == ' ' && i>0)
		Dest[i---1] = '\0';

	return lpret;
}



//destIP = "22.22.22.1-22.22.*"
BOOL Is_szIP_in_range(char *sourceIP, char *destIP)
{
	BOOL flag = TRUE;
	char *sip = sourceIP;
	char *dip = destIP;
	while(sip && dip)
	{
		if(*dip == '*')
			break;
		if(*sip != *dip)
		{
			flag = FALSE;
			break;
		}
		if(*sip =='\0' && *dip == '\0')
			break;
		sip++;
		dip++;
	}
	return flag;
}

//destIP = "22.22.22.1-22.22.22.7"
BOOL Is_dwIP_in_range(char *sourceIP, char *destIP)
{
	const char *nextip;
	char startip[32], endip[32];

	nextip = TakeOutStringByChar(destIP, startip, sizeof(startip), '-');

	if(nextip)
		TakeOutStringByChar(nextip, endip, sizeof(endip), NULL);
	else
		return FALSE;

	DWORD dwIP, srcIP, IP_start, IP_end;

	dwIP = inet_addr(sourceIP);
	if(dwIP == INADDR_NONE)
		return FALSE;

	srcIP = ntohl(dwIP);

	dwIP = inet_addr(startip);
	if(dwIP == INADDR_NONE)
		return FALSE;

	IP_start = ntohl(dwIP);

	dwIP = inet_addr(endip);
	if(dwIP == INADDR_NONE)
		return FALSE;

	IP_end = ntohl(dwIP);

	if(srcIP >= IP_start && srcIP <= IP_end)
		return TRUE;
	else
		return FALSE;
}

BOOL Is_IP_in_range(char *sourceIP, char *destIP)
{
	if(strchr(destIP, '-'))//example: xx.xx.xx.1-xx.xx.xx.5
	{
		if(Is_dwIP_in_range(sourceIP, destIP))
			return TRUE;
		else
			return FALSE;
	}else//example: 202.96.*
	{
		if(Is_szIP_in_range(sourceIP, destIP))
			return TRUE;
		else
			return FALSE;
	}
}

BOOL IP_Filter(SOCKET s, const char *AllowedIP, const char *DeniedIP)
{
	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(clientaddr);
	if(getpeername(s, (SOCKADDR *)&clientaddr, &addrlen) == SOCKET_ERROR)
		return FALSE;
	IN_ADDR iaddr = clientaddr.sin_addr;
	char *IP = inet_ntoa(iaddr);
	char filterIP[64] = {0};
	BOOL IsAllowed;
	const char *p;
	p = TakeOutStringByChar(AllowedIP, filterIP, sizeof(filterIP), ',');
	if(p)
		IsAllowed = FALSE;
	else
		IsAllowed = TRUE;
	while(p)
	{
		if(Is_IP_in_range(IP, filterIP))
		{
			IsAllowed = TRUE;
			break;
		}
		p = TakeOutStringByChar(p, filterIP, sizeof(filterIP), ',');
	}
	p = DeniedIP;
	while(p = TakeOutStringByChar(p, filterIP, sizeof(filterIP), ','))
	{
		if(Is_IP_in_range(IP, filterIP))
			return FALSE;
	}
	return IsAllowed;
}*/

