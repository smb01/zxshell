#if !defined _REMOTECAP

#define _REMOTECAP

#include <winsock2.h>
#include <windows.h>
#include <stdio.h>
#include <Vfw.h>

#include "..\..\zxsCommon\debugoutput.h"
#include "..\..\zxsCommon\rdpBufferEncodeZlib.h"
#include "..\..\zxsCommon\RDP.h"
#include "..\..\zxsCommon\CSocketData.h"
#include "..\..\zxsCommon\CSpeedTest.h"
#include "..\..\zxsCommon\CAPP.h"

#if defined _ZXSHELL
#pragma comment(lib, "../zxsCommon/zlib/zlib.lib")
#else
#pragma comment(lib, "../../zxsCommon/zlib/zlib.lib")
#endif

#pragma comment(lib, "Vfw32.lib")

#pragma pack(push, 1)


typedef struct _CAPDRV
{
	int bExisted;
	char szDeviceName[80];
	char szDeviceVersion[80];
	_CAPDRV()
	{
		memset(this, 0, sizeof(struct _CAPDRV));
	}
}CAPDRV;

class capDevicesCount
{
public:
	int CapDevCount;
	capDevicesCount()
	{
		CapDevCount = GetCapDevCount();
	}

	int GetCapDevCount();
	int GetCount(){ return CapDevCount;};

};

class capDrvDes
{
protected:
	int idx;
	int capIndex;
public:
	CAPDRV capDrv[10];
public:
	capDrvDes();
	int init();
	int GetIndex(){ return capIndex;}
	CAPDRV * GetNextDriver();


};


#pragma pack(pop)

typedef int (WINAPI *MirrorCallBack)(int DataType, BYTE *buffer, int datalen, void *lParam);


class CRemoteCap
{
protected:
	int nCapDrv;

	HWND hWndVideo;

	_rdpBuffer bmpbuf;
	BITMAPINFO *pbiBitInfo;
	_BMPINFO BI;
	bool m_BmpUpdated;
	bool capInit;

	MirrorCallBack callbackFunc;
	void *cblParam;

public:
	CRemoteCap();
	~CRemoteCap();

	capDrvDes capDrivers;
	int EnumDev();

	int GetCapDrvCount(){ return nCapDrv;}
	int GetCurrentPixelBits();
	bool bBmpUpdated(){ return m_BmpUpdated;};

	int InitCapDevice(int idx);
	static LRESULT _capFrameCallBack(HWND hWnd, LPVIDEOHDR lpVHdr);
	static LRESULT _capErrorCallBack(HWND hWnd, int nID, LPCSTR lpsz);
	LRESULT capFrameCallBack(HWND hWnd, LPVIDEOHDR lpVHdr);
	LRESULT capErrorCallBack(HWND hWnd, int nID, LPCSTR lpsz);

	int GetFrame(MirrorCallBack pURCBFunc, void *FuncParam);
	int CaptureStop();

};








#endif