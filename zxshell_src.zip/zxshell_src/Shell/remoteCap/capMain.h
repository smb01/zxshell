
#include <winsock2.h>
#include <windows.h>
#include <stdio.h>
#include "remoteCap.h"
#include "..\remotedesktop\sock.h"

#define CAPPVERSION (float)1.0

class CAPMAIN
{
protected:
	SOCKET m_socket;

	_tagRDPHEAD rdph;

	int comprAutoSel;
	int m_comprLevel;
	_rdpBuffer zbmpbuf;

	CSocketData sockdata;
	CSpeedTest speedtest;

	CRemoteCap rCap;
	bool runFlag;

public:
	CAPMAIN(SOCKET s);
	~CAPMAIN();

	static int WINAPI capUpdate(int DataType, BYTE *buffer, int datalen, void *lParam);
	int WINAPI capUpdate(int DataType, BYTE *buffer, int datalen);
	BOOL ReadAction();

	int go();

	static DWORD WINAPI capServer(LPVOID lParam);
};